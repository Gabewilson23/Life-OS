# Next steps

1. **Deploy** following `docs/DEPLOY.md` (GitHub → Supabase migrate → Netlify env → `/setup` → MFA).
2. **Add `ANTHROPIC_API_KEY`** and run the acceptance checklist (`docs/ACCEPTANCE_CHECKLIST.md`); set `MODEL_PRICE_*` for cost tracking.
3. **Connect Google** (personal + each company) and live-verify: event create/verify/revoke, Gmail draft. Record results in IMPLEMENTATION_STATUS.md.
4. **Onboarding data**: confirm the Atlas Consulting model (Settings), import recruits/agents, policies, commissions, projects, time, invoices.
5. Engineering backlog (priority order):
   - Background-function or external worker for long meetings/runs; move chat execution to queued runs + polling when on Netlify.
   - Dual-key re-encryption script for `TOKEN_ENCRYPTION_KEY` rotation.
   - Vector retrieval (pgvector) as a ranking layer with re-index on model change.
   - Outlook/365 adapter; Slack/Twilio notification delivery with destination permissions.
   - Object storage for form file uploads (Supabase Storage via server-side signed URLs).
   - Retention jobs (run_events 180 d, webhook_deliveries 90 d).
   - Screen-reader audit; evaluation set runner for retrieval/prompt changes.
