# Wilson Holdings OS

Private operating system for Wilson Holdings (Atlas Insurance Agency, Atlas Consulting and personal operations): chairman home, 52 configurable AI roles across 11 buildings, a 3D campus and a fast focus mode on the same records.

**Status:** all 7 slices implemented and locally tested (83 unit/integration + 14 browser tests). Live Anthropic/Google/GitHub use is credential-blocked until you add keys. Deploy with **`docs/DEPLOY.md`** (GitHub + Supabase + Netlify). See `IMPLEMENTATION_STATUS.md`, `NEXT_STEPS.md`, `docs/`.

## Quick start (local)

Requirements: Node 22+, PostgreSQL 16 (native or `docker compose up -d`).

```bash
npm ci
cp .env.example .env.local
# set SESSION_SECRET (32+ chars) and SETUP_TOKEN, e.g.:
#   node -e "console.log(require('crypto').randomBytes(32).toString('base64url'))"
npm run db:migrate
npm run db:seed
npm run dev        # → http://localhost:3000/setup, enter SETUP_TOKEN to create the owner
```

## Commands
| | |
|---|---|
| `npm run dev` / `build` / `start` | Web app |
| `npm run db:migrate` / `db:seed` / `db:reset` | Database (reset refuses in production) |
| `npm run typecheck` | TypeScript |
| `npm test` | Unit + integration (uses `TEST_DATABASE_URL`, default `wilson_holdings_test`) |
| `npm run worker` | Background worker (optional; Netlify uses the scheduled tick) |
| `npm run test:e2e` | Playwright against `wilson_holdings_e2e` (set `PW_CHROME` to a Chrome binary if Playwright browsers aren't installed) |

## Layout
```
db/migrations/        SQL migrations (checksummed; never edit an applied file)
src/lib/org/          Organization design: buildings, departments, 52 roles
src/lib/server/       env validation, db + RLS context, auth, services
src/lib/runs/         run state machine (deterministic)
src/components/       UI (design tokens in src/app/globals.css), campus 3D + plan fallback
src/app/(app)/        Authenticated views; src/app/api/ route handlers
tests/                unit, integration (real Postgres), e2e (Playwright)
docs/BUILD_PROMPT.md  Full product specification
```

## Security model (summary)
- Every scoped row carries `scope`; users hold read/write grants per scope.
- Application services check scopes, and Postgres row-level security enforces the same rules (`app.scopes`, `app.write_scopes` set per transaction in `withCtx`). Queries without a context see no scoped rows.
- External writes default to prepare-only; restricted actions escalate. Global and per-role pause.
- No secrets in the browser; env is validated at startup without printing values.
