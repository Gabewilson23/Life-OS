-- 001_core: organization, identity, org chart, agents, policies, goals, tasks, runs, audit.
-- Conventions: stable text/uuid IDs, created_at/updated_at, integer `version` for optimistic concurrency,
-- `scope` (e.g. 'org', 'company:atlas-insurance', 'personal:health') enforced by RLS + app code,
-- `provenance` jsonb recording where a row came from, `retention` class for lifecycle rules.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Row-level security predicate. Settings are transaction-local, set by withCtx() in src/lib/server/db.ts.
CREATE OR REPLACE FUNCTION app_can(row_org text, row_scope text) RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT coalesce(current_setting('app.bypass_rls', true), 'off') = 'on'
      OR (row_org = current_setting('app.org_id', true)
          AND row_scope = ANY (string_to_array(coalesce(current_setting('app.scopes', true), ''), ',')))
$$;

CREATE OR REPLACE FUNCTION app_can_write(row_org text, row_scope text) RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT coalesce(current_setting('app.bypass_rls', true), 'off') = 'on'
      OR (row_org = current_setting('app.org_id', true)
          AND row_scope = ANY (string_to_array(coalesce(current_setting('app.write_scopes', true), ''), ',')))
$$;

CREATE TABLE organizations (
  id text PRIMARY KEY,
  name text NOT NULL,
  timezone text NOT NULL DEFAULT 'America/New_York',
  settings jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Known scopes for an org. Grants reference these.
CREATE TABLE scopes (
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  label text NOT NULL,
  sensitivity text NOT NULL CHECK (sensitivity IN ('standard', 'confidential', 'private')),
  description text NOT NULL DEFAULT '',
  PRIMARY KEY (org_id, scope)
);

CREATE TABLE companies (
  id text PRIMARY KEY,
  org_id text NOT NULL REFERENCES organizations(id),
  slug text NOT NULL,
  name text NOT NULL,
  kind text NOT NULL CHECK (kind IN ('holding', 'insurance', 'consulting')),
  scope text NOT NULL,
  -- e.g. consulting: {"businessModel": null (unverified), "enabledWorkflows": []}
  settings jsonb NOT NULL DEFAULT '{}',
  verified jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (org_id, slug)
);

CREATE TABLE buildings (
  id text PRIMARY KEY,
  org_id text NOT NULL REFERENCES organizations(id),
  slug text NOT NULL,
  name text NOT NULL,
  description text NOT NULL,
  company_id text REFERENCES companies(id),
  scope text NOT NULL,
  layout jsonb NOT NULL, -- {x, z, w, d, h, accent}
  sort integer NOT NULL,
  UNIQUE (org_id, slug)
);

CREATE TABLE departments (
  id text PRIMARY KEY,
  org_id text NOT NULL REFERENCES organizations(id),
  building_id text NOT NULL REFERENCES buildings(id),
  company_id text REFERENCES companies(id),
  slug text NOT NULL,
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  scope text NOT NULL,
  sort integer NOT NULL DEFAULT 0
);

CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  email text NOT NULL UNIQUE,
  display_name text NOT NULL,
  password_hash text NOT NULL,
  role text NOT NULL CHECK (role IN ('owner', 'admin', 'member', 'viewer')),
  mfa_secret text,
  mfa_enabled boolean NOT NULL DEFAULT false,
  disabled_at timestamptz,
  last_login_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE user_scope_grants (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  org_id text NOT NULL,
  scope text NOT NULL,
  access text NOT NULL CHECK (access IN ('read', 'write')),
  granted_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, scope),
  FOREIGN KEY (org_id, scope) REFERENCES scopes(org_id, scope)
);

CREATE TABLE sessions (
  id text PRIMARY KEY, -- sha256(token) hex; the raw token only exists in the cookie
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  idle_expires_at timestamptz NOT NULL,
  absolute_expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  user_agent text,
  ip text
);
CREATE INDEX sessions_user_idx ON sessions(user_id);

CREATE TABLE login_attempts (
  id bigserial PRIMARY KEY,
  email text NOT NULL,
  ip text,
  success boolean NOT NULL,
  at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX login_attempts_email_idx ON login_attempts(email, at DESC);

-- Real people (company leaders, licensed agents, contractors). Distinct entity type from AI roles.
CREATE TABLE human_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  company_id text REFERENCES companies(id),
  scope text NOT NULL,
  name text NOT NULL,
  title text NOT NULL DEFAULT '',
  kind text NOT NULL CHECK (kind IN ('leader', 'licensed_agent', 'contractor', 'staff', 'advisor')),
  email text,
  provenance jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1
);

-- AI roles are configuration records, not running processes.
CREATE TABLE agent_definitions (
  id text PRIMARY KEY,                      -- durable ID, e.g. 'hq.chief-of-staff'
  number integer NOT NULL,                  -- 1..52 as in the org design
  org_id text NOT NULL REFERENCES organizations(id),
  building_id text NOT NULL REFERENCES buildings(id),
  department_id text NOT NULL REFERENCES departments(id),
  company_id text REFERENCES companies(id),
  manager_id text REFERENCES agent_definitions(id),
  scope text NOT NULL,
  title text NOT NULL,
  charter text NOT NULL,
  input_schema jsonb NOT NULL,
  output_schema jsonb NOT NULL,
  allowed_tools text[] NOT NULL,
  data_scopes text[] NOT NULL,
  evidence_rules jsonb NOT NULL,
  escalation_policy jsonb NOT NULL,
  triggers jsonb NOT NULL,
  model_config jsonb NOT NULL,
  budget jsonb NOT NULL,
  success_criteria jsonb NOT NULL,
  guardrails text[] NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'idle' CHECK (status IN ('idle', 'paused')),
  prompt_version integer NOT NULL DEFAULT 1,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (org_id, number)
);

CREATE TABLE agent_prompt_versions (
  agent_id text NOT NULL REFERENCES agent_definitions(id),
  version integer NOT NULL,
  system_prompt text NOT NULL,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (agent_id, version)
);

-- Authority policies: observe | prepare | execute_within_policy | escalate.
CREATE TABLE policies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  subject_type text NOT NULL CHECK (subject_type IN ('agent', 'org', 'company', 'connector')),
  subject_id text NOT NULL,
  action_class text NOT NULL,              -- e.g. 'external_write', 'email.send', 'calendar.create'
  level text NOT NULL CHECK (level IN ('observe', 'prepare', 'execute_within_policy', 'escalate')),
  conditions jsonb NOT NULL DEFAULT '{}',
  description text NOT NULL DEFAULT '',
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1
);

-- Global and per-subject pause switches + other system flags.
CREATE TABLE system_flags (
  org_id text NOT NULL REFERENCES organizations(id),
  key text NOT NULL,                       -- 'pause.global', 'pause.company:<id>', 'pause.connector:<id>'
  value jsonb NOT NULL,
  updated_by text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (org_id, key)
);

CREATE TABLE goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  company_id text REFERENCES companies(id),
  parent_id uuid REFERENCES goals(id),
  title text NOT NULL CHECK (length(title) BETWEEN 1 AND 300),
  description text NOT NULL DEFAULT '',
  horizon text NOT NULL CHECK (horizon IN ('annual', 'quarterly', 'monthly', 'weekly')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'achieved', 'paused', 'dropped')),
  period_start date,
  period_end date,
  target_metric text,
  target_value numeric,
  current_value numeric,
  progress_note text NOT NULL DEFAULT '',
  owner_kind text NOT NULL DEFAULT 'user' CHECK (owner_kind IN ('user', 'human_member', 'agent')),
  owner_id text,
  provenance jsonb NOT NULL DEFAULT '{}',
  retention text NOT NULL DEFAULT 'standard',
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  deleted_at timestamptz
);
CREATE INDEX goals_org_scope_idx ON goals(org_id, scope) WHERE deleted_at IS NULL;

-- Human work items (distinct from agent runs, which use the run state machine).
CREATE TABLE tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  company_id text REFERENCES companies(id),
  goal_id uuid REFERENCES goals(id),
  title text NOT NULL CHECK (length(title) BETWEEN 1 AND 300),
  notes text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'waiting', 'blocked', 'done', 'cancelled')),
  priority integer NOT NULL DEFAULT 2 CHECK (priority BETWEEN 0 AND 3), -- 0 = critical
  due_date date,
  assignee_kind text CHECK (assignee_kind IN ('user', 'human_member', 'agent')),
  assignee_id text,
  blocked_reason text,
  provenance jsonb NOT NULL DEFAULT '{}',
  retention text NOT NULL DEFAULT 'standard',
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  version integer NOT NULL DEFAULT 1,
  deleted_at timestamptz
);
CREATE INDEX tasks_org_scope_idx ON tasks(org_id, scope, status) WHERE deleted_at IS NULL;

-- Chairman's three outcomes for a given local date.
CREATE TABLE daily_outcomes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL DEFAULT 'org',
  user_id uuid NOT NULL REFERENCES users(id),
  local_date date NOT NULL,
  position integer NOT NULL CHECK (position BETWEEN 1 AND 3),
  title text NOT NULL DEFAULT '',
  goal_id uuid REFERENCES goals(id),
  done boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (user_id, local_date, position)
);

-- Agent runs: proposed -> queued -> running -> waiting_approval|blocked -> succeeded|failed|cancelled.
CREATE TABLE runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  agent_id text NOT NULL REFERENCES agent_definitions(id),
  parent_run_id uuid REFERENCES runs(id),
  depth integer NOT NULL DEFAULT 0,
  state text NOT NULL CHECK (state IN ('proposed', 'queued', 'running', 'waiting_approval', 'blocked', 'succeeded', 'failed', 'cancelled')),
  outcome_certainty text CHECK (outcome_certainty IN ('confirmed', 'uncertain')),
  input jsonb NOT NULL DEFAULT '{}',
  output jsonb,
  error text,
  attempts integer NOT NULL DEFAULT 0,
  max_attempts integer NOT NULL DEFAULT 3,
  lease_owner text,
  lease_expires_at timestamptz,
  heartbeat_at timestamptz,
  cancel_requested boolean NOT NULL DEFAULT false,
  idempotency_key text,
  is_demo boolean NOT NULL DEFAULT false,
  requested_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  started_at timestamptz,
  finished_at timestamptz,
  version integer NOT NULL DEFAULT 1,
  UNIQUE (org_id, idempotency_key)
);
CREATE INDEX runs_queue_idx ON runs(state, created_at) WHERE state IN ('queued', 'running');
CREATE INDEX runs_agent_idx ON runs(agent_id, created_at DESC);

CREATE TABLE run_transitions (
  id bigserial PRIMARY KEY,
  run_id uuid NOT NULL REFERENCES runs(id),
  from_state text,
  to_state text NOT NULL,
  reason text NOT NULL DEFAULT '',
  actor text NOT NULL,
  at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE audit_events (
  id bigserial PRIMARY KEY,
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  actor text NOT NULL,                    -- 'user:<id>' | 'agent:<id>' | 'system:<job>'
  action text NOT NULL,                   -- e.g. 'goal.update'
  resource_type text NOT NULL,
  resource_id text NOT NULL,
  summary text NOT NULL DEFAULT '',
  before jsonb,
  after jsonb,
  at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_resource_idx ON audit_events(resource_type, resource_id, at DESC);
CREATE INDEX audit_org_idx ON audit_events(org_id, at DESC);

-- Audit is append-only.
CREATE OR REPLACE FUNCTION audit_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'audit_events is append-only'; END $$;
CREATE TRIGGER audit_no_update BEFORE UPDATE OR DELETE ON audit_events FOR EACH ROW EXECUTE FUNCTION audit_immutable();

-- Row-level security on scoped tables. FORCE so the owning role is also subject to policies.
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['goals', 'tasks', 'daily_outcomes', 'runs', 'audit_events', 'human_members', 'agent_definitions', 'policies', 'companies', 'buildings', 'departments']
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR SELECT USING (app_can(org_id, scope))', t || '_read', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR INSERT WITH CHECK (app_can_write(org_id, scope))', t || '_insert', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR UPDATE USING (app_can_write(org_id, scope)) WITH CHECK (app_can_write(org_id, scope))', t || '_update', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR DELETE USING (app_can_write(org_id, scope))', t || '_delete', t);
  END LOOP;
END $$;
