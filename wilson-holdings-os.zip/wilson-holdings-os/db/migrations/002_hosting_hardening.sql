-- 002: least-privilege application role + hosted-Postgres (Supabase) hardening.
-- The app connects as the migration/owner role but every user/agent transaction runs
-- `SET LOCAL ROLE wh_app`, which never bypasses row-level security.

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'wh_app') THEN
    CREATE ROLE wh_app NOLOGIN NOBYPASSRLS NOINHERIT;
  END IF;
END $$;

DO $$ BEGIN EXECUTE format('GRANT wh_app TO %I', current_user); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

GRANT USAGE ON SCHEMA public TO wh_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO wh_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO wh_app;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO wh_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO wh_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO wh_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT EXECUTE ON FUNCTIONS TO wh_app;
-- Migration bookkeeping and the append-only audit table are not app-writable beyond INSERT.
REVOKE UPDATE, DELETE ON audit_events FROM wh_app;
REVOKE ALL ON schema_migrations FROM wh_app;

-- Supabase exposes the public schema through its Data API (PostgREST) to `anon` and
-- `authenticated`. This app never uses that API, so remove all access.
DO $$
DECLARE r text;
BEGIN
  FOREACH r IN ARRAY ARRAY['anon', 'authenticated'] LOOP
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
      EXECUTE format('REVOKE ALL ON ALL TABLES IN SCHEMA public FROM %I', r);
      EXECUTE format('REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM %I', r);
      EXECUTE format('REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM %I', r);
      EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON TABLES FROM %I', r);
      EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON SEQUENCES FROM %I', r);
      EXECUTE format('ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON FUNCTIONS FROM %I', r);
    END IF;
  END LOOP;
END $$;

-- Identity tables: enable RLS without FORCE. The owner (server auth code) still reads them;
-- any other role without a policy sees nothing.
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE login_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_scope_grants ENABLE ROW LEVEL SECURITY;
ALTER TABLE scopes ENABLE ROW LEVEL SECURITY;
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_flags ENABLE ROW LEVEL SECURITY;
ALTER TABLE agent_prompt_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE run_transitions ENABLE ROW LEVEL SECURITY;
-- wh_app reads these inside user transactions; scope them by org.
CREATE POLICY org_read ON organizations FOR SELECT TO wh_app USING (id = current_setting('app.org_id', true));
CREATE POLICY org_write ON organizations FOR UPDATE TO wh_app USING (id = current_setting('app.org_id', true) AND 'org' = ANY (string_to_array(coalesce(current_setting('app.write_scopes', true), ''), ',')));
CREATE POLICY flags_read ON system_flags FOR SELECT TO wh_app USING (org_id = current_setting('app.org_id', true));
CREATE POLICY flags_write ON system_flags FOR ALL TO wh_app USING (org_id = current_setting('app.org_id', true) AND 'org' = ANY (string_to_array(coalesce(current_setting('app.write_scopes', true), ''), ','))) WITH CHECK (org_id = current_setting('app.org_id', true) AND 'org' = ANY (string_to_array(coalesce(current_setting('app.write_scopes', true), ''), ',')));
CREATE POLICY scopes_read ON scopes FOR SELECT TO wh_app USING (org_id = current_setting('app.org_id', true));
CREATE POLICY prompts_read ON agent_prompt_versions FOR SELECT TO wh_app USING (EXISTS (SELECT 1 FROM agent_definitions a WHERE a.id = agent_id));
CREATE POLICY transitions_rw ON run_transitions FOR ALL TO wh_app USING (EXISTS (SELECT 1 FROM runs r WHERE r.id = run_id)) WITH CHECK (EXISTS (SELECT 1 FROM runs r WHERE r.id = run_id));
-- users / sessions / grants / login_attempts: no wh_app policy => invisible inside user transactions.
