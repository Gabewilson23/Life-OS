-- 003: chat, run events, usage/costs, proposals, and the executive memory system.

CREATE TABLE channels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  kind text NOT NULL CHECK (kind IN ('chief_of_staff', 'agent_dm', 'department', 'company')),
  agent_id text REFERENCES agent_definitions(id),
  title text NOT NULL,
  private boolean NOT NULL DEFAULT false,      -- private session: never enters memory/search; messages expire
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz
);

CREATE TABLE messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  channel_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
  author text NOT NULL,
  content text NOT NULL,
  run_id uuid REFERENCES runs(id),
  evidence jsonb NOT NULL DEFAULT '[]',
  is_demo boolean NOT NULL DEFAULT false,
  private boolean NOT NULL DEFAULT false,
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX messages_channel_idx ON messages(channel_id, created_at);

ALTER TABLE runs ADD COLUMN channel_id uuid REFERENCES channels(id) ON DELETE SET NULL;
ALTER TABLE runs ADD COLUMN blocked_reason text;
ALTER TABLE runs ADD COLUMN cost_usd numeric(12, 6);
ALTER TABLE runs ADD COLUMN input_tokens integer NOT NULL DEFAULT 0;
ALTER TABLE runs ADD COLUMN output_tokens integer NOT NULL DEFAULT 0;

CREATE TABLE run_events (
  id bigserial PRIMARY KEY,
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  run_id uuid NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('status', 'text', 'tool_call', 'tool_result', 'usage', 'error', 'proposal')),
  data jsonb NOT NULL,
  at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX run_events_run_idx ON run_events(run_id, id);

CREATE TABLE usage_events (
  id bigserial PRIMARY KEY,
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  run_id uuid REFERENCES runs(id) ON DELETE SET NULL,
  agent_id text,
  company_id text,
  workflow text NOT NULL DEFAULT 'chat',
  model text NOT NULL,
  input_tokens integer NOT NULL,
  output_tokens integer NOT NULL,
  cost_usd numeric(12, 6),                     -- NULL when model pricing is not configured
  at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX usage_events_day_idx ON usage_events(org_id, at);

-- Structured proposals from agents. Never executed by the model; a human (or a narrow
-- standing policy, slice 5) accepts them and deterministic code performs the change.
CREATE TABLE proposals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  run_id uuid REFERENCES runs(id) ON DELETE SET NULL,
  agent_id text,
  kind text NOT NULL,
  title text NOT NULL,
  payload jsonb NOT NULL,
  payload_hash text NOT NULL,
  rationale text NOT NULL DEFAULT '',
  evidence jsonb NOT NULL DEFAULT '[]',
  status text NOT NULL DEFAULT 'proposed' CHECK (status IN ('proposed', 'accepted', 'rejected', 'executed', 'failed', 'expired')),
  result jsonb,
  decided_by text,
  decided_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1
);
CREATE INDEX proposals_status_idx ON proposals(org_id, status, created_at DESC);

-- Seven memory types in one table, discriminated by mtype.
CREATE TABLE memory_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  mtype text NOT NULL CHECK (mtype IN ('identity', 'semantic', 'episodic', 'working', 'procedural', 'relationship', 'outcome')),
  subject text NOT NULL,                       -- entity or topic key, e.g. 'gabe.schedule', 'atlas-consulting.model'
  about_person text NOT NULL DEFAULT 'owner',  -- whose fact this is
  assertion text,                              -- NULL after forgetting
  sensitivity text NOT NULL DEFAULT 'standard' CHECK (sensitivity IN ('standard', 'sensitive')),
  status text NOT NULL CHECK (status IN ('staged', 'active', 'superseded', 'forgotten', 'rejected')),
  confidence text NOT NULL CHECK (confidence IN ('user_confirmed', 'source_confirmed', 'inferred', 'unverified')),
  source_kind text NOT NULL,                   -- 'chat', 'user_entry', 'document', 'import', 'agent'
  source_ref text,
  excerpt text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  valid_from timestamptz NOT NULL DEFAULT now(),
  valid_to timestamptz,
  verified_at timestamptz,
  stale_after_days integer,
  expires_at timestamptz,
  supersedes_id uuid REFERENCES memory_records(id),
  conflicts_with uuid[] NOT NULL DEFAULT '{}',
  embedding_model text,
  retention text NOT NULL DEFAULT 'standard',
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  tsv tsvector GENERATED ALWAYS AS (to_tsvector('english', coalesce(subject, '') || ' ' || coalesce(assertion, ''))) STORED
);
CREATE INDEX memory_tsv_idx ON memory_records USING gin(tsv);
CREATE INDEX memory_subject_idx ON memory_records(org_id, subject, status);

-- Source-level exclusions so forgotten content is not re-imported.
CREATE TABLE memory_tombstones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  source_kind text NOT NULL,
  source_ref text,
  subject text,
  reason text NOT NULL DEFAULT '',
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Which memories influenced which run (inspectable lineage).
CREATE TABLE retrieval_lineage (
  id bigserial PRIMARY KEY,
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  run_id uuid NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
  memory_id uuid NOT NULL REFERENCES memory_records(id) ON DELETE CASCADE,
  rank real NOT NULL,
  at timestamptz NOT NULL DEFAULT now()
);

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['channels', 'messages', 'run_events', 'usage_events', 'proposals', 'memory_records', 'memory_tombstones', 'retrieval_lineage']
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR SELECT USING (app_can(org_id, scope))', t || '_read', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR INSERT WITH CHECK (app_can_write(org_id, scope))', t || '_insert', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR UPDATE USING (app_can_write(org_id, scope)) WITH CHECK (app_can_write(org_id, scope))', t || '_update', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR DELETE USING (app_can_write(org_id, scope))', t || '_delete', t);
  END LOOP;
END $$;
