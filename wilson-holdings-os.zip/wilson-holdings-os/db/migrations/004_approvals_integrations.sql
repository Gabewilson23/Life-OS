-- 004: approval → action → verification pipeline, standing permissions, integration accounts (OAuth),
-- calendar mirror and email drafts.

CREATE TABLE integration_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,                         -- which company/personal scope this account belongs to
  provider text NOT NULL,                      -- 'google'
  label text NOT NULL,
  external_account text,                       -- e.g. the Google account email (from userinfo)
  status text NOT NULL CHECK (status IN ('setup_needed', 'authorized', 'syncing', 'healthy', 'stale', 'degraded', 'revoked')),
  capabilities text[] NOT NULL DEFAULT '{}',   -- e.g. calendar.read, calendar.write, gmail.read, gmail.draft, drive.read
  scopes_granted text[] NOT NULL DEFAULT '{}',
  access_token_enc text,
  refresh_token_enc text,
  token_expires_at timestamptz,
  last_sync_at timestamptz,
  last_error text,
  paused boolean NOT NULL DEFAULT false,
  settings jsonb NOT NULL DEFAULT '{}',        -- selected calendars, working hours, buffers
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1
);

CREATE TABLE oauth_states (
  state text PRIMARY KEY,
  org_id text NOT NULL,
  user_id uuid NOT NULL,
  provider text NOT NULL,
  account_scope text NOT NULL,
  label text NOT NULL,
  capabilities text[] NOT NULL,
  code_verifier text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL
);

CREATE TABLE sync_cursors (
  account_id uuid NOT NULL REFERENCES integration_accounts(id) ON DELETE CASCADE,
  resource text NOT NULL,
  cursor text,
  cursor_version integer NOT NULL DEFAULT 1,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (account_id, resource)
);

CREATE TABLE calendar_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  account_id uuid NOT NULL REFERENCES integration_accounts(id) ON DELETE CASCADE,
  calendar_id text NOT NULL,
  remote_id text NOT NULL,
  etag text,
  title text NOT NULL DEFAULT '',
  starts_at timestamptz,
  ends_at timestamptz,
  all_day boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'confirmed',
  visibility text,
  attendees jsonb NOT NULL DEFAULT '[]',
  recurring_event_id text,
  last_synced_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (account_id, calendar_id, remote_id)
);
CREATE INDEX calendar_events_time_idx ON calendar_events(org_id, starts_at);

CREATE TABLE email_drafts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  account_id uuid REFERENCES integration_accounts(id) ON DELETE SET NULL,
  to_addrs text[] NOT NULL DEFAULT '{}',
  cc_addrs text[] NOT NULL DEFAULT '{}',
  bcc_addrs text[] NOT NULL DEFAULT '{}',
  subject text NOT NULL DEFAULT '',
  body_text text NOT NULL DEFAULT '',
  thread_id text,
  remote_draft_id text,
  sync_state text NOT NULL DEFAULT 'local_only' CHECK (sync_state IN ('local_only', 'pending', 'synced', 'failed', 'sent')),
  provider_status text,                        -- 'accepted' after send; delivery is never claimed without evidence
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1
);

-- Approvals bind actor, company scope, account, resource, content hash, amount, timing, expiry.
CREATE TABLE approvals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  proposal_id uuid REFERENCES proposals(id) ON DELETE SET NULL,
  action_kind text NOT NULL,
  account_id uuid REFERENCES integration_accounts(id),
  resource text NOT NULL DEFAULT '',          -- calendar id / recipients / destination
  payload jsonb NOT NULL,
  content_hash text NOT NULL,
  amount_cents bigint,
  not_before timestamptz,
  expires_at timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'denied', 'expired', 'revoked', 'consumed')),
  via_standing_permission uuid,
  discloses text[] NOT NULL DEFAULT '{}',      -- e.g. 'sends invitations to attendees'
  requested_by text NOT NULL,
  decided_by text,
  decided_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1
);
CREATE INDEX approvals_status_idx ON approvals(org_id, status, created_at DESC);

CREATE TABLE standing_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  action_kind text NOT NULL,
  account_id uuid REFERENCES integration_accounts(id) ON DELETE CASCADE,
  constraints jsonb NOT NULL DEFAULT '{}',     -- {private_only: true, no_attendees: true, max_per_day: 5}
  description text NOT NULL,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  revoked_at timestamptz
);

-- One approval can produce at most one action attempt (replay protection).
CREATE TABLE action_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  approval_id uuid NOT NULL UNIQUE REFERENCES approvals(id),
  idempotency_key text NOT NULL UNIQUE,
  action_kind text NOT NULL,
  account_id uuid REFERENCES integration_accounts(id),
  state text NOT NULL CHECK (state IN ('pending', 'executing', 'succeeded', 'failed', 'uncertain')),
  verified boolean NOT NULL DEFAULT false,
  request jsonb NOT NULL,
  remote_id text,
  response jsonb,
  error text,
  tries integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  verified_at timestamptz,
  version integer NOT NULL DEFAULT 1
);

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['integration_accounts', 'calendar_events', 'email_drafts', 'approvals', 'standing_permissions', 'action_attempts']
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR SELECT USING (app_can(org_id, scope))', t || '_read', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR INSERT WITH CHECK (app_can_write(org_id, scope))', t || '_insert', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR UPDATE USING (app_can_write(org_id, scope)) WITH CHECK (app_can_write(org_id, scope))', t || '_update', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR DELETE USING (app_can_write(org_id, scope))', t || '_delete', t);
  END LOOP;
END $$;
ALTER TABLE oauth_states ENABLE ROW LEVEL SECURITY;  -- owner-only (server auth code)
ALTER TABLE sync_cursors ENABLE ROW LEVEL SECURITY;
CREATE POLICY cursors_rw ON sync_cursors FOR ALL TO wh_app USING (EXISTS (SELECT 1 FROM integration_accounts a WHERE a.id = account_id)) WITH CHECK (EXISTS (SELECT 1 FROM integration_accounts a WHERE a.id = account_id));
