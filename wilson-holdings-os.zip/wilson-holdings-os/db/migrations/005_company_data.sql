-- 005: company datasets (generated from src/lib/company/datasets.ts by scripts/gen-company-sql.ts) + import batches.

CREATE TABLE import_batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  dataset text NOT NULL,
  filename text NOT NULL,
  file_sha256 text NOT NULL,
  raw bytea,
  headers text[] NOT NULL DEFAULT '{}',
  mapping jsonb NOT NULL DEFAULT '{}',
  row_count integer NOT NULL DEFAULT 0,
  inserted integer NOT NULL DEFAULT 0,
  updated integer NOT NULL DEFAULT 0,
  unchanged integer NOT NULL DEFAULT 0,
  rejected integer NOT NULL DEFAULT 0,
  errors jsonb NOT NULL DEFAULT '[]',
  status text NOT NULL CHECK (status IN ('previewed', 'committed', 'failed', 'superseded')),
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  committed_at timestamptz
);
CREATE INDEX import_batches_ds_idx ON import_batches(org_id, dataset, created_at DESC);

CREATE TABLE ins_people (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  external_key text NOT NULL,
  name text NOT NULL,
  kind text NOT NULL CHECK (kind IN ('candidate', 'agent')),
  stage text NOT NULL CHECK (stage IN ('sourced', 'interviewing', 'offered', 'licensing', 'onboarding', 'active', 'inactive')),
  source text,
  cohort text,
  licensed_states text,
  hired_at date,
  first_production_at date,
  training_complete boolean,
  batch_id uuid REFERENCES import_batches(id),
  row_num integer,
  row_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (org_id, scope, external_key)
);

CREATE TABLE ins_policies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  external_key text NOT NULL,
  client_name text,
  agent_key text,
  carrier text,
  product text,
  lead_source text,
  annual_premium_cents bigint NOT NULL,
  submitted_at date NOT NULL,
  issued_at date,
  placed_at date,
  paid_at date,
  status text NOT NULL CHECK (status IN ('submitted', 'issued', 'placed', 'paid', 'declined', 'withdrawn', 'lapsed', 'cancelled')),
  lapsed_at date,
  missing_documents text,
  batch_id uuid REFERENCES import_batches(id),
  row_num integer,
  row_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (org_id, scope, external_key)
);

CREATE TABLE ins_commissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  external_key text NOT NULL,
  policy_key text NOT NULL,
  agent_key text,
  kind text NOT NULL CHECK (kind IN ('advance', 'earned', 'override', 'chargeback', 'renewal')),
  expected_cents bigint,
  received_cents bigint,
  statement_date date NOT NULL,
  batch_id uuid REFERENCES import_batches(id),
  row_num integer,
  row_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (org_id, scope, external_key)
);

CREATE TABLE ins_lead_costs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  external_key text NOT NULL,
  source text NOT NULL,
  month date NOT NULL,
  cost_cents bigint NOT NULL,
  leads integer,
  batch_id uuid REFERENCES import_batches(id),
  row_num integer,
  row_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (org_id, scope, external_key)
);

CREATE TABLE con_opportunities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  external_key text NOT NULL,
  client text NOT NULL,
  name text NOT NULL,
  stage text NOT NULL CHECK (stage IN ('lead', 'qualified', 'proposal', 'negotiation', 'won', 'lost')),
  amount_cents bigint NOT NULL,
  probability numeric(5,2),
  expected_close date,
  next_step text,
  batch_id uuid REFERENCES import_batches(id),
  row_num integer,
  row_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (org_id, scope, external_key)
);

CREATE TABLE con_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  external_key text NOT NULL,
  client text NOT NULL,
  name text NOT NULL,
  billing_model text CHECK (billing_model IN ('project', 'retainer', 'placement', 'time_and_materials')),
  contract_value_cents bigint NOT NULL,
  budget_cost_cents bigint,
  status text NOT NULL CHECK (status IN ('planned', 'active', 'on_hold', 'complete', 'cancelled')),
  health text CHECK (health IN ('green', 'amber', 'red')),
  start_date date,
  end_date date,
  renewal_date date,
  batch_id uuid REFERENCES import_batches(id),
  row_num integer,
  row_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (org_id, scope, external_key)
);

CREATE TABLE con_time (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  external_key text NOT NULL,
  project_key text NOT NULL,
  person text NOT NULL,
  work_date date NOT NULL,
  hours numeric(12,2) NOT NULL,
  cost_rate_cents bigint NOT NULL,
  bill_rate_cents bigint,
  approved boolean NOT NULL,
  batch_id uuid REFERENCES import_batches(id),
  row_num integer,
  row_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (org_id, scope, external_key)
);

CREATE TABLE con_expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  external_key text NOT NULL,
  project_key text NOT NULL,
  expense_date date NOT NULL,
  amount_cents bigint NOT NULL,
  billable boolean,
  approved boolean NOT NULL,
  description text,
  batch_id uuid REFERENCES import_batches(id),
  row_num integer,
  row_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (org_id, scope, external_key)
);

CREATE TABLE con_invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  external_key text NOT NULL,
  project_key text NOT NULL,
  issued_at date NOT NULL,
  due_at date NOT NULL,
  amount_cents bigint NOT NULL,
  status text CHECK (status IN ('draft', 'sent', 'paid', 'void')),
  batch_id uuid REFERENCES import_batches(id),
  row_num integer,
  row_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (org_id, scope, external_key)
);

CREATE TABLE con_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  external_key text NOT NULL,
  invoice_key text NOT NULL,
  received_at date NOT NULL,
  amount_cents bigint NOT NULL,
  batch_id uuid REFERENCES import_batches(id),
  row_num integer,
  row_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (org_id, scope, external_key)
);

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['import_batches', 'ins_people', 'ins_policies', 'ins_commissions', 'ins_lead_costs', 'con_opportunities', 'con_projects', 'con_time', 'con_expenses', 'con_invoices', 'con_payments']
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR SELECT USING (app_can(org_id, scope))', t || '_read', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR INSERT WITH CHECK (app_can_write(org_id, scope))', t || '_insert', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR UPDATE USING (app_can_write(org_id, scope)) WITH CHECK (app_can_write(org_id, scope))', t || '_update', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR DELETE USING (app_can_write(org_id, scope))', t || '_delete', t);
  END LOOP;
END $$;
