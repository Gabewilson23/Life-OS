-- 006: schedules (DST-safe, once per window), reports/snapshots, notifications, worker heartbeats,
-- bounded AI meetings, webhooks, and connector configs (Atlas CRM).

CREATE TABLE schedules (
  id text PRIMARY KEY,
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  kind text NOT NULL CHECK (kind IN ('chairman_briefing', 'company_close', 'executive_review', 'monthly_owner_report')),
  company_id text REFERENCES companies(id),
  label text NOT NULL,
  rule jsonb NOT NULL,                -- {"freq":"daily","time":"07:30"} | {"freq":"weekly","weekday":5,"time":"15:00"} | {"freq":"monthly","day":1,"time":"08:00"}
  timezone text NOT NULL DEFAULT 'America/New_York',
  enabled boolean NOT NULL DEFAULT false,
  catchup_hours integer NOT NULL DEFAULT 6,
  delivery jsonb NOT NULL DEFAULT '{"in_app": true}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1
);

CREATE TABLE reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  kind text NOT NULL,
  schedule_id text REFERENCES schedules(id),
  window_key text,
  title text NOT NULL,
  period_from timestamptz NOT NULL,
  period_to timestamptz NOT NULL,
  source_cutoff timestamptz NOT NULL,
  metric_version text NOT NULL,
  data jsonb NOT NULL,                -- deterministic sections; reproducible from cutoff + metric version
  narrative text,
  narrative_status text NOT NULL DEFAULT 'none' CHECK (narrative_status IN ('none', 'generated', 'unavailable')),
  reading_minutes integer NOT NULL DEFAULT 1,
  previous_report_id uuid REFERENCES reports(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX reports_kind_idx ON reports(org_id, kind, created_at DESC);

-- Exactly one run per schedule per reporting window, across restarts and concurrent workers.
CREATE TABLE schedule_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  schedule_id text NOT NULL REFERENCES schedules(id),
  window_key text NOT NULL,
  scheduled_for timestamptz NOT NULL,
  status text NOT NULL CHECK (status IN ('running', 'succeeded', 'failed')),
  report_id uuid REFERENCES reports(id),
  error text,
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  UNIQUE (schedule_id, window_key)
);

CREATE TABLE notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  kind text NOT NULL,
  title text NOT NULL,
  body text NOT NULL DEFAULT '',
  link text,
  priority text NOT NULL DEFAULT 'routine' CHECK (priority IN ('routine', 'important', 'urgent')),
  dedupe_key text NOT NULL,
  group_key text,
  occurrences integer NOT NULL DEFAULT 1,
  deliver_after timestamptz NOT NULL DEFAULT now(),
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, dedupe_key)
);

CREATE TABLE worker_heartbeats (
  worker_id text PRIMARY KEY,
  kind text NOT NULL,
  last_seen timestamptz NOT NULL DEFAULT now(),
  last_tick jsonb NOT NULL DEFAULT '{}'
);

CREATE TABLE meetings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  title text NOT NULL,
  agenda text NOT NULL,
  participants text[] NOT NULL,
  max_rounds integer NOT NULL CHECK (max_rounds BETWEEN 1 AND 3),
  status text NOT NULL CHECK (status IN ('draft', 'running', 'completed', 'blocked', 'failed')),
  blocked_reason text,
  summary text,
  is_demo boolean NOT NULL DEFAULT false,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz
);

CREATE TABLE meeting_contributions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  round integer NOT NULL,
  agent_id text NOT NULL,
  run_id uuid REFERENCES runs(id),
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE meeting_outcomes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  meeting_id uuid NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('decision', 'dissent', 'action')),
  content text NOT NULL,
  owner_agent_id text,
  evidence text,
  task_id uuid REFERENCES tasks(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE webhook_endpoints (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  direction text NOT NULL CHECK (direction IN ('inbound', 'outbound')),
  name text NOT NULL,
  url text,                                     -- outbound only (https; validated against SSRF rules)
  secret_enc text NOT NULL,
  allowed_events text[] NOT NULL DEFAULT '{}',
  trusted_internal boolean NOT NULL DEFAULT false, -- explicit opt-in to reach private networks
  enabled boolean NOT NULL DEFAULT true,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE webhook_deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  endpoint_id uuid NOT NULL REFERENCES webhook_endpoints(id) ON DELETE CASCADE,
  direction text NOT NULL,
  event text NOT NULL,
  payload jsonb NOT NULL,
  idempotency_key text NOT NULL,
  status text NOT NULL CHECK (status IN ('accepted', 'rejected', 'pending', 'delivered', 'failed')),
  attempts integer NOT NULL DEFAULT 0,
  response_status integer,
  error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (endpoint_id, idempotency_key)
);

CREATE TABLE connector_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  connector text NOT NULL,                      -- 'atlas-crm'
  base_url text NOT NULL,
  auth_header text NOT NULL DEFAULT 'Authorization',
  secret_enc text,
  mapping jsonb NOT NULL DEFAULT '{}',
  discovered jsonb,
  status text NOT NULL DEFAULT 'setup_needed',
  trusted_internal boolean NOT NULL DEFAULT false,
  last_sync_at timestamptz,
  last_error text,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['schedules', 'reports', 'schedule_runs', 'notifications', 'meetings', 'meeting_contributions', 'meeting_outcomes', 'webhook_endpoints', 'webhook_deliveries', 'connector_configs']
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR SELECT USING (app_can(org_id, scope))', t || '_read', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR INSERT WITH CHECK (app_can_write(org_id, scope))', t || '_insert', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR UPDATE USING (app_can_write(org_id, scope)) WITH CHECK (app_can_write(org_id, scope))', t || '_update', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR DELETE USING (app_can_write(org_id, scope))', t || '_delete', t);
  END LOOP;
END $$;
ALTER TABLE worker_heartbeats ENABLE ROW LEVEL SECURITY;
CREATE POLICY heartbeats_read ON worker_heartbeats FOR SELECT TO wh_app USING (true);
