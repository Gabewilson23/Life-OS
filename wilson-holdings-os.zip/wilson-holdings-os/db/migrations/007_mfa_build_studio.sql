-- 007: TOTP MFA replay protection; Build Studio (capability registry, versioned forms/workflows,
-- submissions, custom records, workflow runs) and code-path change requests.

ALTER TABLE users ADD COLUMN mfa_last_step bigint;
ALTER TABLE users ADD COLUMN mfa_pending_secret text;

CREATE TABLE capabilities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  kind text NOT NULL CHECK (kind IN ('form', 'workflow', 'email_template', 'record_type', 'report')),
  name text NOT NULL,
  slug text NOT NULL,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'paused', 'archived')),
  access text NOT NULL DEFAULT 'private' CHECK (access IN ('private', 'public')),
  current_version integer NOT NULL DEFAULT 1,
  depends_on uuid[] NOT NULL DEFAULT '{}',
  owner_agent_id text,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (org_id, slug)
);

CREATE TABLE capability_versions (
  capability_id uuid NOT NULL REFERENCES capabilities(id) ON DELETE CASCADE,
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  version integer NOT NULL,
  definition jsonb NOT NULL,
  definition_hash text NOT NULL,
  test_status text NOT NULL DEFAULT 'untested' CHECK (test_status IN ('untested', 'passed', 'failed')),
  test_report jsonb,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (capability_id, version)
);

CREATE TABLE form_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  form_id uuid NOT NULL REFERENCES capabilities(id),
  form_version integer NOT NULL,                -- frozen schema version used for this submission
  data jsonb NOT NULL,
  consent_given boolean NOT NULL DEFAULT false,
  client_key text NOT NULL,                     -- idempotency key from the submitting client
  source_hash text,                             -- salted hash of IP for rate limiting (no raw IPs stored)
  is_test boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (form_id, client_key)
);

CREATE TABLE custom_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  record_type text NOT NULL,                    -- e.g. 'contractor'
  data jsonb NOT NULL,
  source_submission uuid REFERENCES form_submissions(id),
  is_test boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (source_submission, record_type)
);

CREATE TABLE workflow_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  workflow_id uuid NOT NULL REFERENCES capabilities(id),
  workflow_version integer NOT NULL,
  trigger_ref text NOT NULL,                    -- e.g. submission id; unique per workflow => replay-safe
  status text NOT NULL CHECK (status IN ('running', 'succeeded', 'failed', 'waiting_approval')),
  steps jsonb NOT NULL DEFAULT '[]',
  error text,
  is_test boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  UNIQUE (workflow_id, trigger_ref)
);

CREATE TABLE change_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL DEFAULT 'engineering',
  title text NOT NULL,
  request text NOT NULL,
  spec jsonb NOT NULL DEFAULT '{}',             -- Product Architect spec: reuse analysis, data/permissions, acceptance criteria
  status text NOT NULL CHECK (status IN ('spec', 'blocked', 'in_development', 'preview_ready', 'qa_passed', 'qa_failed', 'awaiting_release_approval', 'released', 'rejected')),
  blocker text,
  branch text,
  pr_number integer,
  commit_sha text,
  checks jsonb,
  rollback_plan text,
  release_approval_hash text,
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1
);

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['capabilities', 'capability_versions', 'form_submissions', 'custom_records', 'workflow_runs', 'change_requests']
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR SELECT USING (app_can(org_id, scope))', t || '_read', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR INSERT WITH CHECK (app_can_write(org_id, scope))', t || '_insert', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR UPDATE USING (app_can_write(org_id, scope)) WITH CHECK (app_can_write(org_id, scope))', t || '_update', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR DELETE USING (app_can_write(org_id, scope))', t || '_delete', t);
  END LOOP;
END $$;
