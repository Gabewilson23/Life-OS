# Manual acceptance checklist (production)

- [ ] `/api/health` ok; `/setup` creates owner; MFA enrolled; sign out/in with code.
- [ ] Organization shows 52 roles / 11 buildings; a goal edit survives a redeploy.
- [ ] Campus: click a building and an avatar → same role page as Organization.
- [ ] With `ANTHROPIC_API_KEY`: Chief of Staff answers using tools (evidence expander lists tool calls); without it, the run shows "Not run — Model credential missing".
- [ ] Import both companies' CSVs; console numbers match a hand calculation of the files; source records show file + row.
- [ ] Insurance-only user (create via SQL grant) cannot see consulting or personal data in pages, search, chat or reports.
- [ ] Google connected: propose a private event → approve → exactly one event in Google, verified, remote ID shown; revoke access → pending approvals voided.
- [ ] Global pause prevents an approved action from running.
- [ ] Activate the 7:30 briefing; next morning exactly one report exists; stale/missing sources are named.
- [ ] AI meeting (1 round, 2 roles) records decisions/dissent/actions with owners.
- [ ] Studio: contractor intake → test → activate → publish → submit from a private browser window → one contractor record, one review task, one draft (local if Gmail not connected).
- [ ] Keyboard-only: ⌘K, g-shortcuts; reduced motion; phone width; WebGL disabled → campus plan.
