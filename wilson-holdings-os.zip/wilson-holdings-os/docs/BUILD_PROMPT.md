# Wilson Holdings — Master Claude Code Build Prompt

Copy everything below into Claude Code, or place this file in the project and ask Claude Code to implement it in full.

---

You are my principal software architect, product designer, and implementation engineer. Build Wilson Holdings OS: a private, production-oriented application through which I direct my life and companies as a holding company. My name is Gabe Wilson. I own Atlas Insurance Agency and Atlas Consulting, which I describe as my contracting company. Verify the contracting business model during onboarding; do not assume it is construction, staffing, or advisory consulting. Support configurable project, retainer, placement, and time/materials workflows, activating only those that apply.

Implement working software, not a plan, slideshow, static dashboard, or interface with fake functionality. Make reasonable reversible decisions and proceed. Maintain a persistent implementation checklist and resume document. Credentials and external provisioning may block individual integrations; continue all independent implementation and report those blockers exactly. Do not declare the entire product complete until its acceptance criteria pass. Do not deploy publicly, incur paid services, contact people, or operate my accounts merely because you are building this app.

## 1. Outcomes and operating model

I am chairman and owner. The chief of staff is my main interface. Departmental agents prepare and execute work within explicit policies. Human company leaders and licensed professionals remain accountable for real-world work. AI job titles identify software responsibilities; they do not imply legal authority, professional licensure, or actual employees.

Optimize for time reclaimed, important goals advanced, reliable commitments, business visibility, and meaningful personal time. Track net time saved after review/correction costs. Protect focus and batch decisions. Agents must surface uncertainty, conflicts, source freshness, and blocked execution.

Create 11 buildings, 52 configurable agent roles, and real departments. Roles run on demand or on schedule; they are not 52 continuously running model sessions. Default global concurrency to 3, configurable downward/upward; enforce workspace, company, workflow, and daily usage budgets. Use event-driven work and bounded jobs. An avatar sitting at a desk is not proof of a running agent.

## 2. Organization: seed all 52 roles

Each role needs a durable ID, title, building, department, manager, charter, input/output schemas, allowed tools, accessible data scopes, evidence rules, escalation policy, triggers, model configuration, budget, and measurable success criteria. Display AI roles separately from real human team members.

### Headquarters: 4
1. Chief of Staff: intake, orchestration, consolidated briefings, decision queue, conflict resolution.
2. Strategy Director: annual/quarterly goals, milestones, weekly priorities.
3. Portfolio Director: time/capital allocation across companies and personal priorities; no double counting intercompany money.
4. Performance Analyst: scorecards, goal drift, net time savings, capacity constraints.

### Atlas Insurance Agency: 9
5. Insurance Operations Director: company operating plan, owners, exceptions, daily CEO update.
6. Recruiting Manager: candidate pipeline, source quality, interviews, recruiting follow-up drafts.
7. Licensing and Onboarding Coordinator: licensing progress, onboarding, state/carrier requirements from verified records; never invent eligibility.
8. Training and Activation Manager: training completion, bottlenecks, first-production readiness, coaching preparation.
9. Sales and Production Analyst: submitted/issued/placed/paid AP, conversion, cohort performance, persistency and chargebacks.
10. Lead Acquisition and Economics Analyst: lead cost, source cohorts, acquisition cost, cash contribution and economics.
11. Case Management and Retention Coordinator: pending cases, missing documents, service queues, retention and lapse indicators.
12. Commissions and Reconciliation Analyst: expected versus received commissions, advances, earned amounts, overrides, chargebacks and discrepancies.
13. Compliance and Carrier Research Coordinator: maintain sourced carrier/product material and policy review queues; route licensed judgments and regulated decisions to the appropriate human.

Departments: Growth; Licensing and Development; Production and Case Operations; Economics and Controls. The operations director coordinates these departments.

### Atlas Consulting: 9
14. Consulting Operations Director: delivery portfolio, capacity, company health, daily CEO update.
15. Business Development Manager: opportunities, accounts, next steps and forecast assumptions.
16. Scoping and Estimating Analyst: requirements, estimates, proposal drafts, pricing assumptions and exclusions.
17. Contracts and Change Coordinator: SOW drafts, obligation extraction, renewal dates, change requests, approval routing; no legal sign-off.
18. Project Delivery Manager: milestones, dependencies, project health, blockers, acceptance criteria.
19. Contractor and Capacity Coordinator: availability, assignment proposals, approved rates, qualifications and conflicts; no autonomous hiring/firing.
20. Quality and Acceptance Analyst: deliverable reviews, evidence, punch lists if relevant, client acceptance records.
21. Billing and Job Cost Analyst: budgets, approved time/expenses, invoice drafts, receivables and project margins.
22. Client Success Manager: status update drafts, risks, feedback, renewal/expansion opportunities.

Departments: Sales and Commercial; Delivery and Resourcing; Quality and Client Success; Project Finance. Provide configurable templates appropriate to the confirmed contracting model. Construction-specific capabilities, if requested later, need verified requirements rather than assumed terminology.

### Capital House: 4
23. Personal CFO; 24. Controller; 25. Investment Research Analyst; 26. Tax and Estate Coordinator.
Maintain separate personal/company books and cash positions. Investment research is sourced analysis, not autonomous trading. Professional review remains explicit.

### Human Performance Center: 4
27. Performance Director; 28. Training Programmer; 29. Nutrition Coordinator; 30. Recovery Analyst.
Use confirmed goals, logs, equipment, constraints and voluntary health data. Never infer diagnoses. Old injuries and goals require freshness rules. No medication changes or autonomous clinical decisions.

### Relationship House: 3
31. Relationship Coordinator; 32. Experiences Concierge; 33. Family and Friends Coordinator.
Support deliberate commitments, plans, important dates and user-supplied preferences. No covert monitoring, partner scoring, or automatic intimate messages.

### Executive Services: 3
34. Executive Assistant; 35. Travel Concierge; 36. Household Operations Manager.
Calendar, meeting preparation, buffers, travel research, errands, renewals and logistics.

### Opportunity and Ventures Lab: 3
37. Opportunity Analyst; 38. Due Diligence Analyst; 39. Experiment Manager.
Require investment memos, owner-time estimates, evidence, budgets and stop conditions. Park ideas that exceed capacity.

### Communications Studio: 3
40. Communications Director; 41. Content Producer; 42. Network Coordinator.
Separate personal/business voices and recipient scopes. Drafting does not authorize sending.

### Learning Institute: 2
43. Learning Curator; 44. Decision Coach.
Tie learning to active constraints; maintain decision journals and outcome reviews.

### Infrastructure and Assurance: 8
45. Systems Engineer; 46. Knowledge Steward; 47. Independent Auditor; 48. Integration Reliability Engineer.
Monitor jobs, access boundaries, evidence, stale data, reconciliation and verified action outcomes. Audits use deterministic checks wherever possible, with model review as an additional layer.

Internal Product and Engineering department:
49. Product Architect: translate plain-language ability requests into scoped specifications, reuse existing features, identify data/permission/integration requirements and define acceptance criteria.
50. Software Engineer: implement genuinely new capabilities in isolated branches/worktrees and sandboxed development environments, with migrations and tests.
51. Forms and Automation Builder: configure forms, intake portals, approval chains, reports, email templates and workflow definitions using versioned schemas rather than new code whenever possible.
52. QA and Release Engineer: independently validate changes, prepare preview environments, verify migration/rollback plans and coordinate explicitly authorized releases. A different role prompt alone is not sufficient isolation; enforce release permissions outside the agents.

These roles add an engineering office inside the existing infrastructure building. They must be reachable from the chief of staff and a dedicated Build Studio. The software engineer has an isolated development tool environment; this does not grant shell/code execution privileges to business agents.

## 3. Product experience and visual design

Create an exceptionally polished, modern private headquarters: architectural glass, warm stone, brushed metal, deep graphite, restrained champagne accents, luminous blue company indicators, refined typography, translucent panels, glass buttons, believable lighting and dimensional depth. Avoid illegible transparency, constant neon, clutter and generic KPI-card wallpaper. Define reusable design tokens for spacing, radius, shadows, blur, typography and motion.

Two synchronized interfaces share the same real application state:
- Campus mode: interactive 3D/isometric headquarters with all 11 labeled buildings, offices, desks, AI employee avatars, meeting rooms and purposeful transitions. Use React Three Fiber/Three.js if appropriate after checking current compatibility. Clicking a building opens its company/department; clicking an employee opens its profile, work queue, evidence and chat; clicking a meeting room opens its actual agenda/session. Provide orbit/reset controls, direct navigation, labels and camera focus. Create lightweight procedural geometry so the scene works without external paid assets.
- Focus mode: fast conventional workspace with the same entities, workflows, decisions, search and keyboard commands. Every important action must be accessible without navigating 3D. Mobile defaults here; offer a lightweight campus overview.

Use real state for idle, queued, running, waiting for approval, blocked, failed and complete. Never animate fake productivity. Seeded demonstration activity must be visibly marked demo. Provide keyboard navigation, accessible labels, contrast, reduced motion, screen-reader equivalents, low-power mode, WebGL failure fallback, lazy-loaded scene and adaptive rendering quality. Keep initial application load independent of 3D. No continuous rendering when the scene is hidden or motion can be paused.

Required views:
1. Chairman home: today's three outcomes, prepared next actions, company updates, decisions, exceptions and system health.
2. Campus and building interiors.
3. Agent directory/profile with reporting lines, real role permissions, history, tasks and pause controls.
4. Chief-of-staff chat, scoped agent DMs and department/company channels. Stream actual responses; persist messages and tool outcomes. Show user-facing rationale/evidence summaries, not hidden chain-of-thought.
5. Meetings: AI working sessions with selected participants, bounded rounds, agenda, visible contribution records, decisions, dissent and assigned actions. They must actually call configured agents. Separately support human meeting invitations/transcripts through connected services; do not pretend an AI meeting is a real video call.
6. Calendar: day/week/month, multiple accounts, personal/company overlays, drag/drop proposals, timezone-aware scheduling, conflicts and buffers.
7. Goals, projects, dependencies and work queues.
8. Atlas Insurance operations console.
9. Atlas Consulting delivery and financial console.
10. Approvals, external action history and audit evidence.
11. Integration marketplace and connection health.
12. Knowledge, document ingestion, search, source details and corrections.
13. Finance/health/relationships/household views with access controls.
14. Automation builder, run history, costs, policies and administrative settings.

Use searchable command navigation and deep links. Chat can propose structured changes to tasks, goals, calendar and policies, with previews and authority checks. Chat alone must not bypass policy controls.

## 4. Business records and dashboards

Insurance: people/candidates, recruiting sources, licenses, carrier appointments, training milestones, leads, cases, policy lifecycle events, commission ledger entries and reconciliation records. Mask sensitive client data by default. Distinguish headcount from productive agents, submitted from placed AP, advances from earned commission, and forecast from reconciled cash. Show period, cohort, currency, assumptions, record provenance and last sync. Do not hardcode historical team size, contracts, carrier rates or production goals as current facts.

Consulting: clients, opportunities, proposal versions, contracts/SOWs, deliverables, projects, milestones, contractor records, assignments, time/expenses, approved rates, change orders, acceptance records, invoices, payments and cost allocations. Show backlog, weighted pipeline with explicit assumptions, budget variance, delivery health, utilization where applicable, receivables aging and project contribution margin. Label cash versus accrual bases and internal estimates versus approved amounts. Avoid adding pipeline and contracted backlog as though they are the same money.

Both companies need separate permissions, accounts, calendars, channels, documents and credentials. Shared services operate only with granted scopes. Consolidated owner reports must preserve company-level detail and avoid intercompany double counting. AI identities and actual insurance agents/contractors are different entity types.

## 5. Updates and escalation

Create configurable schedules, defaulting to America/New_York with DST handled properly:
- 7:30 AM chairman briefing: calendar, three outcomes, overnight exceptions, company summaries, decisions and preparation.
- 5:30 PM company closes: each company reports changes, results, blockers, completed actions and tomorrow's commitments.
- Friday 3:00 PM executive review: progress against goals, cash/production/delivery signals, time allocation and decisions.
- Monthly owner report: company economics, personal cash visibility, capacity, health/commitment trends and system reliability.

These are seeded schedules, disabled until explicitly activated. Users can edit quiet hours and schedules. Deliver in-app first; external email/SMS/other delivery requires a configured destination and permission. Deduplicate alerts, respect quiet hours, group routine items, and escalate only against explicit thresholds. No data means an honest missing-data report, not fabricated figures.

Every update includes: reporting period, sources/freshness, what changed, outcome versus target, top blockers with owners, decisions with recommendations, actions already verified, next commitments. Estimate reading time. Default to concise; expand on demand.

## 6. Integrations: broad coverage with honest status

Build a connector framework and marketplace, not a claim that every service on earth has an API. Provider cards must have distinct statuses: catalog-only, adapter implemented, setup needed, authorized, syncing, healthy, stale, degraded, revoked and unsupported. Mark read/write capabilities individually. No fake Connect buttons or fabricated OAuth success.

Priority working adapters, implemented against current official documentation:
- Google Calendar: actual OAuth, list/read/create/update/delete within granted scopes; conflicts, refresh and verification.
- Gmail: search/read and draft creation; sending gated separately.
- Google Drive: authorized file listing/read/import and supported export paths.
- CSV/XLSX import with mapping preview, validation, deduplication, provenance and error report for both companies.
- A documented custom Atlas CRM adapter with configurable base URL, authentication, mapping and capability discovery. Do not guess private endpoints. Deliver a working local contract-test server and adapter tests; label live integration blocked until a verified API contract/access exists.
- Generic inbound/outbound webhooks with signing, schema validation, retries, replay protection and per-destination authority.

Expandable integration catalog; implement additional adapters in priority order after the core is verified. Verify provider availability and scopes before labeling supported:
- Microsoft Outlook/365, Calendar, OneDrive, Teams.
- Google Docs/Sheets, Slack, Zoom, Twilio, GroupMe, Telegram, WhatsApp Business where eligible.
- QuickBooks, Xero, Stripe and authorized bank-data aggregation providers; default financial access to read-only.
- HubSpot, Salesforce, GoHighLevel, Airtable, Notion, Asana, ClickUp, Monday, Trello.
- DocuSign or equivalent for prepared signing workflows with explicit authority.
- WHOOP, Oura, Fitbit, Garmin and Strava where official access permits. Apple Health requires a companion app/authorized export route; do not pretend a web app can directly read it. Use file import when APIs are unavailable.
- Calendly, supported travel/weather/maps providers, GitHub, Dropbox, S3-compatible storage.
- Zapier, Make, n8n, approved MCP servers and documented custom REST adapters for long-tail services.

For every adapter implement a consistent interface: capabilities, authorize, refresh, revoke, health, pull, normalize, proposeWrite, executeAuthorizedWrite and verify. Use versioned cursors, incremental sync, rate-limit backoff, token refresh locking, scoped account selection, idempotency and deletion handling. Outbound arbitrary HTTP destinations and user-added MCP servers require allowlists and explicit trust configuration; prevent SSRF and access to infrastructure metadata/private networks unless specifically configured for a trusted internal connector. Never execute arbitrary connector package code in the web process.

Do not couple all other development to credentials. A missing provider secret results in setup-needed with actionable instructions, while the rest of the app runs. Demo mode uses a separate database namespace and conspicuous banner; demo writes never reach real providers.

## 7. Runtime and architecture

Inspect the repository before choosing changes. For a new project, prefer a typed TypeScript stack: Next.js/React web application, Tailwind and accessible headless components, PostgreSQL with migrations, a durable queue/scheduler backed by Redis or another justified durable engine, object storage abstraction and a separately deployed worker. Check current official documentation and compatible stable dependency versions; commit a lockfile. Use Docker Compose for reproducible local dependencies. Do not overcomplicate deployment with microservices that provide no operational benefit.

Claude Code is the development tool. Use a server-side Anthropic Agent SDK integration for application agents if it meets verified deployment requirements; document its binary/runtime/authentication dependencies. Keep the model runtime behind an adapter so a direct Anthropic API tool loop can be used if needed. Never spawn an unrestricted developer shell from a user chat. No API tokens in the browser. Do not assume the user's Claude subscription includes production API usage.

Business tools must be narrowly typed application functions. Coding tools, filesystem shell access and deployment credentials are unavailable to business agents by default. Worker execution is isolated with CPU/time/tool/cost limits. Agent-generated code cannot be executed as an ordinary business action. Use deterministic code for financial arithmetic, authorization, scheduling and state transitions; models interpret and prepare structured proposals.

Roles are configuration records, with versioned prompts and optional generated .claude/agents files for developer workflows. Runtime work must not depend on undocumented nesting behavior or 52 permanent terminals. The orchestrator dispatches queued jobs explicitly and enforces concurrency and delegation depth.

Task state machine: proposed, queued, running, waiting_approval, blocked, succeeded, failed, cancelled. Support leases, heartbeats, cancellation, retries, dead-letter handling and restart recovery. Separate approval from execution and execution from verified success. Distinguish succeeded, failed and uncertain external outcomes. Reconcile uncertain outcomes before retries; never blindly resend payments/messages/events.

## 8. Data and memory

Implement organizations, companies, departments, users, human members, agent definitions, policies, goals, projects, tasks, runs, messages, channels, meetings, decisions, approvals, action attempts, audit events, sources, knowledge facts, documents, calendar records, integration accounts, sync cursors, metric definitions and snapshots, notification rules, usage/cost events, and the domain records above.

All relevant rows have ownership scope, stable IDs, timestamps, provenance, retention rules and version/concurrency controls. Enforce isolation server-side and at the data layer where applicable, including background jobs and search. Vectors are retrieval aids, never the source of truth. Facts record source, observed/verified dates, validity period, confidence category and supersession history. Show contradictions and stale facts. Changes to sensitive memories require explicit user intent. Support correction, export and deletion workflows.

Onboarding confirms owner identity, businesses, contracting model, human leaders, current goals, calendar accounts, data sources, budgets, quiet hours, standing permissions and sensitive-data preferences. Do not import unrelated people's school/baseball projects into Gabe's records. Do not preload unverified personal history as current truth.

## 9. Authority, security and reliability

Policies define observe, prepare, execute-within-policy and escalate. Default external writes to prepare-only. Allow users to establish narrow standing permissions; do not ask again for already-authorized in-policy actions. Approval payloads bind actor, company, account, recipient/resource, content hash, amount, timing, expiry and scope. Material changes invalidate approval. One approval cannot be replayed to produce duplicate actions.

Use proper authentication, MFA support where available, secure sessions, RBAC plus resource scopes, encrypted transport, protected credentials, environment/secret validation, log redaction, audit trails and tested backup/restore procedures. Relationship and health scopes are private by default. Sensitive insurance/client records need strict minimization and access controls. Do not claim legal/regulatory certification merely because controls exist.

Protect against prompt injection: external emails, documents, webpages and tool results are untrusted data. They cannot change policy, permissions, tool destinations or system instructions. Retrieval and delegation must preserve access scope. Apply controls outside model prompts. No autonomous trading, money transfers, contract execution, hiring/firing or intimate messaging by default. Global pause and per-agent/company/connector pause must stop pending execution; recheck revocation immediately before writes.

## 10. Required vertical slices and acceptance tests

Implement sequentially; keep earlier slices working:
1. Auth, database, organization seed, design system, polished chairman home and real editable goals/tasks.
2. Interactive campus and focus mode linked to the same persisted entities.
3. Chief-of-staff chat and actual bounded agent runs, streamed events, tool permissions, costs, pause/cancel and persisted history.
4. Both company consoles, import flows, validated calculations and source drill-down.
5. Approval/action/verification pipeline and Google Calendar plus Gmail draft integrations.
6. Scheduled briefings, durable workers, notifications, agent meetings and connection health.
7. Hardening, accessibility, mobile, documentation and additional prioritized connectors.

Required meaningful verification:
- Owner can log in, inspect 52 roles across 11 buildings, change a goal, restart the app and see it persisted.
- Selecting a 3D employee and selecting the same role in focus mode opens the same real records.
- With an actual model credential, chief-of-staff dispatch invokes allowed tools and returns source-grounded results. Missing credentials are clearly identified; demo output is labeled.
- Insurance import produces distinguishable submitted/placed/paid metrics; consulting import produces correct job cost/receivables calculations. Validate known fixtures, malformed files, duplicate imports and money rounding.
- Company scopes and sensitive personal scopes resist unauthorized reads/writes, including through chat, retrieval and background workers.
- A calendar proposal needs appropriate authority, creates exactly one event, verifies it, survives a retry and records its remote ID. Test uncertainty/reconciliation paths.
- A revoked or altered approval cannot execute. Global pause prevents queued external writes.
- OAuth state/PKCE where appropriate, token refresh, webhook signatures and secret redaction are tested.
- A scheduled briefing runs once per intended reporting window across restart and DST cases; stale sources are disclosed.
- A bounded agent meeting generates persisted decisions/tasks with owners and evidence; agents cannot loop indefinitely.
- Keyboard/reduced-motion/mobile/non-WebGL flows remain usable. Empty, loading, error and disconnected states are designed and tested.
- Production build, typecheck, relevant unit/integration tests and browser end-to-end flows pass. Record actual results; never fabricate passing checks or external integrations.

## 11. Executive brain: durable memory, connected advice and learning

This is a core requirement, not a future feature: the application must operate as a coherent executive intelligence system with durable memory. The model itself is not a permanent brain. Build the persistence, retrieval, verification and feedback machinery that enables useful continuity across sessions and model changes. Do not claim consciousness, perfect recall, or automatic model training. Improvement comes from better authorized records, retrieval, explicit feedback and evaluated workflow changes.

### A. Seven complementary memory systems

1. Identity and preferences: confirmed goals, values, priorities, communication preferences, boundaries, decision style, schedule preferences and present constraints. Track which person owns each fact. Distinguish a passing request from an enduring preference. Require explicit intent before saving sensitive personal information.
2. Semantic memory: verified facts about my businesses, people, products, projects, responsibilities and operating policies. Every fact has provenance, effective dates, last verification and confidence category.
3. Episodic memory: dated events, meetings, actions, feedback, decisions and meaningful conversations. Preserve the distinction between what was proposed, promised, attempted, verified and reported by another person.
4. Working memory: active priorities, current projects, unresolved questions, open loops and near-term constraints. Keep this small and refresh it before each consequential workflow.
5. Procedural memory: approved playbooks, preferred workflows, checklists and decision rules. Proposed lessons do not automatically alter executable procedures or tool permissions.
6. Relationship/entity memory: explicitly authorized links among people, companies, accounts, commitments, projects, contracts and goals. Implement typed relationships in relational tables initially; use a graph database only if justified. Never infer intimate facts or covertly profile others.
7. Outcome memory: predictions, assumptions, chosen actions, observed results, user corrections and postmortems. Record both successful and unsuccessful recommendations. Absence of a reported outcome is unknown, not success.

For each memory record store: ID, type, subject/entity, owner and company scope, original source reference and excerpt pointer, assertion, source reliability category, observed/valid dates, verification date, status, sensitivity, retention/expiry, supersedes/conflicts-with links, and embedding/model version where relevant. Use explicit user-confirmed/source-confirmed/inferred/unverified labels rather than invented numerical certainty. Preserve source evidence separately from generated summaries.

### B. Ingestion, consolidation and correction

Ingest only authorized chats, notes, connected records, documents, meeting material and user feedback. Classify scope and sensitivity before indexing. Extract candidate facts into a reviewable staging layer; do not make every sentence a permanent fact. Deduplicate, resolve entities cautiously, detect contradictory assertions and keep historical versions. Show material conflicts for review instead of silently overwriting them.

Run bounded consolidation jobs to summarize relevant events, identify open commitments, suggest preference updates and propose lessons. Every summary retains source references and can be rebuilt. Consolidation must not amplify an inference into a verified fact. Documents and imported instructions cannot change system policy. Memory writes are subject to tool policy and access control.

Provide a Brain/Memory view with search, entity timeline, source evidence, active assumptions, stale facts, conflicts and proposed lessons. Support 'remember this', 'this changed', 'that is incorrect', 'forget this', 'do not remember this conversation', and private-session mode with explicit retention behavior. Forgetting must remove or invalidate derived summaries, embeddings, caches and future retrieval references; document backup retention and deletion limits honestly. No silent resurfacing from scheduled imports: support source-level exclusion/tombstones where appropriate.

### C. Retrieval and context assembly

Before giving personalized advice, assemble a task-specific context packet: current goal, relevant constraints/preferences, fresh authoritative records, related prior decisions, outcome history, unresolved conflicts and permitted actions. Use hybrid lexical/vector retrieval plus entity/date filters. Enforce access scopes before retrieval and again before context assembly; cross-company summaries require explicit grants and minimize details. Semantic similarity never grants permission.

Use freshness requirements appropriate to the task: calendar availability needs a current check; an old pricing sheet cannot silently establish today's price. Prefer authoritative current records over stale summaries. When required data is missing, ask one targeted question or give a clearly conditional recommendation. Do not retrieve the entire life history for every question. Track retrieval lineage so I can inspect which memories influenced an answer.

### D. Advice that connects the whole picture

Advice should consider goals, time, cash, capacity, relationships and health when relevant and permitted. Detect competing commitments and identify the actual tradeoff. Never reduce all personal choices to business return. My stated values and personal priorities outrank a simplistic revenue objective.

For consequential recommendations produce a concise decision memo containing: decision/question; relevant facts and sources; assumptions and unknowns; feasible options including deferral where relevant; recommended action; expected benefits and costs; effects on time/cash/commitments; risks and reversibility; what would change the recommendation; and next review date. Offer expanded evidence on demand. Show an explanation of factors and evidence, never hidden chain-of-thought or fabricated internal deliberation.

Example behavior: if I ask whether to take on an Atlas Consulting project, check authorized delivery capacity, project economics, Atlas Insurance priorities, travel and protected commitments, and previous comparable project outcomes. Return a conditional recommendation with sources and missing inputs. Do not assert that observed correlations establish causation. If I report poor sleep, do not automatically cancel work or make a medical inference.

### E. Reports that accumulate understanding

Reports compare current period against prior periods, targets and prior commitments. Persist report snapshots, source cutoffs and metric definitions so comparisons remain reproducible. Explain changes using supporting evidence; separate measured drivers, plausible hypotheses and unknown causes. Show what last week's report recommended, whether it was acted on, and the observed outcome. Avoid repeating unresolved issues without updating owner, next step and age.

Monthly and quarterly reports identify recurring bottlenecks, forecast-versus-actual differences, failed assumptions, time allocation patterns and possible changes to playbooks. Lessons are proposals until reviewed or permitted under a narrow standing policy. Operational reports should be useful even if model services are down, using deterministic queries and clearly labeled missing narrative analysis.

### F. Learning and quality evaluation

Capture explicit thumbs-up/down, corrections, user edits, accepted/rejected advice, execution results and later outcomes with minimal friction. Do not equate approval with correctness or disagreement with user error. A lesson must cite examples and contrary evidence where present. No self-modification of authority, security policies or production prompts without controlled versioning and review.

Maintain a versioned evaluation set with synthetic/anonymized cases: preference recall, temporal changes, identity ambiguity, conflicting sources, numerical correctness, cross-company leakage, sensitive-memory exclusion, forgotten facts, prompt injection, unsupported conclusions and stale data. Compare changes to retrieval/prompt/workflow versions against the baseline before promotion. Track source-grounded answer rate, correction rate, stale-memory incidents, unauthorized retrieval attempts, cost and time saved; define the denominator for each metric. The same model agreeing with itself is not independent verification.

### G. Required brain acceptance tests

- A confirmed preference persists across restarts and changes a relevant future plan; an unrelated preference is not retrieved.
- A corrected preference supersedes the old one, while a dated historical query can still distinguish past from current truth.
- A company record change triggers an updated report using the new authoritative source, with previous snapshots preserved.
- A recommendation references relevant prior decisions/outcomes and labels missing evidence rather than inventing a pattern.
- Private-session content and forbidden scopes do not enter memory, search results, reports or agent handoffs.
- Forgetting a fact removes it from active derived retrieval and prevents its reintroduction through the excluded source according to the documented retention policy.
- Contradictory sources produce a visible conflict; stale assumptions are not presented as confirmed facts.
- A model/runtime switch preserves durable facts and history, with compatible reindexing where needed.
- A malicious document cannot turn its instructions into policies, verified memories or an authorized external action.
- Report numbers can be recomputed from their recorded data cutoffs and metric versions; unsupported causal explanations are flagged.

Build a working memory vertical slice alongside agent chat, before treating personalization or the chief-of-staff experience as complete. Demonstrate ingestion, retrieval with citations, correction, expiry and deletion end to end. This section adds responsibilities to the existing Knowledge Steward, Performance Analyst, Decision Coach and Independent Auditor; it does not require more permanent agents.

## 12. Build Studio: add abilities without rebuilding the application

Make this an extensible product with an internal engineering capability, not a fixed collection of dashboards. From chief-of-staff chat I can say: 'Create a contractor intake form for Atlas Consulting, save responses to the contractor directory, prepare a confirmation email, and add a review task to the delivery manager.' The request must produce an actual editable, testable form and workflow using existing modules wherever possible. Do not require a developer deployment for every form, field, email template or workflow edit.

### Configuration path: everyday changes

Build a versioned capability registry and typed schema-driven builders for forms, custom fields, record types, views, dashboards, reports, email templates and workflow graphs. Use allowlisted components and action types, validated server-side; never evaluate arbitrary JavaScript from configuration. Use additive custom metadata/field schemas rather than altering SQL tables per field. Major structural changes still need controlled migrations. Each capability records ownership scope, version, dependencies, triggers, inputs/outputs, tools, permission requirements, owner, tests and activation state. Definitions must be exportable and recoverable.

Forms support accessible field types, validation, conditional visibility, required fields, file uploads, consent text, multi-step layouts, preview, drafts, published versions, submissions and typed record mapping. Add public/private access modes, expiring invitation links if appropriate, rate limiting, spam controls and protected uploads. Public forms must not expose internal records, secrets or unrestricted lookup APIs. Store company ownership and provenance on submissions. Freeze the form version used for each submission. Sensitive-data collection must be deliberate and minimized.

Workflows support intake events, conditional branches, owner assignment, waiting/approval steps, notifications, calendar proposals, permitted integrations, retries and error queues. Provide a visual editor and a plain-language builder that produces the same validated definitions. Test with sample inputs before activation. Detect cycles or enforce bounded repetitions. Automation definitions cannot grant their own permissions.

Private reversible configuration changes can activate under an explicit standing policy. Publishing a public form, emailing external recipients or enabling external writes requires appropriate authority. Present the actual preview, affected records, permission changes and expected downstream actions before approval. Changing a workflow does not expand a previously granted external-action policy.

### Code path: genuinely new abilities

When configuration cannot meet the request, Product Architect creates a concrete change specification. Software Engineer works on an isolated repository branch/worktree and ephemeral sandbox using synthetic or redacted data, scoped repository credentials, resource limits and controlled network egress. It must never edit the running production filesystem, database or its own execution policy. Production secrets are unavailable to coding runs. Untrusted repository instructions and documents cannot expand sandbox privileges.

Produce a diff, tests, migration analysis, dependency/security checks, working preview and rollback plan. QA and Release Engineer runs independent checks against the acceptance criteria. Release requires an authorized action bound to the exact artifact/commit, environment and migration plan. If CI, repository or deployment access is missing, provide the tested change and exact blocker; do not pretend it is released. Support GitHub initially through verified interfaces or local git with a documented manual release path. Additional repository/hosting providers use adapters.

Use feature flags, versioned contracts and backwards-compatible migrations where possible. Rolling back code does not automatically reverse database writes; document recovery and test migrations against a disposable copy. Installable third-party extensions require a separate trust decision. Never silently install packages or execute arbitrary code from a marketplace request. Track build cost, progress, failures, approval status and deployed version in Build Studio.

### Email workspace: real composing and permitted sending

Provide an email composer reachable from any relevant entity, chief-of-staff chat and company workspace. Support new messages, replies and forwards, subjects, recipients, CC/BCC, safe attachments, signatures, templates, preview and company/account selection. Use confirmed recipient identities; do not guess addresses. Draft with scoped memory and source context, and show material missing facts before sending. Sanitize rendered HTML, detect cross-company leakage and keep drafts separate from sent records.

Implement Gmail read/search, thread retrieval, draft creation/update and actual sending via current official APIs with separate scopes and explicit authority. Sending may operate under narrow standing policies established by me; otherwise require approval for the exact message, account, recipients and attachments. Prevent duplicate sends, preserve thread IDs, and reconcile ambiguous provider responses before retrying. Show provider-accepted versus delivered accurately; do not claim delivery without evidence. Scheduled sends need durable jobs, cancellation, current permission checks and freshness checks before execution. Email marketing/bulk messaging is a separate capability with additional requirements, not an implied extension of one-to-one email access.

Outlook support is a separately implemented adapter, with honest setup/status labels. No connection to my actual email is implied by having an integration card.

### Calendar onboarding and coordination

Make Connect Calendar a prominent setup step. Let me authorize my personal and each company's Google accounts separately, choose calendars, pick read/write scopes, set working hours, protected blocks, timezone, buffers and meeting rules. Provide the equivalent through a Microsoft adapter when implemented. OAuth must involve my actual account consent; never fabricate a connection. Handle revocation, partial access and reconnect flows.

Calendar workflows must list real availability, propose conflict-aware slots, create/update/cancel events within authority, handle recurring-event scope explicitly and verify remote results. Creating an event with attendees can send invitations; disclose this in the action preview and apply person-directed permissions. Treat external invitations/notifications separately from private time blocks. Keep relationships, health and confidential business event details masked in shared views. Show last sync, source calendar and authoritative remote event ID. Changes require concurrency protection; do not overwrite a newer remote event silently.

### Build Studio acceptance scenarios

1. Request the contractor intake form in chat. Preview, edit and publish it under authorization. Submit a sample, create exactly one correctly scoped contractor record and review task, and prepare a real saved email draft. If email is disconnected, retain a local draft marked not synced. Replaying the submission does not duplicate downstream work.
2. Change a field and automation through chat and the visual editor without redeploying the app. Existing submissions retain their original schema version. Pause and roll back the definition while preserving history.
3. Request a genuinely new coded report/tool. Produce an isolated tested branch, functioning preview, release approval request and visible capability/version status. No production change occurs before authorized release.
4. Connect an actual test Google account where credentials are available, create a draft and privately scoped event, verify remote objects, and test revocation. If credentials are unavailable, show setup-needed and exercise the contract-test adapter without claiming live verification.
5. An engineering request cannot access personal messages, company secrets or production credentials without a specific grant, or escalate itself from development to deployment.

## 13. Delivery and continuation

Create working code, schema/migrations, seed and demo datasets, tests, .env.example without secrets, local start scripts, worker commands, container definitions, setup guide, deployment guide, connector capability matrix and operational runbook. Supply backup/restore and key-rotation procedures, data map, cost controls and a manual acceptance checklist. Record exact commands run and limitations.

Maintain IMPLEMENTATION_STATUS.md and NEXT_STEPS.md with completed slices, blockers, tests and the next executable task so another session can resume. External deployment requires an explicitly authorized target and verified configuration. Provide a realistic monthly cost worksheet based on actual selected providers and observed usage, with unknowns labeled.

At the end, distinguish implemented, locally tested, live-provider verified, credential-blocked and deferred features. Provide the local URL and setup commands. Never call an adapter connected merely because its settings screen exists.

Begin by inspecting the workspace, confirming the architecture against current official documentation, writing a short implementation checklist, and building slice 1. Continue through the slices without stopping at the plan. Favor a complete, verifiable workflow over adding decorative screens. Preserve the premium campus vision throughout.
