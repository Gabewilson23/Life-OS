# Connector capability matrix

Status meanings: **implemented** (code + automated contract tests here) · **live-verified** (exercised against a real provider account) · **catalog-only** (listed, not built) · **unsupported**.

| Connector | Read | Write | Status | Live-verified? | Notes |
|---|---|---|---|---|---|
| Google Calendar | calendars, events (incremental sync tokens, 410 → full resync) | create/update/delete event — approval-gated, deterministic event ID, ETag `If-Match`, verified after write | implemented | **No** — no Google credentials in the build environment | Invitations disclosed when attendees are present |
| Gmail | search, message metadata | draft create (approval-gated; verified via `X-WH-Idempotency` header); send gated separately | implemented | **No** | `gmail.compose` technically allows sending; the app gates it |
| Google Drive | list, read/export Docs (text) & Sheets (CSV) | — | implemented | **No** | read-only scope |
| CSV / XLSX import | mapping preview, validation, dedupe, provenance, error report | — | implemented | n/a (local) | 5 MB limit |
| Webhooks | signed inbound (HMAC-SHA256 over `ts.nonce.body`, 300 s window, event-id dedupe, schema) | signed outbound to allowlisted HTTPS (SSRF guard, retries, idempotency key) | implemented | n/a | inbound events become proposals/notifications, never actions |
| Atlas CRM (custom REST) | capability discovery, paginated agents via configured mapping | — | implemented against a **local contract server only** | **Blocked** — needs a verified API contract + credentials | contract below |
| Outlook/365, Slack, Zoom, Twilio, Telegram, WhatsApp, GroupMe, QuickBooks, Xero, Stripe, bank aggregation, HubSpot, Salesforce, GoHighLevel, Airtable, Notion, Asana, ClickUp, Monday, Trello, DocuSign, WHOOP, Oura, Fitbit, Garmin, Strava, Calendly, GitHub (as data source), Dropbox, S3, Zapier/Make/n8n, MCP | — | — | catalog-only | — | verify provider availability/scopes before building |
| Apple Health | — | — | unsupported | — | needs a companion iOS app or export-file import |

Every implemented adapter follows the same interface: `capabilities, authorize/refresh/revoke (shared OAuth), health, pull, proposeWrite, executeAuthorizedWrite, verify` (`src/lib/server/integrations/adapters.ts`).

## Atlas CRM contract (what the adapter expects)
```
GET {base}/capabilities        → {"version":"1","resources":[{"name":"agents","fields":["…"]}]}
GET {base}/agents?cursor=…     → {"items":[{…}],"next_cursor":"…"|null}
Auth: header named in config (e.g. x-api-key) with the stored secret.
Mapping (config, not guessed): {"key":"agent_no","fields":{"display_name":"name","kind":"kind","state":"stage"}}
```
If the real CRM differs, add a mapping layer — do not guess private endpoints.
