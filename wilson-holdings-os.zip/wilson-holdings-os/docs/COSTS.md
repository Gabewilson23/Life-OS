# Monthly cost worksheet (fill in with your actual plans and usage)

Prices change — check each provider's pricing page; nothing here is a quote.

| Item | Plan you choose | Monthly cost | Notes |
|---|---|---|---|
| Netlify | Free / Personal / Pro | ? | Functions invocations + the 5-minute tick (~8,600 invocations/month) |
| Supabase | Free / Pro | ? | Free projects pause when idle; Pro adds daily backups |
| Supabase IPv4 add-on | not needed | 0 | app uses the IPv4 pooler |
| Anthropic API | usage-based | ? | Track in-app: set MODEL_PRICE_* env vars so runs record cost; otherwise cost shows "unknown" while tokens are still counted |
| Google Cloud (Calendar/Gmail/Drive APIs) | free quotas | usually 0 | |
| GitHub | Free/Team | ? | Actions minutes for CI |
| Optional worker host | Railway/Fly/Render | ? | only if you outgrow Netlify's ~30 s limit |

Usage levers in the app: per-role `budget.daily_usd`, `max_runs_per_day`, global `AGENT_CONCURRENCY`, `max_tool_rounds`. Observed usage: Home → System health and `usage_events`.
