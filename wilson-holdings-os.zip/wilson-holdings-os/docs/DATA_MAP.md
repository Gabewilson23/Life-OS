# Data map

| Area | Tables | Scope | Sensitivity | Retention |
|---|---|---|---|---|
| Identity & access | users, sessions, user_scope_grants, login_attempts | org (no RLS policy for app role) | secret (password hashes, MFA secrets encrypted) | sessions 7 days max |
| Org design | organizations, companies, buildings, departments, agent_definitions, agent_prompt_versions, policies | org / company | standard | permanent, versioned |
| Work | goals, tasks, daily_outcomes | any scope | per scope | soft-delete |
| Agents | runs, run_transitions, run_events, usage_events, proposals, retrieval_lineage | agent scope | per scope | keep; prune events after 180 days (next step) |
| Chat | channels, messages | agent scope | per scope; **private sessions expire after 24 h** | private: 24 h |
| Memory | memory_records, memory_tombstones | any; health/relationships/finance = private | sensitive needs explicit intent | forget erases text + lineage; tombstones block re-import |
| Insurance | ins_people, ins_policies (client names **masked by default**), ins_commissions, ins_lead_costs, import_batches | company:atlas-insurance | confidential | per company policy |
| Consulting | con_* tables | company:atlas-consulting | confidential | per company policy |
| Integrations | integration_accounts (tokens AES-256-GCM encrypted), oauth_states, sync_cursors, calendar_events, email_drafts | account scope | confidential | revoke deletes tokens |
| Authority | approvals, standing_permissions, action_attempts, audit_events (append-only) | per scope | standard | permanent |
| Cadence | schedules, schedule_runs, reports, notifications, worker_heartbeats | per scope | per scope | reports permanent (reproducible snapshots) |
| Studio | capabilities, capability_versions, form_submissions (IP stored only as salted hash), custom_records, workflow_runs, change_requests | per scope / engineering | submissions may contain personal data | define per form |
| Webhooks/connectors | webhook_endpoints (secrets encrypted), webhook_deliveries, connector_configs | per scope | confidential | deliveries: prune after 90 days (next step) |
