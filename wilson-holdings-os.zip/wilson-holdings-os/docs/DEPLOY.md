# Deploying Wilson Holdings OS — GitHub + Supabase + Netlify

This takes about 30–45 minutes. Nothing here is automated on your behalf: you create the accounts, paste the secrets and click deploy. Order matters.

```
GitHub (code) ──push──▶ Netlify (builds & hosts the Next.js app + 5-minute scheduled tick)
                              │
                              └──▶ Supabase Postgres (all data; app connects via the transaction pooler)
GitHub Actions ── "Migrate database" (manual) ──▶ Supabase (schema migrations + org seed)
```

## 1. Put the code on GitHub
1. Create a **private** repository (e.g. `wilson-holdings-os`). Do not add a README/licence (the repo already has them).
2. From the unzipped project folder:
   ```bash
   git remote add origin git@github.com:<you>/wilson-holdings-os.git
   git push -u origin main        # the history already contains commits
   ```
3. The `CI` workflow (`.github/workflows/ci.yml`) runs typecheck, tests (against a throwaway Postgres) and a build on every push.

## 2. Create the Supabase project
1. supabase.com → **New project**. Pick a region near you (e.g. `us-east-1` for New York). Save the database password in a password manager.
2. Click **Connect** (top of the dashboard). Copy two strings:
   - **Transaction pooler** (port **6543**) → used by the website on Netlify (serverless).
   - **Session pooler** (port **5432**) → used only for migrations from GitHub Actions (supports the advisory lock the migration runner uses).
   Both pooler hosts are IPv4, which GitHub runners and Netlify need; the "direct connection" is IPv6-only on most plans.
3. You do **not** need Supabase Auth, Storage or the Data API. The app has its own auth. Migration `002` removes all access for Supabase's `anon` / `authenticated` roles so nothing is exposed through the Data API.

## 3. Run the database migrations (GitHub Actions)
1. GitHub repo → **Settings → Environments → New environment** `production`.
2. Add environment secret **`SUPABASE_DB_URL`** = the **session pooler** string (with your password filled in).
3. **Actions → "Migrate database" → Run workflow** (leave "seed" checked). It applies `db/migrations/*.sql` in order and seeds the 11 buildings, 52 roles, policies and the (disabled) schedules. It is safe to re-run.

> Locally instead: `DATABASE_URL="<session pooler>" DATABASE_SSL=require SESSION_SECRET=x… npm run db:migrate && npm run db:seed`

## 4. Generate secrets
Run this four times and keep each value:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('base64url'))"
```
→ `SESSION_SECRET`, `SETUP_TOKEN`, `TOKEN_ENCRYPTION_KEY`, `CRON_SECRET`.
**Back up `TOKEN_ENCRYPTION_KEY`.** Losing it means reconnecting Google accounts and re-enrolling MFA (see RUNBOOK.md → key rotation).

## 5. Create the Netlify site
1. app.netlify.com → **Add new site → Import an existing project → GitHub** → choose the repo. Netlify detects Next.js; `netlify.toml` sets the build (`npm run build`, Node 22).
2. **Before the first deploy**, open **Site configuration → Environment variables** and add:

| Variable | Value |
|---|---|
| `APP_ENV` | `production` |
| `APP_URL` | your Netlify URL, e.g. `https://wilson-holdings.netlify.app` (update if you add a custom domain) |
| `DATABASE_URL` | Supabase **transaction pooler** string (port 6543) |
| `DATABASE_SSL` | `require` |
| `DATABASE_POOL_MAX` | `2` |
| `SESSION_SECRET`, `SETUP_TOKEN`, `TOKEN_ENCRYPTION_KEY`, `CRON_SECRET` | from step 4 |
| `DEFAULT_TIMEZONE` | `America/New_York` |
| `ANTHROPIC_API_KEY` | optional now; agents show "credential missing" until set (this is API billing, separate from a Claude subscription) |

3. Deploy. When it finishes, open `https://<site>/api/health` — it should say `{"ok":true,"db":"up","migrations":7}`.
4. Open `https://<site>/setup`, enter `SETUP_TOKEN`, your name, email and a 12+ character password. This creates the single owner account. Then **Settings → Sign-in security → Set up MFA**.

The scheduled function `netlify/functions/tick.mts` runs every 5 minutes and calls `/api/cron/tick` with `CRON_SECRET`. Schedules stay **disabled** until you activate them in **Briefings**.

## 6. Connect Google (optional, when ready)
1. console.cloud.google.com → new project → **APIs & Services → Enable**: Google Calendar API, Gmail API, Google Drive API.
2. **OAuth consent screen**: External (or Internal if you use Google Workspace), add your own account(s) as test users.
3. **Credentials → Create OAuth client ID → Web application**. Authorized redirect URI: `https://<site>/api/integrations/google/callback`.
4. Add `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` to Netlify env and redeploy.
5. In the app: **Integrations → Connect a Google account** — once for personal, once per company account, choosing capabilities per account.

## 7. Known hosting limits (honest)
- **Netlify function time limit (~30 s).** Chat runs, multi-round AI meetings and big imports must finish inside it. Keep meetings to 1–2 rounds with few participants. For heavier use, run the background worker on a host without that cap (Railway, Fly.io, Render, a small VPS): `npm run worker` with the same env vars. It is safe to run alongside the Netlify tick — schedule windows and run leases are claimed in the database, so nothing runs twice.
- **Streaming**: chat streams via Server-Sent Events; if a proxy buffers it, responses appear at the end instead of token-by-token.
- **Supabase free tier** pauses projects after inactivity; a paused DB makes the app show "db down" until resumed.
- **Backups**: Supabase daily backups depend on plan. See RUNBOOK.md.

## 8. Updating
Push to `main` → CI → Netlify redeploys automatically. If the push contains a new `db/migrations/00N_*.sql`, run **Actions → Migrate database** *before* (or right after) the deploy. Migrations are additive.
