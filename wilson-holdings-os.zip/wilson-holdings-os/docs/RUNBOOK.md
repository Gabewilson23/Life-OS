# Operations runbook

## Emergency stop
- **Global pause**: Settings → Emergency controls. Stops agent runs and all external writes (re-checked immediately before every write).
- **Per role**: pause on the role profile (cancels its queued runs, flags running ones).
- **Per connector**: Integrations → Pause / Revoke (revoking voids pending approvals for that account).
- **Per company**: set system flag `pause.scope:company:<slug>` = `true` (SQL) — external actions for that company stop.

## Health
- `/api/health` — DB reachability and migration count.
- Home → System health: model credential, background runner heartbeat, connected accounts.
- Briefings page shows the last heartbeat of the scheduled tick / worker.

## Backups & restore (Supabase)
- Supabase takes daily backups on paid plans (point-in-time recovery is an add-on). Free projects: run your own.
- Manual logical backup (use the **session pooler** or direct URL):
  `pg_dump "$SUPABASE_DB_URL" --no-owner --format=custom -f wh-$(date +%F).dump`
- Restore into a **new** project first, verify, then switch `DATABASE_URL`:
  `pg_restore --no-owner --clean --if-exists -d "$NEW_DB_URL" wh-YYYY-MM-DD.dump`
  Then re-run the Migrate workflow (idempotent) so the `wh_app` role and grants exist.
- Test a restore at least quarterly. Record the date here.
- **Deletion and backups**: "Forget" removes text from live data immediately, but backups keep prior data until they age out under your plan's retention window. Restoring an old backup can reintroduce forgotten facts — re-apply tombstones after any restore (`memory_tombstones` survives in newer backups).

## Key rotation
- `SESSION_SECRET`: change it → redeploy. Public-form rate-limit hashes reset; sessions are DB-backed and are not invalidated by this alone — to force sign-out: `UPDATE sessions SET revoked_at = now();`
- `TOKEN_ENCRYPTION_KEY`: tokens/secrets encrypted with the old key become unreadable. Procedure: (1) set new key, (2) redeploy, (3) reconnect Google accounts, recreate webhook endpoints, re-enroll MFA (`UPDATE users SET mfa_enabled=false, mfa_secret=NULL` first). A dual-key re-encryption script is a listed next step.
- `CRON_SECRET`: update in Netlify env; the function reads it at run time.
- Google client secret: rotate in Google Cloud, update env, redeploy. Existing refresh tokens keep working.
- Database password: reset in Supabase, update `DATABASE_URL` in Netlify and `SUPABASE_DB_URL` in GitHub.

## Uncertain external actions
Approvals → an attempt shows `uncertain` or `failed`. Use **Reconcile & retry safely**: it looks the object up at the provider first and only re-sends with the same idempotency key if it is confirmed absent. Never re-create manually.

## Incident checklist
1. Global pause. 2. Check Activity & audit for the actor/action. 3. Revoke affected connectors. 4. Rotate secrets if exposure is suspected. 5. Restore from backup only into a new project. 6. Write a postmortem as an `outcome` memory.
