// Netlify Scheduled Function: drives the durable job queue and schedules every 5 minutes.
// It only calls the app's authenticated tick endpoint; all logic lives in the app.
import type { Config } from "@netlify/functions";

export default async () => {
  const base = process.env.APP_URL ?? process.env.URL;
  const secret = process.env.CRON_SECRET;
  if (!base || !secret) {
    console.log("tick skipped: APP_URL/URL or CRON_SECRET not configured");
    return new Response("not configured", { status: 200 });
  }
  const res = await fetch(`${base}/api/cron/tick`, { method: "POST", headers: { authorization: `Bearer ${secret}`, "content-type": "application/json" }, body: "{}" });
  console.log("tick", res.status, (await res.text()).slice(0, 500));
  return new Response("ok");
};

export const config: Config = { schedule: "*/5 * * * *" };
