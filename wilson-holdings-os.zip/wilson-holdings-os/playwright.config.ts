import { defineConfig, devices } from "@playwright/test";
import fs from "node:fs";

// Uses a separate database so e2e runs never touch development data.
const E2E_DB = process.env.E2E_DATABASE_URL ?? "postgres://wh:wh_local_dev@localhost:5432/wilson_holdings_e2e";
const chrome = process.env.PW_CHROME ?? (fs.existsSync("/usr/bin/google-chrome") ? "/usr/bin/google-chrome" : undefined);
const port = 3100;
const envVars = { DATABASE_URL: E2E_DB, SESSION_SECRET: "e2e-secret-e2e-secret-e2e-secret-0000", SETUP_TOKEN: "e2e-setup-token", APP_URL: `http://localhost:${port}`, APP_ENV: "test", DEMO_MODE: "false", ANTHROPIC_API_KEY: "" };

export default defineConfig({
  testDir: "tests/e2e",
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: [["list"]],
  globalSetup: "./tests/e2e/global-setup.ts",
  use: { baseURL: `http://localhost:${port}`, trace: "retain-on-failure", launchOptions: chrome ? { executablePath: chrome } : undefined },
  projects: [
    { name: "desktop", use: { ...devices["Desktop Chrome"], viewport: { width: 1440, height: 900 } } },
  ],
  webServer: { command: `npx next start -p ${port}`, url: `http://localhost:${port}/api/health`, reuseExistingServer: false, timeout: 60_000, env: envVars },
});
