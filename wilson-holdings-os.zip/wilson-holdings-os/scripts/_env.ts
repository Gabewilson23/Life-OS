import fs from "node:fs";
// Scripts read .env.local (same file Next.js uses) unless variables are already set.
for (const f of [".env.local", ".env"]) {
  if (fs.existsSync(f)) {
    try { process.loadEnvFile(f); } catch { /* ignore malformed */ }
  }
}
