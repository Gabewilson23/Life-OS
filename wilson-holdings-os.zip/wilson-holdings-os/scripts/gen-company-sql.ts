// Generates db/migrations/005_company_data.sql from src/lib/company/datasets.ts (run once; the SQL is committed).
import fs from "node:fs";
import { DATASETS, columnFor, sqlType } from "../src/lib/company/datasets";

let sql = `-- 005: company datasets (generated from src/lib/company/datasets.ts by scripts/gen-company-sql.ts) + import batches.\n\n`;
sql += `CREATE TABLE import_batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  dataset text NOT NULL,
  filename text NOT NULL,
  file_sha256 text NOT NULL,
  raw bytea,
  headers text[] NOT NULL DEFAULT '{}',
  mapping jsonb NOT NULL DEFAULT '{}',
  row_count integer NOT NULL DEFAULT 0,
  inserted integer NOT NULL DEFAULT 0,
  updated integer NOT NULL DEFAULT 0,
  unchanged integer NOT NULL DEFAULT 0,
  rejected integer NOT NULL DEFAULT 0,
  errors jsonb NOT NULL DEFAULT '[]',
  status text NOT NULL CHECK (status IN ('previewed', 'committed', 'failed', 'superseded')),
  created_by text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  committed_at timestamptz
);
CREATE INDEX import_batches_ds_idx ON import_batches(org_id, dataset, created_at DESC);\n\n`;
const tables = ["import_batches"];
for (const d of DATASETS) {
  tables.push(d.table);
  const cols = d.fields.map((f) => `  ${columnFor(f)} ${sqlType(f.type)}${f.required ? " NOT NULL" : ""}${f.enum ? ` CHECK (${columnFor(f)} IN (${f.enum.map((e) => `'${e}'`).join(", ")}))` : ""},`).join("\n");
  sql += `CREATE TABLE ${d.table} (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id text NOT NULL REFERENCES organizations(id),
  scope text NOT NULL,
  external_key text NOT NULL,
${cols}
  batch_id uuid REFERENCES import_batches(id),
  row_num integer,
  row_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1,
  UNIQUE (org_id, scope, external_key)
);\n\n`;
}
sql += `DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[${tables.map((t) => `'${t}'`).join(", ")}]
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR SELECT USING (app_can(org_id, scope))', t || '_read', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR INSERT WITH CHECK (app_can_write(org_id, scope))', t || '_insert', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR UPDATE USING (app_can_write(org_id, scope)) WITH CHECK (app_can_write(org_id, scope))', t || '_update', t);
    EXECUTE format('CREATE POLICY %I ON %I FOR DELETE USING (app_can_write(org_id, scope))', t || '_delete', t);
  END LOOP;
END $$;
`;
fs.writeFileSync("db/migrations/005_company_data.sql", sql);
console.log("wrote db/migrations/005_company_data.sql");
