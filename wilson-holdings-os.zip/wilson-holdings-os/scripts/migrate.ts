import "./_env";
import { runMigrations } from "../src/lib/server/migrate";
import { pool } from "../src/lib/server/db";

const applied = await runMigrations();
console.log(applied.length ? `Applied: ${applied.join(", ")}` : "Database is up to date.");
await pool().end();
