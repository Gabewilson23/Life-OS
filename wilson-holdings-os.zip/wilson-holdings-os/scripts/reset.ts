import "./_env";
import { pool } from "../src/lib/server/db";
import { env } from "../src/lib/server/env";

if (env().APP_ENV === "production") throw new Error("Refusing to reset a production database.");
await pool().query("DROP SCHEMA public CASCADE; CREATE SCHEMA public;");
console.log("Schema dropped and recreated.");
await pool().end();
