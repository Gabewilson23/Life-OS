import "./_env";
import { pool, withCtx, systemCtx } from "../src/lib/server/db";
import { env } from "../src/lib/server/env";
import { seedOrganization } from "../src/lib/server/seed";
import { ORG_ID } from "../src/lib/org/definitions";

await withCtx(systemCtx(ORG_ID, "seed"), (db) => seedOrganization(db, { defaultModel: env().ANTHROPIC_MODEL, timezone: env().DEFAULT_TIMEZONE }));
const users = await pool().query("SELECT count(*)::int AS n FROM users");
console.log("Organization seeded: 11 buildings, 52 roles, default prepare-only policies.");
if (users.rows[0].n === 0) {
  console.log(env().SETUP_TOKEN ? "No owner yet. Visit /setup and use SETUP_TOKEN from .env.local." : "No owner yet. Set SETUP_TOKEN in .env.local, then visit /setup.");
}
await pool().end();
