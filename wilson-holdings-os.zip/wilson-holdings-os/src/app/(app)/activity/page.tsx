import { PageHeader, Panel, ScopeTag } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { recentAudit } from "@/lib/server/services/audit";

export const metadata = { title: "Activity & audit" };

export default async function ActivityPage() {
  const { ctx } = await requirePageUser();
  const events = await withCtx(ctx, (db) => recentAudit(db, { limit: 200 }));
  return (
    <>
      <PageHeader eyebrow="Assurance" title="Activity & audit">Append-only record of every change, filtered to scopes you can read. External action history and approval evidence join this view in slice 5.</PageHeader>
      <Panel>
        {events.length === 0 ? <p className="text-sm text-stone-500">No events.</p> : (
          <table className="w-full text-sm">
            <thead className="text-left text-[11px] uppercase tracking-wider text-stone-500"><tr><th className="py-2 pr-3 font-medium">When</th><th className="py-2 pr-3 font-medium">Event</th><th className="hidden py-2 pr-3 font-medium md:table-cell">Actor</th><th className="hidden py-2 font-medium sm:table-cell">Scope</th></tr></thead>
            <tbody className="divide-y divide-white/[0.05]">
              {events.map((e) => (
                <tr key={e.id}>
                  <td className="whitespace-nowrap py-2 pr-3 text-xs text-stone-500">{new Date(e.at).toLocaleString("en-US", { timeZone: "America/New_York", dateStyle: "medium", timeStyle: "short" })}</td>
                  <td className="py-2 pr-3"><span className="text-stone-200">{e.summary || e.action}</span> <code className="ml-1 font-mono text-[11px] text-stone-500">{e.action}</code></td>
                  <td className="hidden py-2 pr-3 font-mono text-[11px] text-stone-500 md:table-cell">{String(e.actor).slice(0, 22)}</td>
                  <td className="hidden py-2 sm:table-cell"><ScopeTag scope={e.scope} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Panel>
    </>
  );
}
