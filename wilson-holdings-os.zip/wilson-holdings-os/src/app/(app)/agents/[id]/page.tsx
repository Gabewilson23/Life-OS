import Link from "next/link";
import { notFound } from "next/navigation";
import { AgentPauseButton } from "@/components/OrgClient";
import { Badge, Empty, Panel, ScopeTag, StateBadge } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { recentAudit } from "@/lib/server/services/audit";
import { getAgent } from "@/lib/server/services/org";

export default async function AgentPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { ctx } = await requirePageUser();
  const data = await withCtx(ctx, async (db) => {
    const a = await getAgent(db, id);
    return a ? { a, history: await recentAudit(db, { type: "agent", id, limit: 20 }) } : null;
  });
  if (!data) notFound();
  const { a, history } = data;
  const triggers = a.triggers as { kind: string; spec: string }[];
  const budget = a.budget as Record<string, number>;
  const model = a.model_config as Record<string, unknown>;
  const evidence = a.evidence_rules as { level: string; rules: string[] };
  const esc = a.escalation_policy as { escalate_to: string; escalate_when: string[]; default_external_writes: string };
  return (
    <div className="space-y-6">
      <nav aria-label="Breadcrumb" className="text-xs text-stone-500"><Link href="/agents" className="hover:text-stone-300">Organization</Link> / <Link href={`/buildings/${a.building_slug}`} className="hover:text-stone-300">{a.building_name}</Link> / {a.department_name}</nav>
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-start gap-4">
          <div aria-hidden className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl border border-white/10 bg-gradient-to-b from-white/10 to-transparent display text-xl text-champagne-200">{a.number}</div>
          <div>
            <p className="eyebrow mb-1">AI role · {a.id}</p>
            <h1 className="display text-[30px] leading-tight text-stone-50">{a.title}</h1>
            <div className="mt-2 flex flex-wrap gap-1.5"><StateBadge state={a.live_state} /><ScopeTag scope={a.scope} />{a.is_demo && <Badge tone="demo">demo</Badge>}<Badge>prompt v{a.prompt_version}</Badge></div>
          </div>
        </div>
        <div className="flex items-start gap-2"><Link className="btn btn-primary" href={`/chat?agent=${a.id}`}>Message this role</Link><AgentPauseButton id={a.id} status={a.status} version={a.version} title={a.title} /></div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <Panel title="Charter">
          <p className="text-[15px] leading-relaxed text-stone-200">{a.charter}</p>
          {a.guardrails.length > 0 && (<><h3 className="eyebrow mb-2 mt-5">Guardrails</h3><ul className="list-disc space-y-1 pl-5 text-sm text-stone-300">{a.guardrails.map((g: string) => <li key={g}>{g}</li>)}</ul></>)}
          <h3 className="eyebrow mb-2 mt-5">Success criteria</h3>
          <ul className="list-disc space-y-1 pl-5 text-sm text-stone-300">{(a.success_criteria as string[]).map((s) => <li key={s}>{s}</li>)}</ul>
        </Panel>
        <Panel title="Reporting line">
          <dl className="space-y-3 text-sm">
            <div><dt className="text-stone-500">Reports to</dt><dd>{a.manager_id ? <Link href={`/agents/${a.manager_id}`} className="text-stone-100 hover:text-champagne-200">{a.manager_title}</Link> : <span className="text-stone-100">Chairman (owner)</span>}</dd></div>
            <div><dt className="text-stone-500">Direct reports</dt><dd>{a.reports.length ? <ul className="mt-1 space-y-0.5">{a.reports.map((r: { id: string; title: string }) => <li key={r.id}><Link className="text-stone-200 hover:text-champagne-200" href={`/agents/${r.id}`}>{r.title}</Link></li>)}</ul> : <span className="text-stone-400">None</span>}</dd></div>
            <div><dt className="text-stone-500">Accountable humans</dt><dd className="text-stone-400">Not yet confirmed — set during onboarding.</dd></div>
          </dl>
        </Panel>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Permissions (enforced server-side)">
          <h3 className="eyebrow mb-2">Allowed tools</h3>
          <div className="flex flex-wrap gap-1.5">{a.allowed_tools.map((t: string) => <code key={t} className="rounded-md border border-white/10 bg-black/30 px-1.5 py-0.5 font-mono text-[11.5px] text-stone-300">{t}</code>)}</div>
          <h3 className="eyebrow mb-2 mt-4">Data scopes</h3>
          <div className="flex flex-wrap gap-1.5">{a.data_scopes.map((s: string) => <ScopeTag key={s} scope={s} />)}</div>
          <h3 className="eyebrow mb-2 mt-4">Escalation</h3>
          <p className="text-sm text-stone-300">External writes default to <strong className="text-stone-100">{esc.default_external_writes}</strong>. Escalates to {esc.escalate_to === "chairman" ? "the chairman" : <Link className="underline" href={`/agents/${esc.escalate_to}`}>{esc.escalate_to}</Link>} when: {esc.escalate_when.join("; ")}.</p>
        </Panel>
        <Panel title="Runtime configuration">
          <dl className="grid grid-cols-2 gap-3 text-sm">
            <div><dt className="text-stone-500">Model</dt><dd className="font-mono text-[12.5px] text-stone-200">{String(model.model)}</dd></div>
            <div><dt className="text-stone-500">Max tool rounds</dt><dd className="num text-stone-200">{String(model.max_tool_rounds)}</dd></div>
            <div><dt className="text-stone-500">Daily budget</dt><dd className="num text-stone-200">${budget.daily_usd?.toFixed(2)}</dd></div>
            <div><dt className="text-stone-500">Per-run budget</dt><dd className="num text-stone-200">${budget.per_run_usd?.toFixed(2)}</dd></div>
            <div className="col-span-2"><dt className="text-stone-500">Triggers</dt><dd className="text-stone-200">{triggers.map((t) => `${t.kind.replace("_", " ")}: ${t.spec}`).join(" · ")}</dd></div>
            <div className="col-span-2"><dt className="text-stone-500">Evidence ({evidence.level})</dt><dd><ul className="list-disc pl-5 text-stone-300">{evidence.rules.map((r) => <li key={r}>{r}</li>)}</ul></dd></div>
          </dl>
        </Panel>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Work queue & run history">
          {a.runs.length === 0 ? <Empty title="No runs yet">This role has never run. Message it, include it in a meeting, or let the Chief of Staff delegate to it.</Empty> : (
            <ul className="space-y-2 text-sm">{a.runs.map((r: { id: string; state: string; created_at: Date; is_demo: boolean }) => <li key={r.id} className="flex justify-between"><span className="font-mono text-xs">{r.id.slice(0, 8)}</span><StateBadge state={r.state} /></li>)}</ul>
          )}
        </Panel>
        <Panel title="Change history">
          {history.length === 0 ? <p className="text-sm text-stone-500">No configuration changes since seed.</p> : (
            <ul className="space-y-1.5 text-sm">{history.map((h) => <li key={h.id} className="flex justify-between gap-3"><span className="text-stone-300">{h.summary}</span><time className="text-xs text-stone-500">{new Date(h.at).toLocaleString("en-US", { timeZone: "America/New_York" })}</time></li>)}</ul>
          )}
        </Panel>
      </div>

      <details className="glass rounded-[var(--radius-lg)] p-5">
        <summary className="cursor-pointer text-sm text-stone-300">System prompt v{a.prompt_version} (versioned configuration)</summary>
        <pre className="mt-3 whitespace-pre-wrap font-mono text-[12px] leading-relaxed text-stone-400">{a.system_prompt}</pre>
      </details>
    </div>
  );
}
