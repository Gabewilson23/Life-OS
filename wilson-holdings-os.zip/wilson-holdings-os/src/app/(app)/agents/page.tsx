import Link from "next/link";
import { Badge, PageHeader, ScopeTag, StateBadge } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { listAgents, listBuildings, listHumanMembers } from "@/lib/server/services/org";

export const metadata = { title: "Organization" };

export default async function AgentsPage({ searchParams }: { searchParams: Promise<{ building?: string }> }) {
  const { ctx } = await requirePageUser();
  const sp = await searchParams;
  const [agents, buildings, humans] = await withCtx(ctx, (db) => Promise.all([listAgents(db), listBuildings(db), listHumanMembers(db)]));
  const visible = sp.building ? buildings.filter((b) => b.slug === sp.building) : buildings;
  return (
    <>
      <PageHeader eyebrow="Organization" title={`${agents.length} AI roles across ${buildings.length} buildings`}>
        AI roles are configuration records that run on demand or on schedule as bounded jobs — they are not employees, licensed professionals or always-on sessions. Status reflects real runs only.
      </PageHeader>
      <nav aria-label="Filter by building" className="mb-6 flex flex-wrap gap-1.5">
        <Link href="/agents" className={`btn btn-sm ${!sp.building ? "btn-primary" : ""}`}>All</Link>
        {buildings.map((b) => <Link key={b.slug} href={`/agents?building=${b.slug}`} className={`btn btn-sm ${sp.building === b.slug ? "btn-primary" : ""}`}>{b.name} · {b.role_count}</Link>)}
      </nav>
      <div className="space-y-8">
        {visible.map((b) => {
          const list = agents.filter((a) => a.buildingId === b.id);
          return (
            <section key={b.id} aria-labelledby={`b-${b.slug}`}>
              <div className="mb-3 flex items-baseline justify-between gap-3">
                <h2 id={`b-${b.slug}`} className="display text-xl text-stone-50"><span aria-hidden className="mr-2 inline-block h-2 w-2 rounded-full align-middle" style={{ background: b.layout.accent }} />{b.name}</h2>
                <Link href={`/buildings/${b.slug}`} className="text-xs text-stone-400 hover:text-champagne-200">Open building →</Link>
              </div>
              <div className="glass overflow-hidden rounded-[var(--radius-lg)]">
                <table className="w-full text-sm">
                  <caption className="sr-only">Roles in {b.name}</caption>
                  <thead className="text-left text-[11px] uppercase tracking-wider text-stone-500"><tr><th className="px-4 py-2.5 font-medium">#</th><th className="px-4 py-2.5 font-medium">Role</th><th className="hidden px-4 py-2.5 font-medium md:table-cell">Department</th><th className="hidden px-4 py-2.5 font-medium sm:table-cell">Scope</th><th className="px-4 py-2.5 font-medium">State</th></tr></thead>
                  <tbody className="divide-y divide-white/[0.05]">
                    {list.map((a) => (
                      <tr key={a.id} className="hover:bg-white/[0.03]">
                        <td className="num px-4 py-2.5 text-stone-500">{a.number}</td>
                        <td className="px-4 py-2.5"><Link href={`/agents/${a.id}`} className="text-stone-100 hover:text-champagne-200">{a.title}</Link> {a.isDemo && <Badge tone="demo">demo</Badge>}</td>
                        <td className="hidden px-4 py-2.5 text-stone-400 md:table-cell">{a.departmentName}</td>
                        <td className="hidden px-4 py-2.5 sm:table-cell"><ScopeTag scope={a.scope} /></td>
                        <td className="px-4 py-2.5"><StateBadge state={a.liveState} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          );
        })}
      </div>
      <section className="mt-10" aria-labelledby="humans">
        <h2 id="humans" className="display mb-3 text-xl text-stone-50">Human team</h2>
        {humans.length === 0 ? <p className="text-sm text-stone-500">No human leaders, licensed agents or contractors recorded yet. They are a separate entity type from AI roles and will be confirmed during onboarding.</p> : (
          <ul className="space-y-1 text-sm">{humans.map((h) => <li key={h.id}>{h.name} — {h.title} ({h.kind})</li>)}</ul>
        )}
      </section>
    </>
  );
}
