import { ApprovalCard, ProposalRow, type ApprovalRow } from "@/components/ActionsClient";
import { Empty, PageHeader, Panel } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { listApprovals } from "@/lib/server/services/approvals";
import { listProposals } from "@/lib/server/services/proposals";

export const metadata = { title: "Approvals" };

export default async function ApprovalsPage() {
  const { ctx } = await requirePageUser();
  const [approvals, proposals, perms] = await withCtx(ctx, (db) => Promise.all([listApprovals(db), listProposals(db, { status: "proposed" }), db.query(`SELECT s.*, a.label FROM standing_permissions s LEFT JOIN integration_accounts a ON a.id = s.account_id WHERE s.revoked_at IS NULL`).then((r) => r.rows)]));
  const rows = approvals.map((a) => ({ ...a, expires_at: new Date(a.expires_at).toISOString(), created_at: new Date(a.created_at).toISOString() })) as ApprovalRow[];
  const pending = rows.filter((a) => a.status === "pending" || a.status === "approved");
  const history = rows.filter((a) => !(a.status === "pending" || a.status === "approved"));
  return (
    <>
      <PageHeader eyebrow="Authority" title="Approvals & actions">External writes default to prepare-only. Each approval is bound to the exact content, account, recipients/resource and expiry — any change voids it, and one approval can run at most once. Execution is verified against the provider.</PageHeader>
      <div className="grid gap-6 xl:grid-cols-[1.4fr_1fr]">
        <Panel eyebrow="Decision queue" title={`Waiting on you (${pending.length})`}>
          {pending.length ? <ul className="space-y-3">{pending.map((a) => <ApprovalCard key={a.id} a={a} />)}</ul> : <Empty title="Nothing waiting">Agent proposals for external actions and your own calendar/email actions appear here.</Empty>}
        </Panel>
        <Panel eyebrow="From agents" title={`Proposals (${proposals.length})`}>
          {proposals.length ? <ul className="space-y-2">{proposals.map((p) => <ProposalRow key={p.id} p={p} />)}</ul> : <p className="text-sm text-stone-500">No open proposals.</p>}
          <h3 className="eyebrow mb-2 mt-6">Standing permissions</h3>
          {perms.length ? <ul className="space-y-1 text-sm">{perms.map((p) => <li key={p.id}>{p.description} <span className="text-xs text-stone-500">({p.action_kind} · {p.label} · {JSON.stringify(p.constraints)})</span></li>)}</ul> : <p className="text-sm text-stone-500">None. Create narrow ones on the Integrations page.</p>}
        </Panel>
      </div>
      <Panel className="mt-6" title="Action history & audit evidence">
        {history.length ? <ul className="space-y-3">{history.map((a) => <ApprovalCard key={a.id} a={a} />)}</ul> : <p className="text-sm text-stone-500">No completed actions yet.</p>}
      </Panel>
    </>
  );
}
