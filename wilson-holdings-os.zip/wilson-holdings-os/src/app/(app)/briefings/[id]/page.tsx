import Link from "next/link";
import { notFound } from "next/navigation";
import { z } from "zod";
import { Badge, PageHeader, Panel } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";

export default async function ReportPage({ params }: { params: Promise<{ id: string }> }) {
  const id = z.string().uuid().safeParse((await params).id);
  if (!id.success) notFound();
  const { ctx } = await requirePageUser();
  const r = (await withCtx(ctx, (db) => db.query(`SELECT * FROM reports WHERE id = $1`, [id.data]))).rows[0];
  if (!r) notFound();
  const sections = r.data.sections as { title: string; items: { text: string; meta?: string; link?: string }[]; empty?: string }[];
  const tz = { timeZone: "America/New_York", dateStyle: "medium", timeStyle: "short" } as const;
  return (
    <>
      <nav className="mb-2 text-xs text-stone-500"><Link href="/briefings">← Briefings</Link></nav>
      <PageHeader eyebrow={r.kind.replace(/_/g, " ")} title={r.title} actions={<Badge>{r.reading_minutes} min read</Badge>}>
        Period {new Date(r.period_from).toLocaleString("en-US", tz)} → {new Date(r.period_to).toLocaleString("en-US", tz)} · data cutoff {new Date(r.source_cutoff).toLocaleString("en-US", tz)} · {r.metric_version} · narrative: {r.narrative_status === "none" ? "not generated (deterministic report)" : r.narrative_status}
      </PageHeader>
      <div className="grid gap-4 lg:grid-cols-2">
        {sections.map((s) => (
          <Panel key={s.title} title={s.title}>
            {s.items.length ? <ul className="space-y-1.5 text-sm">{s.items.map((i, k) => <li key={k} className="flex justify-between gap-3"><span className="text-stone-200">{i.link ? <Link className="hover:text-signal-blue" href={i.link}>{i.text}</Link> : i.text}</span>{i.meta && <span className="shrink-0 text-right text-xs text-stone-500">{i.meta}</span>}</li>)}</ul> : <p className="text-sm text-stone-500">{s.empty}</p>}
          </Panel>
        ))}
      </div>
    </>
  );
}
