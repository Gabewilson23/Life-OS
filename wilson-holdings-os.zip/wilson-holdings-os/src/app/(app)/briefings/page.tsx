import Link from "next/link";
import { QuietHours, RunReportNow, ScheduleRow } from "@/components/OpsClient";
import { Badge, PageHeader, Panel, ScopeTag } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { nextRun, type Rule } from "@/lib/schedule";

export const metadata = { title: "Briefings" };
const fmt = (d: Date | null) => (d ? new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }).format(d) : null);

export default async function BriefingsPage() {
  const { ctx } = await requirePageUser();
  const [schedules, reports, org, hb] = await withCtx(ctx, (db) => Promise.all([
    db.query(`SELECT s.*, (SELECT max(started_at) FROM schedule_runs r WHERE r.schedule_id = s.id) AS last FROM schedules s ORDER BY s.id`).then((r) => r.rows),
    db.query(`SELECT id, kind, title, scope, reading_minutes, narrative_status, created_at FROM reports ORDER BY created_at DESC LIMIT 50`).then((r) => r.rows),
    db.query(`SELECT settings FROM organizations WHERE id = $1`, [ctx.orgId]).then((r) => r.rows[0]),
    db.query(`SELECT worker_id, last_seen FROM worker_heartbeats ORDER BY last_seen DESC LIMIT 3`).then((r) => r.rows),
  ]));
  return (
    <>
      <PageHeader eyebrow="Cadence" title="Briefings & reports">Seeded schedules (America/New_York, DST-aware) are off until you activate them. Each runs at most once per reporting window, delivers in-app first, and reports missing or stale data honestly.</PageHeader>
      <div className="grid gap-6 xl:grid-cols-[1.2fr_1fr]">
        <Panel title="Schedules">
          <ul className="space-y-2">{schedules.map((s) => <ScheduleRow key={s.id} s={{ id: s.id, label: s.label, enabled: s.enabled, rule: s.rule, next: fmt(nextRun(s.rule as Rule, s.timezone, new Date())), last: fmt(s.last ? new Date(s.last) : null) }} />)}</ul>
          <p className="mt-3 text-xs text-stone-500">Background runner: {hb.length ? hb.map((h) => `${h.worker_id} seen ${fmt(new Date(h.last_seen))}`).join(" · ") : "no heartbeat yet — configure the Netlify scheduled function (CRON_SECRET) or run `npm run worker`."}</p>
        </Panel>
        <Panel title="Run now & quiet hours">
          <RunReportNow />
          <h3 className="eyebrow mb-2 mt-5">Quiet hours (routine alerts wait; urgent ones don&apos;t)</h3>
          <QuietHours q={org?.settings?.quietHours ?? { start: "21:00", end: "07:00" }} />
        </Panel>
      </div>
      <Panel className="mt-6" title="Report history">
        {reports.length ? <ul className="divide-y divide-white/[0.05]">{reports.map((r) => <li key={r.id} className="flex items-center justify-between gap-3 py-2 text-sm"><Link className="hover:text-signal-blue" href={`/briefings/${r.id}`}>{r.title}</Link><span className="flex items-center gap-2"><ScopeTag scope={r.scope} /><Badge>{r.reading_minutes} min read</Badge><span className="text-xs text-stone-500">{fmt(new Date(r.created_at))}</span></span></li>)}</ul> : <p className="text-sm text-stone-500">No reports yet. Run one now or activate a schedule.</p>}
      </Panel>
    </>
  );
}
