import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader, Panel, ScopeTag, StateBadge } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { getBuilding, listAgents } from "@/lib/server/services/org";
import { listTasks } from "@/lib/server/services/work";

export default async function BuildingPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const { ctx } = await requirePageUser();
  const data = await withCtx(ctx, async (db) => {
    const b = await getBuilding(db, slug);
    if (!b) return null;
    const [agents, tasks] = await Promise.all([listAgents(db), listTasks(db)]);
    return { b, agents: agents.filter((a) => a.buildingId === b.id), tasks: tasks.filter((t) => t.scope === b.scope) };
  });
  if (!data) notFound();
  const { b, agents, tasks } = data;
  return (
    <>
      <nav aria-label="Breadcrumb" className="mb-3 text-xs text-stone-500"><Link href="/campus" className="hover:text-stone-300">Campus</Link> / {b.name}</nav>
      <PageHeader eyebrow="Building" title={b.name} actions={<Link className="btn btn-sm" href={`/campus?focus=${b.slug}`}>View on campus</Link>}>
        {b.description} <span className="ml-1 inline-block align-middle"><ScopeTag scope={b.scope} /></span>
      </PageHeader>
      <div className="grid gap-6 lg:grid-cols-2">
        {b.departments.map((d) => (
          <Panel key={d.id} eyebrow="Department" title={d.name}>
            <p className="mb-3 text-sm text-stone-400">{d.description}</p>
            <ul className="divide-y divide-white/[0.05]">
              {agents.filter((a) => a.departmentId === d.id).map((a) => (
                <li key={a.id} className="flex items-center justify-between gap-3 py-2">
                  <Link href={`/agents/${a.id}`} className="text-sm text-stone-100 hover:text-champagne-200"><span className="num mr-2 text-stone-500">{a.number}</span>{a.title}</Link>
                  <StateBadge state={a.liveState} />
                </li>
              ))}
            </ul>
          </Panel>
        ))}
        <Panel title="Open work in this scope">
          {tasks.length ? <ul className="space-y-1 text-sm">{tasks.map((t) => <li key={t.id}><Link href={`/tasks#${t.id}`} className="text-stone-200 hover:text-champagne-200">{t.title}</Link></li>)}</ul> : <p className="text-sm text-stone-500">No open tasks in this scope.</p>}
        </Panel>
      </div>
    </>
  );
}
