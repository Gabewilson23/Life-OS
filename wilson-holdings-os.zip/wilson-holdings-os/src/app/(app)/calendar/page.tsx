import { CalendarClient, type CalEvent } from "@/components/CalendarClient";
import { PageHeader } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { localDate } from "@/lib/time";

export const metadata = { title: "Calendar" };

export default async function CalendarPage({ searchParams }: { searchParams: Promise<{ d?: string }> }) {
  const { ctx } = await requirePageUser();
  const sp = await searchParams;
  const anchor = /^\d{4}-\d{2}-\d{2}$/.test(sp.d ?? "") ? sp.d! : localDate("America/New_York");
  const from = new Date(new Date(`${anchor}T00:00:00Z`).getTime() - 40 * 86400_000), to = new Date(new Date(`${anchor}T00:00:00Z`).getTime() + 40 * 86400_000);
  const [events, accounts] = await withCtx(ctx, (db) => Promise.all([
    db.query(`SELECT e.*, a.label AS account_label FROM calendar_events e JOIN integration_accounts a ON a.id = e.account_id WHERE e.starts_at < $2 AND e.ends_at > $1 AND a.status <> 'revoked' ORDER BY e.starts_at`, [from, to]).then((r) => r.rows),
    db.query(`SELECT id, label, scope, capabilities, settings FROM integration_accounts WHERE provider = 'google' AND status <> 'revoked'`).then((r) => r.rows),
  ]));
  const ev = events.map((e) => ({ ...e, starts_at: new Date(e.starts_at).toISOString(), ends_at: new Date(e.ends_at).toISOString(), last_synced_at: new Date(e.last_synced_at).toISOString() })) as CalEvent[];
  return (
    <>
      <PageHeader eyebrow="Time" title="Calendar">Personal and company calendars overlaid (only scopes you can read). Proposals are conflict-aware and go through approval; events with attendees disclose that invitations will be sent.</PageHeader>
      <CalendarClient events={ev} accounts={accounts} anchor={anchor} />
    </>
  );
}
