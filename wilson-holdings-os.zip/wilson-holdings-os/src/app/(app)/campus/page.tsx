import { Suspense } from "react";
import { CampusView } from "@/components/campus/CampusView";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { listAgents, listBuildings } from "@/lib/server/services/org";

export const metadata = { title: "Campus" };

export default async function CampusPage() {
  const { ctx } = await requirePageUser();
  const data = await withCtx(ctx, async (db) => {
    const [b, a, d] = await Promise.all([listBuildings(db), listAgents(db), db.query(`SELECT id, building_id, name FROM departments ORDER BY sort`)]);
    return {
      buildings: b.map((x) => ({ id: x.id, slug: x.slug, name: x.name, description: x.description, scope: x.scope, layout: x.layout, departments: d.rows.filter((r) => r.building_id === x.id).map((r) => ({ id: r.id, name: r.name })) })),
      agents: a.map((x) => ({ id: x.id, number: x.number, title: x.title, buildingId: x.buildingId, departmentId: x.departmentId, departmentName: x.departmentName, liveState: x.liveState, isDemo: x.isDemo })),
    };
  });
  return <Suspense><CampusView {...data} /></Suspense>;
}
