import { ChatClient } from "@/components/ChatClient";
import { PageHeader } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { modelAdapter } from "@/lib/server/model";
import { listChannels } from "@/lib/server/services/chat";
import { listAgents } from "@/lib/server/services/org";

export const metadata = { title: "Chief of staff" };

export default async function ChatPage({ searchParams }: { searchParams: Promise<{ agent?: string }> }) {
  const { ctx } = await requirePageUser();
  const sp = await searchParams;
  const [agents, channels] = await withCtx(ctx, (db) => Promise.all([listAgents(db), listChannels(db)]));
  const avail = modelAdapter().available();
  const initial = agents.find((a) => a.id === sp.agent)?.id ?? "hq.chief-of-staff";
  return (
    <>
      <PageHeader eyebrow="Chief of staff" title="Conversations">
        {avail.ok ? "Streamed responses from real, bounded agent runs." : <>Agent runs will be <strong>blocked</strong> until a model credential is configured on the server ({avail.reason}). Messages are still saved.</>}
      </PageHeader>
      <ChatClient agents={agents.map((a) => ({ id: a.id, title: a.title, number: a.number }))} channels={channels} initialAgentId={initial} modelReady={avail.ok} />
    </>
  );
}
