import Link from "next/link";
import { notFound } from "next/navigation";
import { Freshness, MetricGrid } from "@/components/MetricGrid";
import { Badge, Empty, PageHeader, Panel, StateBadge } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { consultingMetrics, insuranceMetrics, maskName } from "@/lib/server/services/metrics";
import { listAgents } from "@/lib/server/services/org";
import { usd } from "@/lib/format";
import { localDate } from "@/lib/time";

function defaultPeriod() {
  const today = localDate("America/New_York");
  return { from: `${today.slice(0, 7)}-01`, to: today };
}

export default async function CompanyPage({ params, searchParams }: { params: Promise<{ slug: string }>; searchParams: Promise<{ from?: string; to?: string; cohort?: string }> }) {
  const { slug } = await params;
  if (!["atlas-insurance", "atlas-consulting"].includes(slug)) notFound();
  const { ctx } = await requirePageUser();
  const scope = `company:${slug}`;
  if (!ctx.scopes.includes(scope)) notFound();
  const sp = await searchParams;
  const d = defaultPeriod();
  const iso = (s?: string) => (s && /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : undefined);
  const period = { from: iso(sp.from) ?? d.from, to: iso(sp.to) ?? d.to };
  const data = await withCtx(ctx, async (db) => {
    const company = (await db.query(`SELECT * FROM companies WHERE slug = $1`, [slug])).rows[0];
    const agents = (await listAgents(db)).filter((a) => a.scope === scope);
    if (slug === "atlas-insurance") {
      const m = await insuranceMetrics(db, period, sp.cohort || undefined);
      const funnel = (await db.query(`SELECT stage, count(*)::int n FROM ins_people GROUP BY stage`)).rows;
      const pending = (await db.query(`SELECT external_key, client_name, carrier, missing_documents, submitted_at FROM ins_policies WHERE status IN ('submitted','issued') ORDER BY submitted_at LIMIT 15`)).rows;
      const cohorts = (await db.query(`SELECT DISTINCT cohort FROM ins_people WHERE cohort IS NOT NULL ORDER BY cohort DESC`)).rows.map((r) => r.cohort as string);
      return { company, agents, kind: "insurance" as const, m, funnel, pending, cohorts };
    }
    const m = await consultingMetrics(db, period, period.to);
    const opps = (await db.query(`SELECT external_key, client, name, stage, amount_cents, probability, expected_close, next_step FROM con_opportunities WHERE stage NOT IN ('won','lost') ORDER BY expected_close NULLS LAST LIMIT 15`)).rows;
    return { company, agents, kind: "consulting" as const, m, opps };
  });
  const tasksLink = `/tasks?scope=${encodeURIComponent(scope)}`;
  return (
    <>
      <PageHeader eyebrow="Company console" title={data.company.name} actions={<><Link className="btn btn-sm" href="/imports">Import data</Link><Link className="btn btn-sm" href={tasksLink}>Tasks</Link><Link className="btn btn-sm" href={`/buildings/${slug}`}>Building</Link></>}>
        {data.kind === "consulting" && (data.company.settings.businessModel ? <>Business model (confirmed): {data.company.settings.businessModel}. Workflows: {(data.company.settings.enabledWorkflows as string[]).join(", ") || "none"}.</> : <>Business model not yet confirmed — <Link className="underline" href="/settings">confirm it</Link>. Figures below are neutral to model.</>)}
        {data.kind === "insurance" && <>Client data is masked by default. Figures are computed deterministically from imported records; nothing is preloaded.</>}
      </PageHeader>
      <form className="glass mb-5 flex flex-wrap items-end gap-2 rounded-[16px] p-3" action="">
        <label className="text-xs text-stone-400">From<input className="input mt-1 w-auto" type="date" name="from" defaultValue={period.from} /></label>
        <label className="text-xs text-stone-400">To<input className="input mt-1 w-auto" type="date" name="to" defaultValue={period.to} /></label>
        {data.kind === "insurance" && <label className="text-xs text-stone-400">Cohort<select className="input mt-1 w-auto" name="cohort" defaultValue={sp.cohort ?? ""}><option value="">All</option>{data.cohorts.map((c) => <option key={c}>{c}</option>)}</select></label>}
        <button className="btn">Apply</button>
        <span className="ml-auto text-xs text-stone-500">Currency USD · period {period.from} → {period.to}</span>
      </form>
      <div className="mb-4"><Freshness f={data.m.freshness} /></div>
      <MetricGrid metrics={data.m.metrics} slug={slug} />
      {data.kind === "insurance" ? (
        <div className="mt-6 grid gap-6 xl:grid-cols-2">
          <Panel title="Lead economics by source">
            {data.m.leadEconomics.length ? <table className="w-full text-sm"><thead className="text-left text-[11px] uppercase text-stone-500"><tr><th className="py-1">Source</th><th>Spend</th><th>Leads</th><th>Placed</th><th>Cost / placement</th><th>Placed AP per $1</th></tr></thead><tbody>
              {data.m.leadEconomics.map((l) => <tr key={l.source} className="border-t border-white/[0.05]"><td className="py-1.5">{l.source}</td><td className="num">{usd(l.costCents)}</td><td className="num">{l.leads ?? "—"}</td><td className="num">{l.placed}</td><td className="num">{usd(l.costPerPlacementCents)}</td><td className="num">{l.apPerDollar ?? "—"}</td></tr>)}
            </tbody></table> : <Empty title="No lead spend imported">Import “Lead spend” to see acquisition economics.</Empty>}
          </Panel>
          <Panel title="Recruiting & licensing funnel">
            {data.funnel.length ? <ul className="space-y-1.5 text-sm">{["sourced", "interviewing", "offered", "licensing", "onboarding", "active", "inactive"].map((s) => <li key={s} className="flex justify-between"><span className="capitalize text-stone-300">{s}</span><span className="num">{data.funnel.find((f) => f.stage === s)?.n ?? 0}</span></li>)}</ul> : <Empty title="No people imported" />}
          </Panel>
          <Panel title="Pending cases (client names masked)">
            {data.pending.length ? <ul className="space-y-1 text-sm">{data.pending.map((p) => <li key={p.external_key} className="flex justify-between gap-3"><Link className="hover:text-signal-blue" href={`/companies/${slug}/records/ins_policies?key=${encodeURIComponent(p.external_key)}`}>{p.external_key} · {maskName(p.client_name)} · {p.carrier}</Link><span className="text-xs text-signal-amber">{p.missing_documents || "—"}</span></li>)}</ul> : <p className="text-sm text-stone-500">No pending cases.</p>}
          </Panel>
          <AgentsPanel agents={data.agents} />
        </div>
      ) : (
        <div className="mt-6 grid gap-6">
          <Panel title="Projects — job cost & margin">
            {data.m.projects.length ? <div className="overflow-x-auto"><table className="w-full min-w-[900px] text-sm"><thead className="text-left text-[11px] uppercase text-stone-500"><tr><th className="py-1">Project</th><th>Health</th><th>Contract (approved)</th><th>Budget (estimate)</th><th>Job cost</th><th>Variance</th><th>Billed</th><th>Collected</th><th>Margin accrual / cash</th><th>Backlog</th></tr></thead><tbody>
              {data.m.projects.map((p) => <tr key={p.key} className="border-t border-white/[0.05]"><td className="py-1.5"><Link className="hover:text-signal-blue" href={`/companies/${slug}/records/con_time?project=${encodeURIComponent(p.key)}`}>{p.name}</Link><span className="block text-xs text-stone-500">{p.client} · {p.status}</span></td><td>{p.health ? <Badge tone={p.health === "green" ? "green" : p.health === "amber" ? "amber" : "red"}>{p.health}</Badge> : "—"}</td><td className="num">{usd(p.contractCents)}</td><td className="num">{usd(p.budgetCostCents)}</td><td className="num">{usd(p.costCents)}</td><td className={`num ${p.budgetVarianceCents != null && p.budgetVarianceCents < 0 ? "text-signal-red" : ""}`}>{usd(p.budgetVarianceCents)}</td><td className="num">{usd(p.billedCents)}</td><td className="num">{usd(p.collectedCents)}</td><td className="num">{usd(p.accrualMarginCents)} / {usd(p.cashMarginCents)}</td><td className="num">{usd(p.backlogCents)}</td></tr>)}
            </tbody></table></div> : <Empty title="No projects imported">Import “Projects & contracts”, time, expenses, invoices and payments.</Empty>}
          </Panel>
          <div className="grid gap-6 xl:grid-cols-3">
            <Panel title={`Receivables aging (as of ${data.m.asOf})`}><ul className="space-y-1.5 text-sm">{data.m.aging.map((a) => <li key={a.bucket} className="flex justify-between"><span>{a.bucket === "current" ? "Not yet due" : `${a.bucket} days past due`}</span><span className="num">{usd(a.cents)} <span className="text-xs text-stone-500">({a.count})</span></span></li>)}</ul></Panel>
            <Panel title="Utilization (approved hours)"><p className="mb-2 text-xs text-stone-500">{data.m.utilizationAssumption}</p>{data.m.utilization.length ? <ul className="space-y-1 text-sm">{data.m.utilization.map((u) => <li key={u.person} className="flex justify-between"><span>{u.person}</span><span className="num">{u.hours} h · {u.pctOf40h}%</span></li>)}</ul> : <p className="text-sm text-stone-500">No approved time in period.</p>}</Panel>
            <Panel title="Open pipeline (forecast — separate from backlog)">{data.opps.length ? <ul className="space-y-1 text-sm">{data.opps.map((o) => <li key={o.external_key} className="flex justify-between gap-2"><span className="truncate">{o.name} <span className="text-xs text-stone-500">{o.client} · {o.stage}</span></span><span className="num shrink-0">{usd(Number(o.amount_cents), { compact: true })} · {o.probability ?? "?"}%</span></li>)}</ul> : <p className="text-sm text-stone-500">No open opportunities.</p>}</Panel>
          </div>
          <AgentsPanel agents={data.agents} />
        </div>
      )}
    </>
  );
}

function AgentsPanel({ agents }: { agents: { id: string; number: number; title: string; liveState: string; departmentName: string }[] }) {
  return (
    <Panel title="AI roles for this company">
      <ul className="divide-y divide-white/[0.05]">{agents.map((a) => <li key={a.id} className="flex items-center justify-between py-1.5 text-sm"><Link className="hover:text-signal-blue" href={`/agents/${a.id}`}>{a.number}. {a.title} <span className="text-xs text-stone-500">· {a.departmentName}</span></Link><span className="flex items-center gap-2"><StateBadge state={a.liveState} /><Link className="btn btn-ghost btn-sm" href={`/chat?agent=${a.id}`}>Ask</Link></span></li>)}</ul>
    </Panel>
  );
}
