import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader, Panel } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { columnFor, datasetById } from "@/lib/company/datasets";
import { maskName } from "@/lib/server/services/metrics";
import { audit } from "@/lib/server/services/audit";
import { usd } from "@/lib/format";

/** Source drill-down with provenance (import batch + row). Sensitive fields masked unless explicitly revealed (audited). */
export default async function RecordsPage({ params, searchParams }: { params: Promise<{ slug: string; dataset: string }>; searchParams: Promise<Record<string, string | undefined>> }) {
  const { slug, dataset } = await params;
  const sp = await searchParams;
  const ds = datasetById(dataset);
  if (!ds || ds.company !== slug) notFound();
  const { ctx } = await requirePageUser();
  const reveal = sp.reveal === "1" && ctx.writeScopes.includes(`company:${slug}`);
  const rows = await withCtx(ctx, async (db) => {
    const where: string[] = ["true"]; const vals: unknown[] = [];
    if (sp.key) { vals.push(sp.key); where.push(`r.external_key = $${vals.length}`); }
    if (sp.project && ds.fields.some((f) => f.key === "project_key")) { vals.push(sp.project); where.push(`r.project_key = $${vals.length}`); }
    if (sp.stage && ds.id === "ins_people") { vals.push(sp.stage); where.push(`r.stage = $${vals.length}`); }
    if (sp.missing && ds.id === "ins_policies") where.push(`r.missing_documents IS NOT NULL AND r.missing_documents <> ''`);
    if (sp.discrepancy && ds.id === "ins_commissions") where.push(`r.expected_cents IS DISTINCT FROM r.received_cents`);
    if (sp.date && ds.fields.some((f) => f.key === sp.date && f.type === "date")) where.push(`r.${sp.date} IS NOT NULL`);
    const q = await db.query(`SELECT r.*, b.filename, b.committed_at FROM ${ds.table} r LEFT JOIN import_batches b ON b.id = r.batch_id WHERE ${where.join(" AND ")} ORDER BY r.external_key LIMIT 500`, vals);
    if (reveal) await audit(db, ctx, { scope: `company:${slug}`, action: "data.reveal_sensitive", type: ds.table, id: sp.key ?? "*", summary: `Revealed sensitive fields in ${ds.label}` });
    return q.rows;
  });
  const sensitive = ds.fields.some((f) => f.sensitive);
  const q = new URLSearchParams(Object.entries(sp).filter(([k, v]) => k !== "reveal" && v) as [string, string][]);
  return (
    <>
      <nav className="mb-2 text-xs text-stone-500"><Link href={`/companies/${slug}`}>← Console</Link></nav>
      <PageHeader eyebrow="Source records" title={ds.label} actions={sensitive ? <Link className="btn btn-sm" href={`?${q}${reveal ? "" : "&reveal=1"}`}>{reveal ? "Mask sensitive fields" : "Reveal client names (audited)"}</Link> : undefined}>{rows.length} record{rows.length === 1 ? "" : "s"}. Each row shows the import file and row number it came from.</PageHeader>
      <Panel>
        <div className="overflow-x-auto"><table className="w-full min-w-[800px] text-xs">
          <thead className="text-left uppercase text-stone-500"><tr><th className="py-1 pr-2">{ds.keyLabel}</th>{ds.fields.map((f) => <th key={f.key} className="pr-2">{f.label}</th>)}<th>Provenance</th></tr></thead>
          <tbody>{rows.map((r) => <tr key={r.id} className="border-t border-white/[0.05]"><td className="py-1 pr-2 font-medium">{r.external_key}</td>
            {ds.fields.map((f) => { const v = r[columnFor(f)]; return <td key={f.key} className="pr-2 num">{v == null ? "—" : f.sensitive && !reveal ? maskName(String(v)) : f.type === "money" ? usd(Number(v)) : typeof v === "boolean" ? (v ? "yes" : "no") : String(v)}</td>; })}
            <td className="text-stone-500">{r.filename ? `${r.filename} · row ${r.row_num}` : "manual"} · v{r.version}</td></tr>)}</tbody>
        </table></div>
      </Panel>
    </>
  );
}
