import { EmailComposer } from "@/components/EmailClient";
import { Badge, PageHeader, Panel, ScopeTag, scopeOptions } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";

export const metadata = { title: "Email" };

export default async function EmailPage() {
  const { user, ctx } = await requirePageUser();
  const [accounts, drafts] = await withCtx(ctx, (db) => Promise.all([
    db.query(`SELECT id, label, scope, external_account, capabilities FROM integration_accounts WHERE provider = 'google' AND status <> 'revoked'`).then((r) => r.rows),
    db.query(`SELECT id, scope, to_addrs, subject, sync_state, provider_status, updated_at FROM email_drafts ORDER BY updated_at DESC LIMIT 50`).then((r) => r.rows),
  ]));
  return (
    <>
      <PageHeader eyebrow="Communications" title="Email">Compose with company-separated voices and accounts. Drafts are kept separate from sent mail; nothing is sent without an approval bound to the exact message.</PageHeader>
      <div className="grid gap-6 xl:grid-cols-[1.3fr_1fr]">
        <Panel title="New message"><EmailComposer accounts={accounts} scopes={scopeOptions(user.writeScopes)} /></Panel>
        <Panel title="Drafts">
          {drafts.length ? <ul className="space-y-2 text-sm">{drafts.map((d) => <li key={d.id} className="flex items-center justify-between gap-2"><span className="truncate">{d.subject || "(no subject)"} <span className="text-xs text-stone-500">→ {(d.to_addrs as string[]).join(", ")}</span></span><span className="flex shrink-0 gap-1"><ScopeTag scope={d.scope} /><Badge tone={d.sync_state === "synced" ? "green" : d.sync_state === "local_only" ? "neutral" : "amber"}>{d.sync_state === "local_only" ? "not synced" : d.sync_state}</Badge></span></li>)}</ul> : <p className="text-sm text-stone-500">No drafts.</p>}
        </Panel>
      </div>
    </>
  );
}
