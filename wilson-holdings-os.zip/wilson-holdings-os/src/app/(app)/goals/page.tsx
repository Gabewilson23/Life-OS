import { GoalCard, GoalForm } from "@/components/WorkClient";
import { Empty, PageHeader, Panel, scopeOptions } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { listGoals } from "@/lib/server/services/work";

export const metadata = { title: "Goals" };

export default async function GoalsPage({ searchParams }: { searchParams: Promise<{ all?: string }> }) {
  const { user, ctx } = await requirePageUser();
  const all = (await searchParams).all === "1";
  const goals = await withCtx(ctx, (db) => listGoals(db, { includeClosed: all }));
  const scopes = scopeOptions(user.writeScopes);
  const groups = ["annual", "quarterly", "monthly", "weekly"].map((h) => ({ h, items: goals.filter((g) => g.horizon === h) }));
  return (
    <>
      <PageHeader eyebrow="Strategy" title="Goals" actions={<a className="btn btn-ghost btn-sm" href={all ? "/goals" : "/goals?all=1"}>{all ? "Hide closed" : "Show achieved & dropped"}</a>}>
        Annual and quarterly goals, milestones and weekly priorities. Goals are entered by you — none are preloaded as current facts.
      </PageHeader>
      <Panel title="New goal" className="mb-6"><GoalForm scopes={scopes} /></Panel>
      {goals.length === 0 ? <Empty title="No goals yet">Add your first annual or quarterly goal above.</Empty> : groups.filter((g) => g.items.length).map((g) => (
        <section key={g.h} className="mb-8" aria-label={`${g.h} goals`}>
          <h2 className="eyebrow mb-3">{g.h}</h2>
          <div className="grid gap-4 lg:grid-cols-2">{g.items.map((goal) => <GoalCard key={goal.id + goal.version} goal={goal} scopes={scopes} />)}</div>
        </section>
      ))}
    </>
  );
}
