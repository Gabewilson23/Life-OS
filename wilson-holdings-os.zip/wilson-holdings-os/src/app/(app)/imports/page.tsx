import { ImportWizard } from "@/components/ImportClient";
import { Badge, PageHeader, Panel, ScopeTag } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { DATASETS, companyScope } from "@/lib/company/datasets";

export const metadata = { title: "Imports" };

export default async function ImportsPage() {
  const { user, ctx } = await requirePageUser();
  const batches = (await withCtx(ctx, (db) => db.query(`SELECT id, scope, dataset, filename, row_count, inserted, updated, unchanged, rejected, status, created_at FROM import_batches ORDER BY created_at DESC LIMIT 40`))).rows;
  const allowed = DATASETS.filter((d) => user.writeScopes.includes(companyScope(d.company)));
  return (
    <>
      <PageHeader eyebrow="Data" title="Imports">CSV/XLSX import with mapping preview, row-level validation, de-duplication by natural key, and provenance on every record. Nothing is hardcoded — figures come only from what you import or connect.</PageHeader>
      <Panel title="Import a file">{allowed.length ? <ImportWizard datasets={allowed.map((d) => ({ id: d.id, label: d.label, company: d.company, keyLabel: d.keyLabel, description: d.description, fields: d.fields.map((f) => ({ key: f.key, label: f.label, required: f.required })) }))} /> : <p className="text-sm text-stone-500">You have no write access to a company scope.</p>}</Panel>
      <Panel className="mt-6" title="Import history">
        {batches.length ? <table className="w-full text-sm"><thead className="text-left text-[11px] uppercase tracking-wider text-stone-500"><tr><th className="py-2">When</th><th>File</th><th>Dataset</th><th>Result</th><th /></tr></thead><tbody className="divide-y divide-white/[0.05]">
          {batches.map((b) => <tr key={b.id}><td className="py-2 text-xs text-stone-500">{new Date(b.created_at).toLocaleString("en-US", { timeZone: "America/New_York" })}</td><td>{b.filename}</td><td><ScopeTag scope={b.scope} /> {b.dataset}</td><td className="text-xs">{b.status === "committed" ? `${b.inserted} new · ${b.updated} upd · ${b.unchanged} same · ${b.rejected} rejected` : <Badge>{b.status}</Badge>}</td><td>{b.rejected > 0 && <a className="text-xs underline" href={`/api/imports/${b.id}/errors`}>errors.csv</a>}</td></tr>)}
        </tbody></table> : <p className="text-sm text-stone-500">No imports yet.</p>}
      </Panel>
    </>
  );
}
