import { AccountActions, ConnectGoogle, StatusBadge } from "@/components/IntegrationsClient";
import { PageHeader, Panel, ScopeTag, scopeOptions } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { canEncrypt } from "@/lib/server/crypto";
import { CATALOG } from "@/lib/server/integrations/catalog";
import { googleConfigured } from "@/lib/server/integrations/google";

export const metadata = { title: "Integrations" };

export default async function IntegrationsPage({ searchParams }: { searchParams: Promise<{ connected?: string; partial?: string; error?: string }> }) {
  const { user, ctx } = await requirePageUser();
  const sp = await searchParams;
  const accounts = (await withCtx(ctx, (db) => db.query(`SELECT id, scope, label, external_account, status, capabilities, paused, last_sync_at, last_error FROM integration_accounts ORDER BY created_at DESC`))).rows;
  const configured = googleConfigured() && canEncrypt();
  return (
    <>
      <PageHeader eyebrow="Connections" title="Integrations">A connector framework with honest statuses. A card here never means an account is connected — only an authorized account below does.</PageHeader>
      {sp.error && <p role="alert" className="mb-4 rounded-[12px] border border-signal-red/30 bg-signal-red/10 p-3 text-sm text-signal-red">Connection failed: {sp.error}</p>}
      {sp.connected && <p role="status" className="mb-4 rounded-[12px] border border-signal-green/30 bg-signal-green/10 p-3 text-sm text-signal-green">Google account connected.{sp.partial ? " Some requested permissions were not granted — only the granted capabilities are enabled." : ""}</p>}
      <div className="grid gap-6 xl:grid-cols-2">
        <Panel eyebrow="Calendar & email" title="Connect a Google account"><ConnectGoogle scopes={scopeOptions(user.writeScopes)} configured={configured} /></Panel>
        <Panel title={`Connected accounts (${accounts.length})`}>
          {accounts.length === 0 ? <p className="text-sm text-stone-500">None connected. Connect your personal and each company&apos;s Google account separately.</p> : (
            <ul className="space-y-3">{accounts.map((a) => (
              <li key={a.id} className="rounded-[14px] border border-white/[0.07] bg-black/20 p-3">
                <div className="flex flex-wrap items-center gap-1.5"><span className="font-medium text-stone-50">{a.label}</span><span className="text-xs text-stone-400">{a.external_account}</span><StatusBadge s={a.paused ? "paused" : a.status} /><ScopeTag scope={a.scope} /></div>
                <p className="mt-1 text-xs text-stone-500">Capabilities: {(a.capabilities as string[]).join(", ") || "none"} · last sync {a.last_sync_at ? new Date(a.last_sync_at).toLocaleString("en-US", { timeZone: "America/New_York" }) : "never"}{a.last_error ? ` · ${a.last_error}` : ""}</p>
                <div className="mt-2"><AccountActions id={a.id} paused={a.paused} scope={a.scope} capabilities={a.capabilities} /></div>
              </li>))}</ul>
          )}
        </Panel>
      </div>
      <Panel className="mt-6" title="Marketplace">
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {CATALOG.map((c) => (
            <div key={c.id} className="rounded-[14px] border border-white/[0.07] bg-black/20 p-3">
              <div className="flex items-start justify-between gap-2"><div><p className="font-medium text-stone-50">{c.name}</p><p className="text-xs text-stone-500">{c.category}</p></div><StatusBadge s={c.id.startsWith("google") || c.id === "gmail" ? (configured ? c.status : "setup needed") : c.status} /></div>
              {(c.read.length > 0 || c.write.length > 0) && <p className="mt-2 text-xs text-stone-400"><strong className="text-stone-300">Read:</strong> {c.read.join(", ") || "—"}<br /><strong className="text-stone-300">Write:</strong> {c.write.join(", ") || "—"}</p>}
              <p className="mt-1.5 text-xs text-stone-500">{c.notes}</p>
            </div>
          ))}
        </div>
      </Panel>
    </>
  );
}
