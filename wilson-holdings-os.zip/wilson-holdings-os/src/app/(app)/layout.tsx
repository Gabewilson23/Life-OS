import { Shell } from "@/components/Shell";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { isDemo } from "@/lib/server/env";
import { getFlag } from "@/lib/server/services/org";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const { user, ctx } = await requirePageUser();
  const paused = (await withCtx(ctx, (db) => getFlag(db, ctx, "pause.global"))) === true;
  return <Shell user={{ displayName: user.displayName, role: user.role }} demo={isDemo()} paused={paused}>{children}</Shell>;
}
