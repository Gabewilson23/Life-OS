import Link from "next/link";
import { notFound } from "next/navigation";
import { z } from "zod";
import { Badge, PageHeader, Panel } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";

export default async function MeetingPage({ params }: { params: Promise<{ id: string }> }) {
  const id = z.string().uuid().safeParse((await params).id);
  if (!id.success) notFound();
  const { ctx } = await requirePageUser();
  const data = await withCtx(ctx, async (db) => {
    const m = (await db.query(`SELECT * FROM meetings WHERE id = $1`, [id.data])).rows[0];
    if (!m) return null;
    const c = (await db.query(`SELECT c.*, a.title FROM meeting_contributions c JOIN agent_definitions a ON a.id = c.agent_id WHERE meeting_id = $1 ORDER BY round, created_at`, [id.data])).rows;
    const o = (await db.query(`SELECT o.*, a.title AS owner_title FROM meeting_outcomes o LEFT JOIN agent_definitions a ON a.id = o.owner_agent_id WHERE meeting_id = $1 ORDER BY kind`, [id.data])).rows;
    return { m, c, o };
  });
  if (!data) notFound();
  const { m, c, o } = data;
  return (
    <>
      <nav className="mb-2 text-xs text-stone-500"><Link href="/meetings">← Meetings</Link></nav>
      <PageHeader eyebrow="AI working session" title={m.title} actions={<Badge tone={m.status === "completed" ? "green" : "amber"}>{m.status}</Badge>}>{m.agenda}{m.blocked_reason && <span className="mt-1 block text-signal-amber">Stopped: {m.blocked_reason}</span>}</PageHeader>
      {m.summary && <Panel className="mb-6" title="Summary"><p className="text-sm text-stone-200">{m.summary}</p></Panel>}
      <div className="grid gap-6 xl:grid-cols-3">
        {(["decision", "dissent", "action"] as const).map((k) => (
          <Panel key={k} title={k === "action" ? "Actions (tasks created)" : k === "decision" ? "Decisions" : "Dissent"}>
            {o.filter((x) => x.kind === k).length ? <ul className="space-y-2 text-sm">{o.filter((x) => x.kind === k).map((x) => <li key={x.id}>{x.content}{x.owner_title && <span className="block text-xs text-stone-500">{k === "dissent" ? "raised by" : "owner"}: {x.owner_title}</span>}{x.evidence && <span className="block text-xs text-stone-500">evidence: {x.evidence}</span>}{x.task_id && <Link className="text-xs text-signal-blue" href={`/tasks#${x.task_id}`}>task →</Link>}</li>)}</ul> : <p className="text-sm text-stone-500">None recorded.</p>}
          </Panel>
        ))}
      </div>
      <Panel className="mt-6" title="Contribution record">
        <ol className="space-y-3">{c.map((x) => <li key={x.id} className="rounded-[12px] border border-white/[0.06] bg-black/20 p-3 text-sm"><p className="mb-1 text-xs text-stone-500">Round {x.round} · {x.title}</p><p className="whitespace-pre-wrap text-stone-200">{x.content}</p></li>)}</ol>
      </Panel>
    </>
  );
}
