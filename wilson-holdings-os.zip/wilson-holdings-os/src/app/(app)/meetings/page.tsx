import Link from "next/link";
import { NewMeeting } from "@/components/OpsClient";
import { Badge, PageHeader, Panel } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { listAgents } from "@/lib/server/services/org";

export const metadata = { title: "Meetings" };

export default async function MeetingsPage() {
  const { ctx } = await requirePageUser();
  const [agents, meetings, human] = await withCtx(ctx, (db) => Promise.all([
    listAgents(db),
    db.query(`SELECT id, title, status, blocked_reason, participants, created_at FROM meetings ORDER BY created_at DESC LIMIT 30`).then((r) => r.rows),
    db.query(`SELECT title, starts_at, jsonb_array_length(attendees) AS n FROM calendar_events WHERE jsonb_array_length(attendees) > 0 AND starts_at > now() - interval '1 day' ORDER BY starts_at LIMIT 10`).then((r) => r.rows),
  ]));
  return (
    <>
      <PageHeader eyebrow="Sessions" title="Meetings">AI working sessions call real roles with bounded rounds and record contributions, decisions, dissent and owned actions. Human meetings come from connected calendars; transcripts from Zoom/Teams are not connected yet.</PageHeader>
      <div className="grid gap-6 xl:grid-cols-[1.2fr_1fr]">
        <Panel title="New AI working session"><NewMeeting agents={agents.map((a) => ({ id: a.id, title: a.title, number: a.number }))} /></Panel>
        <div className="space-y-6">
          <Panel title="Recent sessions">{meetings.length ? <ul className="space-y-2 text-sm">{meetings.map((m) => <li key={m.id} className="flex justify-between gap-2"><Link className="hover:text-signal-blue" href={`/meetings/${m.id}`}>{m.title}</Link><Badge tone={m.status === "completed" ? "green" : m.status === "blocked" ? "amber" : "neutral"}>{m.status}</Badge></li>)}</ul> : <p className="text-sm text-stone-500">None yet.</p>}</Panel>
          <Panel title="Upcoming human meetings (calendar)">{human.length ? <ul className="space-y-1 text-sm">{human.map((h, i) => <li key={i}>{h.title} <span className="text-xs text-stone-500">{new Date(h.starts_at).toLocaleString("en-US", { timeZone: "America/New_York" })} · {h.n} attendees</span></li>)}</ul> : <p className="text-sm text-stone-500">No synced meetings with attendees.</p>}</Panel>
        </div>
      </div>
    </>
  );
}
