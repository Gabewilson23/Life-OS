import { MemoryItem, RememberForm, type Mem } from "@/components/MemoryClient";
import { Empty, PageHeader, Panel, scopeOptions } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { isStale, searchMemory } from "@/lib/server/services/memory";

export const metadata = { title: "Brain & memory" };

export default async function MemoryPage({ searchParams }: { searchParams: Promise<{ q?: string; asOf?: string; type?: string }> }) {
  const { user, ctx } = await requirePageUser();
  const sp = await searchParams;
  const { rows, uses, staged } = await withCtx(ctx, async (db) => {
    const rows = await searchMemory(db, ctx, { text: sp.q || undefined, asOf: sp.asOf || undefined, mtypes: sp.type ? [sp.type] : undefined, includeStaged: true, limit: 200 });
    const uses = (await db.query(`SELECT memory_id, count(*)::int n FROM retrieval_lineage GROUP BY memory_id`)).rows as { memory_id: string; n: number }[];
    const staged = (await db.query(`SELECT count(*)::int n FROM proposals WHERE kind = 'memory.remember' AND status = 'proposed'`)).rows[0].n as number;
    return { rows, uses, staged };
  });
  const mems: Mem[] = rows.map((m) => ({ ...m, observed_at: new Date(m.observed_at).toISOString(), verified_at: m.verified_at ? new Date(m.verified_at).toISOString() : null, valid_to: m.valid_to ? new Date(m.valid_to).toISOString() : null, stale: isStale(m), uses: uses.find((u) => u.memory_id === m.id)?.n ?? 0 })) as unknown as Mem[];
  const conflicts = mems.filter((m) => m.conflicts_with.length && m.status === "active");
  const stale = mems.filter((m) => m.stale);
  return (
    <>
      <PageHeader eyebrow="Executive brain" title="Brain & memory">
        Durable, sourced memory across seven types. The model is not the memory — these records are. Nothing sensitive is saved without your explicit intent, and forgetting removes text, derived references and (optionally) re-import of the source.
      </PageHeader>
      <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
        <Panel eyebrow="Teach" title="Remember this"><RememberForm scopes={scopeOptions(user.writeScopes)} /></Panel>
        <Panel eyebrow="Review" title="Needs attention">
          <ul className="space-y-1.5 text-sm">
            <li>{conflicts.length} conflicting fact{conflicts.length === 1 ? "" : "s"} shown side by side below — resolve with “this changed”.</li>
            <li>{stale.length} stale fact{stale.length === 1 ? "" : "s"} past their re-verification window.</li>
            <li>{staged} agent-proposed memor{staged === 1 ? "y" : "ies"} awaiting review in <a className="underline" href="/approvals">Approvals</a> or the chat thread.</li>
          </ul>
          <form className="mt-4 grid gap-2 sm:grid-cols-[1fr_auto_auto_auto]" action="/memory">
            <input className="input" name="q" defaultValue={sp.q} placeholder="Search memory…" aria-label="Search memory" />
            <select className="input w-auto" name="type" defaultValue={sp.type ?? ""} aria-label="Type"><option value="">All types</option>{["identity", "semantic", "episodic", "working", "procedural", "relationship", "outcome"].map((t) => <option key={t}>{t}</option>)}</select>
            <input className="input w-auto" type="date" name="asOf" defaultValue={sp.asOf} aria-label="As of date" title="What was true on this date" />
            <button className="btn">Search</button>
          </form>
        </Panel>
      </div>
      <Panel className="mt-6" title={sp.asOf ? `As of ${sp.asOf}` : "Memories"}>
        {mems.length === 0 ? <Empty title="No memories yet">Teach the system with “Remember this”, or accept facts that agents stage during conversations.</Empty> : <ul className="space-y-2">{mems.map((m) => <MemoryItem key={m.id + m.version} m={m} />)}</ul>}
      </Panel>
    </>
  );
}
