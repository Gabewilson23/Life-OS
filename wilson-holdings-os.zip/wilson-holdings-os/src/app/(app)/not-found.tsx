import Link from "next/link";
export default function NotFound() {
  return <div className="py-20 text-center"><p className="eyebrow">404</p><h1 className="display mt-2 text-3xl">Not found — or not in your scopes</h1><Link href="/" className="btn mt-6">Back to home</Link></div>;
}
