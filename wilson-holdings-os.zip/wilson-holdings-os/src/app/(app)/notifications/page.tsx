import Link from "next/link";
import { MarkAllRead } from "@/components/OpsClient";
import { Badge, PageHeader, Panel } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";

export const metadata = { title: "Notifications" };
export default async function NotificationsPage() {
  const { ctx } = await requirePageUser();
  const rows = (await withCtx(ctx, (db) => db.query(`SELECT * FROM notifications WHERE deliver_after <= now() ORDER BY read_at NULLS FIRST, created_at DESC LIMIT 100`))).rows;
  const held = (await withCtx(ctx, (db) => db.query(`SELECT count(*)::int n FROM notifications WHERE deliver_after > now()`))).rows[0].n;
  return (
    <>
      <PageHeader eyebrow="Inbox" title="Notifications" actions={<MarkAllRead />}>In-app delivery. Duplicates are grouped; routine items wait for quiet hours to end ({held} held right now). External delivery (email/SMS) requires a configured destination and permission.</PageHeader>
      <Panel>{rows.length ? <ul className="divide-y divide-white/[0.05]">{rows.map((n) => <li key={n.id} className={`flex items-center justify-between gap-3 py-2 text-sm ${n.read_at ? "opacity-60" : ""}`}><span>{n.link ? <Link className="hover:text-signal-blue" href={n.link}>{n.title}</Link> : n.title}{n.occurrences > 1 && <span className="ml-1 text-xs text-stone-500">×{n.occurrences}</span>}{n.body && <span className="block text-xs text-stone-500">{n.body}</span>}</span><span className="flex shrink-0 items-center gap-2"><Badge tone={n.priority === "urgent" ? "red" : n.priority === "important" ? "amber" : "neutral"}>{n.priority}</Badge><span className="text-xs text-stone-500">{new Date(n.created_at).toLocaleString("en-US", { timeZone: "America/New_York" })}</span></span></li>)}</ul> : <p className="text-sm text-stone-500">Nothing yet.</p>}</Panel>
    </>
  );
}
