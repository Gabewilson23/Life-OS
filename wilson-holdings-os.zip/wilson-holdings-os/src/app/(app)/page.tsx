import Link from "next/link";
import { OutcomesEditor, QuickAddTask, TaskList } from "@/components/WorkClient";
import { Badge, Empty, Panel, scopeOptions } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { chairmanOverview } from "@/lib/server/services/overview";
import { greeting, longDate } from "@/lib/time";

export const metadata = { title: "Chairman home" };

export default async function Home() {
  const { user, ctx } = await requirePageUser();
  const o = await withCtx(ctx, (db) => chairmanOverview(db, ctx));
  const first = user.displayName.split(" ")[0];
  const scopes = scopeOptions(user.writeScopes);
  const onboarding = o.system.onboarding as Record<string, boolean>;
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow mb-2">{longDate(o.tz)} · {o.tz.replace("_", " ")}</p>
          <h1 className="display text-[34px] leading-tight text-stone-50">{greeting(o.tz)}, {first}.</h1>
          <p className="mt-1 text-sm text-stone-400">{o.exceptions.length ? `${o.exceptions.length} exception${o.exceptions.length > 1 ? "s" : ""} need attention.` : "No open exceptions."} {o.goals.active} active goal{o.goals.active === 1 ? "" : "s"}.</p>
        </div>
        <Link href="/campus" className="btn">Open campus</Link>
      </div>

      {!onboarding.contractingModelConfirmed && (
        <div className="glass flex flex-wrap items-center justify-between gap-3 rounded-[var(--radius-lg)] border-champagne-400/25 px-5 py-4">
          <div>
            <p className="text-sm font-medium text-champagne-200">Onboarding is incomplete</p>
            <p className="text-sm text-stone-400">Atlas Consulting&apos;s contracting model, company leaders, calendars and data sources are not yet confirmed. Nothing has been assumed.</p>
          </div>
          <Link href="/settings" className="btn btn-sm">Review onboarding</Link>
        </div>
      )}

      <div className="grid gap-6 xl:grid-cols-[1.35fr_1fr]">
        <Panel id="outcomes" eyebrow="Today" title="Three outcomes">
          <OutcomesEditor date={o.today} outcomes={o.outcomes} />
        </Panel>
        <Panel id="exceptions" eyebrow="Needs attention" title="Exceptions">
          {o.exceptions.length === 0 ? <p className="text-sm text-stone-500">No blocked or overdue tasks.</p> : (
            <ul className="space-y-2">
              {o.exceptions.slice(0, 6).map((e) => (
                <li key={e.task.id} className="flex items-start justify-between gap-3 text-sm">
                  <Link href={`/tasks#${e.task.id}`} className="text-stone-100 hover:text-champagne-200">{e.task.title}</Link>
                  <Badge tone="red">{e.kind === "blocked" ? "Blocked" : `Overdue · ${e.task.dueDate}`}</Badge>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.35fr_1fr]">
        <Panel id="next" eyebrow="Prepared" title="Next actions" actions={<Link href="/tasks" className="btn btn-ghost btn-sm">All tasks</Link>}>
          <div className="mb-4"><QuickAddTask scopes={scopes} /></div>
          <TaskList tasks={o.nextActions} today={o.today} emptyText="No open tasks yet. Add the first one above." />
        </Panel>
        <Panel id="decisions" eyebrow="Decision queue" title="Decisions">
          {o.decisions.length ? <ul className="space-y-2 text-sm">{o.decisions.map((d) => <li key={d.id}><Link className="text-stone-100 hover:text-signal-blue" href={d.href}>{d.title}</Link></li>)}</ul> : <Empty title="No decisions waiting">External writes are prepare-only by policy; anything that needs you appears here.</Empty>}
          {o.latestReport && <p className="mt-4 text-xs text-stone-500">Latest report: <Link className="underline" href={`/briefings/${o.latestReport.id}`}>{o.latestReport.title}</Link></p>}
        </Panel>
      </div>

      <Panel id="companies" eyebrow="Portfolio" title="Company updates">
        <div className="grid gap-4 md:grid-cols-2">
          {o.companies.map((c) => (
            <div key={c.id} className="rounded-[var(--radius-md)] border border-white/[0.06] bg-black/20 p-4">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2"><span aria-hidden className="h-2 w-2 rounded-full bg-signal-blue shadow-[0_0_10px_#6fb6ff]" /><h3 className="font-medium text-stone-50">{c.name}</h3></div>
                <Link className="btn btn-ghost btn-sm" href={`/buildings/${c.slug}`}>Building</Link>
              </div>
              <dl className="mt-3 grid grid-cols-3 gap-2 text-xs">
                <div><dt className="text-stone-500">Open tasks</dt><dd className="num text-lg text-stone-100">{c.openTasks}</dd></div>
                <div><dt className="text-stone-500">Blocked</dt><dd className="num text-lg text-stone-100">{c.blocked}</dd></div>
                <div><dt className="text-stone-500">Last data</dt><dd className="text-stone-400">{c.lastSync ? new Date(c.lastSync).toLocaleDateString("en-US", { timeZone: o.tz }) : "Never"}</dd></div>
              </dl>
              <p className="mt-3 text-xs text-stone-500">{c.lastSync ? <Link className="underline" href={`/companies/${c.slug}`}>Open console for figures</Link> : "No company data imported yet, so there are no figures to report."}{c.needsConfirmation && " Business model awaits confirmation."}</p>
            </div>
          ))}
        </div>
      </Panel>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel id="health" eyebrow="System" title="System health">
          <ul className="space-y-2 text-sm">
            <HealthRow label="Database" ok detail="Connected" />
            <HealthRow label="Global pause" ok={!o.system.globalPause} detail={o.system.globalPause ? "Engaged" : "Off"} />
            <HealthRow label="Model credential" ok={o.system.modelCredential} warn detail={o.system.modelCredential ? "Configured (server-side)" : "Missing — agent runs will report credential missing"} />
            <HealthRow label="Background runner" warn ok={!!o.system.worker?.healthy} detail={o.system.worker ? `${o.system.worker.id} · last seen ${new Date(o.system.worker.lastSeen).toLocaleTimeString("en-US", { timeZone: o.tz, hour: "numeric", minute: "2-digit" })}` : "No heartbeat — set up the scheduled tick or `npm run worker`"} />
            <HealthRow label="Connected accounts" warn ok={!o.system.integrations.degraded && !o.system.integrations.stale} detail={Object.keys(o.system.integrations).length ? Object.entries(o.system.integrations).map(([k, v]) => `${v} ${k}`).join(", ") : "None connected"} />
            <HealthRow label="Google OAuth" warn ok={o.system.googleOAuthConfigured} detail={o.system.googleOAuthConfigured ? "Client configured; no account connected" : "Setup needed"} />
            <HealthRow label="Agent runs" ok detail={Object.keys(o.system.runs).length ? Object.entries(o.system.runs).map(([k, v]) => `${v} ${k}`).join(", ") : "None yet"} />
          </ul>
        </Panel>
        <Panel id="activity" eyebrow="Audit trail" title="Recent activity" actions={<Link href="/activity" className="btn btn-ghost btn-sm">All</Link>}>
          {o.recentActivity.length === 0 ? <p className="text-sm text-stone-500">No activity yet.</p> : (
            <ul className="space-y-2 text-sm">
              {o.recentActivity.map((a, i) => (
                <li key={i} className="flex justify-between gap-3"><span className="text-stone-300">{a.summary || a.action}</span><time className="shrink-0 text-xs text-stone-500" dateTime={new Date(a.at).toISOString()}>{new Date(a.at).toLocaleTimeString("en-US", { timeZone: o.tz, hour: "numeric", minute: "2-digit" })}</time></li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </div>
  );
}

function HealthRow({ label, ok, warn, detail }: { label: string; ok: boolean; warn?: boolean; detail: string }) {
  return (
    <li className="flex items-center justify-between gap-3">
      <span className="flex items-center gap-2 text-stone-300"><span aria-hidden className={`h-1.5 w-1.5 rounded-full ${ok ? "bg-signal-green" : warn ? "bg-signal-amber" : "bg-signal-red"}`} />{label}</span>
      <span className="text-right text-xs text-stone-500">{detail}</span>
    </li>
  );
}
