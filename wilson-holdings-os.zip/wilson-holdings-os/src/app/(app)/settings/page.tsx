import { ConsultingModelForm, GlobalPauseToggle } from "@/components/OrgClient";
import { Badge, PageHeader, Panel } from "@/components/ui";
import { MfaSetup } from "@/components/MfaClient";
import { pool } from "@/lib/server/db";
import { canEncrypt } from "@/lib/server/crypto";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { env, isDemo } from "@/lib/server/env";
import { getFlag, listCompanies } from "@/lib/server/services/org";

export const metadata = { title: "Settings" };

export default async function SettingsPage() {
  const { user, ctx } = await requirePageUser();
  const [paused, companies, policies, org] = await withCtx(ctx, (db) => Promise.all([
    getFlag(db, ctx, "pause.global"), listCompanies(db),
    db.query(`SELECT action_class, level, description FROM policies ORDER BY created_at`).then((r) => r.rows),
    db.query(`SELECT settings, timezone FROM organizations WHERE id = $1`, [ctx.orgId]).then((r) => r.rows[0]),
  ]));
  const mfa = (await pool().query(`SELECT mfa_enabled FROM users WHERE id = $1`, [user.id])).rows[0]?.mfa_enabled === true;
  const consulting = companies.find((c) => c.kind === "consulting");
  const ob = (org?.settings?.onboarding ?? {}) as Record<string, boolean>;
  const checklist: [string, boolean, string][] = [
    ["Owner identity", !!ob.ownerConfirmed, "Owner account created"],
    ["Atlas Consulting contracting model", !!ob.contractingModelConfirmed, "Confirm below"],
    ["Human company leaders", false, "Import recruits & agents, or add via Atlas CRM"],
    ["Calendar accounts", false, "Integrations → Connect a Google account"],
    ["Data sources", false, "Imports (CSV/XLSX) or connectors"],
    ["Budgets and quiet hours", false, "Briefings → quiet hours; role budgets on each role"],
    ["Standing permissions", false, "Integrations → narrow standing permissions"],
    ["Sensitive-data preferences", false, "Brain & memory (sensitive items need explicit intent)"],
  ];
  return (
    <>
      <PageHeader eyebrow="Administration" title="Settings" />
      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Onboarding">
          <ul className="space-y-2 text-sm">
            {checklist.map(([l, ok, hint]) => (
              <li key={l} className="flex items-center justify-between gap-3"><span className="flex items-center gap-2"><span aria-hidden className={`h-1.5 w-1.5 rounded-full ${ok ? "bg-signal-green" : "bg-white/20"}`} />{l}</span><span className="text-right text-xs text-stone-500">{ok ? "Confirmed" : hint}</span></li>
            ))}
          </ul>
        </Panel>
        <Panel title="Sign-in security"><MfaSetup enabled={mfa} available={canEncrypt()} /></Panel>
        <Panel title="Emergency controls">
          <p className="mb-3 text-sm text-stone-400">Global pause stops pending agent execution and external writes. Per-role pause is on each role&apos;s profile.</p>
          <GlobalPauseToggle paused={paused === true} />
        </Panel>
        <Panel title="Atlas Consulting — contracting model" className="lg:col-span-2">
          <p className="mb-4 text-sm text-stone-400">Nothing about this business is assumed (not construction, staffing or advisory). Your answer is stored as a user-confirmed fact and decides which workflow templates activate.</p>
          <ConsultingModelForm current={{ businessModel: consulting?.settings?.businessModel ?? null, enabledWorkflows: consulting?.settings?.enabledWorkflows ?? [] }} />
        </Panel>
        <Panel title="Authority policies">
          <ul className="space-y-2 text-sm">{policies.map((p) => <li key={p.action_class} className="flex items-start justify-between gap-3"><span><code className="font-mono text-xs text-stone-300">{p.action_class}</code><span className="block text-xs text-stone-500">{p.description}</span></span><Badge tone={p.level === "escalate" ? "red" : "champagne"}>{p.level}</Badge></li>)}</ul>
        </Panel>
        <Panel title="Environment">
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between"><dt className="text-stone-500">Signed in as</dt><dd>{user.email}</dd></div>
            <div className="flex justify-between"><dt className="text-stone-500">Timezone</dt><dd>{org?.timezone}</dd></div>
            <div className="flex justify-between"><dt className="text-stone-500">Mode</dt><dd>{isDemo() ? "Demo (separate database)" : "Live data"}</dd></div>
            <div className="flex justify-between"><dt className="text-stone-500">Agent concurrency</dt><dd className="num">{env().AGENT_CONCURRENCY}</dd></div>
            <div className="flex justify-between"><dt className="text-stone-500">Default model</dt><dd className="font-mono text-xs">{env().ANTHROPIC_MODEL}</dd></div>
          </dl>
        </Panel>
      </div>
    </>
  );
}
