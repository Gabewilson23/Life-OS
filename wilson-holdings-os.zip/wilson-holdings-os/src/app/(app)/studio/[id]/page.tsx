import Link from "next/link";
import { notFound } from "next/navigation";
import { z } from "zod";
import { FormRenderer, type FormDefinition } from "@/components/FormRenderer";
import { CapabilityEditor } from "@/components/StudioClient";
import { Badge, PageHeader, Panel, ScopeTag } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";

export default async function CapabilityPage({ params }: { params: Promise<{ id: string }> }) {
  const id = z.string().uuid().safeParse((await params).id);
  if (!id.success) notFound();
  const { ctx } = await requirePageUser();
  const data = await withCtx(ctx, async (db) => {
    const c = (await db.query(`SELECT * FROM capabilities WHERE id = $1`, [id.data])).rows[0];
    if (!c) return null;
    const versions = (await db.query(`SELECT version, definition, definition_hash, test_status, test_report, created_at FROM capability_versions WHERE capability_id = $1 ORDER BY version`, [id.data])).rows;
    const subs = c.kind === "form" ? (await db.query(`SELECT id, form_version, data, created_at FROM form_submissions WHERE form_id = $1 ORDER BY created_at DESC LIMIT 25`, [id.data])).rows : [];
    const runs = c.kind === "workflow" ? (await db.query(`SELECT id, workflow_version, status, steps, error, created_at FROM workflow_runs WHERE workflow_id = $1 ORDER BY created_at DESC LIMIT 25`, [id.data])).rows : [];
    const related = c.kind === "form" ? (await db.query(`SELECT c.id, c.name FROM capabilities c JOIN capability_versions v ON v.capability_id = c.id AND v.version = c.current_version WHERE c.kind = 'workflow' AND v.definition->'trigger'->>'formSlug' = $1`, [c.slug])).rows : [];
    return { c, versions, subs, runs, related };
  });
  if (!data) notFound();
  const { c, versions, subs, runs, related } = data;
  const live = versions.find((v) => v.version === c.current_version)!;
  const lastTest = [...versions].reverse().find((v) => v.test_report)?.test_report;
  return (
    <>
      <nav className="mb-2 text-xs text-stone-500"><Link href="/studio">← Build Studio</Link></nav>
      <PageHeader eyebrow={c.kind} title={c.name} actions={<ScopeTag scope={c.scope} />}>Slug <code>{c.slug}</code>. Edits create a new version; submissions keep the version they were made with.{related.length > 0 && <> Triggers: {related.map((r) => <Link key={r.id} className="underline" href={`/studio/${r.id}`}>{r.name}</Link>)}.</>}</PageHeader>
      <div className="grid gap-6 xl:grid-cols-[1.3fr_1fr]">
        <Panel title="Editor"><CapabilityEditor id={c.id} kind={c.kind} status={c.status} access={c.access} slug={c.slug} currentVersion={c.current_version} versions={versions.map((v) => ({ version: v.version, definition: v.definition, definition_hash: v.definition_hash, test_status: v.test_status }))} /></Panel>
        {c.kind === "form" ? <Panel title={`Preview (live v${c.current_version})`}><FormRenderer slug={c.slug} def={live.definition as FormDefinition} preview /></Panel>
          : <Panel title="Last test result">{lastTest ? <pre className="max-h-96 overflow-auto whitespace-pre-wrap font-mono text-[11px] text-stone-300">{JSON.stringify(lastTest, null, 2)}</pre> : <p className="text-sm text-stone-500">Not tested yet. Tests run the real steps in a rolled-back transaction and call no external services.</p>}</Panel>}
      </div>
      {c.kind === "form" ? (
        <Panel className="mt-6" title={`Submissions (${subs.length})`}>{subs.length ? <ul className="space-y-1 text-sm">{subs.map((s) => <li key={s.id} className="flex justify-between gap-2"><span className="truncate">{String(s.data.full_name ?? Object.values(s.data)[0] ?? "")} <span className="text-xs text-stone-500">{String(s.data.email ?? "")}</span></span><span className="flex gap-1"><Badge>form v{s.form_version}</Badge><span className="text-xs text-stone-500">{new Date(s.created_at).toLocaleString("en-US", { timeZone: "America/New_York" })}</span></span></li>)}</ul> : <p className="text-sm text-stone-500">No submissions.</p>}</Panel>
      ) : (
        <Panel className="mt-6" title={`Runs (${runs.length})`}>{runs.length ? <ul className="space-y-2 text-sm">{runs.map((r) => <li key={r.id}><Badge tone={r.status === "succeeded" ? "green" : r.status === "failed" ? "red" : "amber"}>{r.status}</Badge> <span className="text-xs text-stone-500">v{r.workflow_version} · {new Date(r.created_at).toLocaleString("en-US", { timeZone: "America/New_York" })}</span>{r.error && <span className="ml-1 text-xs text-signal-red">{r.error}</span>}<ul className="ml-4 text-xs text-stone-400">{(r.steps as { type: string; result: string }[]).map((s, i) => <li key={i}>{s.type}: {s.result}</li>)}</ul></li>)}</ul> : <p className="text-sm text-stone-500">No runs yet. Runs are triggered by submissions of the linked form.</p>}</Panel>
      )}
    </>
  );
}
