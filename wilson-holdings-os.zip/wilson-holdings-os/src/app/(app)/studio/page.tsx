import Link from "next/link";
import { ChangeActions, ChangeRequestForm, NewFromTemplate } from "@/components/StudioClient";
import { Badge, PageHeader, Panel, ScopeTag, scopeOptions } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { githubConfig } from "@/lib/server/integrations/github";

export const metadata = { title: "Build Studio" };
export default async function StudioPage() {
  const { user, ctx } = await requirePageUser();
  const [caps, changes] = await withCtx(ctx, (db) => Promise.all([
    db.query(`SELECT c.*, (SELECT count(*)::int FROM form_submissions s WHERE s.form_id = c.id) AS submissions FROM capabilities c ORDER BY c.updated_at DESC`).then((r) => r.rows),
    db.query(`SELECT * FROM change_requests ORDER BY created_at DESC LIMIT 20`).then((r) => r.rows),
  ]));
  const companyScopes = scopeOptions(user.writeScopes.filter((s) => s.startsWith("company:") || s === "org"));
  return (
    <>
      <PageHeader eyebrow="Build Studio" title="Add abilities without rebuilding">Everyday changes are versioned configuration — forms, fields, workflows and templates built from allowlisted parts and validated on the server. Genuinely new abilities go through an isolated branch, independent checks and a release approval bound to the exact commit.</PageHeader>
      <div className="grid gap-6 xl:grid-cols-2">
        <Panel eyebrow="Configuration path" title="Create">
          <NewFromTemplate scopes={companyScopes} />
        </Panel>
        <Panel eyebrow="Registry" title={`Capabilities (${caps.length})`}>
          {caps.length ? <ul className="divide-y divide-white/[0.05]">{caps.map((c) => <li key={c.id} className="flex items-center justify-between gap-2 py-2 text-sm"><Link className="hover:text-signal-blue" href={`/studio/${c.id}`}>{c.name} <span className="text-xs text-stone-500">· {c.kind} · v{c.current_version}{c.kind === "form" ? ` · ${c.submissions} submissions` : ""}</span></Link><span className="flex gap-1"><ScopeTag scope={c.scope} /><Badge tone={c.status === "active" ? "green" : c.status === "paused" ? "amber" : "neutral"}>{c.status}</Badge>{c.access === "public" && <Badge tone="red">public</Badge>}</span></li>)}</ul> : <p className="text-sm text-stone-500">No capabilities yet.</p>}
        </Panel>
      </div>
      <Panel className="mt-6" eyebrow="Code path" title="Change requests">
        <p className="mb-3 text-xs text-stone-500">Repository access: {githubConfig() ? <Badge tone="green">configured</Badge> : <Badge tone="amber">not configured — branches/PRs are blocked (set GITHUB_TOKEN + GITHUB_REPO)</Badge>}. The app never edits its own running code, database or policies; production secrets are never available to coding work.</p>
        <ChangeRequestForm />
        <ul className="mt-4 space-y-3">{changes.map((c) => (
          <li key={c.id} className="rounded-[14px] border border-white/[0.07] bg-black/20 p-3">
            <div className="flex flex-wrap items-center justify-between gap-2"><p className="font-medium text-stone-50">{c.title}</p><Badge tone={c.status === "released" ? "green" : c.status === "blocked" || c.status === "qa_failed" ? "red" : "amber"}>{c.status.replace(/_/g, " ")}</Badge></div>
            <p className="mt-1 text-xs text-stone-400">{c.spec?.reuseAnalysis}</p>
            {c.blocker && <p className="mt-1 text-xs text-signal-amber">Blocker: {c.blocker}</p>}
            <p className="mt-1 text-xs text-stone-500">{c.branch && <>branch {c.branch} · </>}{c.pr_number && <>PR #{c.pr_number} · </>}{c.commit_sha && <>commit {String(c.commit_sha).slice(0, 7)} · </>}{c.checks ? `${(c.checks as unknown[]).length} checks` : "no checks yet"}</p>
            <details className="mt-1 text-xs text-stone-400"><summary className="cursor-pointer">Spec & acceptance criteria</summary><ul className="mt-1 list-disc pl-5">{(c.spec?.acceptanceCriteria ?? []).map((a: string) => <li key={a}>{a}</li>)}</ul><p className="mt-1">Rollback: {c.rollback_plan}</p></details>
            <div className="mt-2"><ChangeActions id={c.id} status={c.status} hash={c.release_approval_hash} /></div>
          </li>))}</ul>
      </Panel>
    </>
  );
}
