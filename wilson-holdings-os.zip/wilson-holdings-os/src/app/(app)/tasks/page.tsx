import { QuickAddTask, TaskList } from "@/components/WorkClient";
import { PageHeader, Panel, scopeOptions, SCOPE_LABEL } from "@/components/ui";
import { requirePageUser } from "@/lib/server/auth/current";
import { withCtx } from "@/lib/server/db";
import { env } from "@/lib/server/env";
import { listGoals, listTasks } from "@/lib/server/services/work";
import { localDate } from "@/lib/time";

export const metadata = { title: "Tasks" };

export default async function TasksPage({ searchParams }: { searchParams: Promise<{ all?: string; scope?: string }> }) {
  const { user, ctx } = await requirePageUser();
  const sp = await searchParams;
  const all = sp.all === "1";
  const [tasks, goals] = await withCtx(ctx, (db) => Promise.all([listTasks(db, { includeClosed: all }), listGoals(db)]));
  const filtered = sp.scope ? tasks.filter((t) => t.scope === sp.scope) : tasks;
  const today = localDate(env().DEFAULT_TIMEZONE);
  const usedScopes = [...new Set(tasks.map((t) => t.scope))];
  return (
    <>
      <PageHeader eyebrow="Work queue" title="Tasks" actions={<a className="btn btn-ghost btn-sm" href={all ? "/tasks" : "/tasks?all=1"}>{all ? "Hide closed" : "Show closed"}</a>}>
        Your work items across the holding company, both companies and personal scopes. Agent runs are tracked separately on each role.
      </PageHeader>
      <Panel className="mb-6" title="Add task"><QuickAddTask scopes={scopeOptions(user.writeScopes)} goals={goals.map((g) => ({ id: g.id, title: g.title }))} /></Panel>
      <nav aria-label="Filter by scope" className="mb-3 flex flex-wrap gap-1.5 text-xs">
        <a href={all ? "/tasks?all=1" : "/tasks"} className={`btn btn-sm ${!sp.scope ? "btn-primary" : ""}`}>All ({tasks.length})</a>
        {usedScopes.map((s) => <a key={s} href={`/tasks?scope=${encodeURIComponent(s)}${all ? "&all=1" : ""}`} className={`btn btn-sm ${sp.scope === s ? "btn-primary" : ""}`}>{SCOPE_LABEL[s] ?? s} ({tasks.filter((t) => t.scope === s).length})</a>)}
      </nav>
      <Panel><TaskList tasks={filtered} today={today} emptyText="No tasks in this view." /></Panel>
    </>
  );
}
