export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <main id="main" className="grid min-h-screen place-items-center px-4 py-12">
      <div className="w-full max-w-[420px]">
        <div className="mb-8 text-center">
          <div aria-hidden className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-2xl border border-champagne-400/40 bg-gradient-to-b from-champagne-400/25 to-transparent shadow-[var(--shadow-glow-champagne)]">
            <span className="display text-xl text-champagne-200">W</span>
          </div>
          <p className="eyebrow">Private headquarters</p>
          <h1 className="display mt-1 text-3xl text-stone-50">Wilson Holdings</h1>
        </div>
        {children}
      </div>
    </main>
  );
}
