import { redirect } from "next/navigation";
import { LoginForm } from "@/components/AuthForms";
import { currentUser } from "@/lib/server/auth/current";
import { ownerExists } from "@/lib/server/services/auth";

export const dynamic = "force-dynamic";
export const metadata = { title: "Sign in" };

export default async function LoginPage() {
  if (await currentUser()) redirect("/");
  if (!(await ownerExists())) redirect("/setup");
  return <LoginForm />;
}
