import { redirect } from "next/navigation";
import { SetupForm } from "@/components/AuthForms";
import { ownerExists } from "@/lib/server/services/auth";

export const dynamic = "force-dynamic";
export const metadata = { title: "Owner setup" };

export default async function SetupPage() {
  if (await ownerExists()) redirect("/login");
  return <SetupForm />;
}
