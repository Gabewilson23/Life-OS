import { NextResponse } from "next/server";
import { z } from "zod";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { setAgentStatus } from "@/lib/server/services/org";

const Body = z.object({ status: z.enum(["idle", "paused"]), version: z.number().int().positive() });

export const POST = route<{ id: string }>(async (req, { id }) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, Body);
  return NextResponse.json(await withCtx(ctx, (db) => setAgentStatus(db, ctx, z.string().max(80).parse(id), b.status, b.version)));
});
