import { NextResponse } from "next/server";
import { z } from "zod";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { decideApproval, executeApproval, reconcileAttempt, revokeApproval } from "@/lib/server/services/approvals";

const Body = z.discriminatedUnion("action", [
  z.object({ action: z.literal("approve"), hash: z.string().length(64), executeNow: z.boolean().default(true) }),
  z.object({ action: z.literal("deny"), hash: z.string().length(64) }),
  z.object({ action: z.literal("execute") }),
  z.object({ action: z.literal("revoke") }),
  z.object({ action: z.literal("reconcile"), attemptId: z.string().uuid(), retryIfAbsent: z.boolean().default(false) }),
]);

export const POST = route<{ id: string }>(async (req, { id }) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, Body);
  const aid = z.string().uuid().parse(id);
  if (b.action === "approve") {
    await withCtx(ctx, (db) => decideApproval(db, ctx, aid, true, b.hash));
    return NextResponse.json(b.executeNow ? await executeApproval(ctx, aid) : { status: "approved" });
  }
  if (b.action === "deny") return NextResponse.json(await withCtx(ctx, (db) => decideApproval(db, ctx, aid, false, b.hash)));
  if (b.action === "execute") return NextResponse.json(await executeApproval(ctx, aid));
  if (b.action === "revoke") { await withCtx(ctx, (db) => revokeApproval(db, ctx, aid)); return NextResponse.json({ ok: true }); }
  return NextResponse.json(await reconcileAttempt(ctx, b.attemptId, { retryIfAbsent: b.retryIfAbsent }));
});
