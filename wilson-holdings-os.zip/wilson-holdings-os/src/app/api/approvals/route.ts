import { NextResponse } from "next/server";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { ApprovalRequest, listApprovals, requestApproval } from "@/lib/server/services/approvals";

export const GET = route(async (req) => {
  const { ctx } = await apiUser(req);
  return NextResponse.json({ approvals: await withCtx(ctx, (db) => listApprovals(db, req.nextUrl.searchParams.get("status") ?? undefined)) });
});
export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, ApprovalRequest);
  return NextResponse.json(await withCtx(ctx, (db) => requestApproval(db, ctx, b)), { status: 201 });
});
