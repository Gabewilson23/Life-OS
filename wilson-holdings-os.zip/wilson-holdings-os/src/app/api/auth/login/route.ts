import { NextResponse } from "next/server";
import { z } from "zod";
import { env } from "@/lib/server/env";
import { parseJson, route } from "@/lib/server/http";
import { login } from "@/lib/server/services/auth";
import { createSession, SESSION_COOKIE } from "@/lib/server/auth/session";

const Body = z.object({ email: z.string().trim().min(1).max(254), password: z.string().min(1).max(256), code: z.string().max(10).optional() });

export const POST = route(async (req) => {
  const b = await parseJson(req, Body);
  const ip = req.headers.get("x-forwarded-for");
  const userId = await login(b.email, b.password, ip, b.code);
  const s = await createSession(userId, { ua: req.headers.get("user-agent"), ip });
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, s.token, { httpOnly: true, sameSite: "lax", secure: env().APP_ENV === "production", path: "/", maxAge: s.maxAgeSeconds });
  return res;
});
