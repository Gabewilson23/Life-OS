import { NextResponse } from "next/server";
import { route } from "@/lib/server/http";
import { revokeSession, SESSION_COOKIE } from "@/lib/server/auth/session";

export const POST = route(async (req) => {
  const t = req.cookies.get(SESSION_COOKIE)?.value;
  if (t) await revokeSession(t);
  const res = NextResponse.json({ ok: true });
  res.cookies.delete(SESSION_COOKIE);
  return res;
});
