import { NextResponse } from "next/server";
import { z } from "zod";
import { pool } from "@/lib/server/db";
import { canEncrypt, decrypt, encrypt } from "@/lib/server/crypto";
import { apiUser, HttpError, parseJson, route } from "@/lib/server/http";
import { newTotpSecret, otpauthUri, verifyTotp } from "@/lib/server/auth/totp";

const Body = z.discriminatedUnion("action", [z.object({ action: z.literal("begin") }), z.object({ action: z.literal("confirm"), code: z.string().regex(/^\d{6}$/) }), z.object({ action: z.literal("disable"), code: z.string().regex(/^\d{6}$/) })]);
export const POST = route(async (req) => {
  const { user } = await apiUser(req);
  if (!canEncrypt()) throw new HttpError(503, "MFA needs TOKEN_ENCRYPTION_KEY configured on the server.");
  const b = await parseJson(req, Body);
  const u = (await pool().query(`SELECT mfa_enabled, mfa_secret, mfa_pending_secret FROM users WHERE id = $1`, [user.id])).rows[0];
  if (b.action === "begin") {
    const secret = newTotpSecret();
    await pool().query(`UPDATE users SET mfa_pending_secret = $2 WHERE id = $1`, [user.id, encrypt(secret)]);
    return NextResponse.json({ secret, uri: otpauthUri(secret, user.email) });
  }
  if (b.action === "confirm") {
    if (!u.mfa_pending_secret) throw new HttpError(409, "Start MFA setup first.");
    const step = verifyTotp(decrypt(u.mfa_pending_secret), b.code);
    if (step == null) throw new HttpError(422, "Code did not match. Check your device clock and try again.");
    await pool().query(`UPDATE users SET mfa_secret = mfa_pending_secret, mfa_pending_secret = NULL, mfa_enabled = true, mfa_last_step = $2 WHERE id = $1`, [user.id, step]);
    await pool().query(`UPDATE sessions SET revoked_at = now() WHERE user_id = $1 AND id <> $2`, [user.id, user.sessionId]);
    return NextResponse.json({ enabled: true });
  }
  if (!u.mfa_enabled || verifyTotp(decrypt(u.mfa_secret), b.code) == null) throw new HttpError(422, "Code did not match.");
  await pool().query(`UPDATE users SET mfa_enabled = false, mfa_secret = NULL WHERE id = $1`, [user.id]);
  return NextResponse.json({ enabled: false });
});
