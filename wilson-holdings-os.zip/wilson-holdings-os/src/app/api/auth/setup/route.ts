import { NextResponse } from "next/server";
import { z } from "zod";
import { env } from "@/lib/server/env";
import { parseJson, route } from "@/lib/server/http";
import { setupOwner } from "@/lib/server/services/auth";
import { createSession, SESSION_COOKIE } from "@/lib/server/auth/session";

const Body = z.object({ setupToken: z.string().min(1).max(200), displayName: z.string().trim().min(1).max(120), email: z.string().trim().email().max(254), password: z.string().min(1).max(256) });

export const POST = route(async (req) => {
  const b = await parseJson(req, Body);
  const userId = await setupOwner({ ...b, expectedToken: env().SETUP_TOKEN });
  const s = await createSession(userId, { ua: req.headers.get("user-agent"), ip: req.headers.get("x-forwarded-for") });
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, s.token, { httpOnly: true, sameSite: "lax", secure: env().APP_ENV === "production", path: "/", maxAge: s.maxAgeSeconds });
  return res;
});
