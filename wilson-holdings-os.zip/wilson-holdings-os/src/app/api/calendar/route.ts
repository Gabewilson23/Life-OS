import { NextResponse } from "next/server";
import { withCtx } from "@/lib/server/db";
import { apiUser, route } from "@/lib/server/http";

export const GET = route(async (req) => {
  const { ctx } = await apiUser(req);
  const from = req.nextUrl.searchParams.get("from") ?? new Date(Date.now() - 86400_000).toISOString();
  const to = req.nextUrl.searchParams.get("to") ?? new Date(Date.now() + 30 * 86400_000).toISOString();
  const rows = await withCtx(ctx, (db) => db.query(`SELECT e.*, a.label AS account_label FROM calendar_events e JOIN integration_accounts a ON a.id = e.account_id WHERE e.starts_at < $2 AND e.ends_at > $1 ORDER BY e.starts_at`, [from, to]));
  return NextResponse.json({ events: rows.rows });
});
