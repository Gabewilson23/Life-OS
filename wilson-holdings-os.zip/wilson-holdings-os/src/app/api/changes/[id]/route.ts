import { NextResponse } from "next/server";
import { z } from "zod";
import { withCtx } from "@/lib/server/db";
import { apiUser, HttpError, parseJson, route } from "@/lib/server/http";
import { approveRelease, refreshChecks, requestRelease, startDevelopment } from "@/lib/server/services/changes";

const Body = z.discriminatedUnion("action", [z.object({ action: z.literal("start") }), z.object({ action: z.literal("refresh") }), z.object({ action: z.literal("request_release") }), z.object({ action: z.literal("approve_release"), hash: z.string().length(64) })]);
export const POST = route<{ id: string }>(async (req, { id }) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, Body);
  const cid = z.string().uuid().parse(id);
  try {
    return NextResponse.json(await withCtx<unknown>(ctx, (db) => b.action === "start" ? startDevelopment(db, ctx, cid) : b.action === "refresh" ? refreshChecks(db, ctx, cid) : b.action === "request_release" ? requestRelease(db, ctx, cid) : approveRelease(db, ctx, cid, b.hash)));
  } catch (e) { const s = (e as { status?: number }).status; if (s && s < 500) throw e; throw new HttpError(502, (e as Error).message); }
});
