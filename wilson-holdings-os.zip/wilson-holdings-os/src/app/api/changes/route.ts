import { NextResponse } from "next/server";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { ChangeInput, createChangeRequest } from "@/lib/server/services/changes";

export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, ChangeInput);
  return NextResponse.json({ id: await withCtx(ctx, (db) => createChangeRequest(db, ctx, b)) }, { status: 201 });
});
