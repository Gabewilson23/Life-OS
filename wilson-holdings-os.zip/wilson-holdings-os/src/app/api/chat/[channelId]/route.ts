import { NextResponse } from "next/server";
import { z } from "zod";
import { withCtx } from "@/lib/server/db";
import { apiUser, route } from "@/lib/server/http";
import { getChannel, listMessages } from "@/lib/server/services/chat";
import { listProposals } from "@/lib/server/services/proposals";

export const GET = route<{ channelId: string }>(async (req, { channelId }) => {
  const { ctx } = await apiUser(req);
  const id = z.string().uuid().parse(channelId);
  return NextResponse.json(await withCtx(ctx, async (db) => {
    const channel = await getChannel(db, id);
    const messages = await listMessages(db, id);
    const runIds = messages.map((m) => m.run_id).filter(Boolean);
    const proposals = runIds.length ? (await listProposals(db, { limit: 200 })).filter((p) => runIds.includes(p.run_id)) : [];
    return { channel, messages, proposals };
  }));
});
