import { NextResponse } from "next/server";
import { z } from "zod";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { listChannels, openChannel } from "@/lib/server/services/chat";

export const GET = route(async (req) => {
  const { ctx } = await apiUser(req);
  return NextResponse.json({ channels: await withCtx(ctx, (db) => listChannels(db)) });
});
export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, z.object({ agentId: z.string().max(80), private: z.boolean().default(false) }));
  return NextResponse.json({ channel: await withCtx(ctx, (db) => openChannel(db, ctx, b)) });
});
