import { z } from "zod";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { openChannel, postUserMessage } from "@/lib/server/services/chat";
import { createRun, executeRun, type RunEvent } from "@/lib/server/agents/executor";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const Body = z.object({
  channelId: z.string().uuid().optional(),
  agentId: z.string().max(80).default("hq.chief-of-staff"),
  private: z.boolean().default(false),
  message: z.string().trim().min(1).max(8000),
  clientMessageId: z.string().max(80).optional(),
});

/** Posts a message and streams the role's actual run as Server-Sent Events. */
export const POST = route(async (req) => {
  const { user, ctx } = await apiUser(req);
  const b = await parseJson(req, Body);
  const { channel, runId } = await withCtx(ctx, async (db) => {
    const ch = b.channelId ? { id: b.channelId } : await openChannel(db, ctx, { agentId: b.agentId, private: b.private });
    const { channel } = await postUserMessage(db, ctx, ch.id, b.message);
    return { channel, runId: null as string | null };
  });
  const rid = runId ?? (await createRun(user, { agentId: channel.agent_id, request: b.message, channelId: channel.id, idempotencyKey: b.clientMessageId ? `chat:${b.clientMessageId}` : undefined }));
  const enc = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (e: RunEvent | { type: "channel"; channelId: string; runId: string }) => controller.enqueue(enc.encode(`data: ${JSON.stringify(e)}\n\n`));
      send({ type: "channel", channelId: channel.id, runId: rid });
      try { await executeRun(rid, user.orgId, send); } catch (e) { send({ type: "done", runId: rid, state: "failed", text: (e as Error).message }); }
      controller.close();
    },
  });
  return new Response(stream, { headers: { "content-type": "text/event-stream", "cache-control": "no-cache, no-transform", "x-accel-buffering": "no" } });
});
