import { NextResponse } from "next/server";
import { z } from "zod";
import { assertWrite, withCtx } from "@/lib/server/db";
import { apiUser, HttpError, parseJson, route } from "@/lib/server/http";
import { encrypt } from "@/lib/server/crypto";
import { assertSafeOutboundUrl } from "@/lib/server/net";
import { discoverAtlasCrm, pullAtlasCrmAgents } from "@/lib/server/integrations/atlas-crm";

const Body = z.discriminatedUnion("action", [
  z.object({ action: z.literal("create"), baseUrl: z.string().url(), authHeader: z.string().max(60).default("Authorization"), secret: z.string().max(500).optional(), mapping: z.object({ key: z.string().max(60), fields: z.record(z.string().max(60), z.string().max(60)) }) }),
  z.object({ action: z.literal("discover"), id: z.string().uuid() }),
  z.object({ action: z.literal("pull"), id: z.string().uuid() }),
]);
export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, Body);
  assertWrite(ctx, "company:atlas-insurance");
  try {
    if (b.action === "create") {
      await assertSafeOutboundUrl(b.baseUrl);
      const id = (await withCtx(ctx, (db) => db.query(`INSERT INTO connector_configs(org_id, scope, connector, base_url, auth_header, secret_enc, mapping, created_by) VALUES ($1,'company:atlas-insurance','atlas-crm',$2,$3,$4,$5,$6) RETURNING id`, [ctx.orgId, b.baseUrl, b.authHeader, b.secret ? encrypt(b.secret) : null, b.mapping, `user:${ctx.actorId}`]))).rows[0].id;
      return NextResponse.json({ id });
    }
    if (b.action === "discover") return NextResponse.json(await discoverAtlasCrm(ctx.orgId, b.id));
    return NextResponse.json(await pullAtlasCrmAgents(ctx, b.id));
  } catch (e) { throw new HttpError(422, (e as Error).message); }
});
