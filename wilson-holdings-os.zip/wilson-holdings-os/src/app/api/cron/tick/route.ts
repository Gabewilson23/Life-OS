import crypto from "node:crypto";
import { NextResponse, type NextRequest } from "next/server";
import { env } from "@/lib/server/env";
import { tick } from "@/lib/server/services/scheduler";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** Called by the Netlify scheduled function (or any cron) with `Authorization: Bearer $CRON_SECRET`. */
export async function POST(req: NextRequest) {
  const secret = env().CRON_SECRET;
  const got = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
  if (!secret || got.length !== secret.length || !crypto.timingSafeEqual(Buffer.from(got), Buffer.from(secret))) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  try { return NextResponse.json(await tick("cron:netlify", { maxRuns: 2 })); }
  catch (e) { console.error("[tick]", e); return NextResponse.json({ error: "tick failed" }, { status: 500 }); }
}
