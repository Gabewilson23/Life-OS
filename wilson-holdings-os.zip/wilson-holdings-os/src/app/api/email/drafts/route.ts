import { NextResponse } from "next/server";
import { z } from "zod";
import { assertWrite, withCtx } from "@/lib/server/db";
import { apiUser, HttpError, parseJson, route } from "@/lib/server/http";
import { requestApproval } from "@/lib/server/services/approvals";
import { audit } from "@/lib/server/services/audit";

const email = z.string().trim().email().max(254);
const Body = z.object({
  scope: z.string().max(60), accountId: z.string().uuid().nullable().optional(),
  to: z.array(email).min(1).max(20), cc: z.array(email).max(20).default([]), bcc: z.array(email).max(20).default([]),
  subject: z.string().max(300), body: z.string().max(50_000), threadId: z.string().max(100).nullable().optional(),
  sync: z.boolean().default(false),
});

/** Saves a local draft; optionally requests approval to create it as a Gmail draft. Never sends. */
export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, Body);
  assertWrite(ctx, b.scope);
  return NextResponse.json(await withCtx(ctx, async (db) => {
    if (b.accountId) {
      const a = (await db.query(`SELECT scope FROM integration_accounts WHERE id = $1`, [b.accountId])).rows[0];
      if (!a || a.scope !== b.scope) throw new HttpError(403, "That account belongs to a different scope; cross-company sending is blocked.");
    }
    const d = (await db.query(`INSERT INTO email_drafts(org_id, scope, account_id, to_addrs, cc_addrs, bcc_addrs, subject, body_text, thread_id, sync_state, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
      [ctx.orgId, b.scope, b.accountId ?? null, b.to, b.cc, b.bcc, b.subject, b.body, b.threadId ?? null, b.sync && b.accountId ? "pending" : "local_only", `user:${ctx.actorId}`])).rows[0];
    await audit(db, ctx, { scope: b.scope, action: "email.draft.save", type: "email_draft", id: d.id, summary: `Saved draft "${b.subject}" (${b.accountId ? "account selected" : "not synced — no account"})` });
    if (!b.sync || !b.accountId) return { draftId: d.id, syncState: "local_only" };
    const appr = await requestApproval(db, ctx, { kind: "email.draft.create", scope: b.scope, accountId: b.accountId, payload: { to: b.to, cc: b.cc, bcc: b.bcc, subject: b.subject, body: b.body, threadId: b.threadId ?? null, localDraftId: d.id } });
    return { draftId: d.id, syncState: "pending", approval: appr };
  }), { status: 201 });
});
