import crypto from "node:crypto";
import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { env } from "@/lib/server/env";
import { assertSameOrigin, HttpError } from "@/lib/server/http";
import { validateSession, SESSION_COOKIE } from "@/lib/server/auth/session";
import { ctxFor } from "@/lib/server/auth/current";
import { submitForm } from "@/lib/server/services/studio";
import { ORG_ID } from "@/lib/org/definitions";

/** Form submission endpoint. Public forms need no session; private forms require a signed-in user with scope. */
export async function POST(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  try {
    assertSameOrigin(req);
    const slug = z.string().regex(/^[a-z0-9-]{3,60}$/).parse((await params).slug);
    const text = await req.text();
    if (text.length > 64_000) throw new HttpError(413, "Too large");
    const body = z.object({ clientKey: z.string().min(8).max(80), data: z.record(z.string(), z.unknown()) }).parse(JSON.parse(text));
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? req.headers.get("x-real-ip") ?? "unknown";
    const sourceHash = crypto.createHmac("sha256", env().SESSION_SECRET).update(`${slug}:${ip}`).digest("hex");
    const u = await validateSession(req.cookies.get(SESSION_COOKIE)?.value);
    const r = await submitForm(ORG_ID, slug, body.data, { clientKey: body.clientKey, sourceHash, isPublic: !u, ctx: u ? ctxFor(u) : undefined });
    return NextResponse.json(r, { status: Object.keys(r.errors).length ? 422 : 200 });
  } catch (e) {
    const err = e as Error & { status?: number };
    const status = err instanceof HttpError ? err.status : err.status ?? (e instanceof z.ZodError || e instanceof SyntaxError ? 400 : 500);
    if (status >= 500) console.error("[form]", e);
    return NextResponse.json({ error: status >= 500 ? "Internal error" : err.message }, { status });
  }
}
