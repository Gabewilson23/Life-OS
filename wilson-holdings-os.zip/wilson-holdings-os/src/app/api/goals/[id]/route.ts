import { NextResponse } from "next/server";
import { z } from "zod";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { deleteGoal, GoalPatch, updateGoal } from "@/lib/server/services/work";

const Id = z.string().uuid();

export const PATCH = route<{ id: string }>(async (req, { id }) => {
  const { ctx } = await apiUser(req);
  const body = await parseJson(req, GoalPatch);
  return NextResponse.json({ goal: await withCtx(ctx, (db) => updateGoal(db, ctx, Id.parse(id), body)) });
});

export const DELETE = route<{ id: string }>(async (req, { id }) => {
  const { ctx } = await apiUser(req);
  const { version } = await parseJson(req, z.object({ version: z.number().int().positive() }));
  await withCtx(ctx, (db) => deleteGoal(db, ctx, Id.parse(id), version));
  return NextResponse.json({ ok: true });
});
