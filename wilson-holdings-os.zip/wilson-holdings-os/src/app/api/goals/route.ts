import { NextResponse } from "next/server";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { createGoal, GoalInput, listGoals } from "@/lib/server/services/work";

export const GET = route(async (req) => {
  const { ctx } = await apiUser(req);
  const all = req.nextUrl.searchParams.get("all") === "1";
  return NextResponse.json({ goals: await withCtx(ctx, (db) => listGoals(db, { includeClosed: all })) });
});

export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const body = await parseJson(req, GoalInput);
  return NextResponse.json({ goal: await withCtx(ctx, (db) => createGoal(db, ctx, body)) }, { status: 201 });
});
