import { NextResponse } from "next/server";
import { pool } from "@/lib/server/db";

export const dynamic = "force-dynamic";
/** Liveness + basic readiness. Never exposes configuration values. */
export async function GET() {
  try {
    const reg = await pool().query(`SELECT to_regclass('public.schema_migrations') IS NOT NULL AS ok`);
    const n = reg.rows[0].ok ? (await pool().query(`SELECT count(*)::int AS n FROM schema_migrations`)).rows[0].n : 0;
    return NextResponse.json({ ok: true, db: "up", migrations: n });
  } catch (e) {
    console.error("[health]", (e as Error).message);
    return NextResponse.json({ ok: false, db: "down" }, { status: 503 });
  }
}
