import { NextResponse } from "next/server";
import { z } from "zod";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { commitImport } from "@/lib/server/services/imports";

export const maxDuration = 60;
export const POST = route<{ id: string }>(async (req, { id }) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, z.object({ mapping: z.record(z.string().max(200), z.string().max(60)), allowDuplicateFile: z.boolean().default(false) }));
  return NextResponse.json(await withCtx(ctx, (db) => commitImport(db, ctx, z.string().uuid().parse(id), b.mapping, { allowDuplicateFile: b.allowDuplicateFile })));
});
