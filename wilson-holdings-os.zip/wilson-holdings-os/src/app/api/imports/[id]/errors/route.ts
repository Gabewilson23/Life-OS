import { z } from "zod";
import { withCtx } from "@/lib/server/db";
import { apiUser, HttpError, route } from "@/lib/server/http";
import { errorReportCsv } from "@/lib/server/services/imports";

export const GET = route<{ id: string }>(async (req, { id }) => {
  const { ctx } = await apiUser(req);
  const b = (await withCtx(ctx, (db) => db.query(`SELECT filename, errors FROM import_batches WHERE id = $1`, [z.string().uuid().parse(id)]))).rows[0];
  if (!b) throw new HttpError(404, "Not found");
  return new Response(errorReportCsv(b.errors), { headers: { "content-type": "text/csv; charset=utf-8", "content-disposition": `attachment; filename="errors-${String(b.filename).replace(/[^\w.-]/g, "_")}.csv"` } });
});
