import { NextResponse } from "next/server";
import { withCtx } from "@/lib/server/db";
import { apiUser, HttpError, route } from "@/lib/server/http";
import { MAX_IMPORT_BYTES, previewImport } from "@/lib/server/services/imports";

export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const form = await req.formData().catch(() => { throw new HttpError(400, "Expected multipart form data"); });
  const file = form.get("file");
  const dataset = String(form.get("dataset") ?? "");
  if (!(file instanceof File)) throw new HttpError(422, "Attach a .csv or .xlsx file");
  if (file.size > MAX_IMPORT_BYTES) throw new HttpError(413, "File exceeds 5 MB");
  const data = Buffer.from(await file.arrayBuffer());
  try {
    return NextResponse.json(await withCtx(ctx, (db) => previewImport(db, ctx, { dataset, filename: file.name, data })));
  } catch (e) {
    const err = e as Error & { status?: number };
    throw new HttpError(err.status ?? 422, err.message);
  }
});
