import { NextResponse } from "next/server";
import { z } from "zod";
import { assertWrite, systemCtx, withCtx } from "@/lib/server/db";
import { apiUser, HttpError, parseJson, route } from "@/lib/server/http";
import { revokeGoogle } from "@/lib/server/integrations/google";
import { driveList, gmail, gmailSearch, googleCalendar } from "@/lib/server/integrations/adapters";
import { audit } from "@/lib/server/services/audit";

const Body = z.discriminatedUnion("action", [
  z.object({ action: z.literal("sync") }), z.object({ action: z.literal("health") }), z.object({ action: z.literal("revoke") }),
  z.object({ action: z.literal("pause") }), z.object({ action: z.literal("resume") }),
  z.object({ action: z.literal("settings"), calendars: z.array(z.string().max(200)).max(20), workingHours: z.object({ start: z.string(), end: z.string() }).optional(), bufferMinutes: z.number().int().min(0).max(120).optional() }),
  z.object({ action: z.literal("gmail_search"), q: z.string().max(200) }),
  z.object({ action: z.literal("drive_list"), q: z.string().max(100).optional() }),
]);

export const POST = route<{ id: string }>(async (req, { id }) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, Body);
  const aid = z.string().uuid().parse(id);
  const acct = (await withCtx(ctx, (db) => db.query(`SELECT id, scope, capabilities, status FROM integration_accounts WHERE id = $1`, [aid]))).rows[0];
  if (!acct) throw new HttpError(404, "Account not found");
  const caps = acct.capabilities as string[];
  if (b.action === "revoke") { assertWrite(ctx, acct.scope); await revokeGoogle(ctx, aid); return NextResponse.json({ ok: true }); }
  if (b.action === "pause" || b.action === "resume" || b.action === "settings") {
    assertWrite(ctx, acct.scope);
    await withCtx(ctx, async (db) => {
      if (b.action === "settings") await db.query(`UPDATE integration_accounts SET settings = settings || $2::jsonb, updated_at = now(), version = version + 1 WHERE id = $1`, [aid, JSON.stringify({ calendars: b.calendars, workingHours: b.workingHours, bufferMinutes: b.bufferMinutes })]);
      else await db.query(`UPDATE integration_accounts SET paused = $2, updated_at = now(), version = version + 1 WHERE id = $1`, [aid, b.action === "pause"]);
      await audit(db, ctx, { scope: acct.scope, action: `integration.${b.action}`, type: "integration_account", id: aid, summary: `Integration ${b.action}` });
    });
    return NextResponse.json({ ok: true });
  }
  if (acct.status === "revoked") throw new HttpError(409, "Account is revoked; reconnect it.");
  try {
    if (b.action === "sync") {
      if (!caps.includes("calendar.read")) throw new HttpError(403, "calendar.read not granted");
      await withCtx(systemCtx(ctx.orgId), (db) => db.query(`UPDATE integration_accounts SET status = 'syncing' WHERE id = $1`, [aid]));
      return NextResponse.json(await googleCalendar.pull!(ctx.orgId, aid));
    }
    if (b.action === "health") {
      const r = [caps.some((c) => c.startsWith("calendar")) ? await googleCalendar.health(ctx.orgId, aid) : null, caps.some((c) => c.startsWith("gmail")) ? await gmail.health(ctx.orgId, aid) : null].filter(Boolean);
      const ok = r.every((x) => x!.ok);
      await withCtx(systemCtx(ctx.orgId), (db) => db.query(`UPDATE integration_accounts SET status = $2, last_error = $3 WHERE id = $1`, [aid, ok ? "healthy" : "degraded", ok ? null : r.map((x) => x!.detail).join("; ")]));
      return NextResponse.json({ ok, checks: r });
    }
    if (b.action === "gmail_search") { if (!caps.includes("gmail.read")) throw new HttpError(403, "gmail.read not granted"); return NextResponse.json({ messages: await gmailSearch(ctx.orgId, aid, b.q) }); }
    if (!caps.includes("drive.read")) throw new HttpError(403, "drive.read not granted");
    return NextResponse.json({ files: await driveList(ctx.orgId, aid, b.q) });
  } catch (e) {
    if (e instanceof HttpError) throw e;
    await withCtx(systemCtx(ctx.orgId), (db) => db.query(`UPDATE integration_accounts SET status = 'degraded', last_error = $2 WHERE id = $1`, [aid, (e as Error).message.slice(0, 300)]));
    throw new HttpError(502, (e as Error).message);
  }
});
