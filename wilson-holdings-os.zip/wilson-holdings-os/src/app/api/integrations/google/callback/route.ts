import { NextResponse, type NextRequest } from "next/server";
import { env } from "@/lib/server/env";
import { validateSession, SESSION_COOKIE } from "@/lib/server/auth/session";
import { completeGoogleAuth } from "@/lib/server/integrations/google";
import { redact } from "@/lib/server/crypto";

export async function GET(req: NextRequest) {
  const base = env().APP_URL;
  const u = await validateSession(req.cookies.get(SESSION_COOKIE)?.value);
  if (!u) return NextResponse.redirect(`${base}/login`);
  const sp = req.nextUrl.searchParams;
  if (sp.get("error")) return NextResponse.redirect(`${base}/integrations?error=${encodeURIComponent(sp.get("error")!)}`);
  try {
    const r = await completeGoogleAuth(u.id, sp.get("state") ?? "", sp.get("code") ?? "");
    return NextResponse.redirect(`${base}/integrations?connected=${r.id}${r.partial ? "&partial=1" : ""}`);
  } catch (e) {
    return NextResponse.redirect(`${base}/integrations?error=${encodeURIComponent(redact((e as Error).message).slice(0, 200))}`);
  }
}
