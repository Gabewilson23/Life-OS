import { NextResponse } from "next/server";
import { z } from "zod";
import { assertWrite } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { beginGoogleAuth } from "@/lib/server/integrations/google";

const Body = z.object({ scope: z.string().max(60), label: z.string().trim().min(1).max(80), capabilities: z.array(z.enum(["calendar.read", "calendar.write", "gmail.read", "gmail.draft", "drive.read"])).min(1) });
export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, Body);
  assertWrite(ctx, b.scope);
  return NextResponse.json({ url: await beginGoogleAuth(ctx, b) });
});
