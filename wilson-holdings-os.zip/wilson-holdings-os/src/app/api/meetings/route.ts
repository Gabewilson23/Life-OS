import { NextResponse } from "next/server";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { MeetingInput, runMeeting } from "@/lib/server/services/meetings";

export const maxDuration = 300;
export const POST = route(async (req) => {
  const { user, ctx } = await apiUser(req);
  const b = await parseJson(req, MeetingInput);
  return NextResponse.json(await runMeeting(ctx, { id: user.id, orgId: user.orgId, readScopes: user.readScopes, writeScopes: user.writeScopes }, b));
});
