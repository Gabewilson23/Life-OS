import { NextResponse } from "next/server";
import { z } from "zod";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { correct, decideStaged, forget } from "@/lib/server/services/memory";

const Body = z.discriminatedUnion("action", [
  z.object({ action: z.literal("correct"), assertion: z.string().trim().min(1).max(4000), version: z.number().int().positive() }),
  z.object({ action: z.literal("forget"), tombstoneSource: z.boolean().default(false), tombstoneSubject: z.boolean().default(false), reason: z.string().max(500).optional() }),
  z.object({ action: z.literal("accept") }),
  z.object({ action: z.literal("reject") }),
]);

export const POST = route<{ id: string }>(async (req, { id }) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, Body);
  const mid = z.string().uuid().parse(id);
  return NextResponse.json(await withCtx<unknown>(ctx, (db) =>
    b.action === "correct" ? correct(db, ctx, mid, b.assertion, b.version)
      : b.action === "forget" ? forget(db, ctx, mid, b)
        : decideStaged(db, ctx, mid, b.action === "accept")));
});
