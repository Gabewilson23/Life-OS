import { NextResponse } from "next/server";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { remember, RememberInput, searchMemory } from "@/lib/server/services/memory";

export const GET = route(async (req) => {
  const { ctx } = await apiUser(req);
  const sp = req.nextUrl.searchParams;
  const rows = await withCtx(ctx, (db) => searchMemory(db, ctx, { text: sp.get("q") ?? undefined, asOf: sp.get("asOf") ?? undefined, mtypes: sp.get("type") ? [sp.get("type")!] : undefined, includeStaged: true, limit: 100 }));
  return NextResponse.json({ memories: rows });
});
export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const body = await parseJson(req, RememberInput);
  return NextResponse.json(await withCtx(ctx, (db) => remember(db, ctx, body)), { status: 201 });
});
