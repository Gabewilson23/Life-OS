import { NextResponse } from "next/server";
import { z } from "zod";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";

export const GET = route(async (req) => {
  const { ctx } = await apiUser(req);
  const rows = (await withCtx(ctx, (db) => db.query(`SELECT * FROM notifications WHERE deliver_after <= now() ORDER BY read_at NULLS FIRST, created_at DESC LIMIT 100`))).rows;
  return NextResponse.json({ notifications: rows, unread: rows.filter((r) => !r.read_at).length });
});
export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, z.object({ ids: z.array(z.string().uuid()).max(200).optional(), all: z.boolean().optional() }));
  await withCtx(ctx, (db) => db.query(`UPDATE notifications SET read_at = now() WHERE read_at IS NULL AND ($1::boolean OR id = ANY($2::uuid[]))`, [!!b.all, b.ids ?? []]));
  return NextResponse.json({ ok: true });
});
