import { NextResponse } from "next/server";
import { z } from "zod";
import { assertWrite, withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { audit } from "@/lib/server/services/audit";

const Body = z.object({
  businessModel: z.string().trim().min(3).max(1000),
  enabledWorkflows: z.array(z.enum(["project", "retainer", "placement", "time_and_materials"])).max(4),
});

export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, Body);
  await withCtx(ctx, async (db) => {
    assertWrite(ctx, "company:atlas-consulting");
    const before = (await db.query(`SELECT settings FROM companies WHERE id = 'co.atlas-consulting' FOR UPDATE`)).rows[0]?.settings;
    const verified = { businessModel: { source: "user_confirmed", at: new Date().toISOString(), by: `user:${ctx.actorId}` } };
    await db.query(
      `UPDATE companies SET settings = settings || $1::jsonb, verified = verified || $2::jsonb, version = version + 1, updated_at = now() WHERE id = 'co.atlas-consulting'`,
      [JSON.stringify({ businessModel: b.businessModel, enabledWorkflows: b.enabledWorkflows }), JSON.stringify(verified)],
    );
    await db.query(`UPDATE organizations SET settings = jsonb_set(settings, '{onboarding,contractingModelConfirmed}', 'true'), updated_at = now() WHERE id = $1`, [ctx.orgId]);
    await audit(db, ctx, { scope: "company:atlas-consulting", action: "company.business_model_confirmed", type: "company", id: "co.atlas-consulting", summary: `Confirmed Atlas Consulting model; workflows: ${b.enabledWorkflows.join(", ") || "none"}`, before, after: b });
  });
  return NextResponse.json({ ok: true });
});
