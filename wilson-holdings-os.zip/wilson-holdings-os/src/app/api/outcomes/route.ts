import { NextResponse } from "next/server";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { OutcomeInput, saveOutcome } from "@/lib/server/services/work";

export const PUT = route(async (req) => {
  const { ctx } = await apiUser(req);
  const body = await parseJson(req, OutcomeInput);
  return NextResponse.json(await withCtx(ctx, (db) => saveOutcome(db, ctx, body)));
});
