import { NextResponse } from "next/server";
import { z } from "zod";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { decideProposal } from "@/lib/server/services/proposals";

export const POST = route<{ id: string }>(async (req, { id }) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, z.object({ decision: z.enum(["accept", "reject"]), payloadHash: z.string().length(64) }));
  return NextResponse.json(await withCtx(ctx, (db) => decideProposal(db, ctx, z.string().uuid().parse(id), b.decision, b.payloadHash)));
});
