import { NextResponse } from "next/server";
import { z } from "zod";
import { assertRead } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { buildReport } from "@/lib/server/services/reports";

export const maxDuration = 60;
export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, z.object({ kind: z.enum(["chairman_briefing", "company_close", "executive_review", "monthly_owner_report"]), companyId: z.enum(["co.atlas-insurance", "co.atlas-consulting"]).optional() }));
  assertRead(ctx, b.kind === "company_close" ? (b.companyId === "co.atlas-consulting" ? "company:atlas-consulting" : "company:atlas-insurance") : "personal");
  return NextResponse.json(await buildReport(ctx.orgId, b.kind, { companyId: b.kind === "company_close" ? b.companyId ?? "co.atlas-insurance" : null }));
});
