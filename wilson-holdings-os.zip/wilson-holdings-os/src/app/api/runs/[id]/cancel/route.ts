import { NextResponse } from "next/server";
import { z } from "zod";
import { apiUser, route } from "@/lib/server/http";
import { requestCancel } from "@/lib/server/agents/executor";

export const POST = route<{ id: string }>(async (req, { id }) => {
  const { ctx } = await apiUser(req);
  return NextResponse.json(await requestCancel(ctx, z.string().uuid().parse(id)));
});
