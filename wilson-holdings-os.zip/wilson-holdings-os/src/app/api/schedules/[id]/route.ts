import { NextResponse } from "next/server";
import { z } from "zod";
import { assertWrite, withCtx } from "@/lib/server/db";
import { apiUser, HttpError, parseJson, route } from "@/lib/server/http";
import { audit } from "@/lib/server/services/audit";

const Body = z.object({ enabled: z.boolean(), time: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/), weekday: z.number().int().min(0).max(6).optional(), day: z.number().int().min(1).max(28).optional() });
export const POST = route<{ id: string }>(async (req, { id }) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, Body);
  await withCtx(ctx, async (db) => {
    const sc = (await db.query(`SELECT * FROM schedules WHERE id = $1`, [id])).rows[0];
    if (!sc) throw new HttpError(404, "Schedule not found");
    assertWrite(ctx, sc.scope);
    const rule = { ...sc.rule, time: b.time, ...(b.weekday !== undefined && sc.rule.freq === "weekly" ? { weekday: b.weekday } : {}), ...(b.day !== undefined && sc.rule.freq === "monthly" ? { day: b.day } : {}) };
    await db.query(`UPDATE schedules SET enabled = $2, rule = $3, updated_at = now(), version = version + 1 WHERE id = $1`, [id, b.enabled, rule]);
    await audit(db, ctx, { scope: sc.scope, action: b.enabled ? "schedule.enable" : "schedule.disable", type: "schedule", id, summary: `${sc.label}: ${b.enabled ? "activated" : "disabled"} at ${b.time}` });
  });
  return NextResponse.json({ ok: true });
});
