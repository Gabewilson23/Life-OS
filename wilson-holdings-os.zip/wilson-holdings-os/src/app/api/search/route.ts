import { NextResponse } from "next/server";
import { withCtx } from "@/lib/server/db";
import { apiUser, route } from "@/lib/server/http";

/** Scoped lexical search for the command palette. RLS restricts rows to the caller's scopes. */
export const GET = route(async (req) => {
  const { ctx } = await apiUser(req);
  const q = (req.nextUrl.searchParams.get("q") ?? "").trim().slice(0, 100);
  if (!q) return NextResponse.json({ results: [] });
  const like = `%${q.replace(/[%_\\]/g, (c) => "\\" + c)}%`;
  const results = await withCtx(ctx, async (db) => {
    const [agents, goals, tasks, buildings] = await Promise.all([
      db.query(`SELECT id, title, number FROM agent_definitions WHERE title ILIKE $1 OR charter ILIKE $1 ORDER BY number LIMIT 8`, [like]),
      db.query(`SELECT id, title FROM goals WHERE deleted_at IS NULL AND title ILIKE $1 LIMIT 5`, [like]),
      db.query(`SELECT id, title FROM tasks WHERE deleted_at IS NULL AND title ILIKE $1 LIMIT 5`, [like]),
      db.query(`SELECT slug, name FROM buildings WHERE name ILIKE $1 LIMIT 5`, [like]),
    ]);
    return [
      ...buildings.rows.map((b) => ({ kind: "Building", label: b.name, href: `/buildings/${b.slug}` })),
      ...agents.rows.map((a) => ({ kind: "Role", label: `${a.number}. ${a.title}`, href: `/agents/${a.id}` })),
      ...goals.rows.map((g) => ({ kind: "Goal", label: g.title, href: `/goals#${g.id}` })),
      ...tasks.rows.map((t) => ({ kind: "Task", label: t.title, href: `/tasks#${t.id}` })),
    ];
  });
  return NextResponse.json({ results });
});
