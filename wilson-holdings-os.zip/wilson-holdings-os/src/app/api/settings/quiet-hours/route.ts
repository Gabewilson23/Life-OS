import { NextResponse } from "next/server";
import { z } from "zod";
import { assertWrite, withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { audit } from "@/lib/server/services/audit";

const hhmm = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/);
export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, z.object({ start: hhmm, end: hhmm }));
  assertWrite(ctx, "org");
  await withCtx(ctx, async (db) => {
    await db.query(`UPDATE organizations SET settings = settings || jsonb_build_object('quietHours', $2::jsonb), updated_at = now() WHERE id = $1`, [ctx.orgId, JSON.stringify(b)]);
    await audit(db, ctx, { scope: "org", action: "settings.quiet_hours", type: "organization", id: ctx.orgId, summary: `Quiet hours ${b.start}–${b.end}` });
  });
  return NextResponse.json({ ok: true });
});
