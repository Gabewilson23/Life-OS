import { NextResponse } from "next/server";
import { z } from "zod";
import { assertWrite, withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { audit } from "@/lib/server/services/audit";

const Body = z.object({
  scope: z.string().max(60), actionKind: z.enum(["calendar.event.create", "email.draft.create"]), accountId: z.string().uuid(),
  constraints: z.object({ no_attendees: z.boolean().default(true), private_only: z.boolean().default(true), max_per_day: z.number().int().min(1).max(50).default(5) }),
  description: z.string().trim().min(3).max(200),
});
export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, Body);
  assertWrite(ctx, b.scope);
  const id = await withCtx(ctx, async (db) => {
    const r = await db.query(`INSERT INTO standing_permissions(org_id, scope, action_kind, account_id, constraints, description, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`, [ctx.orgId, b.scope, b.actionKind, b.accountId, b.constraints, b.description, `user:${ctx.actorId}`]);
    await audit(db, ctx, { scope: b.scope, action: "policy.standing_permission.create", type: "standing_permission", id: r.rows[0].id, summary: `Standing permission: ${b.description}` });
    return r.rows[0].id;
  });
  return NextResponse.json({ id }, { status: 201 });
});
export const DELETE = route(async (req) => {
  const { ctx } = await apiUser(req);
  const { id } = await parseJson(req, z.object({ id: z.string().uuid() }));
  await withCtx(ctx, async (db) => {
    const p = (await db.query(`UPDATE standing_permissions SET revoked_at = now() WHERE id = $1 AND revoked_at IS NULL RETURNING scope`, [id])).rows[0];
    if (p) await audit(db, ctx, { scope: p.scope, action: "policy.standing_permission.revoke", type: "standing_permission", id, summary: "Revoked standing permission" });
  });
  return NextResponse.json({ ok: true });
});
