import { NextResponse } from "next/server";
import { z } from "zod";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { activate, addVersion, rollback, setStatus, testWorkflow } from "@/lib/server/services/studio";

const Body = z.discriminatedUnion("action", [
  z.object({ action: z.literal("version"), definition: z.unknown() }),
  z.object({ action: z.literal("test"), version: z.number().int().positive(), sample: z.record(z.string(), z.unknown()) }),
  z.object({ action: z.literal("activate"), version: z.number().int().positive(), access: z.enum(["private", "public"]).optional(), confirmHash: z.string().length(64).optional() }),
  z.object({ action: z.literal("pause") }), z.object({ action: z.literal("resume") }),
  z.object({ action: z.literal("rollback"), version: z.number().int().positive() }),
]);
export const POST = route<{ id: string }>(async (req, { id }) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, Body);
  const cid = z.string().uuid().parse(id);
  return NextResponse.json(await withCtx<unknown>(ctx, async (db) => {
    switch (b.action) {
      case "version": return { version: await addVersion(db, ctx, cid, b.definition) };
      case "test": return testWorkflow(db, ctx, cid, b.version, b.sample);
      case "activate": await activate(db, ctx, cid, b.version, { access: b.access, confirmHash: b.confirmHash }); return { ok: true };
      case "pause": await setStatus(db, ctx, cid, "paused"); return { ok: true };
      case "resume": await setStatus(db, ctx, cid, "active"); return { ok: true };
      case "rollback": await rollback(db, ctx, cid, b.version); return { ok: true };
    }
  }));
});
