import { NextResponse } from "next/server";
import { z } from "zod";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { contractorIntakeTemplate, createCapability } from "@/lib/server/services/studio";

const Body = z.discriminatedUnion("mode", [
  z.object({ mode: z.literal("template"), template: z.literal("contractor_intake"), scope: z.string().max(60) }),
  z.object({ mode: z.literal("custom"), kind: z.enum(["form", "workflow"]), scope: z.string().max(60), name: z.string().trim().min(1).max(120), slug: z.string().regex(/^[a-z0-9-]{3,60}$/), definition: z.unknown() }),
]);
export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, Body);
  return NextResponse.json(await withCtx(ctx, async (db) => {
    if (b.mode === "custom") return { id: await createCapability(db, ctx, { scope: b.scope, kind: b.kind, name: b.name, slug: b.slug, definition: b.definition }) };
    const t = contractorIntakeTemplate();
    const suffix = Math.random().toString(36).slice(2, 6);
    const formSlug = `contractor-intake-${suffix}`;
    const formId = await createCapability(db, ctx, { scope: b.scope, kind: "form", name: "Contractor intake", slug: formSlug, definition: t.form });
    const wfId = await createCapability(db, ctx, { scope: b.scope, kind: "workflow", name: "Contractor intake workflow", slug: `${formSlug}-workflow`, definition: { ...t.workflow, trigger: { type: "form_submission", formSlug } } });
    return { id: formId, workflowId: wfId };
  }), { status: 201 });
});
