import { NextResponse } from "next/server";
import { z } from "zod";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { setGlobalPause } from "@/lib/server/services/org";

export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const { paused } = await parseJson(req, z.object({ paused: z.boolean() }));
  await withCtx(ctx, (db) => setGlobalPause(db, ctx, paused));
  return NextResponse.json({ paused });
});
