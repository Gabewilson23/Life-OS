import { NextResponse } from "next/server";
import { withCtx } from "@/lib/server/db";
import { apiUser, parseJson, route } from "@/lib/server/http";
import { createTask, TaskInput, listTasks } from "@/lib/server/services/work";

export const GET = route(async (req) => {
  const { ctx } = await apiUser(req);
  const all = req.nextUrl.searchParams.get("all") === "1";
  return NextResponse.json({ tasks: await withCtx(ctx, (db) => listTasks(db, { includeClosed: all })) });
});

export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const body = await parseJson(req, TaskInput);
  return NextResponse.json({ task: await withCtx(ctx, (db) => createTask(db, ctx, body)) }, { status: 201 });
});
