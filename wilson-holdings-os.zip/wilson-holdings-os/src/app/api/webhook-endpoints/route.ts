import crypto from "node:crypto";
import { NextResponse } from "next/server";
import { z } from "zod";
import { assertWrite, withCtx } from "@/lib/server/db";
import { apiUser, HttpError, parseJson, route } from "@/lib/server/http";
import { encrypt } from "@/lib/server/crypto";
import { assertSafeOutboundUrl } from "@/lib/server/net";
import { env } from "@/lib/server/env";
import { audit } from "@/lib/server/services/audit";

const Body = z.object({ scope: z.string().max(60), direction: z.enum(["inbound", "outbound"]), name: z.string().trim().min(1).max(80), url: z.string().url().optional(), allowedEvents: z.array(z.string().regex(/^[a-z0-9_.-]{1,60}$/)).max(20) });
/** Creates an endpoint and returns its signing secret ONCE. Outbound URLs are SSRF-checked. */
export const POST = route(async (req) => {
  const { ctx } = await apiUser(req);
  const b = await parseJson(req, Body);
  assertWrite(ctx, b.scope);
  if (b.direction === "outbound") {
    if (!b.url) throw new HttpError(422, "Outbound endpoints need a URL");
    try { await assertSafeOutboundUrl(b.url); } catch (e) { throw new HttpError(422, (e as Error).message); }
  }
  const secret = crypto.randomBytes(32).toString("base64url");
  const id = await withCtx(ctx, async (db) => {
    const r = await db.query(`INSERT INTO webhook_endpoints(org_id, scope, direction, name, url, secret_enc, allowed_events, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`, [ctx.orgId, b.scope, b.direction, b.name, b.url ?? null, encrypt(secret), b.allowedEvents, `user:${ctx.actorId}`]);
    await audit(db, ctx, { scope: b.scope, action: "webhook.create", type: "webhook_endpoint", id: r.rows[0].id, summary: `${b.direction} webhook "${b.name}" (${b.allowedEvents.join(", ") || "no events"})` });
    return r.rows[0].id as string;
  });
  return NextResponse.json({ id, secret, inboundUrl: b.direction === "inbound" ? `${env().APP_URL}/api/webhooks/in/${id}` : undefined, note: "Store the secret now; it is shown only once." }, { status: 201 });
});
