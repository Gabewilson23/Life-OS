import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { receiveWebhook } from "@/lib/server/services/webhooks";

export const dynamic = "force-dynamic";
/** Public inbound webhook. Authenticated by HMAC signature + timestamp + nonce, not by cookies. */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const id = z.string().uuid().safeParse((await params).id);
  if (!id.success) return NextResponse.json({ error: "unknown endpoint" }, { status: 404 });
  const body = await req.text();
  if (body.length > 256_000) return NextResponse.json({ error: "payload too large" }, { status: 413 });
  const r = await receiveWebhook(id.data, { ts: req.headers.get("x-wh-timestamp"), nonce: req.headers.get("x-wh-nonce"), sig: req.headers.get("x-wh-signature") }, body);
  return NextResponse.json(r, { status: r.status });
}
