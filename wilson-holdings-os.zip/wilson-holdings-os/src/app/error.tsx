"use client";
export default function Error({ reset }: { error: Error; reset: () => void }) {
  return <main id="main" className="grid min-h-screen place-items-center"><div className="glass rounded-[var(--radius-xl)] p-8 text-center"><p className="eyebrow">Something went wrong</p><h1 className="display mt-2 text-2xl">This view failed to load</h1><p className="mt-2 text-sm text-stone-400">The error was logged on the server. No data was changed.</p><button className="btn mt-5" onClick={reset}>Try again</button></div></main>;
}
