import { notFound } from "next/navigation";
import { FormRenderer, type FormDefinition } from "@/components/FormRenderer";
import { systemCtx, withCtx } from "@/lib/server/db";
import { ORG_ID } from "@/lib/org/definitions";

export const dynamic = "force-dynamic";
export const metadata = { robots: { index: false } };

/** Public form page: only exposes the live definition of an ACTIVE PUBLIC form — no internal records or lookups. */
export default async function PublicForm({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  if (!/^[a-z0-9-]{3,60}$/.test(slug)) notFound();
  const row = (await withCtx(systemCtx(ORG_ID, "public-form"), (db) => db.query(`SELECT v.definition FROM capabilities c JOIN capability_versions v ON v.capability_id = c.id AND v.version = c.current_version WHERE c.slug = $1 AND c.kind = 'form' AND c.status = 'active' AND c.access = 'public'`, [slug]))).rows[0];
  if (!row) notFound();
  const def = row.definition as FormDefinition;
  return <main id="main" className="mx-auto max-w-xl px-4 py-12"><FormRenderer slug={slug} def={{ title: def.title, description: def.description, consentText: def.consentText, steps: def.steps, fields: def.fields.map((f) => ({ key: f.key, label: f.label, type: f.type, required: f.required, options: f.options, help: f.help, step: f.step, visibleWhen: f.visibleWhen })) }} /></main>;
}
