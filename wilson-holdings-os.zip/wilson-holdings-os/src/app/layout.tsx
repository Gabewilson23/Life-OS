import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = { title: { default: "Wilson Holdings OS", template: "%s · Wilson Holdings" }, robots: { index: false, follow: false } };
export const viewport: Viewport = { themeColor: "#090b0e", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <a href="#main" className="skip-link btn">Skip to content</a>
        {children}
      </body>
    </html>
  );
}
