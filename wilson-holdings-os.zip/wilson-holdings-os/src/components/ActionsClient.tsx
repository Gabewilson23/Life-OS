"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { api, ApiError } from "@/lib/client";
import { Badge } from "./ui";

export function useRefreshAction() {
  const router = useRouter();
  const [err, setErr] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const run = async (fn: () => Promise<unknown>, ok?: string) => {
    setErr(null); setMsg(null);
    try { const r = await fn(); if (ok) setMsg(ok); start(() => router.refresh()); return r; } catch (e) { setErr((e as ApiError).message); start(() => router.refresh()); return null; }
  };
  return { err, msg, pending, run };
}

export type ApprovalRow = { id: string; action_kind: string; status: string; scope: string; resource: string; payload: Record<string, unknown>; content_hash: string; discloses: string[]; expires_at: string; created_at: string; account_label: string | null; external_account: string | null; attempt_id: string | null; attempt_state: string | null; verified: boolean | null; remote_id: string | null; attempt_error: string | null; via_standing_permission: string | null };

export function ApprovalCard({ a }: { a: ApprovalRow }) {
  const { err, msg, run, pending } = useRefreshAction();
  const p = a.payload;
  return (
    <li className="rounded-[16px] border border-white/[0.08] bg-black/25 p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap gap-1.5"><Badge tone="blue">{a.action_kind}</Badge><Badge tone={a.status === "pending" ? "amber" : a.status === "consumed" || a.status === "approved" ? "green" : "neutral"}>{a.status}</Badge>{a.via_standing_permission && <Badge tone="champagne">standing permission</Badge>}</div>
          <p className="mt-2 text-[15px] font-medium text-stone-50">{String(p.title ?? p.subject ?? "")}</p>
          <dl className="mt-1 grid gap-x-4 text-xs text-stone-400 sm:grid-cols-2">
            <div>Account: <span className="text-stone-200">{a.account_label} {a.external_account ? `(${a.external_account})` : ""}</span></div>
            <div>Resource: <span className="text-stone-200">{a.resource}</span></div>
            {p.start ? <div>When: <span className="text-stone-200">{String(p.start)} → {String(p.end)}</span></div> : null}
            {p.to ? <div>To: <span className="text-stone-200">{(p.to as string[]).join(", ")}</span></div> : null}
            <div>Expires: {new Date(a.expires_at).toLocaleString("en-US", { timeZone: "America/New_York" })}</div>
            <div className="font-mono">hash {a.content_hash.slice(0, 12)}…</div>
          </dl>
          {a.discloses.length > 0 && <ul className="mt-2 space-y-0.5 text-xs text-signal-amber">{a.discloses.map((d) => <li key={d}>⚠ {d}</li>)}</ul>}
          {a.attempt_state && <p className="mt-2 text-xs">Execution: <Badge tone={a.attempt_state === "succeeded" ? "green" : a.attempt_state === "uncertain" ? "amber" : "red"}>{a.attempt_state}{a.verified ? " · verified" : ""}</Badge> {a.remote_id && <span className="font-mono text-stone-400">remote {a.remote_id}</span>} {a.attempt_error && <span className="text-signal-red">{a.attempt_error}</span>}</p>}
        </div>
        <div className="flex shrink-0 flex-wrap gap-1.5">
          {a.status === "pending" && <><button className="btn btn-primary btn-sm" disabled={pending} onClick={() => run(() => api(`/api/approvals/${a.id}`, { body: { action: "approve", hash: a.content_hash, executeNow: true } }), "Approved and executed")}>Approve & run</button>
            <button className="btn btn-sm" onClick={() => run(() => api(`/api/approvals/${a.id}`, { body: { action: "deny", hash: a.content_hash } }))}>Deny</button></>}
          {a.status === "approved" && <button className="btn btn-primary btn-sm" onClick={() => run(() => api(`/api/approvals/${a.id}`, { body: { action: "execute" } }), "Executed")}>Run now</button>}
          {["pending", "approved"].includes(a.status) && <button className="btn btn-ghost btn-sm" onClick={() => run(() => api(`/api/approvals/${a.id}`, { body: { action: "revoke" } }))}>Revoke</button>}
          {a.attempt_id && a.attempt_state !== "succeeded" && <button className="btn btn-sm" onClick={() => run(() => api(`/api/approvals/${a.id}`, { body: { action: "reconcile", attemptId: a.attempt_id, retryIfAbsent: true } }), "Reconciled")}>Reconcile & retry safely</button>}
        </div>
      </div>
      {msg && <p role="status" className="mt-2 text-xs text-signal-green">{msg}</p>}
      {err && <p role="alert" className="mt-2 text-xs text-signal-red">{err}</p>}
    </li>
  );
}

export function ProposalRow({ p }: { p: { id: string; title: string; kind: string; rationale: string; payload_hash: string; agent_title: string | null; payload: unknown } }) {
  const { err, run } = useRefreshAction();
  return (
    <li className="flex flex-wrap items-start justify-between gap-3 rounded-[14px] border border-white/[0.07] bg-black/20 p-3">
      <div><p className="text-sm text-stone-50">{p.title}</p><p className="text-xs text-stone-500">{p.agent_title ?? "agent"} · {p.kind} — {p.rationale}</p></div>
      <div className="flex gap-1.5"><button className="btn btn-primary btn-sm" onClick={() => run(() => api(`/api/proposals/${p.id}`, { body: { decision: "accept", payloadHash: p.payload_hash } }))}>Accept</button><button className="btn btn-sm" onClick={() => run(() => api(`/api/proposals/${p.id}`, { body: { decision: "reject", payloadHash: p.payload_hash } }))}>Reject</button></div>
      {err && <p role="alert" className="w-full text-xs text-signal-red">{err}</p>}
    </li>
  );
}
