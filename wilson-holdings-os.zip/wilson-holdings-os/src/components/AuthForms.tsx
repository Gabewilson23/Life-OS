"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api, ApiError } from "@/lib/client";

export function LoginForm() {
  const router = useRouter();
  const [mfa, setMfa] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <form
      className="glass space-y-4 rounded-[var(--radius-xl)] p-6"
      onSubmit={async (e) => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        setBusy(true); setErr(null);
        try {
          await api("/api/auth/login", { body: { email: f.get("email"), password: f.get("password"), code: (f.get("code") as string) || undefined } });
          router.replace("/"); router.refresh();
        } catch (x) { const ae = x as ApiError; if ((ae.details as { mfaRequired?: boolean } | undefined)?.mfaRequired) setMfa(true); setErr(ae.message); } finally { setBusy(false); }
      }}
    >
      <label className="block text-sm"><span className="mb-1.5 block text-stone-300">Email</span><input className="input" name="email" type="email" autoComplete="username" required /></label>
      <label className="block text-sm"><span className="mb-1.5 block text-stone-300">Password</span><input className="input" name="password" type="password" autoComplete="current-password" required /></label>
      {mfa && <label className="block text-sm"><span className="mb-1.5 block text-stone-300">Authenticator code</span><input className="input font-mono tracking-widest" name="code" inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} required autoFocus /></label>}
      {err && <p role="alert" className="text-sm text-signal-red">{err}</p>}
      <button className="btn btn-primary w-full" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button>
    </form>
  );
}

export function SetupForm() {
  const router = useRouter();
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <form
      className="glass space-y-4 rounded-[var(--radius-xl)] p-6"
      onSubmit={async (e) => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        if (f.get("password") !== f.get("confirm")) { setErr("Passwords do not match."); return; }
        setBusy(true); setErr(null);
        try {
          await api("/api/auth/setup", { body: { setupToken: f.get("setupToken"), displayName: f.get("displayName"), email: f.get("email"), password: f.get("password") } });
          router.replace("/"); router.refresh();
        } catch (x) { setErr((x as ApiError).message); } finally { setBusy(false); }
      }}
    >
      <p className="text-sm text-stone-400">Create the owner account. This confirms your identity for onboarding; nothing else about you is preloaded.</p>
      <label className="block text-sm"><span className="mb-1.5 block text-stone-300">Setup token</span><input className="input font-mono" name="setupToken" required autoComplete="off" /><span className="mt-1 block text-xs text-stone-500">From SETUP_TOKEN in your server environment.</span></label>
      <label className="block text-sm"><span className="mb-1.5 block text-stone-300">Your name</span><input className="input" name="displayName" required autoComplete="name" /></label>
      <label className="block text-sm"><span className="mb-1.5 block text-stone-300">Email</span><input className="input" name="email" type="email" required autoComplete="username" /></label>
      <label className="block text-sm"><span className="mb-1.5 block text-stone-300">Password (12+ characters)</span><input className="input" name="password" type="password" minLength={12} required autoComplete="new-password" /></label>
      <label className="block text-sm"><span className="mb-1.5 block text-stone-300">Confirm password</span><input className="input" name="confirm" type="password" minLength={12} required autoComplete="new-password" /></label>
      {err && <p role="alert" className="text-sm text-signal-red">{err}</p>}
      <button className="btn btn-primary w-full" disabled={busy}>{busy ? "Creating…" : "Create owner account"}</button>
    </form>
  );
}
