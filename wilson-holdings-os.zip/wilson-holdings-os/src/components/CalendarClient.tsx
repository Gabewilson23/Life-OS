"use client";
import { useMemo, useState } from "react";
import { api } from "@/lib/client";
import { useRefreshAction } from "./ActionsClient";
import { Badge, cx } from "./ui";

export type CalEvent = { id: string; remote_id: string; title: string; starts_at: string; ends_at: string; all_day: boolean; account_id: string; account_label: string; calendar_id: string; etag: string | null; scope: string; attendees: { email: string }[]; last_synced_at: string };
type Account = { id: string; label: string; scope: string; capabilities: string[]; settings: { bufferMinutes?: number } };
const TZ = "America/New_York";
const fmt = (d: Date, o: Intl.DateTimeFormatOptions) => new Intl.DateTimeFormat("en-US", { timeZone: TZ, ...o }).format(d);
const ymd = (d: Date) => new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
const hourOf = (d: Date) => Number(fmt(d, { hour: "numeric", hourCycle: "h23" })) + Number(fmt(d, { minute: "numeric" })) / 60;
/** Offset string (e.g. -05:00 / -04:00) for a local NY wall time — DST aware. */
function nyOffset(dateStr: string) {
  const probe = new Date(`${dateStr}T12:00:00Z`);
  const p = new Intl.DateTimeFormat("en-US", { timeZone: TZ, timeZoneName: "longOffset" }).formatToParts(probe).find((x) => x.type === "timeZoneName")!.value;
  return p === "GMT" ? "+00:00" : p.replace("GMT", "");
}
export const toNyIso = (date: string, time: string) => `${date}T${time}:00${nyOffset(date)}`;

export function CalendarClient({ events, accounts, anchor }: { events: CalEvent[]; accounts: Account[]; anchor: string }) {
  const [view, setView] = useState<"day" | "week" | "month">("week");
  const [msg, setMsg] = useState<string | null>(null);
  const { err, run } = useRefreshAction();
  const writable = accounts.filter((a) => a.capabilities.includes("calendar.write"));
  const base = new Date(`${anchor}T12:00:00Z`);
  const days = useMemo(() => {
    const n = view === "day" ? 1 : view === "week" ? 7 : 35;
    const start = new Date(base);
    if (view === "week") start.setUTCDate(start.getUTCDate() - start.getUTCDay());
    if (view === "month") { start.setUTCDate(1); start.setUTCDate(1 - start.getUTCDay()); }
    return Array.from({ length: n }, (_, i) => { const d = new Date(start); d.setUTCDate(start.getUTCDate() + i); return ymd(d); });
  }, [view, anchor]); // eslint-disable-line react-hooks/exhaustive-deps

  const byDay = (d: string) => events.filter((e) => ymd(new Date(e.starts_at)) === d);
  const conflicts = useMemo(() => {
    const s = new Set<string>();
    const sorted = [...events].filter((e) => !e.all_day).sort((a, b) => a.starts_at.localeCompare(b.starts_at));
    for (let i = 0; i < sorted.length; i++) for (let j = i + 1; j < sorted.length; j++) {
      const a = sorted[i]!, b = sorted[j]!;
      if (new Date(b.starts_at) < new Date(a.ends_at)) { s.add(a.id); s.add(b.id); }
    }
    return s;
  }, [events]);

  async function propose(f: FormData) {
    const acct = writable.find((a) => a.id === f.get("account"))!;
    const date = String(f.get("date"));
    const attendees = String(f.get("attendees") ?? "").split(",").map((x) => x.trim()).filter(Boolean);
    const r = (await run(() => api<{ status: string }>("/api/approvals", { body: { kind: "calendar.event.create", scope: acct.scope, accountId: acct.id, payload: { title: f.get("title"), start: toNyIso(date, String(f.get("start"))), end: toNyIso(date, String(f.get("end"))), calendarId: "primary", attendees, visibility: f.get("visibility"), timeZone: TZ } } }))) as { status: string } | null;
    if (r) setMsg(r.status === "approved" ? "Auto-approved by a standing permission — run it from Approvals." : "Proposed. Review the exact preview in Approvals before it is created.");
  }
  async function moveEvent(e: CalEvent, date: string, hour: number) {
    const durMin = (new Date(e.ends_at).getTime() - new Date(e.starts_at).getTime()) / 60000;
    const hh = String(Math.floor(hour)).padStart(2, "0");
    const start = toNyIso(date, `${hh}:00`);
    const end = new Date(new Date(start).getTime() + durMin * 60000).toISOString();
    const acct = accounts.find((a) => a.id === e.account_id);
    if (!acct?.capabilities.includes("calendar.write")) { setMsg("That calendar is read-only here."); return; }
    const r = await run(() => api("/api/approvals", { body: { kind: "calendar.event.update", scope: acct.scope, accountId: acct.id, payload: { eventId: e.remote_id, etag: e.etag, calendarId: e.calendar_id, title: e.title, start, end, attendees: e.attendees.map((a) => a.email), timeZone: TZ } } }));
    if (r) setMsg(`Proposed moving "${e.title}". ${e.attendees.length ? "Attendees will be notified if approved." : ""} Approve it in Approvals.`);
  }

  const hours = Array.from({ length: 16 }, (_, i) => i + 6);
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div role="group" aria-label="View" className="glass-subtle flex rounded-[10px] p-0.5">{(["day", "week", "month"] as const).map((v) => <button key={v} onClick={() => setView(v)} aria-pressed={view === v} className={cx("rounded-[8px] px-3 py-1 text-sm capitalize", view === v ? "bg-azure-500 text-white" : "text-stone-300")}>{v}</button>)}</div>
        <a className="btn btn-sm" href={`?d=${shift(anchor, view === "month" ? -30 : view === "week" ? -7 : -1)}`}>←</a>
        <a className="btn btn-sm" href="?">Today</a>
        <a className="btn btn-sm" href={`?d=${shift(anchor, view === "month" ? 30 : view === "week" ? 7 : 1)}`}>→</a>
        <span className="text-sm text-stone-400">Times in {TZ.replace("_", " ")} · {conflicts.size ? <span className="text-signal-red">{conflicts.size} events in conflict</span> : "no conflicts"}</span>
      </div>
      {view === "month" ? (
        <div className="grid grid-cols-7 gap-1.5">
          {days.map((d) => <div key={d} className="glass-subtle min-h-[96px] rounded-[10px] p-1.5"><p className="text-[11px] text-stone-500">{d.slice(5)}</p>{byDay(d).slice(0, 4).map((e) => <p key={e.id} className={cx("truncate rounded px-1 text-[11px]", conflicts.has(e.id) ? "bg-signal-red/25" : "bg-azure-500/25")}>{fmt(new Date(e.starts_at), { hour: "numeric", minute: "2-digit" })} {e.title}</p>)}</div>)}
        </div>
      ) : (
        <div className="glass overflow-x-auto rounded-[16px]">
          <div className="grid min-w-[720px]" style={{ gridTemplateColumns: `56px repeat(${days.length}, 1fr)` }}>
            <div />{days.map((d) => <div key={d} className="border-b border-white/[0.06] px-2 py-2 text-center text-xs text-stone-300">{fmt(new Date(`${d}T12:00:00Z`), { weekday: "short", month: "short", day: "numeric" })}</div>)}
            {hours.map((h) => (
              <div key={h} className="contents">
                <div className="h-12 pr-2 text-right text-[10px] text-stone-500">{h % 12 || 12}{h < 12 ? "a" : "p"}</div>
                {days.map((d) => (
                  <div key={d + h} className="relative h-12 border-l border-t border-white/[0.04]" onDragOver={(ev) => ev.preventDefault()} onDrop={(ev) => { const id = ev.dataTransfer.getData("text/plain"); const e = events.find((x) => x.id === id); if (e) moveEvent(e, d, h); }}>
                    {byDay(d).filter((e) => !e.all_day && Math.floor(hourOf(new Date(e.starts_at))) === h).map((e) => {
                      const dur = Math.max(0.5, (new Date(e.ends_at).getTime() - new Date(e.starts_at).getTime()) / 3600000);
                      return <div key={e.id} draggable onDragStart={(ev) => ev.dataTransfer.setData("text/plain", e.id)} title={`${e.title} · ${e.account_label} · synced ${e.last_synced_at.slice(0, 16)}`}
                        className={cx("absolute inset-x-0.5 z-10 cursor-grab overflow-hidden rounded-[6px] border px-1 text-[11px] leading-tight text-white shadow", conflicts.has(e.id) ? "border-signal-red/60 bg-signal-red/40" : "border-azure-500/50 bg-gradient-to-b from-azure-500/70 to-azure-700/70")}
                        style={{ top: `${(hourOf(new Date(e.starts_at)) - h) * 48}px`, height: `${dur * 48 - 2}px` }}>{e.title}</div>;
                    })}
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      )}
      <div className="glass rounded-[16px] p-4">
        <h3 className="display mb-3 text-base text-stone-50">Propose an event</h3>
        {writable.length === 0 ? <p className="text-sm text-stone-500">Connect a Google account with “Create/update events” on the Integrations page to propose events. Drag events in week/day view to propose a move.</p> : (
          <form className="grid gap-2 sm:grid-cols-6" onSubmit={(e) => { e.preventDefault(); propose(new FormData(e.currentTarget)); }}>
            <input className="input sm:col-span-2" name="title" required placeholder="Title" aria-label="Title" />
            <input className="input" type="date" name="date" required defaultValue={anchor} aria-label="Date" />
            <input className="input" type="time" name="start" required defaultValue="09:00" aria-label="Start" />
            <input className="input" type="time" name="end" required defaultValue="10:00" aria-label="End" />
            <select className="input" name="account" aria-label="Calendar account">{writable.map((a) => <option key={a.id} value={a.id}>{a.label}</option>)}</select>
            <input className="input sm:col-span-3" name="attendees" placeholder="Attendee emails (comma-separated) — invitations will be sent" aria-label="Attendees" />
            <select className="input" name="visibility" defaultValue="private" aria-label="Visibility"><option value="private">Private</option><option value="default">Default</option></select>
            <button className="btn btn-primary sm:col-span-2">Prepare for approval</button>
          </form>
        )}
        {msg && <p role="status" className="mt-2 text-sm text-signal-green">{msg} <a className="underline" href="/approvals">Open approvals</a></p>}
        {err && <p role="alert" className="mt-2 text-sm text-signal-red">{err}</p>}
        <p className="mt-2 text-xs text-stone-500"><Badge>read-only mirror</Badge> Events shown come from the last sync; source calendar and remote event ID are on hover. Changes never overwrite a newer remote version (ETag check).</p>
      </div>
    </div>
  );
}
function shift(d: string, days: number) { const x = new Date(`${d}T12:00:00Z`); x.setUTCDate(x.getUTCDate() + days); return x.toISOString().slice(0, 10); }
