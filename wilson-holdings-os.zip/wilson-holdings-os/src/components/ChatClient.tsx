"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { api, ApiError } from "@/lib/client";
import { Badge, cx, StateBadge } from "./ui";

type Agent = { id: string; title: string; number: number };
type Channel = { id: string; title: string; agent_id: string; private: boolean; expires_at: string | null; kind: string };
type Msg = { id: string; role: string; content: string; run_id: string | null; run_state?: string | null; blocked_reason?: string | null; run_error?: string | null; evidence: { tools?: { tool: string; ok: boolean; summary: string }[]; memories?: { ref: string; subject: string }[] }; is_demo: boolean; created_at: string };
type Proposal = { id: string; run_id: string; title: string; kind: string; status: string; rationale: string; payload: Record<string, unknown>; payload_hash: string; scope: string; agent_title: string | null };
type Live = { runId: string; text: string; state: string; reason?: string; tools: { tool: string; ok?: boolean; summary?: string }[] };

export function ChatClient({ agents, channels: initialChannels, initialAgentId, modelReady }: { agents: Agent[]; channels: Channel[]; initialAgentId: string; modelReady: boolean }) {
  const [channels, setChannels] = useState(initialChannels);
  const [agentId, setAgentId] = useState(initialAgentId);
  const [channelId, setChannelId] = useState<string | null>(initialChannels.find((c) => c.agent_id === initialAgentId && !c.private)?.id ?? null);
  const [priv, setPriv] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [live, setLive] = useState<Live | null>(null);
  const [pending, setPending] = useState<string | null>(null);
  const [text, setText] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  const load = useCallback(async (id: string) => {
    const r = await api<{ messages: Msg[]; proposals: Proposal[] }>(`/api/chat/${id}`);
    setMsgs(r.messages); setProposals(r.proposals);
  }, []);
  useEffect(() => { if (channelId) load(channelId).catch((e) => setErr((e as Error).message)); else { setMsgs([]); setProposals([]); } }, [channelId, load]);
  useEffect(() => { endRef.current?.scrollIntoView({ block: "end" }); }, [msgs, live]);

  const pick = (aid: string, isPrivate = false) => {
    setAgentId(aid); setPriv(isPrivate); setLive(null);
    setChannelId(isPrivate ? null : channels.find((c) => c.agent_id === aid && !c.private)?.id ?? null);
  };

  async function send() {
    const message = text.trim();
    if (!message || live) return;
    setErr(null); setText(""); setPending(message);
    try {
      const res = await fetch("/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ channelId: channelId ?? undefined, agentId, private: priv, message, clientMessageId: crypto.randomUUID() }) });
      if (!res.ok || !res.body) throw new ApiError(res.status, (await res.json().catch(() => ({}))).error ?? "Request failed");
      const reader = res.body.getReader(); const dec = new TextDecoder(); let buf = ""; let cid = channelId;
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf("\n\n")) >= 0) {
          const line = buf.slice(0, i).replace(/^data: /, ""); buf = buf.slice(i + 2);
          const e = JSON.parse(line);
          if (e.type === "channel") { cid = e.channelId; setLive({ runId: e.runId, text: "", state: "queued", tools: [] }); }
          else if (e.type === "text") setLive((l) => l && { ...l, text: l.text + e.delta });
          else if (e.type === "status") setLive((l) => l && { ...l, state: e.state, reason: e.reason });
          else if (e.type === "tool_call") setLive((l) => l && { ...l, tools: [...l.tools, { tool: e.tool }] });
          else if (e.type === "tool_result") setLive((l) => l && { ...l, tools: l.tools.map((t, k) => (k === l.tools.length - 1 ? { ...t, ok: e.ok, summary: e.summary } : t)) });
          else if (e.type === "done") setLive((l) => l && { ...l, state: e.state });
        }
      }
      if (cid && cid !== channelId) {
        setChannelId(cid);
        const r = await api<{ channels: Channel[] }>("/api/chat/channels"); setChannels(r.channels);
      } else if (cid) await load(cid);
    } catch (e) { setErr((e as Error).message); }
    finally { setPending(null); setLive(null); }
  }

  async function decide(p: Proposal, decision: "accept" | "reject") {
    try { await api(`/api/proposals/${p.id}`, { body: { decision, payloadHash: p.payload_hash } }); if (channelId) await load(channelId); }
    catch (e) { setErr((e as Error).message); }
  }

  const agent = agents.find((a) => a.id === agentId);
  const current = channels.find((c) => c.id === channelId);
  return (
    <div className="grid gap-4 lg:grid-cols-[260px_1fr]">
      <aside className="glass rounded-[20px] p-3" aria-label="Conversations">
        <button onClick={() => pick("hq.chief-of-staff")} className={cx("mb-2 w-full rounded-[12px] px-3 py-2.5 text-left", agentId === "hq.chief-of-staff" && !priv ? "bg-gradient-to-b from-azure-500 to-azure-700 text-white" : "hover:bg-white/[0.06]")}>
          <span className="block text-sm font-semibold">Chief of Staff</span><span className="text-xs opacity-75">Main interface · orchestrates roles</span>
        </button>
        <button onClick={() => pick(agentId, true)} className={cx("mb-3 w-full rounded-[12px] border border-dashed border-white/15 px-3 py-2 text-left text-xs", priv ? "bg-champagne-600/40 text-white" : "text-stone-400 hover:text-white")}>
          🔒 New private session with {agent?.title ?? "this role"} — not remembered; expires in 24h
        </button>
        <label className="block text-xs text-stone-400">Message a specific role
          <select className="input mt-1" value={agentId} onChange={(e) => pick(e.target.value)}>
            {agents.map((a) => <option key={a.id} value={a.id}>{a.number}. {a.title}</option>)}
          </select>
        </label>
        {channels.length > 0 && <p className="eyebrow mb-1 mt-4 px-1">Recent</p>}
        <ul className="space-y-0.5">
          {channels.slice(0, 12).map((c) => (
            <li key={c.id}><button onClick={() => { setAgentId(c.agent_id); setPriv(c.private); setChannelId(c.id); }} className={cx("w-full truncate rounded-[10px] px-2.5 py-1.5 text-left text-[13px]", c.id === channelId ? "bg-white/10 text-white" : "text-stone-300 hover:bg-white/[0.05]")}>{c.private ? "🔒 " : ""}{c.title}</button></li>
          ))}
        </ul>
      </aside>

      <section className="glass flex min-h-[70vh] flex-col rounded-[20px]" aria-label="Conversation">
        <header className="flex items-center justify-between gap-3 border-b border-white/[0.07] px-5 py-3">
          <div><h2 className="display text-lg text-stone-50">{priv || current?.private ? "Private session · " : ""}{agent?.title}</h2>
            <p className="text-xs text-stone-500">Responses are real runs with permitted tools. Proposals never execute until you accept them.</p></div>
          {!modelReady && <Badge tone="amber">Model credential missing</Badge>}
        </header>
        <div className="flex-1 space-y-4 overflow-y-auto px-5 py-4" aria-live="polite">
          {msgs.length === 0 && !pending && <p className="text-sm text-stone-500">Ask for a briefing, a plan, or a decision memo. Example: “What should I focus on this week given my goals and open tasks?”</p>}
          {msgs.map((m) => <MessageView key={m.id} m={m} proposals={proposals.filter((p) => p.run_id && p.run_id === m.run_id)} decide={decide} />)}
          {pending && <div className="ml-auto max-w-[80%] rounded-[16px] rounded-br-[6px] bg-gradient-to-b from-azure-500 to-azure-700 px-4 py-2.5 text-sm text-white">{pending}</div>}
          {live && (
            <div className="max-w-[88%]">
              <div className="mb-1 flex items-center gap-2"><StateBadge state={live.state} />{live.reason && <span className="text-xs text-stone-400">{live.reason}</span>}
                {live.state === "running" && <button className="btn btn-ghost btn-sm" onClick={() => api(`/api/runs/${live.runId}/cancel`, { body: {} })}>Cancel</button>}</div>
              {live.tools.map((t, i) => <p key={i} className="text-xs text-stone-500">↳ {t.tool}{t.ok === false ? " — failed" : t.summary ? " ✓" : "…"}</p>)}
              {live.text && <div className="mt-1 whitespace-pre-wrap rounded-[16px] rounded-bl-[6px] border border-white/10 bg-white/[0.05] px-4 py-3 text-[14px] leading-relaxed text-stone-100">{live.text}</div>}
            </div>
          )}
          <div ref={endRef} />
        </div>
        {err && <p role="alert" className="px-5 pb-2 text-sm text-signal-red">{err}</p>}
        <form className="flex gap-2 border-t border-white/[0.07] p-3" onSubmit={(e) => { e.preventDefault(); send(); }}>
          <textarea className="input min-h-[44px] flex-1 resize-none" rows={2} value={text} onChange={(e) => setText(e.target.value)} placeholder={`Message ${agent?.title ?? ""}…`} aria-label="Message"
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }} />
          <button className="btn btn-primary self-end" disabled={!text.trim() || !!live}>Send</button>
        </form>
      </section>
    </div>
  );
}

function MessageView({ m, proposals, decide }: { m: Msg; proposals: Proposal[]; decide: (p: Proposal, d: "accept" | "reject") => void }) {
  if (m.role === "system") return <p className="rounded-[12px] border border-signal-amber/30 bg-signal-amber/10 px-3 py-2 text-xs text-signal-amber">{m.content}</p>;
  if (m.role === "user") return <div className="ml-auto max-w-[80%] whitespace-pre-wrap rounded-[16px] rounded-br-[6px] bg-gradient-to-b from-azure-500 to-azure-700 px-4 py-2.5 text-sm text-white">{m.content}</div>;
  const tools = m.evidence?.tools ?? [];
  const mems = m.evidence?.memories ?? [];
  return (
    <div className="max-w-[88%]">
      {m.is_demo && <Badge tone="demo">demo output</Badge>}
      <div className="whitespace-pre-wrap rounded-[16px] rounded-bl-[6px] border border-white/10 bg-white/[0.05] px-4 py-3 text-[14px] leading-relaxed text-stone-100">{m.content}</div>
      {(tools.length > 0 || mems.length > 0) && (
        <details className="mt-1 text-xs text-stone-400"><summary className="cursor-pointer">Evidence: {tools.length} tool call{tools.length === 1 ? "" : "s"}, {mems.length} memor{mems.length === 1 ? "y" : "ies"}</summary>
          <ul className="mt-1 space-y-0.5 pl-3">{tools.map((t, i) => <li key={i}>{t.ok ? "✓" : "✗"} {t.summary}</li>)}{mems.map((x) => <li key={x.ref}>memory:{x.ref} — {x.subject}</li>)}</ul>
        </details>
      )}
      {proposals.map((p) => (
        <div key={p.id} className="mt-2 rounded-[14px] border border-champagne-400/30 bg-champagne-600/10 p-3">
          <div className="flex items-start justify-between gap-3">
            <div><p className="text-sm font-medium text-stone-50">{p.title}</p><p className="text-xs text-stone-400">{p.rationale}</p>
              <pre className="mt-1 max-h-28 overflow-auto whitespace-pre-wrap font-mono text-[11px] text-stone-400">{JSON.stringify(p.payload, null, 1)}</pre></div>
            {p.status === "proposed" ? (
              <div className="flex shrink-0 gap-1.5"><button className="btn btn-primary btn-sm" onClick={() => decide(p, "accept")}>Accept</button><button className="btn btn-sm" onClick={() => decide(p, "reject")}>Reject</button></div>
            ) : <Badge tone={p.status === "executed" || p.status === "accepted" ? "green" : "neutral"}>{p.status}</Badge>}
          </div>
        </div>
      ))}
      {m.run_state && m.run_state !== "succeeded" && <p className="mt-1 text-xs text-signal-amber">Run {m.run_state}{m.blocked_reason ? `: ${m.blocked_reason}` : ""}</p>}
    </div>
  );
}
