"use client";
import { useState } from "react";
import { api } from "@/lib/client";
import { useRefreshAction } from "./ActionsClient";

type Account = { id: string; label: string; scope: string; external_account: string | null; capabilities: string[] };
export function EmailComposer({ accounts, scopes }: { accounts: Account[]; scopes: { scope: string; label: string }[] }) {
  const { err, msg, run } = useRefreshAction();
  const [scope, setScope] = useState(scopes[0]?.scope ?? "org");
  const usable = accounts.filter((a) => a.scope === scope && a.capabilities.includes("gmail.draft"));
  return (
    <form className="grid gap-2" onSubmit={async (e) => {
      e.preventDefault();
      const f = new FormData(e.currentTarget);
      const list = (k: string) => String(f.get(k) ?? "").split(",").map((x) => x.trim()).filter(Boolean);
      const accountId = (f.get("account") as string) || null;
      const ok = await run(() => api("/api/email/drafts", { body: { scope, accountId, to: list("to"), cc: list("cc"), bcc: list("bcc"), subject: f.get("subject"), body: f.get("body"), sync: !!accountId } }), accountId ? "Draft saved locally; Gmail draft creation is waiting in Approvals." : "Draft saved locally (not synced — no Gmail account for this scope).");
      if (ok) (e.target as HTMLFormElement).reset();
    }}>
      <div className="grid gap-2 sm:grid-cols-2">
        <label className="text-xs text-stone-400">Company / voice<select className="input mt-1" value={scope} onChange={(e) => setScope(e.target.value)}>{scopes.map((s) => <option key={s.scope} value={s.scope}>{s.label}</option>)}</select></label>
        <label className="text-xs text-stone-400">From account<select className="input mt-1" name="account" defaultValue="">{usable.length ? usable.map((a) => <option key={a.id} value={a.id}>{a.label} {a.external_account ? `(${a.external_account})` : ""}</option>) : null}<option value="">Local draft only</option></select></label>
      </div>
      <input className="input" name="to" required placeholder="To (confirmed addresses, comma-separated)" aria-label="To" />
      <div className="grid gap-2 sm:grid-cols-2"><input className="input" name="cc" placeholder="Cc" aria-label="Cc" /><input className="input" name="bcc" placeholder="Bcc" aria-label="Bcc" /></div>
      <input className="input" name="subject" required placeholder="Subject" aria-label="Subject" />
      <textarea className="input" name="body" rows={8} required placeholder="Message" aria-label="Body" />
      <p className="text-xs text-stone-500">Sending is not available from here: drafts sync to Gmail only after approval, and sending needs its own approval for the exact message, account and recipients.</p>
      <button className="btn btn-primary w-fit">Save draft</button>
      {msg && <p role="status" className="text-sm text-signal-green">{msg}</p>}
      {err && <p role="alert" className="text-sm text-signal-red">{err}</p>}
    </form>
  );
}
