"use client";
import { useMemo, useState } from "react";

type Field = { key: string; label: string; type: string; required?: boolean; options?: string[]; help?: string; step?: number; visibleWhen?: { field: string; equals: string | boolean } };
export type FormDefinition = { title: string; description?: string; consentText?: string; steps?: string[]; fields: Field[] };

/** Accessible multi-step form renderer for Build Studio forms (preview and public use). */
export function FormRenderer({ slug, def, preview }: { slug: string; def: FormDefinition; preview?: boolean }) {
  const steps = def.steps?.length ? def.steps : ["Details"];
  const [step, setStep] = useState(0);
  const [data, setData] = useState<Record<string, unknown>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [msg, setMsg] = useState("");
  const clientKey = useMemo(() => (typeof crypto !== "undefined" ? crypto.randomUUID() : String(Date.now())), []);
  const visible = (f: Field) => !f.visibleWhen || data[f.visibleWhen.field] === f.visibleWhen.equals || String(data[f.visibleWhen.field] ?? "") === String(f.visibleWhen.equals);
  const fields = def.fields.filter((f) => (f.step ?? 0) === step && visible(f));
  const last = step === steps.length - 1;

  async function submit() {
    if (preview) { setMsg("Preview only — nothing was submitted."); return; }
    setState("sending"); setErrors({});
    const res = await fetch(`/api/forms/${slug}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ clientKey, data }) });
    const j = await res.json().catch(() => ({}));
    if (res.ok) { setState("done"); return; }
    setState("error"); setErrors(j.errors ?? {}); setMsg(j.error ?? "Please fix the highlighted fields.");
  }
  if (state === "done") return <div role="status" className="glass rounded-[20px] p-6 text-center"><p className="display text-xl text-stone-50">Thank you</p><p className="mt-1 text-sm text-stone-300">Your submission was received.</p></div>;
  return (
    <form className="glass space-y-4 rounded-[20px] p-6" onSubmit={(e) => { e.preventDefault(); if (last) submit(); else setStep(step + 1); }} noValidate={false}>
      <div><h1 className="display text-2xl text-stone-50">{def.title}</h1>{def.description && <p className="mt-1 text-sm text-stone-400">{def.description}</p>}</div>
      {steps.length > 1 && <ol className="flex gap-2 text-xs" aria-label="Steps">{steps.map((s, i) => <li key={s} aria-current={i === step ? "step" : undefined} className={`rounded-full px-2.5 py-1 ${i === step ? "bg-azure-500 text-white" : "bg-white/10 text-stone-400"}`}>{i + 1}. {s}</li>)}</ol>}
      <input type="text" name="_hp" tabIndex={-1} autoComplete="off" aria-hidden className="hidden" onChange={(e) => setData({ ...data, _hp: e.target.value })} />
      {fields.map((f) => (
        <div key={f.key}>
          <label htmlFor={`f-${f.key}`} className="mb-1 block text-sm text-stone-200">{f.label}{f.required && <span className="text-signal-red"> *</span>}</label>
          {f.type === "textarea" ? <textarea id={`f-${f.key}`} className="input" rows={4} required={f.required} value={String(data[f.key] ?? "")} onChange={(e) => setData({ ...data, [f.key]: e.target.value })} aria-invalid={!!errors[f.key]} />
            : f.type === "select" ? <select id={`f-${f.key}`} className="input" required={f.required} value={String(data[f.key] ?? "")} onChange={(e) => setData({ ...data, [f.key]: e.target.value })}><option value="">Choose…</option>{f.options?.map((o) => <option key={o}>{o}</option>)}</select>
              : f.type === "checkbox" ? <input id={`f-${f.key}`} type="checkbox" className="h-4 w-4" checked={data[f.key] === true} onChange={(e) => setData({ ...data, [f.key]: e.target.checked })} />
                : <input id={`f-${f.key}`} className="input" required={f.required} type={f.type === "phone" ? "tel" : f.type === "number" ? "number" : f.type === "date" ? "date" : f.type === "email" ? "email" : "text"} value={String(data[f.key] ?? "")} onChange={(e) => setData({ ...data, [f.key]: e.target.value })} aria-invalid={!!errors[f.key]} aria-describedby={errors[f.key] ? `e-${f.key}` : undefined} />}
          {f.help && <p className="mt-1 text-xs text-stone-500">{f.help}</p>}
          {errors[f.key] && <p id={`e-${f.key}`} className="mt-1 text-xs text-signal-red">{errors[f.key]}</p>}
        </div>
      ))}
      {last && def.consentText && <label className="flex items-start gap-2 text-sm text-stone-300"><input type="checkbox" required checked={data._consent === true} onChange={(e) => setData({ ...data, _consent: e.target.checked })} className="mt-1" />{def.consentText}</label>}
      {errors._consent && <p className="text-xs text-signal-red">{errors._consent}</p>}
      <div className="flex gap-2">{step > 0 && <button type="button" className="btn" onClick={() => setStep(step - 1)}>Back</button>}<button className="btn btn-primary" disabled={state === "sending"}>{last ? (state === "sending" ? "Sending…" : "Submit") : "Next"}</button></div>
      {msg && <p role="alert" className="text-sm text-signal-amber">{msg}</p>}
    </form>
  );
}
