"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api, ApiError } from "@/lib/client";
import { Badge } from "./ui";

type DS = { id: string; label: string; company: string; keyLabel: string; fields: { key: string; label: string; required?: boolean }[]; description: string };
type Preview = { batchId: string; headers: string[]; mapping: Record<string, string>; rowCount: number; missing: string[]; preview: { rowNum: number; key: string | null; values: Record<string, unknown>; errors: string[] }[]; duplicateOfBatch: string | null };

export function ImportWizard({ datasets }: { datasets: DS[] }) {
  const router = useRouter();
  const [ds, setDs] = useState(datasets[0]!.id);
  const [p, setP] = useState<Preview | null>(null);
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [result, setResult] = useState<{ inserted: number; updated: number; unchanged: number; rejected: number; errors: { row: number; errors: string[] }[] } | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const def = datasets.find((d) => d.id === ds)!;
  const targets = [{ key: "__key", label: `${def.keyLabel} (unique key)`, required: true }, ...def.fields];
  const missing = targets.filter((t) => t.required && !Object.values(mapping).includes(t.key)).map((t) => t.label);

  async function upload(f: File) {
    setErr(null); setResult(null); setBusy(true);
    const fd = new FormData(); fd.set("dataset", ds); fd.set("file", f);
    try {
      const res = await fetch("/api/imports/preview", { method: "POST", body: fd });
      const j = await res.json();
      if (!res.ok) throw new ApiError(res.status, j.error);
      setP(j); setMapping(j.mapping);
    } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  }
  async function commit(allowDuplicateFile = false) {
    setBusy(true); setErr(null);
    try { setResult(await api(`/api/imports/${p!.batchId}/commit`, { body: { mapping, allowDuplicateFile } })); router.refresh(); }
    catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  }
  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-[1fr_1fr]">
        <label className="text-xs text-stone-400">Dataset<select className="input mt-1" value={ds} onChange={(e) => { setDs(e.target.value); setP(null); setResult(null); }}>{datasets.map((d) => <option key={d.id} value={d.id}>{d.company === "atlas-insurance" ? "Insurance" : "Consulting"} · {d.label}</option>)}</select></label>
        <label className="text-xs text-stone-400">File (.csv or .xlsx, ≤5 MB)<input className="input mt-1 py-1.5" type="file" accept=".csv,.xlsx" disabled={busy} onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} /></label>
      </div>
      <p className="text-xs text-stone-500">{def.description} Required: {targets.filter((t) => t.required).map((t) => t.label).join(", ")}.</p>
      {p && !result && (
        <div className="space-y-3">
          {p.duplicateOfBatch && <p className="rounded-[10px] border border-signal-amber/30 bg-signal-amber/10 p-2 text-sm text-signal-amber">This exact file was imported before. Committing again changes nothing unless rows differ.</p>}
          <h3 className="display text-base">Map columns ({p.rowCount} rows)</h3>
          <div className="grid gap-2 sm:grid-cols-2">
            {p.headers.map((h) => (
              <label key={h} className="flex items-center gap-2 text-sm"><span className="w-40 truncate text-stone-300" title={h}>{h}</span>
                <select className="input" value={mapping[h] ?? ""} onChange={(e) => setMapping({ ...mapping, [h]: e.target.value })}><option value="">— ignore —</option>{targets.map((t) => <option key={t.key} value={t.key}>{t.label}{t.required ? " *" : ""}</option>)}</select></label>
            ))}
          </div>
          {missing.length > 0 && <p className="text-sm text-signal-red">Map required columns: {missing.join(", ")}</p>}
          <h3 className="display text-base">Validation preview (first {p.preview.length} rows, using suggested mapping)</h3>
          <div className="max-h-64 overflow-auto rounded-[10px] border border-white/[0.07]">
            <table className="w-full text-xs"><tbody>{p.preview.map((r) => <tr key={r.rowNum} className="border-b border-white/[0.04]"><td className="px-2 py-1 text-stone-500">{r.rowNum}</td><td className="px-2 py-1">{r.key}</td><td className="px-2 py-1">{r.errors.length ? <span className="text-signal-red">{r.errors.join("; ")}</span> : <Badge tone="green">ok</Badge>}</td></tr>)}</tbody></table>
          </div>
          <button className="btn btn-primary" disabled={busy || missing.length > 0} onClick={() => commit(!!p.duplicateOfBatch)}>Import {p.rowCount} rows</button>
        </div>
      )}
      {result && (
        <div className="rounded-[14px] border border-white/[0.08] bg-black/25 p-4 text-sm">
          <p className="font-medium text-stone-50">Import complete</p>
          <p className="mt-1 text-stone-300">{result.inserted} new · {result.updated} updated · {result.unchanged} unchanged (deduplicated) · <span className={result.rejected ? "text-signal-red" : ""}>{result.rejected} rejected</span></p>
          {result.rejected > 0 && <><ul className="mt-2 max-h-40 overflow-auto text-xs text-signal-red">{result.errors.map((e) => <li key={e.row}>Row {e.row}: {e.errors.join("; ")}</li>)}</ul><a className="btn btn-sm mt-2" href={`/api/imports/${p!.batchId}/errors`}>Download error report</a></>}
        </div>
      )}
      {err && <p role="alert" className="text-sm text-signal-red">{err}</p>}
    </div>
  );
}
