"use client";
import { useState } from "react";
import { api } from "@/lib/client";
import { useRefreshAction } from "./ActionsClient";
import { Badge } from "./ui";

const CAPS = [["calendar.read", "Read calendars"], ["calendar.write", "Create/update events (approval-gated)"], ["gmail.read", "Search & read email"], ["gmail.draft", "Create drafts (sending separately gated)"], ["drive.read", "Read Drive files"]] as const;

export function ConnectGoogle({ scopes, configured }: { scopes: { scope: string; label: string }[]; configured: boolean }) {
  const { err, run } = useRefreshAction();
  if (!configured) return <div className="rounded-[14px] border border-signal-amber/30 bg-signal-amber/10 p-4 text-sm text-stone-200"><p className="font-medium text-signal-amber">Setup needed</p><p className="mt-1">Set <code>GOOGLE_CLIENT_ID</code>, <code>GOOGLE_CLIENT_SECRET</code> and <code>TOKEN_ENCRYPTION_KEY</code> on the server, and add <code>{"{APP_URL}"}/api/integrations/google/callback</code> as an authorized redirect URI in Google Cloud Console. See docs/DEPLOY.md.</p></div>;
  return (
    <form className="grid gap-3" onSubmit={async (e) => {
      e.preventDefault();
      const f = new FormData(e.currentTarget);
      const r = (await run(() => api<{ url: string }>("/api/integrations/google/start", { body: { scope: f.get("scope"), label: f.get("label"), capabilities: f.getAll("cap") } }))) as { url: string } | null;
      if (r?.url) window.location.href = r.url; // real Google consent screen
    }}>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="text-xs text-stone-400">Belongs to<select className="input mt-1" name="scope" defaultValue="personal">{scopes.map((s) => <option key={s.scope} value={s.scope}>{s.label}</option>)}</select></label>
        <label className="text-xs text-stone-400">Label<input className="input mt-1" name="label" required placeholder="Personal Google / Atlas Insurance Google" /></label>
      </div>
      <fieldset className="grid gap-1.5 sm:grid-cols-2"><legend className="mb-1 text-xs text-stone-400">Capabilities to request</legend>
        {CAPS.map(([k, l]) => <label key={k} className="flex items-center gap-2 text-sm text-stone-200"><input type="checkbox" name="cap" value={k} defaultChecked={k === "calendar.read"} />{l}</label>)}
      </fieldset>
      <button className="btn btn-primary w-fit">Connect with Google</button>
      {err && <p role="alert" className="text-sm text-signal-red">{err}</p>}
    </form>
  );
}

export function AccountActions({ id, paused, scope, capabilities }: { id: string; paused: boolean; scope: string; capabilities: string[] }) {
  const { err, msg, run, pending } = useRefreshAction();
  const [out, setOut] = useState<string | null>(null);
  return (
    <div>
      <div className="flex flex-wrap gap-1.5">
        {capabilities.includes("calendar.read") && <button className="btn btn-sm" disabled={pending} onClick={async () => { const r = await run(() => api(`/api/integrations/${id}`, { body: { action: "sync" } })); if (r) setOut(JSON.stringify(r)); }}>Sync calendar</button>}
        <button className="btn btn-sm" onClick={async () => { const r = await run(() => api(`/api/integrations/${id}`, { body: { action: "health" } })); if (r) setOut(JSON.stringify(r)); }}>Health check</button>
        <button className="btn btn-sm" onClick={() => run(() => api(`/api/integrations/${id}`, { body: { action: paused ? "resume" : "pause" } }))}>{paused ? "Resume" : "Pause"}</button>
        {capabilities.includes("calendar.write") && <button className="btn btn-sm" onClick={() => run(() => api("/api/standing-permissions", { body: { scope, actionKind: "calendar.event.create", accountId: id, constraints: { no_attendees: true, private_only: true, max_per_day: 5 }, description: "Private focus blocks without attendees (max 5/day)" } }), "Standing permission created")}>Allow private blocks without asking</button>}
        <button className="btn btn-danger btn-sm" onClick={() => confirm("Revoke Google access for this account? Pending approvals using it will be voided.") && run(() => api(`/api/integrations/${id}`, { body: { action: "revoke" } }))}>Revoke</button>
      </div>
      {out && <pre className="mt-2 max-h-32 overflow-auto whitespace-pre-wrap font-mono text-[11px] text-stone-400">{out}</pre>}
      {msg && <p className="mt-1 text-xs text-signal-green">{msg}</p>}
      {err && <p role="alert" className="mt-1 text-xs text-signal-red">{err}</p>}
    </div>
  );
}

export function StatusBadge({ s }: { s: string }) {
  const tone = s === "healthy" || s === "adapter implemented" ? "green" : s === "authorized" || s === "syncing" ? "blue" : s === "revoked" || s === "unsupported" || s === "degraded" ? "red" : s === "stale" || s === "setup needed" || s === "setup_needed" ? "amber" : "neutral";
  return <Badge tone={tone}>{s.replace("_", " ")}</Badge>;
}
