"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { api, ApiError } from "@/lib/client";
import { Badge, ScopeTag } from "./ui";

export type Mem = { id: string; scope: string; mtype: string; subject: string; assertion: string | null; status: string; confidence: string; source_kind: string; source_ref: string | null; observed_at: string; verified_at: string | null; valid_to: string | null; conflicts_with: string[]; sensitivity: string; version: number; stale: boolean; uses: number };
const TYPES = ["identity", "semantic", "episodic", "working", "procedural", "relationship", "outcome"];

function useAct() {
  const router = useRouter();
  const [err, setErr] = useState<string | null>(null);
  const [, start] = useTransition();
  const act = async (fn: () => Promise<unknown>) => { setErr(null); try { await fn(); start(() => router.refresh()); return true; } catch (e) { setErr((e as ApiError).message); return false; } };
  return { err, act };
}

export function RememberForm({ scopes }: { scopes: { scope: string; label: string }[] }) {
  const { err, act } = useAct();
  const [sensitive, setSensitive] = useState(false);
  return (
    <form className="grid gap-3 sm:grid-cols-2" onSubmit={async (e) => {
      e.preventDefault();
      const f = new FormData(e.currentTarget);
      const ok = await act(() => api("/api/memory", { body: { scope: f.get("scope"), mtype: f.get("mtype"), subject: f.get("subject"), assertion: f.get("assertion"), sensitivity: sensitive ? "sensitive" : "standard", confirmSensitive: f.get("confirm") === "on", supersede: f.get("supersede") === "on", staleAfterDays: f.get("stale") ? Number(f.get("stale")) : null } }));
      if (ok) (e.target as HTMLFormElement).reset();
    }}>
      <label className="text-xs text-stone-400 sm:col-span-2">Remember this<textarea className="input mt-1" name="assertion" rows={2} required placeholder="e.g. I protect Sunday mornings for family — never schedule work then." /></label>
      <label className="text-xs text-stone-400">Subject (topic key)<input className="input mt-1" name="subject" required placeholder="schedule.sunday-mornings" /></label>
      <label className="text-xs text-stone-400">Type<select className="input mt-1" name="mtype" defaultValue="identity">{TYPES.map((t) => <option key={t}>{t}</option>)}</select></label>
      <label className="text-xs text-stone-400">Scope<select className="input mt-1" name="scope" defaultValue="personal">{scopes.map((s) => <option key={s.scope} value={s.scope}>{s.label}</option>)}</select></label>
      <label className="text-xs text-stone-400">Re-verify after (days, optional)<input className="input mt-1" name="stale" type="number" min={1} /></label>
      <label className="flex items-center gap-2 text-xs text-stone-300"><input type="checkbox" name="supersede" /> This changed — replace the current fact on this subject</label>
      <label className="flex items-center gap-2 text-xs text-stone-300"><input type="checkbox" checked={sensitive} onChange={(e) => setSensitive(e.target.checked)} /> Sensitive (health, relationships, finances)</label>
      {sensitive && <label className="flex items-center gap-2 text-xs text-signal-amber sm:col-span-2"><input type="checkbox" name="confirm" required /> I explicitly want this sensitive information stored.</label>}
      <div className="sm:col-span-2"><button className="btn btn-primary">Remember</button></div>
      {err && <p role="alert" className="text-sm text-signal-red sm:col-span-2">{err}</p>}
    </form>
  );
}

export function MemoryItem({ m }: { m: Mem }) {
  const { err, act } = useAct();
  const [editing, setEditing] = useState(false);
  return (
    <li className="rounded-[14px] border border-white/[0.07] bg-black/20 p-3">
      <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
        <Badge tone="champagne">{m.mtype}</Badge><ScopeTag scope={m.scope} />
        <Badge tone={m.confidence === "user_confirmed" || m.confidence === "source_confirmed" ? "green" : "amber"}>{m.confidence.replace("_", " ")}</Badge>
        {m.status !== "active" && <Badge tone={m.status === "staged" ? "blue" : "neutral"}>{m.status}</Badge>}
        {m.stale && <Badge tone="amber">stale — re-verify</Badge>}
        {m.conflicts_with.length > 0 && <Badge tone="red">conflict</Badge>}
        {m.sensitivity === "sensitive" && <Badge tone="red">sensitive</Badge>}
        <span className="text-stone-500">· {m.subject} · observed {m.observed_at.slice(0, 10)} · source {m.source_kind} · used in {m.uses} run{m.uses === 1 ? "" : "s"}</span>
      </div>
      {editing ? (
        <form className="mt-2 flex gap-2" onSubmit={async (e) => { e.preventDefault(); const v = new FormData(e.currentTarget).get("a"); if (await act(() => api(`/api/memory/${m.id}`, { body: { action: "correct", assertion: v, version: m.version } }))) setEditing(false); }}>
          <input className="input flex-1" name="a" defaultValue={m.assertion ?? ""} aria-label="Corrected statement" /><button className="btn btn-primary btn-sm">Save correction</button><button type="button" className="btn btn-ghost btn-sm" onClick={() => setEditing(false)}>Cancel</button>
        </form>
      ) : <p className="mt-1.5 text-sm text-stone-100">{m.assertion ?? <em className="text-stone-500">[forgotten]</em>}</p>}
      <div className="mt-2 flex flex-wrap gap-1.5">
        {m.status === "staged" && <><button className="btn btn-primary btn-sm" onClick={() => act(() => api(`/api/memory/${m.id}`, { body: { action: "accept" } }))}>Confirm</button><button className="btn btn-sm" onClick={() => act(() => api(`/api/memory/${m.id}`, { body: { action: "reject" } }))}>Reject</button></>}
        {m.status === "active" && <button className="btn btn-sm" onClick={() => setEditing(true)}>That&apos;s incorrect / this changed</button>}
        {m.status !== "forgotten" && <button className="btn btn-danger btn-sm" onClick={() => { const ex = confirm("Forget this? OK = also block this source/subject from being re-imported. Cancel = forget only."); act(() => api(`/api/memory/${m.id}`, { body: { action: "forget", tombstoneSource: ex, tombstoneSubject: ex } })); }}>Forget</button>}
      </div>
      {err && <p role="alert" className="mt-1 text-xs text-signal-red">{err}</p>}
    </li>
  );
}
