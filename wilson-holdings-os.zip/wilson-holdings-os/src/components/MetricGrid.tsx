import Link from "next/link";
import { fmtMetric } from "@/lib/format";
import { Badge } from "./ui";

export function MetricGrid({ metrics, slug }: { metrics: { key: string; label: string; value: number | null; unit: string; definition: string; basis?: string; drill?: string }[]; slug: string }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      {metrics.map((m) => (
        <div key={m.key} className="glass rounded-[16px] p-4">
          <div className="flex items-start justify-between gap-2"><p className="text-xs text-stone-400">{m.label}</p>{m.basis && <Badge tone={m.basis === "cash" ? "green" : m.basis === "forecast" ? "amber" : m.basis === "approved" ? "blue" : "neutral"}>{m.basis}</Badge>}</div>
          <p className="display num mt-1 text-[26px] text-stone-50">{fmtMetric(m.value, m.unit)}</p>
          <details className="mt-1 text-[11.5px] text-stone-500"><summary className="cursor-pointer">Definition</summary><p className="mt-1">{m.definition}</p></details>
          {m.drill && <Link className="mt-1 inline-block text-[11.5px] text-signal-blue hover:underline" href={`/companies/${slug}/records/${m.drill.split("?")[0]}${m.drill.includes("?") ? "?" + m.drill.split("?")[1] : ""}`}>Source records →</Link>}
        </div>
      ))}
    </div>
  );
}

export function Freshness({ f }: { f: Record<string, { lastImport: string; file: string } | null> }) {
  return (
    <ul className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-stone-500">
      {Object.entries(f).map(([k, v]) => <li key={k}>{k.replace(/^(ins|con)_/, "")}: {v ? <>{new Date(v.lastImport).toLocaleString("en-US", { timeZone: "America/New_York", dateStyle: "medium", timeStyle: "short" })} <span className="text-stone-600">({v.file})</span></> : <span className="text-signal-amber">no data</span>}</li>)}
    </ul>
  );
}
