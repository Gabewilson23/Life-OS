"use client";
import { useState } from "react";
import { api } from "@/lib/client";
import { useRefreshAction } from "./ActionsClient";

export function MfaSetup({ enabled, available }: { enabled: boolean; available: boolean }) {
  const { err, msg, run } = useRefreshAction();
  const [setup, setSetup] = useState<{ secret: string; uri: string } | null>(null);
  if (!available) return <p className="text-sm text-signal-amber">MFA needs TOKEN_ENCRYPTION_KEY configured on the server.</p>;
  return (
    <div className="space-y-2 text-sm">
      <p className="text-stone-300">Authenticator-app MFA (TOTP) is <strong>{enabled ? "on" : "off"}</strong>.</p>
      {!enabled && !setup && <button className="btn btn-primary btn-sm" onClick={async () => { const r = (await run(() => api<{ secret: string; uri: string }>("/api/auth/mfa", { body: { action: "begin" } }))) as { secret: string; uri: string } | null; if (r) setSetup(r); }}>Set up MFA</button>}
      {setup && (
        <form className="space-y-2" onSubmit={(e) => { e.preventDefault(); const code = new FormData(e.currentTarget).get("code"); run(() => api("/api/auth/mfa", { body: { action: "confirm", code } }), "MFA enabled. Other sessions were signed out."); }}>
          <p className="text-stone-400">Add this key to your authenticator app (or open the otpauth link on your phone), then enter the 6-digit code.</p>
          <code className="block break-all rounded-[10px] bg-black/40 p-2 font-mono text-xs text-stone-100">{setup.secret}</code>
          <a className="text-xs text-signal-blue underline" href={setup.uri}>otpauth link</a>
          <div className="flex gap-2"><input className="input w-36 font-mono" name="code" inputMode="numeric" pattern="[0-9]{6}" maxLength={6} required aria-label="Authenticator code" /><button className="btn btn-primary btn-sm">Confirm</button></div>
        </form>
      )}
      {enabled && <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); const code = new FormData(e.currentTarget).get("code"); run(() => api("/api/auth/mfa", { body: { action: "disable", code } }), "MFA disabled."); }}><input className="input w-36 font-mono" name="code" inputMode="numeric" pattern="[0-9]{6}" maxLength={6} required aria-label="Code to disable" /><button className="btn btn-danger btn-sm">Disable MFA</button></form>}
      {msg && <p className="text-signal-green">{msg}</p>}{err && <p role="alert" className="text-signal-red">{err}</p>}
    </div>
  );
}
