"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/client";
import { useRefreshAction } from "./ActionsClient";

export function ScheduleRow({ s }: { s: { id: string; label: string; enabled: boolean; rule: { freq: string; time: string; weekday?: number; day?: number }; next: string | null; last: string | null } }) {
  const { err, run, pending } = useRefreshAction();
  const [time, setTime] = useState(s.rule.time);
  return (
    <li className="flex flex-wrap items-center justify-between gap-3 rounded-[14px] border border-white/[0.07] bg-black/20 p-3">
      <div><p className="text-sm font-medium text-stone-50">{s.label}</p><p className="text-xs text-stone-500">{s.enabled ? `Next: ${s.next ?? "—"}` : "Disabled (seeded schedules start off)"} · last run {s.last ?? "never"}</p></div>
      <div className="flex items-center gap-2">
        <input className="input w-auto" type="time" value={time} onChange={(e) => setTime(e.target.value)} aria-label={`${s.label} time`} />
        <button className={`btn btn-sm ${s.enabled ? "" : "btn-primary"}`} disabled={pending} onClick={() => run(() => api(`/api/schedules/${s.id}`, { body: { enabled: !s.enabled, time } }))}>{s.enabled ? "Disable" : "Activate"}</button>
        {s.enabled && time !== s.rule.time && <button className="btn btn-sm" onClick={() => run(() => api(`/api/schedules/${s.id}`, { body: { enabled: true, time } }))}>Save time</button>}
      </div>
      {err && <p role="alert" className="w-full text-xs text-signal-red">{err}</p>}
    </li>
  );
}

export function RunReportNow() {
  const router = useRouter();
  const { err, run, pending } = useRefreshAction();
  return (
    <div className="flex flex-wrap gap-2">
      {[["chairman_briefing", "Briefing now"], ["executive_review", "Weekly review now"], ["monthly_owner_report", "Owner report now"]].map(([k, l]) => (
        <button key={k} className="btn btn-sm" disabled={pending} onClick={async () => { const r = (await run(() => api<{ id: string }>("/api/reports/run", { body: { kind: k } }))) as { id: string } | null; if (r) router.push(`/briefings/${r.id}`); }}>{l}</button>
      ))}
      <button className="btn btn-sm" disabled={pending} onClick={async () => { const r = (await run(() => api<{ id: string }>("/api/reports/run", { body: { kind: "company_close", companyId: "co.atlas-insurance" } }))) as { id: string } | null; if (r) router.push(`/briefings/${r.id}`); }}>Insurance close now</button>
      <button className="btn btn-sm" disabled={pending} onClick={async () => { const r = (await run(() => api<{ id: string }>("/api/reports/run", { body: { kind: "company_close", companyId: "co.atlas-consulting" } }))) as { id: string } | null; if (r) router.push(`/briefings/${r.id}`); }}>Consulting close now</button>
      {err && <p role="alert" className="w-full text-xs text-signal-red">{err}</p>}
    </div>
  );
}

export function QuietHours({ q }: { q: { start: string; end: string } }) {
  const { err, msg, run } = useRefreshAction();
  return (
    <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget); run(() => api("/api/settings/quiet-hours", { body: { start: f.get("start"), end: f.get("end") } }), "Saved"); }}>
      <label className="text-xs text-stone-400">Quiet from<input className="input mt-1 w-auto" type="time" name="start" defaultValue={q.start} /></label>
      <label className="text-xs text-stone-400">until<input className="input mt-1 w-auto" type="time" name="end" defaultValue={q.end} /></label>
      <button className="btn btn-sm">Save</button>
      {msg && <span className="text-xs text-signal-green">{msg}</span>}{err && <span className="text-xs text-signal-red">{err}</span>}
    </form>
  );
}

export function NewMeeting({ agents }: { agents: { id: string; title: string; number: number }[] }) {
  const router = useRouter();
  const { err, run, pending } = useRefreshAction();
  const [sel, setSel] = useState<string[]>(["hq.strategy-director"]);
  return (
    <form className="grid gap-3" onSubmit={async (e) => {
      e.preventDefault();
      const f = new FormData(e.currentTarget);
      const r = (await run(() => api<{ meetingId: string }>("/api/meetings", { body: { title: f.get("title"), agenda: f.get("agenda"), participants: sel, maxRounds: Number(f.get("rounds")), scope: f.get("scope") } }))) as { meetingId: string } | null;
      if (r) router.push(`/meetings/${r.meetingId}`);
    }}>
      <input className="input" name="title" required placeholder="Session title" aria-label="Title" />
      <textarea className="input" name="agenda" required rows={3} placeholder="Agenda / question to resolve" aria-label="Agenda" />
      <div className="grid gap-2 sm:grid-cols-2">
        <label className="text-xs text-stone-400">Rounds (max 3)<select className="input mt-1" name="rounds" defaultValue="2"><option>1</option><option>2</option><option>3</option></select></label>
        <label className="text-xs text-stone-400">Scope for actions<select className="input mt-1" name="scope" defaultValue="org"><option value="org">Holding</option><option value="company:atlas-insurance">Atlas Insurance</option><option value="company:atlas-consulting">Atlas Consulting</option></select></label>
      </div>
      <fieldset><legend className="mb-1 text-xs text-stone-400">Participants ({sel.length}/6)</legend>
        <div className="grid max-h-48 gap-1 overflow-y-auto sm:grid-cols-2">{agents.map((a) => <label key={a.id} className="flex items-center gap-2 text-sm text-stone-200"><input type="checkbox" checked={sel.includes(a.id)} disabled={!sel.includes(a.id) && sel.length >= 6} onChange={(e) => setSel(e.target.checked ? [...sel, a.id] : sel.filter((x) => x !== a.id))} />{a.number}. {a.title}</label>)}</div>
      </fieldset>
      <button className="btn btn-primary w-fit" disabled={pending || !sel.length}>{pending ? "Running session…" : "Run AI working session"}</button>
      <p className="text-xs text-stone-500">This calls each selected role for real (bounded rounds), then the Chief of Staff records decisions, dissent and owned actions. It is not a video call.</p>
      {err && <p role="alert" className="text-sm text-signal-red">{err}</p>}
    </form>
  );
}

export function MarkAllRead() {
  const { run } = useRefreshAction();
  return <button className="btn btn-sm" onClick={() => run(() => api("/api/notifications", { body: { all: true } }))}>Mark all read</button>;
}
