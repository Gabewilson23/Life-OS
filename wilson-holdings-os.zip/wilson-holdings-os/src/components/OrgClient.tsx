"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { api, ApiError } from "@/lib/client";

export function AgentPauseButton({ id, status, version, title }: { id: string; status: string; version: number; title: string }) {
  const router = useRouter();
  const [err, setErr] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const paused = status === "paused";
  return (
    <div>
      <button className={`btn ${paused ? "btn-primary" : "btn-danger"}`} disabled={pending}
        onClick={async () => {
          setErr(null);
          try { await api(`/api/agents/${id}/status`, { body: { status: paused ? "idle" : "paused", version } }); }
          catch (e) { setErr((e as ApiError).message); }
          start(() => router.refresh());
        }}>
        {paused ? `Resume ${title}` : "Pause role"}
      </button>
      {err && <p role="alert" className="mt-1 text-xs text-signal-red">{err}</p>}
    </div>
  );
}

export function GlobalPauseToggle({ paused }: { paused: boolean }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [err, setErr] = useState<string | null>(null);
  return (
    <div className="flex flex-wrap items-center gap-3">
      <button className={`btn ${paused ? "btn-primary" : "btn-danger"}`} disabled={pending} onClick={async () => {
        if (!paused && !confirm("Engage global pause? All agent runs and external writes will stop until released.")) return;
        try { await api("/api/system/pause", { body: { paused: !paused } }); } catch (e) { setErr((e as ApiError).message); }
        start(() => router.refresh());
      }}>{paused ? "Release global pause" : "Engage global pause"}</button>
      <span className="text-sm text-stone-400">{paused ? "Paused: nothing executes." : "Running normally."}</span>
      {err && <p role="alert" className="text-xs text-signal-red">{err}</p>}
    </div>
  );
}

const WORKFLOWS = [
  ["project", "Fixed-scope projects"], ["retainer", "Retainers"], ["placement", "Placements"], ["time_and_materials", "Time and materials"],
] as const;

export function ConsultingModelForm({ current }: { current: { businessModel: string | null; enabledWorkflows: string[] } }) {
  const router = useRouter();
  const [err, setErr] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  return (
    <form className="space-y-4" onSubmit={async (e) => {
      e.preventDefault();
      const f = new FormData(e.currentTarget);
      setErr(null); setSaved(false);
      try {
        await api("/api/onboarding/consulting", { body: { businessModel: f.get("businessModel"), enabledWorkflows: f.getAll("wf") } });
        setSaved(true); router.refresh();
      } catch (x) { setErr((x as ApiError).message); }
    }}>
      <label className="block text-sm"><span className="mb-1.5 block text-stone-300">In your words, what does Atlas Consulting do?</span>
        <textarea className="input" name="businessModel" rows={3} required maxLength={1000} defaultValue={current.businessModel ?? ""} placeholder="Describe the contracting business — who the clients are, what is delivered, and how it is billed." /></label>
      <fieldset>
        <legend className="mb-2 text-sm text-stone-300">Which workflows apply? Only these will be activated.</legend>
        <div className="grid gap-2 sm:grid-cols-2">
          {WORKFLOWS.map(([k, l]) => (
            <label key={k} className="flex items-center gap-2 rounded-[var(--radius-md)] border border-white/[0.06] bg-black/20 px-3 py-2 text-sm text-stone-200">
              <input type="checkbox" name="wf" value={k} defaultChecked={current.enabledWorkflows.includes(k)} className="accent-[#d9c39a]" />{l}
            </label>
          ))}
        </div>
      </fieldset>
      <button className="btn btn-primary">Confirm contracting model</button>
      {saved && <p role="status" className="text-sm text-signal-green">Saved and recorded in the audit trail.</p>}
      {err && <p role="alert" className="text-sm text-signal-red">{err}</p>}
    </form>
  );
}
