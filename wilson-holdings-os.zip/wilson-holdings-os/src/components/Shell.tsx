"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { api } from "@/lib/client";
import { cx } from "./ui";
import { Icon } from "./icons";
import { NAV, isActive } from "./nav";

export function Shell({ user, demo, paused, children }: { user: { displayName: string; role: string }; demo: boolean; paused: boolean; children: React.ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const [palette, setPalette] = useState(false);
  const isCampus = path.startsWith("/campus");

  useEffect(() => {
    let g = false;
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      const typing = t.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(t.tagName);
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setPalette((v) => !v); return; }
      if (typing) return;
      if (e.key === "/") { e.preventDefault(); setPalette(true); return; }
      if (g) { const n = NAV.find((x) => x.key && x.key === e.key.toLowerCase()); if (n) router.push(n.href); g = false; return; }
      if (e.key.toLowerCase() === "g") { g = true; setTimeout(() => (g = false), 900); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [router]);

  const current = NAV.find((n) => isActive(path, n.href));
  const groups = ["Run", "Companies", "Work", "System"] as const;
  return (
    <div className="min-h-screen">
      {/* Menu bar */}
      <header className="sticky top-0 z-40 flex h-11 items-center gap-3 border-b border-white/[0.07] bg-black/35 px-3 backdrop-blur-2xl sm:px-4">
        <Link href="/" className="flex items-center gap-2">
          <span aria-hidden className="grid h-6 w-6 place-items-center rounded-[7px] bg-gradient-to-b from-champagne-400 to-champagne-600 text-[12px] font-bold text-white shadow-[inset_0_1px_0_rgb(255_255_255/0.5)]">W</span>
          <span className="text-[13px] font-semibold text-stone-50">Wilson Holdings</span>
        </Link>
        <span className="hidden text-[13px] text-stone-400 sm:inline">{current?.label ?? ""}</span>
        <button onClick={() => setPalette(true)} className="ml-auto flex h-7 w-full max-w-[340px] items-center gap-2 rounded-[8px] border border-white/10 bg-white/[0.06] px-2.5 text-left text-[12.5px] text-stone-400 hover:text-stone-200" aria-label="Open command palette">
          <Icon name="search" size={14} /><span className="truncate">Search or jump to…</span><kbd className="ml-auto hidden font-mono text-[10.5px] sm:inline">⌘K</kbd>
        </button>
        <div role="group" aria-label="Interface mode" className="hidden rounded-[8px] border border-white/10 bg-white/[0.05] p-0.5 text-[12px] sm:flex">
          <Link href="/" aria-pressed={!isCampus} className={cx("rounded-[6px] px-2.5 py-1", !isCampus ? "bg-white/15 text-white" : "text-stone-400")}>Focus</Link>
          <Link href="/campus" aria-pressed={isCampus} className={cx("rounded-[6px] px-2.5 py-1", isCampus ? "bg-white/15 text-white" : "text-stone-400")}>Campus</Link>
        </div>
        <Bell />
        <Clock />
        <button className="hidden text-[12.5px] text-stone-300 hover:text-white md:inline" title="Sign out" onClick={async () => { await api("/api/auth/logout", { method: "POST", body: {} }); router.replace("/login"); router.refresh(); }}>{user.displayName} ⏏</button>
      </header>
      {demo && <div role="status" className="bg-fuchsia-500/25 px-4 py-1 text-center text-xs font-semibold tracking-wide text-fuchsia-50">DEMO MODE — separate database; nothing here reaches real providers</div>}
      {paused && <div role="status" className="bg-signal-amber/20 px-4 py-1 text-center text-xs font-semibold text-signal-amber">Global pause engaged — no agent runs or external writes will execute. <Link className="underline" href="/settings">Manage</Link></div>}

      <div className="lg:grid lg:grid-cols-[252px_1fr]">
        {/* Floating glass sidebar */}
        <aside aria-label="Primary" className="hidden lg:block">
          <div className="glass sticky top-[56px] m-3 mr-0 flex h-[calc(100vh-68px)] flex-col overflow-hidden rounded-[20px]">
            <nav className="flex-1 overflow-y-auto px-2.5 py-3">
              {groups.map((g) => (
                <div key={g} className="mb-3">
                  <p className="px-2.5 pb-1 text-[10.5px] font-semibold uppercase tracking-[0.12em] text-stone-500">{g}</p>
                  <ul className="space-y-0.5">
                    {NAV.filter((n) => n.group === g).map((n) => {
                      const active = isActive(path, n.href);
                      return (
                        <li key={n.href}>
                          <Link href={n.href} aria-current={active ? "page" : undefined}
                            className={cx("flex items-center gap-2.5 rounded-[10px] px-2.5 py-[7px] text-[13px] transition-colors",
                              active ? "bg-gradient-to-b from-azure-500/90 to-azure-700/90 text-white shadow-[inset_0_1px_0_rgb(255_255_255/0.35),0_6px_16px_-8px_rgb(47_124_246/0.8)]" : "text-stone-300 hover:bg-white/[0.07] hover:text-white")}>
                            <Icon name={n.icon} size={16} className={active ? "text-white" : "text-champagne-400"} />
                            <span className="flex-1">{n.label}</span>
                            {n.key && <kbd className={cx("font-mono text-[9.5px]", active ? "text-white/70" : "text-stone-600")}>g {n.key}</kbd>}
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              ))}
            </nav>
            <div className="border-t border-white/[0.07] px-4 py-3 text-xs">
              <p className="text-stone-100">{user.displayName}</p>
              <p className="capitalize text-stone-500">{user.role}</p>
            </div>
          </div>
        </aside>

        <div className="min-w-0">
          <nav aria-label="Primary (mobile)" className="flex gap-1 overflow-x-auto border-b border-white/[0.07] bg-black/20 px-3 py-2 backdrop-blur-xl lg:hidden">
            {NAV.map((n) => (
              <Link key={n.href} href={n.href} className={cx("flex items-center gap-1.5 whitespace-nowrap rounded-lg px-3 py-1.5 text-[13px]", isActive(path, n.href) ? "bg-azure-500 text-white" : "text-stone-300")}><Icon name={n.icon} size={14} />{n.label}</Link>
            ))}
          </nav>
          <main id="main" className={cx(isCampus ? "" : "mx-auto max-w-[1280px] px-4 pb-32 pt-6 sm:px-6 lg:px-8")}>{children}</main>
        </div>
      </div>

      {/* Dock */}
      {!isCampus && (
        <nav aria-label="Dock" className="pointer-events-none fixed inset-x-0 bottom-3 z-30 hidden justify-center lg:flex">
          <ul className="glass pointer-events-auto flex items-end gap-1.5 rounded-[22px] px-2.5 py-2">
            {NAV.filter((n) => n.dock).map((n) => {
              const active = isActive(path, n.href);
              return (
                <li key={n.href} className="relative">
                  <Link href={n.href} aria-label={n.label} title={n.label}
                    className={cx("group grid h-11 w-11 place-items-center rounded-[13px] border border-white/15 transition-transform duration-150 hover:-translate-y-1 motion-reduce:hover:translate-y-0",
                      n.group === "Companies" ? "bg-gradient-to-b from-azure-500 to-azure-700" : n.group === "System" ? "bg-gradient-to-b from-stone-100 to-stone-400 text-graphite-900" : n.group === "Work" ? "bg-gradient-to-b from-champagne-400 to-champagne-600" : "bg-gradient-to-b from-graphite-600 to-graphite-900",
                      "shadow-[inset_0_1px_0_rgb(255_255_255/0.45),0_8px_16px_-8px_rgb(0_0_0/0.9)]")}>
                    <Icon name={n.icon} size={20} className={n.group === "System" ? "text-graphite-900" : "text-white"} />
                  </Link>
                  {active && <span aria-hidden className="absolute -bottom-1.5 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-white" />}
                </li>
              );
            })}
          </ul>
        </nav>
      )}
      {palette && <CommandPalette onClose={() => setPalette(false)} />}
    </div>
  );
}

function Bell() {
  const [n, setN] = useState(0);
  const path = usePathname();
  useEffect(() => { fetch("/api/notifications").then((r) => (r.ok ? r.json() : { unread: 0 })).then((j) => setN(j.unread ?? 0)).catch(() => {}); }, [path]);
  return (
    <Link href="/notifications" aria-label={`Notifications${n ? `, ${n} unread` : ""}`} className="relative grid h-7 w-7 place-items-center rounded-[8px] text-stone-300 hover:bg-white/10 hover:text-white">
      <svg aria-hidden width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M6 16V11a6 6 0 1 1 12 0v5l2 2H4zM10 20a2 2 0 0 0 4 0" /></svg>
      {n > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-azure-500 px-1 text-[9.5px] font-bold text-white">{n > 9 ? "9+" : n}</span>}
    </Link>
  );
}

function Clock() {
  const [now, setNow] = useState<string>("");
  useEffect(() => {
    const f = () => setNow(new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", weekday: "short", hour: "numeric", minute: "2-digit" }).format(new Date()));
    f();
    const t = setInterval(f, 30_000);
    return () => clearInterval(t);
  }, []);
  return <span className="hidden whitespace-nowrap text-[12.5px] tabular-nums text-stone-300 md:inline" suppressHydrationWarning>{now}</span>;
}

type Result = { kind: string; label: string; href: string };

function CommandPalette({ onClose }: { onClose: () => void }) {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Result[]>([]);
  const [sel, setSel] = useState(0);
  const input = useRef<HTMLInputElement>(null);
  const navResults: Result[] = NAV.map((n) => ({ kind: "Go to", label: n.label, href: n.href }));
  const shown = q ? [...navResults.filter((n) => n.label.toLowerCase().includes(q.toLowerCase())), ...results] : navResults;

  useEffect(() => { input.current?.focus(); }, []);
  useEffect(() => {
    if (!q) { setResults([]); return; }
    const ac = new AbortController();
    const t = setTimeout(async () => {
      try {
        const r = await fetch(`/api/search?q=${encodeURIComponent(q)}`, { signal: ac.signal });
        if (r.ok) setResults((await r.json()).results);
      } catch { /* aborted */ }
    }, 120);
    return () => { clearTimeout(t); ac.abort(); };
  }, [q]);
  useEffect(() => setSel(0), [q, results.length]);

  const go = (r?: Result) => { if (!r) return; onClose(); router.push(r.href); };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/55 px-4 pt-[12vh] backdrop-blur-sm" onMouseDown={onClose}>
      <div role="dialog" aria-modal="true" aria-label="Command palette" className="glass w-full max-w-xl overflow-hidden rounded-[var(--radius-xl)]" onMouseDown={(e) => e.stopPropagation()}>
        <input ref={input} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Type a command or search…" aria-label="Search" role="combobox" aria-expanded aria-controls="palette-list" aria-activedescendant={shown[sel] ? `pr-${sel}` : undefined}
          className="w-full border-b border-white/[0.07] bg-transparent px-5 py-4 text-[15px] text-stone-50 outline-none placeholder:text-stone-500"
          onKeyDown={(e) => {
            if (e.key === "Escape") onClose();
            else if (e.key === "ArrowDown") { e.preventDefault(); setSel((s) => Math.min(s + 1, shown.length - 1)); }
            else if (e.key === "ArrowUp") { e.preventDefault(); setSel((s) => Math.max(s - 1, 0)); }
            else if (e.key === "Enter") go(shown[sel]);
          }} />
        <ul id="palette-list" role="listbox" className="max-h-[50vh] overflow-y-auto p-2">
          {shown.length === 0 && <li className="px-3 py-6 text-center text-sm text-stone-500">No matches in your permitted scopes.</li>}
          {shown.map((r, i) => (
            <li key={r.kind + r.href + i} id={`pr-${i}`} role="option" aria-selected={i === sel} onMouseEnter={() => setSel(i)} onClick={() => go(r)}
              className={cx("flex cursor-pointer items-center justify-between rounded-[10px] px-3 py-2 text-sm", i === sel ? "bg-azure-500 text-white" : "text-stone-300")}>
              <span>{r.label}</span><span className="text-[11px] text-stone-500">{r.kind}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
