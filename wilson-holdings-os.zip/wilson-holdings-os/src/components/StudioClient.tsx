"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/client";
import { useRefreshAction } from "./ActionsClient";
import { Badge } from "./ui";

export function NewFromTemplate({ scopes }: { scopes: { scope: string; label: string }[] }) {
  const router = useRouter();
  const { err, run, pending } = useRefreshAction();
  const [scope, setScope] = useState(scopes.find((s) => s.scope === "company:atlas-consulting")?.scope ?? scopes[0]?.scope ?? "org");
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-end gap-2">
        <label className="text-xs text-stone-400">Company<select className="input mt-1 w-auto" value={scope} onChange={(e) => setScope(e.target.value)}>{scopes.map((s) => <option key={s.scope} value={s.scope}>{s.label}</option>)}</select></label>
        <button className="btn btn-primary" disabled={pending} onClick={async () => { const r = (await run(() => api<{ id: string }>("/api/studio", { body: { mode: "template", template: "contractor_intake", scope } }))) as { id: string } | null; if (r) router.push(`/studio/${r.id}`); }}>Contractor intake form + workflow</button>
        <a className="btn" href="/chat?agent=eng.forms-automation-builder">Describe it in plain language →</a>
      </div>
      <p className="text-xs text-stone-500">Creates editable drafts: a multi-step form, and a workflow that saves to the contractor directory, assigns a review task to the Project Delivery Manager, and prepares a confirmation email draft. Nothing goes live until you test and activate it.</p>
      {err && <p role="alert" className="text-sm text-signal-red">{err}</p>}
    </div>
  );
}

type Field = { key: string; label: string; type: string; required?: boolean; options?: string[]; step?: number; help?: string; visibleWhen?: { field: string; equals: string | boolean } };
const TYPES = ["text", "email", "phone", "textarea", "number", "date", "select", "checkbox"];

export function CapabilityEditor({ id, kind, status, access, currentVersion, versions, slug }: { id: string; kind: string; status: string; access: string; currentVersion: number; slug: string; versions: { version: number; definition: Record<string, unknown>; definition_hash: string; test_status: string }[] }) {
  const { err, msg, run, pending } = useRefreshAction();
  const latest = versions[versions.length - 1]!;
  const [def, setDef] = useState<Record<string, unknown>>(latest.definition);
  const [raw, setRaw] = useState(JSON.stringify(latest.definition, null, 2));
  const [mode, setMode] = useState<"visual" | "json">(kind === "form" ? "visual" : "json");
  const [sample, setSample] = useState('{"full_name":"Test Person","email":"test@example.test","trade":"Electrical","rate_expectation":"60"}');
  const fields = (def.fields as Field[] | undefined) ?? [];
  const setFields = (f: Field[]) => { const d = { ...def, fields: f }; setDef(d); setRaw(JSON.stringify(d, null, 2)); };
  const current = mode === "json" ? (() => { try { return JSON.parse(raw); } catch { return null; } })() : def;
  const dirty = JSON.stringify(current) !== JSON.stringify(latest.definition);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone={status === "active" ? "green" : status === "paused" ? "amber" : "neutral"}>{status}</Badge><Badge tone={access === "public" ? "red" : "neutral"}>{access}</Badge><Badge>live v{currentVersion}</Badge><Badge>latest v{latest.version} · test {latest.test_status}</Badge>
        {kind === "form" && status === "active" && access === "public" && <a className="btn btn-sm" href={`/f/${slug}`} target="_blank">Open public form ↗</a>}
      </div>
      {kind === "form" && (
        <div role="group" aria-label="Editor mode" className="glass-subtle inline-flex rounded-[10px] p-0.5 text-sm">{(["visual", "json"] as const).map((m) => <button key={m} aria-pressed={mode === m} onClick={() => { if (m === "visual") { try { setDef(JSON.parse(raw)); } catch { return; } } setMode(m); }} className={`rounded-[8px] px-3 py-1 ${mode === m ? "bg-azure-500 text-white" : "text-stone-300"}`}>{m === "visual" ? "Visual editor" : "Definition (JSON)"}</button>)}</div>
      )}
      {mode === "visual" && kind === "form" ? (
        <div className="space-y-2">
          <div className="grid gap-2 sm:grid-cols-2"><label className="text-xs text-stone-400">Title<input className="input mt-1" value={String(def.title ?? "")} onChange={(e) => { const d = { ...def, title: e.target.value }; setDef(d); setRaw(JSON.stringify(d, null, 2)); }} /></label>
            <label className="text-xs text-stone-400">Consent text<input className="input mt-1" value={String(def.consentText ?? "")} onChange={(e) => { const d = { ...def, consentText: e.target.value || undefined }; setDef(d); setRaw(JSON.stringify(d, null, 2)); }} /></label></div>
          <ul className="space-y-2">{fields.map((f, i) => (
            <li key={i} className="grid items-end gap-2 rounded-[12px] border border-white/[0.07] bg-black/20 p-2 sm:grid-cols-[1fr_1fr_120px_70px_70px_auto]">
              <label className="text-[11px] text-stone-500">Key<input className="input mt-0.5" value={f.key} onChange={(e) => setFields(fields.map((x, j) => (j === i ? { ...x, key: e.target.value } : x)))} /></label>
              <label className="text-[11px] text-stone-500">Label<input className="input mt-0.5" value={f.label} onChange={(e) => setFields(fields.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)))} /></label>
              <label className="text-[11px] text-stone-500">Type<select className="input mt-0.5" value={f.type} onChange={(e) => setFields(fields.map((x, j) => (j === i ? { ...x, type: e.target.value } : x)))}>{TYPES.map((t) => <option key={t}>{t}</option>)}</select></label>
              <label className="text-[11px] text-stone-500">Step<input className="input mt-0.5" type="number" min={0} max={9} value={f.step ?? 0} onChange={(e) => setFields(fields.map((x, j) => (j === i ? { ...x, step: Number(e.target.value) } : x)))} /></label>
              <label className="flex items-center gap-1 text-[11px] text-stone-400"><input type="checkbox" checked={!!f.required} onChange={(e) => setFields(fields.map((x, j) => (j === i ? { ...x, required: e.target.checked } : x)))} />req.</label>
              <div className="flex gap-1"><button className="btn btn-ghost btn-sm" aria-label="Move up" disabled={i === 0} onClick={() => { const c = [...fields]; [c[i - 1], c[i]] = [c[i]!, c[i - 1]!]; setFields(c); }}>↑</button><button className="btn btn-ghost btn-sm" aria-label="Remove field" onClick={() => setFields(fields.filter((_, j) => j !== i))}>✕</button></div>
            </li>))}</ul>
          <button className="btn btn-sm" onClick={() => setFields([...fields, { key: `field_${fields.length + 1}`, label: "New field", type: "text", step: 0 }])}>+ Add field</button>
        </div>
      ) : <textarea className="input font-mono text-[12px]" rows={18} value={raw} onChange={(e) => setRaw(e.target.value)} aria-label="Definition JSON" />}
      <div className="flex flex-wrap gap-2">
        <button className="btn btn-primary" disabled={!dirty || !current || pending} onClick={() => run(() => api(`/api/studio/${id}`, { body: { action: "version", definition: current } }), "Saved as a new version (not live until activated)")}>Save new version</button>
        {kind === "workflow" && <><input className="input max-w-md font-mono text-xs" value={sample} onChange={(e) => setSample(e.target.value)} aria-label="Sample input JSON" /><button className="btn" onClick={() => run(() => api(`/api/studio/${id}`, { body: { action: "test", version: latest.version, sample: JSON.parse(sample) } }), "Test run finished — see the result below")}>Test v{latest.version} with sample</button></>}
        <button className="btn" disabled={pending} onClick={() => run(() => api(`/api/studio/${id}`, { body: { action: "activate", version: latest.version, access: "private" } }), `v${latest.version} activated`)}>Activate v{latest.version}{kind === "form" ? " (private)" : ""}</button>
        {kind === "form" && <button className="btn btn-danger" onClick={() => { if (confirm(`Publish v${latest.version} publicly? Anyone with the link can submit. Downstream workflows will create records/tasks and prepare drafts.`)) run(() => api(`/api/studio/${id}`, { body: { action: "activate", version: latest.version, access: "public", confirmHash: latest.definition_hash } }), "Published"); }}>Publish v{latest.version} publicly…</button>}
        {status === "active" ? <button className="btn" onClick={() => run(() => api(`/api/studio/${id}`, { body: { action: "pause" } }))}>Pause</button> : status === "paused" ? <button className="btn" onClick={() => run(() => api(`/api/studio/${id}`, { body: { action: "resume" } }))}>Resume</button> : null}
        {versions.length > 1 && <select className="input w-auto" defaultValue="" onChange={(e) => e.target.value && run(() => api(`/api/studio/${id}`, { body: { action: "rollback", version: Number(e.target.value) } }), "Rolled back")} aria-label="Roll back to version"><option value="">Roll back to…</option>{versions.filter((v) => v.version !== currentVersion).map((v) => <option key={v.version} value={v.version}>v{v.version}</option>)}</select>}
      </div>
      {msg && <p role="status" className="text-sm text-signal-green">{msg}</p>}
      {err && <p role="alert" className="text-sm text-signal-red">{err}</p>}
    </div>
  );
}

export function ChangeRequestForm() {
  const { err, msg, run } = useRefreshAction();
  return (
    <form className="grid gap-2" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget); run(() => api("/api/changes", { body: { title: f.get("title"), request: f.get("request") } }), "Change request created with a draft spec"); }}>
      <input className="input" name="title" required minLength={3} placeholder="New capability (e.g. Commission variance report)" />
      <textarea className="input" name="request" required minLength={10} rows={3} placeholder="Describe what it should do, for whom, and what 'done' looks like." />
      <button className="btn w-fit">Create change request</button>
      {msg && <p className="text-sm text-signal-green">{msg}</p>}{err && <p role="alert" className="text-sm text-signal-red">{err}</p>}
    </form>
  );
}

export function ChangeActions({ id, status, hash }: { id: string; status: string; hash: string | null }) {
  const { err, run, pending } = useRefreshAction();
  return (
    <div className="flex flex-wrap gap-1.5">
      {["spec", "blocked"].includes(status) && <button className="btn btn-sm" disabled={pending} onClick={() => run(() => api(`/api/changes/${id}`, { body: { action: "start" } }))}>Create isolated branch & PR</button>}
      {["in_development", "preview_ready", "qa_failed", "qa_passed"].includes(status) && <button className="btn btn-sm" onClick={() => run(() => api(`/api/changes/${id}`, { body: { action: "refresh" } }))}>Refresh checks</button>}
      {status === "qa_passed" && <button className="btn btn-sm" onClick={() => run(() => api(`/api/changes/${id}`, { body: { action: "request_release" } }))}>Request release approval</button>}
      {status === "awaiting_release_approval" && hash && <button className="btn btn-danger btn-sm" onClick={() => confirm("Release this exact commit to production? Merging triggers the deploy.") && run(() => api(`/api/changes/${id}`, { body: { action: "approve_release", hash } }))}>Approve release (bound to commit)</button>}
      {err && <p role="alert" className="w-full text-xs text-signal-red">{err}</p>}
    </div>
  );
}
