"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { api, ApiError } from "@/lib/client";
import { Badge, cx, ScopeTag } from "./ui";

export type ScopeOption = { scope: string; label: string };
type Goal = { id: string; title: string; description: string; horizon: string; status: string; scope: string; periodStart: string | null; periodEnd: string | null; targetMetric: string | null; targetValue: number | null; currentValue: number | null; progressNote: string; version: number; openTasks?: number };
type Task = { id: string; title: string; notes: string; status: string; priority: number; dueDate: string | null; scope: string; goalId: string | null; goalTitle: string | null; blockedReason: string | null; version: number };

function useMutate() {
  const router = useRouter();
  const [err, setErr] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const run = async (fn: () => Promise<unknown>) => {
    setErr(null);
    try { await fn(); start(() => router.refresh()); return true; }
    catch (e) { const x = e as ApiError; setErr(x.status === 409 ? "Someone (or another tab) changed this first. Reloaded the latest version — please re-apply your edit." : x.message); start(() => router.refresh()); return false; }
  };
  return { err, pending, run, setErr };
}

// ── Today's three outcomes ──
export function OutcomesEditor({ date, outcomes }: { date: string; outcomes: { position: number; title: string; done: boolean; version: number }[] }) {
  const { err, run } = useMutate();
  return (
    <div>
      <ol className="space-y-2.5">
        {outcomes.map((o) => <OutcomeRow key={`${date}-${o.position}-${o.version}`} date={date} o={o} run={run} />)}
      </ol>
      {err && <p role="alert" className="mt-2 text-xs text-signal-red">{err}</p>}
    </div>
  );
}

function OutcomeRow({ date, o, run }: { date: string; o: { position: number; title: string; done: boolean; version: number }; run: (fn: () => Promise<unknown>) => Promise<boolean> }) {
  const [title, setTitle] = useState(o.title);
  const save = (patch: { title?: string; done?: boolean }) =>
    run(() => api("/api/outcomes", { method: "PUT", body: { localDate: date, position: o.position, title: patch.title ?? title, done: patch.done ?? o.done, version: o.version } }));
  return (
    <li className={cx("group flex items-center gap-3 rounded-[var(--radius-md)] border border-white/[0.06] bg-black/20 px-3 py-2.5", o.done && "opacity-70")}>
      <span aria-hidden className="display w-5 text-center text-lg text-champagne-400">{o.position}</span>
      <input aria-label={`Outcome ${o.position}`} value={title} placeholder={o.position === 1 ? "The one result that would make today a win" : "Another outcome for today"}
        onChange={(e) => setTitle(e.target.value)} onBlur={() => title !== o.title && save({ title })} onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()}
        className={cx("min-w-0 flex-1 bg-transparent text-[15px] text-stone-50 outline-none placeholder:text-stone-600", o.done && "line-through")} />
      <button className="btn btn-sm" disabled={!title.trim()} aria-pressed={o.done} onClick={() => save({ done: !o.done })}>{o.done ? "Done ✓" : "Mark done"}</button>
    </li>
  );
}

// ── Tasks ──
const STATUS = ["open", "in_progress", "waiting", "blocked", "done", "cancelled"] as const;
const STATUS_LABEL: Record<string, string> = { open: "Open", in_progress: "In progress", waiting: "Waiting", blocked: "Blocked", done: "Done", cancelled: "Cancelled" };
const PRIORITY = ["Critical", "High", "Normal", "Low"];

export function QuickAddTask({ scopes, goals, defaultScope = "org", goalId }: { scopes: ScopeOption[]; goals?: { id: string; title: string }[]; defaultScope?: string; goalId?: string }) {
  const { err, run, pending } = useMutate();
  const [title, setTitle] = useState("");
  return (
    <form className="flex flex-wrap items-center gap-2" onSubmit={async (e) => {
      e.preventDefault();
      const f = new FormData(e.currentTarget);
      const ok = await run(() => api("/api/tasks", { body: { title, scope: f.get("scope"), priority: Number(f.get("priority")), dueDate: (f.get("dueDate") as string) || null, goalId: goalId ?? ((f.get("goalId") as string) || null) } }));
      if (ok) setTitle("");
    }}>
      <input className="input min-w-[200px] flex-[3]" aria-label="New task" placeholder="Add a task…" value={title} onChange={(e) => setTitle(e.target.value)} required maxLength={300} />
      <select className="input w-auto flex-1" name="scope" aria-label="Scope" defaultValue={defaultScope}>{scopes.map((s) => <option key={s.scope} value={s.scope}>{s.label}</option>)}</select>
      <select className="input w-auto" name="priority" aria-label="Priority" defaultValue="2">{PRIORITY.map((p, i) => <option key={p} value={i}>{p}</option>)}</select>
      <input className="input w-auto" type="date" name="dueDate" aria-label="Due date" />
      {goals && !goalId && <select className="input w-auto flex-1" name="goalId" aria-label="Goal" defaultValue=""><option value="">No goal</option>{goals.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}</select>}
      <button className="btn btn-primary" disabled={pending || !title.trim()}>Add</button>
      {err && <p role="alert" className="w-full text-xs text-signal-red">{err}</p>}
    </form>
  );
}

export function TaskList({ tasks, today, compact, emptyText = "Nothing open." }: { tasks: Task[]; today: string; compact?: boolean; emptyText?: string }) {
  const { err, run } = useMutate();
  const [editing, setEditing] = useState<string | null>(null);
  if (!tasks.length) return <p className="text-sm text-stone-500">{emptyText}</p>;
  return (
    <>
      {err && <p role="alert" className="mb-2 text-xs text-signal-red">{err}</p>}
      <ul className="divide-y divide-white/[0.05]">
        {tasks.map((t) => {
          const overdue = t.dueDate && t.dueDate < today && !["done", "cancelled"].includes(t.status);
          return (
            <li key={t.id} id={t.id} className="py-2.5">
              <div className="flex items-start gap-3">
                <input type="checkbox" className="mt-1 h-4 w-4 accent-[#d9c39a]" aria-label={`Complete ${t.title}`} checked={t.status === "done"}
                  onChange={(e) => run(() => api(`/api/tasks/${t.id}`, { method: "PATCH", body: { status: e.target.checked ? "done" : "open", version: t.version } }))} />
                <div className="min-w-0 flex-1">
                  <button className={cx("text-left text-[14px] hover:text-champagne-200", t.status === "done" ? "text-stone-500 line-through" : "text-stone-100")} onClick={() => setEditing(editing === t.id ? null : t.id)} aria-expanded={editing === t.id}>{t.title}</button>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-stone-500">
                    {t.priority <= 1 && <Badge tone={t.priority === 0 ? "red" : "amber"}>{PRIORITY[t.priority]}</Badge>}
                    {t.status !== "open" && t.status !== "done" && <Badge tone={t.status === "blocked" ? "red" : "neutral"}>{STATUS_LABEL[t.status]}</Badge>}
                    {!compact && <ScopeTag scope={t.scope} />}
                    {t.dueDate && <span className={overdue ? "text-signal-red" : ""}>Due {t.dueDate}{overdue ? " · overdue" : ""}</span>}
                    {t.goalTitle && <span>→ {t.goalTitle}</span>}
                    {t.blockedReason && <span className="text-signal-red">Blocked: {t.blockedReason}</span>}
                  </div>
                </div>
              </div>
              {editing === t.id && <TaskEditor t={t} onDone={() => setEditing(null)} run={run} />}
            </li>
          );
        })}
      </ul>
    </>
  );
}

function TaskEditor({ t, onDone, run }: { t: Task; onDone: () => void; run: (fn: () => Promise<unknown>) => Promise<boolean> }) {
  return (
    <form className="mt-3 grid gap-2 rounded-[var(--radius-md)] border border-white/[0.06] bg-black/20 p-3 sm:grid-cols-2" onSubmit={async (e) => {
      e.preventDefault();
      const f = new FormData(e.currentTarget);
      const ok = await run(() => api(`/api/tasks/${t.id}`, { method: "PATCH", body: { version: t.version, title: f.get("title"), notes: f.get("notes"), status: f.get("status"), priority: Number(f.get("priority")), dueDate: (f.get("dueDate") as string) || null, blockedReason: (f.get("blockedReason") as string) || null } }));
      if (ok) onDone();
    }}>
      <label className="text-xs text-stone-400 sm:col-span-2">Title<input className="input mt-1" name="title" defaultValue={t.title} required maxLength={300} /></label>
      <label className="text-xs text-stone-400">Status<select className="input mt-1" name="status" defaultValue={t.status}>{STATUS.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}</select></label>
      <label className="text-xs text-stone-400">Priority<select className="input mt-1" name="priority" defaultValue={t.priority}>{PRIORITY.map((p, i) => <option key={p} value={i}>{p}</option>)}</select></label>
      <label className="text-xs text-stone-400">Due<input className="input mt-1" type="date" name="dueDate" defaultValue={t.dueDate ?? ""} /></label>
      <label className="text-xs text-stone-400">Blocked reason<input className="input mt-1" name="blockedReason" defaultValue={t.blockedReason ?? ""} /></label>
      <label className="text-xs text-stone-400 sm:col-span-2">Notes<textarea className="input mt-1" rows={3} name="notes" defaultValue={t.notes} /></label>
      <div className="flex gap-2 sm:col-span-2">
        <button className="btn btn-primary btn-sm">Save</button>
        <button type="button" className="btn btn-ghost btn-sm" onClick={onDone}>Cancel</button>
        <button type="button" className="btn btn-danger btn-sm ml-auto" onClick={async () => { if (confirm(`Delete "${t.title}"?`)) { await run(() => api(`/api/tasks/${t.id}`, { method: "DELETE", body: { version: t.version } })); } }}>Delete</button>
      </div>
    </form>
  );
}

// ── Goals ──
const HORIZONS = ["annual", "quarterly", "monthly", "weekly"] as const;
const GSTATUS = ["active", "paused", "achieved", "dropped"] as const;

export function GoalForm({ scopes, goal, onDone }: { scopes: ScopeOption[]; goal?: Goal; onDone?: () => void }) {
  const { err, run, pending } = useMutate();
  return (
    <form className="grid gap-3 sm:grid-cols-2" onSubmit={async (e) => {
      e.preventDefault();
      const f = new FormData(e.currentTarget);
      const num = (k: string) => (f.get(k) === "" || f.get(k) == null ? null : Number(f.get(k)));
      const body = {
        title: f.get("title"), description: f.get("description") ?? "", horizon: f.get("horizon"), status: f.get("status") ?? "active", scope: f.get("scope"),
        periodStart: (f.get("periodStart") as string) || null, periodEnd: (f.get("periodEnd") as string) || null,
        targetMetric: (f.get("targetMetric") as string) || null, targetValue: num("targetValue"), currentValue: num("currentValue"), progressNote: f.get("progressNote") ?? "",
      };
      const ok = await run(() => goal ? api(`/api/goals/${goal.id}`, { method: "PATCH", body: { ...body, version: goal.version } }) : api("/api/goals", { body }));
      if (ok) { if (!goal) (e.target as HTMLFormElement).reset(); onDone?.(); }
    }}>
      <label className="text-xs text-stone-400 sm:col-span-2">Goal<input className="input mt-1" name="title" defaultValue={goal?.title} required maxLength={300} placeholder="e.g. Confirm Atlas Consulting operating model and first-quarter delivery plan" /></label>
      <label className="text-xs text-stone-400">Horizon<select className="input mt-1" name="horizon" defaultValue={goal?.horizon ?? "quarterly"}>{HORIZONS.map((h) => <option key={h} value={h}>{h[0]!.toUpperCase() + h.slice(1)}</option>)}</select></label>
      <label className="text-xs text-stone-400">Scope<select className="input mt-1" name="scope" defaultValue={goal?.scope ?? "org"}>{scopes.map((s) => <option key={s.scope} value={s.scope}>{s.label}</option>)}</select></label>
      {goal && <label className="text-xs text-stone-400">Status<select className="input mt-1" name="status" defaultValue={goal.status}>{GSTATUS.map((s) => <option key={s} value={s}>{s[0]!.toUpperCase() + s.slice(1)}</option>)}</select></label>}
      <label className="text-xs text-stone-400">Period start<input className="input mt-1" type="date" name="periodStart" defaultValue={goal?.periodStart ?? ""} /></label>
      <label className="text-xs text-stone-400">Period end<input className="input mt-1" type="date" name="periodEnd" defaultValue={goal?.periodEnd ?? ""} /></label>
      <label className="text-xs text-stone-400">Target metric (optional)<input className="input mt-1" name="targetMetric" defaultValue={goal?.targetMetric ?? ""} placeholder="e.g. Placed AP (USD)" /></label>
      <div className="grid grid-cols-2 gap-2">
        <label className="text-xs text-stone-400">Target<input className="input mt-1 num" type="number" step="any" name="targetValue" defaultValue={goal?.targetValue ?? ""} /></label>
        <label className="text-xs text-stone-400">Current<input className="input mt-1 num" type="number" step="any" name="currentValue" defaultValue={goal?.currentValue ?? ""} /></label>
      </div>
      <label className="text-xs text-stone-400 sm:col-span-2">Description<textarea className="input mt-1" rows={2} name="description" defaultValue={goal?.description} /></label>
      {goal && <label className="text-xs text-stone-400 sm:col-span-2">Progress note<textarea className="input mt-1" rows={2} name="progressNote" defaultValue={goal.progressNote} /></label>}
      <div className="flex gap-2 sm:col-span-2">
        <button className="btn btn-primary" disabled={pending}>{goal ? "Save goal" : "Add goal"}</button>
        {goal && <button type="button" className="btn btn-ghost" onClick={onDone}>Cancel</button>}
        {goal && <button type="button" className="btn btn-danger ml-auto" onClick={async () => { if (confirm(`Delete goal "${goal.title}"? Linked tasks are kept and unlinked.`)) await run(() => api(`/api/goals/${goal.id}`, { method: "DELETE", body: { version: goal.version } })); }}>Delete</button>}
      </div>
      {err && <p role="alert" className="text-xs text-signal-red sm:col-span-2">{err}</p>}
    </form>
  );
}

export function GoalCard({ goal, scopes }: { goal: Goal; scopes: ScopeOption[] }) {
  const [edit, setEdit] = useState(false);
  const pct = goal.targetValue && goal.currentValue != null ? Math.max(0, Math.min(100, (goal.currentValue / goal.targetValue) * 100)) : null;
  return (
    <article id={goal.id} className="glass rounded-[var(--radius-lg)] p-4">
      {edit ? <GoalForm scopes={scopes} goal={goal} onDone={() => setEdit(false)} /> : (
        <>
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="mb-1.5 flex flex-wrap gap-1.5"><Badge tone="champagne">{goal.horizon}</Badge><ScopeTag scope={goal.scope} />{goal.status !== "active" && <Badge tone={goal.status === "achieved" ? "green" : "amber"}>{goal.status}</Badge>}</div>
              <h3 className="text-[15px] font-medium text-stone-50">{goal.title}</h3>
              {goal.description && <p className="mt-1 text-sm text-stone-400">{goal.description}</p>}
            </div>
            <button className="btn btn-sm" onClick={() => setEdit(true)} aria-label={`Edit ${goal.title}`}>Edit</button>
          </div>
          {(goal.periodStart || goal.periodEnd || goal.targetMetric) && (
            <dl className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-xs text-stone-500">
              {(goal.periodStart || goal.periodEnd) && <div><dt className="inline">Period </dt><dd className="inline text-stone-300">{goal.periodStart ?? "…"} → {goal.periodEnd ?? "…"}</dd></div>}
              {goal.targetMetric && <div><dt className="inline">{goal.targetMetric} </dt><dd className="inline num text-stone-300">{goal.currentValue ?? "—"} / {goal.targetValue ?? "—"}</dd></div>}
              <div><dt className="inline">Open tasks </dt><dd className="inline text-stone-300">{goal.openTasks ?? 0}</dd></div>
            </dl>
          )}
          {pct != null && <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/[0.06]" role="progressbar" aria-valuenow={Math.round(pct)} aria-valuemin={0} aria-valuemax={100} aria-label="Progress"><div className="h-full rounded-full bg-gradient-to-r from-champagne-600 to-champagne-200" style={{ width: `${pct}%` }} /></div>}
          {goal.progressNote && <p className="mt-3 border-l border-champagne-400/30 pl-3 text-sm text-stone-300">{goal.progressNote}</p>}
        </>
      )}
    </article>
  );
}

