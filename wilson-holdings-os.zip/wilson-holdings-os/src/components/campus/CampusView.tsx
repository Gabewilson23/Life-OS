"use client";
import dynamic from "next/dynamic";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Component, useEffect, useState, type ReactNode } from "react";
import { STATE_LABEL } from "@/lib/runs/state-machine";
import { STATE_HEX, type CampusAgent, type CampusBuilding } from "./types";

// Lazy-loaded: the initial app load never depends on three.js.
const Scene = dynamic(() => import("./Scene"), { ssr: false, loading: () => <SceneLoading /> });

function SceneLoading() {
  return <div className="grid h-full place-items-center text-sm text-stone-500" role="status">Loading campus…</div>;
}

class SceneBoundary extends Component<{ fallback: ReactNode; children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() { return this.state.failed ? this.props.fallback : this.props.children; }
}

function hasWebGL() {
  try {
    const c = document.createElement("canvas");
    return !!(c.getContext("webgl2") || c.getContext("webgl"));
  } catch { return false; }
}

const pref = (k: string, d: boolean) => { try { const v = localStorage.getItem(k); return v == null ? d : v === "1"; } catch { return d; } };
const save = (k: string, v: boolean) => { try { localStorage.setItem(k, v ? "1" : "0"); } catch { /* storage unavailable */ } };

export function CampusView({ buildings, agents }: { buildings: CampusBuilding[]; agents: CampusAgent[] }) {
  const router = useRouter();
  const sp = useSearchParams();
  const [focus, setFocus] = useState<string | null>(sp.get("focus"));
  const [mode, setMode] = useState<"pending" | "3d" | "plan">("pending");
  const [why, setWhy] = useState<string | null>(null);
  const [lowPower, setLowPower] = useState(false);
  const [reduced, setReduced] = useState(false);
  const [reset, setReset] = useState(0);

  useEffect(() => {
    const mqReduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const small = window.matchMedia("(max-width: 767px)").matches;
    setReduced(pref("wh.reducedMotion", mqReduce));
    setLowPower(pref("wh.lowPower", small));
    if (!hasWebGL()) { setMode("plan"); setWhy("WebGL is unavailable in this browser, so the campus is shown as a plan."); }
    else if (small && !pref("wh.mobile3d", false)) { setMode("plan"); setWhy("Lightweight overview on small screens."); }
    else setMode("3d");
  }, []);

  useEffect(() => {
    const url = new URL(window.location.href);
    if (focus) url.searchParams.set("focus", focus); else url.searchParams.delete("focus");
    window.history.replaceState(null, "", url);
  }, [focus]);

  const selected = buildings.find((b) => b.slug === focus) ?? null;
  const selAgents = selected ? agents.filter((a) => a.buildingId === selected.id) : [];
  const openAgent = (id: string) => router.push(`/agents/${id}`);
  const plan = <CampusPlan buildings={buildings} agents={agents} focus={focus} onSelect={(s) => setFocus(s || null)} />;

  return (
    <div className="relative h-[calc(100vh-61px)] min-h-[520px] overflow-hidden">
      <div className="absolute inset-0" aria-hidden={mode === "3d" ? true : undefined}>
        {mode === "3d" ? (
          <SceneBoundary fallback={<div className="h-full p-6">{plan}<p className="mt-2 text-xs text-stone-500">The 3D scene failed to start; showing the plan instead.</p></div>}>
            <Scene buildings={buildings} agents={agents} focus={focus} lowPower={lowPower} reducedMotion={reduced} resetToken={reset}
              onSelectBuilding={(s) => setFocus(s || null)} onSelectAgent={openAgent} />
          </SceneBoundary>
        ) : mode === "plan" ? <div className="h-full overflow-auto p-4 sm:p-6">{plan}</div> : <SceneLoading />}
      </div>

      {/* Controls */}
      <div className="glass absolute left-4 top-4 z-40 flex flex-wrap items-center gap-1.5 rounded-[var(--radius-md)] p-1.5">
        {mode === "3d" && <button className="btn btn-sm" onClick={() => { setFocus(null); setReset((n) => n + 1); }}>Reset view</button>}
        {mode === "plan" && hasWebGLSafe() && <button className="btn btn-sm" onClick={() => { save("wh.mobile3d", true); setMode("3d"); setWhy(null); }}>Load 3D campus</button>}
        {mode === "3d" && <button className="btn btn-sm" onClick={() => setMode("plan")}>Plan view</button>}
        <button className="btn btn-sm" aria-pressed={lowPower} onClick={() => { setLowPower(!lowPower); save("wh.lowPower", !lowPower); }}>Low power {lowPower ? "on" : "off"}</button>
        <button className="btn btn-sm" aria-pressed={reduced} onClick={() => { setReduced(!reduced); save("wh.reducedMotion", !reduced); }}>Reduced motion {reduced ? "on" : "off"}</button>
      </div>
      {why && <p className="absolute left-4 top-[62px] text-xs text-stone-500">{why}</p>}

      {/* Accessible equivalent + direct navigation */}
      <aside className="glass absolute bottom-4 right-4 top-4 z-40 hidden bg-graphite-900/85 w-[320px] flex-col overflow-hidden rounded-[var(--radius-lg)] md:flex" aria-label="Campus directory">
        {selected ? (
          <div className="flex min-h-0 flex-1 flex-col">
            <div className="border-b border-white/[0.06] p-4">
              <button className="text-xs text-stone-500 hover:text-stone-300" onClick={() => setFocus(null)}>← All buildings</button>
              <h2 className="display mt-1 text-xl text-stone-50">{selected.name}</h2>
              <p className="mt-1 text-xs text-stone-400">{selected.description}</p>
              <Link href={`/buildings/${selected.slug}`} className="btn btn-primary btn-sm mt-3">Open building</Link>
            </div>
            <ul className="min-h-0 flex-1 overflow-y-auto p-2">
              {selected.departments.map((d) => (
                <li key={d.id} className="mb-2">
                  <p className="eyebrow px-2 py-1">{d.name}</p>
                  <ul>{selAgents.filter((a) => a.departmentId === d.id).map((a) => <AgentRow key={a.id} a={a} />)}</ul>
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <ul className="min-h-0 flex-1 overflow-y-auto p-2">
            <li className="px-2 pb-2 pt-1"><p className="eyebrow">Campus · {buildings.length} buildings · {agents.length} roles</p></li>
            {buildings.map((b) => (
              <li key={b.id}>
                <button onClick={() => setFocus(b.slug)} className="flex w-full items-center justify-between rounded-[10px] px-2 py-2 text-left text-sm text-stone-200 hover:bg-white/[0.05]">
                  <span className="flex items-center gap-2"><span aria-hidden className="h-2 w-2 rounded-full" style={{ background: b.layout.accent }} />{b.name}</span>
                  <span className="num text-xs text-stone-500">{agents.filter((a) => a.buildingId === b.id).length}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
        <Legend />
      </aside>
    </div>
  );
}

function hasWebGLSafe() { return typeof document !== "undefined" && hasWebGL(); }

function AgentRow({ a }: { a: CampusAgent }) {
  return (
    <li>
      <Link href={`/agents/${a.id}`} className="flex items-center justify-between gap-2 rounded-[10px] px-2 py-1.5 text-sm text-stone-200 hover:bg-white/[0.05]">
        <span><span className="num mr-1.5 text-stone-500">{a.number}</span>{a.title}{a.isDemo && <span className="ml-1 text-[10px] text-fuchsia-300">demo</span>}</span>
        <span className="flex items-center gap-1 text-[10.5px] text-stone-500"><span aria-hidden className="h-1.5 w-1.5 rounded-full" style={{ background: STATE_HEX[a.liveState] }} />{STATE_LABEL[a.liveState]}</span>
      </Link>
    </li>
  );
}

function Legend() {
  return (
    <div className="border-t border-white/[0.06] p-3 text-[10.5px] text-stone-500">
      <p className="mb-1">Avatar color = real run state. An avatar at a desk is not a running agent.</p>
      <div className="flex flex-wrap gap-x-3 gap-y-1">{["idle", "queued", "running", "waiting_approval", "blocked", "paused"].map((s) => <span key={s} className="flex items-center gap-1"><span aria-hidden className="h-1.5 w-1.5 rounded-full" style={{ background: STATE_HEX[s] }} />{STATE_LABEL[s]}</span>)}</div>
    </div>
  );
}

/** 2D plan: non-WebGL fallback and lightweight mobile overview. Same records and links. */
function CampusPlan({ buildings, agents, focus, onSelect }: { buildings: CampusBuilding[]; agents: CampusAgent[]; focus: string | null; onSelect: (slug: string) => void }) {
  const minX = -22, minZ = -25, W = 44, H = 42;
  return (
    <div className="mx-auto max-w-3xl">
      <svg viewBox={`${minX} ${minZ} ${W} ${H}`} className="w-full" role="img" aria-label="Campus plan">
        <rect x={minX} y={minZ} width={W} height={H} fill="#111418" rx="1" />
        <circle cx="0" cy="0" r="9.9" fill="none" stroke="#3a352d" strokeWidth="0.6" />
        {buildings.map((b) => {
          const { x, z, w, d, accent } = b.layout;
          const sel = focus === b.slug;
          const n = agents.filter((a) => a.buildingId === b.id).length;
          return (
            <g key={b.id} role="button" tabIndex={0} aria-label={`${b.name}, ${n} roles`} onClick={() => onSelect(b.slug)} onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && onSelect(b.slug)} className="cursor-pointer outline-none">
              <rect x={x - w / 2} y={z - d / 2} width={w} height={d} rx="0.4" fill={sel ? "#25303b" : "#1b2128"} stroke={accent} strokeWidth={sel ? 0.35 : 0.15} />
              <text x={x} y={z - 0.2} textAnchor="middle" fontSize="0.85" fill="#e8e2d8">{b.name.length > 22 ? b.name.split(" ").slice(0, 2).join(" ") : b.name}</text>
              <text x={x} y={z + 1.1} textAnchor="middle" fontSize="0.7" fill="#857f75">{n} roles</text>
            </g>
          );
        })}
      </svg>
      <ul className="mt-4 grid gap-2 sm:grid-cols-2 md:hidden">
        {buildings.map((b) => <li key={b.id}><Link className="glass-subtle block rounded-[var(--radius-md)] px-3 py-2 text-sm" href={`/buildings/${b.slug}`}>{b.name}</Link></li>)}
      </ul>
    </div>
  );
}
