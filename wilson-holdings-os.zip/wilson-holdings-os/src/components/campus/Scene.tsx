"use client";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Html, OrbitControls } from "@react-three/drei";
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import { deskPositions, STATE_HEX, type CampusAgent, type CampusBuilding } from "./types";

export interface SceneProps {
  buildings: CampusBuilding[];
  agents: CampusAgent[];
  focus: string | null;
  lowPower: boolean;
  reducedMotion: boolean;
  resetToken: number;
  onSelectBuilding: (slug: string) => void;
  onSelectAgent: (id: string) => void;
}

const HOME = { pos: new THREE.Vector3(30, 30, 36), target: new THREE.Vector3(5, 0, -3) };

function CameraRig({ buildings, focus, reducedMotion, resetToken, controls }: { buildings: CampusBuilding[]; focus: string | null; reducedMotion: boolean; resetToken: number; controls: React.RefObject<OrbitControlsImpl | null> }) {
  const { camera, invalidate } = useThree();
  const goal = useRef<{ pos: THREE.Vector3; target: THREE.Vector3 } | null>(null);
  useEffect(() => {
    const b = buildings.find((x) => x.slug === focus);
    goal.current = b
      ? { pos: new THREE.Vector3(b.layout.x + 15, b.layout.h + 12, b.layout.z + 17), target: new THREE.Vector3(b.layout.x + 3, b.layout.h * 0.3, b.layout.z) }
      : { pos: HOME.pos.clone(), target: HOME.target.clone() };
    if (reducedMotion && controls.current) {
      camera.position.copy(goal.current.pos); controls.current.target.copy(goal.current.target); controls.current.update(); goal.current = null;
    }
    invalidate();
  }, [focus, resetToken, buildings, reducedMotion, camera, controls, invalidate]);
  useFrame((_, dt) => {
    const g = goal.current; const c = controls.current;
    if (!g || !c) return;
    const k = 1 - Math.pow(0.002, dt);
    camera.position.lerp(g.pos, k); c.target.lerp(g.target, k); c.update();
    if (camera.position.distanceTo(g.pos) < 0.05 && c.target.distanceTo(g.target) < 0.05) goal.current = null;
    else invalidate(); // render on demand only while animating
  });
  return null;
}

function Building({ b, agents, selected, onSelect, onAgent }: { b: CampusBuilding; agents: CampusAgent[]; selected: boolean; onSelect: () => void; onAgent: (id: string) => void }) {
  const { x, z, w, d, h, accent } = b.layout;
  const desks = useMemo(() => deskPositions(agents.length, w, d), [agents.length, w, d]);
  const floors = Math.max(1, Math.round(h / 2.2));
  return (
    <group position={[x, 0, z]}>
      {/* warm stone plinth */}
      <mesh position={[0, 0.15, 0]} receiveShadow onClick={(e) => { e.stopPropagation(); onSelect(); }}>
        <boxGeometry args={[w + 1.2, 0.3, d + 1.2]} />
        <meshStandardMaterial color="#4a3426" roughness={0.9} />
      </mesh>
      {/* glass volume */}
      <mesh position={[0, h / 2 + 0.3, 0]} onClick={(e) => { e.stopPropagation(); onSelect(); }}
        onPointerOver={(e) => { e.stopPropagation(); document.body.style.cursor = "pointer"; }} onPointerOut={() => (document.body.style.cursor = "")}>
        <boxGeometry args={[w, h, d]} />
        <meshStandardMaterial color={selected ? "#cfe2f5" : "#a9c3dc"} transparent opacity={selected ? 0.26 : 0.17} metalness={0.35} roughness={0.06} depthWrite={false} />
      </mesh>
      {/* brushed metal floor plates */}
      {Array.from({ length: floors }, (_, i) => (
        <mesh key={i} position={[0, 0.3 + (i * h) / floors, 0]}>
          <boxGeometry args={[w - 0.05, 0.08, d - 0.05]} />
          <meshStandardMaterial color="#59616b" metalness={0.7} roughness={0.4} transparent opacity={0.85} />
        </mesh>
      ))}
      {/* dark roof plate with a thin luminous accent frame (company / building color) */}
      <mesh position={[0, h + 0.3, 0]}>
        <boxGeometry args={[w, 0.1, d]} />
        <meshStandardMaterial color="#2b3138" metalness={0.75} roughness={0.35} />
      </mesh>
      {([[0, d / 2, w + 0.1, 0.1], [0, -d / 2, w + 0.1, 0.1], [w / 2, 0, 0.1, d + 0.1], [-w / 2, 0, 0.1, d + 0.1]] as const).map(([fx, fz, fw, fd], i) => (
        <mesh key={i} position={[fx, h + 0.38, fz]}>
          <boxGeometry args={[fw, 0.07, fd]} />
          <meshStandardMaterial color={accent} emissive={accent} emissiveIntensity={selected ? 0.9 : 0.4} metalness={0.6} roughness={0.3} />
        </mesh>
      ))}
      {/* desks + avatars on the ground floor; state colors come from real runs */}
      {agents.map((a, i) => {
        const [dx, dz] = desks[i]!;
        const color = STATE_HEX[a.liveState] ?? STATE_HEX.idle;
        return (
          <group key={a.id} position={[dx, 0.38, dz]}>
            <mesh position={[0, 0.32, 0.35]}><boxGeometry args={[0.9, 0.06, 0.5]} /><meshStandardMaterial color="#2a2f36" metalness={0.5} roughness={0.4} /></mesh>
            <mesh position={[0, 0.38, 0]} onClick={(e) => { e.stopPropagation(); onAgent(a.id); }}
              onPointerOver={(e) => { e.stopPropagation(); document.body.style.cursor = "pointer"; }} onPointerOut={() => (document.body.style.cursor = "")}>
              <capsuleGeometry args={[0.16, 0.36, 4, 10]} />
              <meshStandardMaterial color={color} emissive={color} emissiveIntensity={a.liveState === "running" ? 0.6 : 0.12} roughness={0.5} />
            </mesh>
            {selected && (
              <Html position={[0, 0.95, 0]} center distanceFactor={14} zIndexRange={[10, 0]}>
                <button onClick={() => onAgent(a.id)} className="whitespace-nowrap rounded-md border border-white/10 bg-graphite-900/90 px-1.5 py-0.5 text-[10px] text-stone-200 hover:text-champagne-200">{a.number}. {a.title}</button>
              </Html>
            )}
          </group>
        );
      })}
      <Html position={[0, h + 1.3, 0]} center distanceFactor={22} zIndexRange={[20, 0]}>
        <button onClick={onSelect} className={`whitespace-nowrap rounded-full border px-3 py-1 text-[12px] font-medium backdrop-blur ${selected ? "border-champagne-400/60 bg-graphite-900/90 text-champagne-200" : "border-white/15 bg-graphite-900/75 text-stone-100"}`}>
          {b.name} <span className="text-stone-400">· {agents.length}</span>
        </button>
      </Html>
    </group>
  );
}

export default function Scene(p: SceneProps) {
  const controls = useRef<OrbitControlsImpl | null>(null);
  const byBuilding = useMemo(() => {
    const m = new Map<string, CampusAgent[]>();
    for (const a of p.agents) m.set(a.buildingId, [...(m.get(a.buildingId) ?? []), a]);
    return m;
  }, [p.agents]);
  return (
    <Canvas frameloop="demand" dpr={p.lowPower ? 1 : [1, 1.75]} shadows={!p.lowPower} camera={{ position: HOME.pos.toArray(), fov: 40, near: 0.5, far: 400 }}
      gl={{ antialias: !p.lowPower, powerPreference: p.lowPower ? "low-power" : "high-performance" }} onPointerMissed={() => p.onSelectBuilding("")}>
      <color attach="background" args={["#0c0a09"]} />
      <fog attach="fog" args={["#0c0a09", 60, 140]} />
      <hemisphereLight args={["#dfe7f2", "#2b2620", 0.55]} />
      <directionalLight position={[30, 40, 18]} intensity={1.4} color="#fff3e0" castShadow={!p.lowPower} shadow-mapSize={[1024, 1024]} />
      <directionalLight position={[-20, 18, -25]} intensity={0.35} color="#9cc4ff" />
      {/* ground: dark stone with paths */}
      <mesh rotation-x={-Math.PI / 2} receiveShadow><planeGeometry args={[140, 140]} /><meshStandardMaterial color="#15110e" roughness={0.95} /></mesh>
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.01, 0]}><ringGeometry args={[9.5, 10.3, 64]} /><meshStandardMaterial color="#5b3c28" roughness={0.9} /></mesh>
      {p.buildings.map((b) => (
        <Building key={b.id} b={b} agents={byBuilding.get(b.id) ?? []} selected={p.focus === b.slug} onSelect={() => p.onSelectBuilding(b.slug)} onAgent={p.onSelectAgent} />
      ))}
      <OrbitControls ref={controls} makeDefault enableDamping={!p.reducedMotion} maxPolarAngle={Math.PI / 2.2} minDistance={8} maxDistance={90} target={HOME.target.toArray()} />
      <CameraRig buildings={p.buildings} focus={p.focus} reducedMotion={p.reducedMotion} resetToken={p.resetToken} controls={controls} />
    </Canvas>
  );
}
