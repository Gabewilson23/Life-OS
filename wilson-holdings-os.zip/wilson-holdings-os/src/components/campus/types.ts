export interface CampusBuilding { id: string; slug: string; name: string; description: string; scope: string; layout: { x: number; z: number; w: number; d: number; h: number; accent: string }; departments: { id: string; name: string }[] }
export interface CampusAgent { id: string; number: number; title: string; buildingId: string; departmentId: string; departmentName: string; liveState: string; isDemo: boolean }

export const STATE_HEX: Record<string, string> = {
  idle: "#8a939d", paused: "#f0b45a", proposed: "#c9ced4", queued: "#a99cff", running: "#6fb6ff",
  waiting_approval: "#d9c39a", blocked: "#ef7f7a", failed: "#ef7f7a", succeeded: "#8fd19e", cancelled: "#857f75",
};

/** Deterministic desk positions inside a building footprint (local coordinates). */
export function deskPositions(count: number, w: number, d: number): [number, number][] {
  const cols = Math.max(1, Math.ceil(Math.sqrt(count * (w / d))));
  const rows = Math.ceil(count / cols);
  const out: [number, number][] = [];
  for (let i = 0; i < count; i++) {
    const c = i % cols, r = Math.floor(i / cols);
    out.push([((c + 0.5) / cols - 0.5) * (w - 1.6), ((r + 0.5) / rows - 0.5) * (d - 1.6)]);
  }
  return out;
}
