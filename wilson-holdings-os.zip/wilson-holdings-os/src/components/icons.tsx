// Minimal stroke icon set (original, 24px grid).
const P: Record<string, string> = {
  home: "M3 11.5 12 4l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z",
  campus: "M3 21h18M5 21V10l4-2v13M9 21V6l6-3v18M15 21V9l4 2v10",
  chat: "M4 5h16v11H8l-4 4z M8 9h8 M8 12h5",
  org: "M12 4a3 3 0 1 1 0 6 3 3 0 0 1 0-6zM5 20a7 7 0 0 1 14 0 M4 9a2 2 0 1 1 0 .1 M20 9a2 2 0 1 1 0 .1",
  goals: "M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18zm0 4a5 5 0 1 1 0 10 5 5 0 0 1 0-10zm0 4a1 1 0 1 1 0 2 1 1 0 0 1 0-2z",
  tasks: "M9 6h11M9 12h11M9 18h11M4 6l1 1 2-2M4 12l1 1 2-2M4 18l1 1 2-2",
  insurance: "M12 3 4 6v6c0 4.5 3.4 8.3 8 9 4.6-.7 8-4.5 8-9V6z M9 12l2 2 4-4",
  consulting: "M4 8h16v11H4z M9 8V5h6v3 M4 13h16",
  approvals: "M5 12l4 4 10-10 M4 20h16",
  calendar: "M4 6h16v14H4z M4 10h16 M8 3v5 M16 3v5",
  meetings: "M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm8 0a3 3 0 1 1 0-6 3 3 0 0 1 0 6zM2 20a6 6 0 0 1 12 0M10 20a6 6 0 0 1 12 0",
  integrations: "M9 3v6M15 3v6M7 9h10v3a5 5 0 0 1-10 0zM12 17v4",
  memory: "M9 4a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 6 1V5a3 3 0 0 0-3-1zm6 0a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-6 1",
  briefings: "M6 3h9l4 4v14H6z M14 3v5h5 M9 12h7 M9 16h7",
  studio: "M14 4l6 6-10 10H4v-6z M12 6l6 6",
  activity: "M3 12h4l3-8 4 16 3-8h4",
  settings: "M12 9a3 3 0 1 1 0 6 3 3 0 0 1 0-6z M19 12l2-1-1-3-2 .5-1.5-1.5.5-2-3-1-1 2h-2L9 3 6 4l.5 2L5 7.5 3 7 2 10l2 1v2l-2 1 1 3 2-.5L6.5 18 6 20l3 1 1-2h2l1 2 3-1-.5-2 1.5-1.5 2 .5 1-3-2-1z",
  pause: "M8 5v14M16 5v14",
  search: "M11 4a7 7 0 1 1 0 14 7 7 0 0 1 0-14zm9 16-4-4",
};
export function Icon({ name, size = 18, className }: { name: string; size?: number; className?: string }) {
  return (
    <svg aria-hidden width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d={P[name] ?? P.home} />
    </svg>
  );
}
