export interface NavItem { href: string; label: string; icon: string; key?: string; dock?: boolean; group: "Run" | "Companies" | "Work" | "System" }
export const NAV: NavItem[] = [
  { href: "/", label: "Chairman home", icon: "home", key: "h", dock: true, group: "Run" },
  { href: "/chat", label: "Chief of staff", icon: "chat", key: "c", dock: true, group: "Run" },
  { href: "/campus", label: "Campus", icon: "campus", key: "p", dock: true, group: "Run" },
  { href: "/briefings", label: "Briefings", icon: "briefings", key: "b", dock: true, group: "Run" },
  { href: "/approvals", label: "Approvals", icon: "approvals", key: "a", dock: true, group: "Run" },
  { href: "/companies/atlas-insurance", label: "Atlas Insurance", icon: "insurance", key: "i", dock: true, group: "Companies" },
  { href: "/companies/atlas-consulting", label: "Atlas Consulting", icon: "consulting", key: "k", dock: true, group: "Companies" },
  { href: "/imports", label: "Imports", icon: "integrations", group: "Companies" },
  { href: "/goals", label: "Goals", icon: "goals", key: "g", dock: true, group: "Work" },
  { href: "/tasks", label: "Tasks", icon: "tasks", key: "t", dock: true, group: "Work" },
  { href: "/calendar", label: "Calendar", icon: "calendar", key: "l", dock: true, group: "Work" },
  { href: "/email", label: "Email", icon: "chat", key: "e", group: "Work" },
  { href: "/meetings", label: "Meetings", icon: "meetings", key: "m", dock: true, group: "Work" },
  { href: "/agents", label: "Organization", icon: "org", key: "o", group: "Work" },
  { href: "/memory", label: "Brain & memory", icon: "memory", key: "y", dock: true, group: "System" },
  { href: "/studio", label: "Build Studio", icon: "studio", key: "u", dock: true, group: "System" },
  { href: "/integrations", label: "Integrations", icon: "integrations", key: "n", group: "System" },
  { href: "/activity", label: "Activity & audit", icon: "activity", key: "v", group: "System" },
  { href: "/settings", label: "Settings", icon: "settings", key: "s", group: "System" },
];
export function isActive(path: string, href: string) {
  return href === "/" ? path === "/" : path === href || path.startsWith(href + "/") || (href.startsWith("/companies") && path.startsWith(href));
}
