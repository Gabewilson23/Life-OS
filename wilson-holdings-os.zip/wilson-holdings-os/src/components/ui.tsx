import type { ReactNode } from "react";
import { STATE_LABEL } from "@/lib/runs/state-machine";

export function cx(...c: (string | false | null | undefined)[]) {
  return c.filter(Boolean).join(" ");
}

export function Panel({ title, eyebrow, actions, children, className, id }: { title?: ReactNode; eyebrow?: string; actions?: ReactNode; children: ReactNode; className?: string; id?: string }) {
  return (
    <section id={id} aria-labelledby={id ? `${id}-title` : undefined} className={cx("glass rounded-[20px] p-5 animate-rise", className)}>
      {(title || actions) && (
        <header className="mb-4 flex items-start justify-between gap-3">
          <div className="min-w-0">
            {eyebrow && <p className="eyebrow mb-1 flex items-center gap-2"><span aria-hidden className="window-dots"><span className="bg-champagne-400" /><span className="bg-signal-blue" /><span className="bg-stone-100" /></span>{eyebrow}</p>}
            {title && <h2 id={id ? `${id}-title` : undefined} className="display text-[18px] text-stone-50">{title}</h2>}
          </div>
          {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
        </header>
      )}
      {children}
    </section>
  );
}

const STATE_COLOR: Record<string, string> = {
  idle: "bg-metal-500", paused: "bg-signal-amber", proposed: "bg-metal-300", queued: "bg-signal-violet", running: "bg-signal-blue",
  waiting_approval: "bg-champagne-400", blocked: "bg-signal-red", failed: "bg-signal-red", succeeded: "bg-signal-green", cancelled: "bg-stone-500",
};

export function StateBadge({ state }: { state: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-black/25 px-2 py-0.5 text-[11px] font-medium text-stone-300">
      <span aria-hidden className={cx("h-1.5 w-1.5 rounded-full", STATE_COLOR[state] ?? "bg-metal-500", state === "running" && "motion-safe:animate-pulse")} />
      {STATE_LABEL[state] ?? state}
    </span>
  );
}

export function Badge({ children, tone = "neutral" }: { children: ReactNode; tone?: "neutral" | "blue" | "champagne" | "amber" | "red" | "green" | "demo" }) {
  const tones = {
    neutral: "border-white/10 text-stone-300 bg-white/[0.03]",
    blue: "border-signal-blue/30 text-signal-blue bg-signal-blue/10",
    champagne: "border-champagne-400/30 text-champagne-200 bg-champagne-400/10",
    amber: "border-signal-amber/30 text-signal-amber bg-signal-amber/10",
    red: "border-signal-red/30 text-signal-red bg-signal-red/10",
    green: "border-signal-green/30 text-signal-green bg-signal-green/10",
    demo: "border-fuchsia-300/40 text-fuchsia-200 bg-fuchsia-400/15",
  } as const;
  return <span className={cx("inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium", tones[tone])}>{children}</span>;
}

export function Empty({ title, children, action }: { title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="glass-subtle rounded-[var(--radius-md)] border-dashed px-4 py-5 text-sm">
      <p className="font-medium text-stone-100">{title}</p>
      {children && <div className="mt-1 text-stone-400">{children}</div>}
      {action && <div className="mt-3">{action}</div>}
    </div>
  );
}

export function PageHeader({ eyebrow, title, children, actions }: { eyebrow?: string; title: string; children?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        {eyebrow && <p className="eyebrow mb-2">{eyebrow}</p>}
        <h1 className="display text-[30px] leading-tight text-stone-50 sm:text-[34px]">{title}</h1>
        {children && <div className="mt-2 max-w-2xl text-sm text-stone-400">{children}</div>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}

export const SCOPE_LABEL: Record<string, string> = {
  org: "Holding", "company:atlas-insurance": "Atlas Insurance", "company:atlas-consulting": "Atlas Consulting", personal: "Personal",
  "personal:finance": "Personal finance", "personal:health": "Health", "personal:relationships": "Relationships", engineering: "Build Studio",
};

export function ScopeTag({ scope }: { scope: string }) {
  const company = scope.startsWith("company:");
  const priv = scope.startsWith("personal:");
  return <Badge tone={company ? "blue" : priv ? "amber" : "neutral"}>{SCOPE_LABEL[scope] ?? scope}</Badge>;
}

export function scopeOptions(writeScopes: string[]) {
  return writeScopes.map((s) => ({ scope: s, label: SCOPE_LABEL[s] ?? s }));
}
