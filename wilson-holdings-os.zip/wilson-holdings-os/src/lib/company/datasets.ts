/**
 * Company datasets for import + metrics. Single source of truth for table columns, validation and header synonyms.
 * Money is stored as integer cents. Dates as DATE (no timezone shifting).
 */
export type FieldType = "text" | "date" | "money" | "int" | "numeric" | "bool" | "percent" | "enum";
export interface FieldDef { key: string; label: string; type: FieldType; required?: boolean; enum?: string[]; synonyms?: string[]; sensitive?: boolean }
export interface DatasetDef { id: string; table: string; company: "atlas-insurance" | "atlas-consulting"; label: string; keyLabel: string; keySynonyms: string[]; fields: FieldDef[]; description: string }

export const DATASETS: DatasetDef[] = [
  { id: "ins_people", table: "ins_people", company: "atlas-insurance", label: "Recruits & agents", keyLabel: "Person ID", keySynonyms: ["person id", "agent id", "candidate id", "id", "npn"], description: "Candidates and licensed agents (real people — not AI roles).",
    fields: [
      { key: "name", label: "Name", type: "text", required: true, synonyms: ["full name", "agent name", "candidate"] },
      { key: "kind", label: "Kind", type: "enum", required: true, enum: ["candidate", "agent"], synonyms: ["type", "role"] },
      { key: "stage", label: "Stage", type: "enum", required: true, enum: ["sourced", "interviewing", "offered", "licensing", "onboarding", "active", "inactive"], synonyms: ["status", "pipeline stage"] },
      { key: "source", label: "Recruiting source", type: "text", synonyms: ["recruiting source", "lead source", "channel"] },
      { key: "cohort", label: "Cohort (YYYY-MM)", type: "text", synonyms: ["start cohort", "class"] },
      { key: "licensed_states", label: "Licensed states", type: "text", synonyms: ["states", "licenses"] },
      { key: "hired_at", label: "Hired / contracted date", type: "date", synonyms: ["hire date", "contract date", "start date"] },
      { key: "first_production_at", label: "First production date", type: "date", synonyms: ["first sale", "first production"] },
      { key: "training_complete", label: "Training complete", type: "bool", synonyms: ["trained", "training done"] },
    ] },
  { id: "ins_policies", table: "ins_policies", company: "atlas-insurance", label: "Cases & policies", keyLabel: "Policy / case number", keySynonyms: ["policy number", "policy #", "case id", "case number", "application id", "policy"], description: "Lifecycle: submitted → issued → placed → paid. AP = annualized premium.",
    fields: [
      { key: "client_name", label: "Client name", type: "text", sensitive: true, synonyms: ["client", "insured", "customer"] },
      { key: "agent_key", label: "Writing agent ID", type: "text", synonyms: ["agent id", "writing agent", "agent"] },
      { key: "carrier", label: "Carrier", type: "text", synonyms: ["company", "insurer"] },
      { key: "product", label: "Product", type: "text", synonyms: ["plan", "product type"] },
      { key: "lead_source", label: "Lead source", type: "text", synonyms: ["source", "lead vendor"] },
      { key: "annual_premium", label: "Annualized premium (AP)", type: "money", required: true, synonyms: ["ap", "annual premium", "annualized premium", "premium"] },
      { key: "submitted_at", label: "Submitted date", type: "date", required: true, synonyms: ["submit date", "app date", "application date", "submitted"] },
      { key: "issued_at", label: "Issued date", type: "date", synonyms: ["issue date", "issued"] },
      { key: "placed_at", label: "Placed date", type: "date", synonyms: ["placement date", "placed", "in force date", "effective date"] },
      { key: "paid_at", label: "First premium paid date", type: "date", synonyms: ["paid date", "paid"] },
      { key: "status", label: "Status", type: "enum", required: true, enum: ["submitted", "issued", "placed", "paid", "declined", "withdrawn", "lapsed", "cancelled"], synonyms: ["policy status", "case status"] },
      { key: "lapsed_at", label: "Lapse date", type: "date", synonyms: ["lapse date", "terminated"] },
      { key: "missing_documents", label: "Missing documents", type: "text", synonyms: ["requirements", "outstanding requirements", "pending docs"] },
    ] },
  { id: "ins_commissions", table: "ins_commissions", company: "atlas-insurance", label: "Commission ledger", keyLabel: "Ledger entry ID", keySynonyms: ["entry id", "transaction id", "statement line", "id"], description: "Advances, earned, overrides, chargebacks, renewals — expected vs received.",
    fields: [
      { key: "policy_key", label: "Policy / case number", type: "text", required: true, synonyms: ["policy number", "policy", "case id"] },
      { key: "agent_key", label: "Agent ID", type: "text", synonyms: ["agent id", "agent"] },
      { key: "kind", label: "Entry type", type: "enum", required: true, enum: ["advance", "earned", "override", "chargeback", "renewal"], synonyms: ["type", "transaction type"] },
      { key: "expected", label: "Expected amount", type: "money", synonyms: ["expected", "projected"] },
      { key: "received", label: "Received amount", type: "money", synonyms: ["received", "paid amount", "amount"] },
      { key: "statement_date", label: "Statement date", type: "date", required: true, synonyms: ["date", "period", "statement"] },
    ] },
  { id: "ins_lead_costs", table: "ins_lead_costs", company: "atlas-insurance", label: "Lead spend", keyLabel: "Spend line ID", keySynonyms: ["id", "line id", "invoice id"], description: "Lead acquisition cost by source and month.",
    fields: [
      { key: "source", label: "Lead source", type: "text", required: true, synonyms: ["vendor", "lead source", "channel"] },
      { key: "month", label: "Month (first day)", type: "date", required: true, synonyms: ["period", "date"] },
      { key: "cost", label: "Cost", type: "money", required: true, synonyms: ["spend", "amount"] },
      { key: "leads", label: "Leads purchased", type: "int", synonyms: ["lead count", "quantity", "count"] },
    ] },
  { id: "con_opportunities", table: "con_opportunities", company: "atlas-consulting", label: "Opportunities", keyLabel: "Opportunity ID", keySynonyms: ["opportunity id", "deal id", "id"], description: "Pipeline. Never added to contracted backlog.",
    fields: [
      { key: "client", label: "Client", type: "text", required: true, synonyms: ["account", "customer", "company"] },
      { key: "name", label: "Opportunity", type: "text", required: true, synonyms: ["deal", "opportunity name", "title"] },
      { key: "stage", label: "Stage", type: "enum", required: true, enum: ["lead", "qualified", "proposal", "negotiation", "won", "lost"], synonyms: ["status", "deal stage"] },
      { key: "amount", label: "Amount", type: "money", required: true, synonyms: ["value", "deal value", "estimated value"] },
      { key: "probability", label: "Win probability %", type: "percent", synonyms: ["probability", "likelihood", "win %"] },
      { key: "expected_close", label: "Expected close", type: "date", synonyms: ["close date", "expected close date"] },
      { key: "next_step", label: "Next step", type: "text", synonyms: ["next action"] },
    ] },
  { id: "con_projects", table: "con_projects", company: "atlas-consulting", label: "Projects & contracts", keyLabel: "Project ID", keySynonyms: ["project id", "job id", "job number", "id"], description: "Contracted work. Contract value is approved; budget cost is an internal estimate.",
    fields: [
      { key: "client", label: "Client", type: "text", required: true, synonyms: ["customer", "account"] },
      { key: "name", label: "Project", type: "text", required: true, synonyms: ["project name", "job", "job name"] },
      { key: "billing_model", label: "Billing model", type: "enum", enum: ["project", "retainer", "placement", "time_and_materials"], synonyms: ["contract type", "billing"] },
      { key: "contract_value", label: "Contract value (approved)", type: "money", required: true, synonyms: ["contract amount", "value", "sow value"] },
      { key: "budget_cost", label: "Budgeted cost (internal estimate)", type: "money", synonyms: ["budget", "cost budget", "estimated cost"] },
      { key: "status", label: "Status", type: "enum", required: true, enum: ["planned", "active", "on_hold", "complete", "cancelled"], synonyms: ["project status"] },
      { key: "health", label: "Delivery health", type: "enum", enum: ["green", "amber", "red"], synonyms: ["rag", "health status"] },
      { key: "start_date", label: "Start", type: "date", synonyms: ["start date"] },
      { key: "end_date", label: "End", type: "date", synonyms: ["end date", "due date"] },
      { key: "renewal_date", label: "Renewal date", type: "date", synonyms: ["renewal"] },
    ] },
  { id: "con_time", table: "con_time", company: "atlas-consulting", label: "Time entries", keyLabel: "Entry ID", keySynonyms: ["entry id", "timesheet id", "id"], description: "Approved time drives job cost.",
    fields: [
      { key: "project_key", label: "Project ID", type: "text", required: true, synonyms: ["project id", "job id", "project"] },
      { key: "person", label: "Person / contractor", type: "text", required: true, synonyms: ["contractor", "employee", "name", "resource"] },
      { key: "work_date", label: "Date", type: "date", required: true, synonyms: ["date", "day"] },
      { key: "hours", label: "Hours", type: "numeric", required: true, synonyms: ["hrs", "time"] },
      { key: "cost_rate", label: "Cost rate / hr", type: "money", required: true, synonyms: ["cost rate", "pay rate"] },
      { key: "bill_rate", label: "Bill rate / hr", type: "money", synonyms: ["bill rate", "rate"] },
      { key: "approved", label: "Approved", type: "bool", required: true, synonyms: ["approved?", "status"] },
    ] },
  { id: "con_expenses", table: "con_expenses", company: "atlas-consulting", label: "Expenses", keyLabel: "Expense ID", keySynonyms: ["expense id", "id", "receipt"], description: "Approved expenses add to job cost.",
    fields: [
      { key: "project_key", label: "Project ID", type: "text", required: true, synonyms: ["project id", "job id", "project"] },
      { key: "expense_date", label: "Date", type: "date", required: true, synonyms: ["date"] },
      { key: "amount", label: "Amount", type: "money", required: true, synonyms: ["cost", "total"] },
      { key: "billable", label: "Billable", type: "bool", synonyms: ["rebillable"] },
      { key: "approved", label: "Approved", type: "bool", required: true, synonyms: ["approved?"] },
      { key: "description", label: "Description", type: "text", synonyms: ["memo", "note"] },
    ] },
  { id: "con_invoices", table: "con_invoices", company: "atlas-consulting", label: "Invoices", keyLabel: "Invoice number", keySynonyms: ["invoice number", "invoice #", "invoice", "id"], description: "Billed amounts (accrual basis).",
    fields: [
      { key: "project_key", label: "Project ID", type: "text", required: true, synonyms: ["project id", "job id", "project"] },
      { key: "issued_at", label: "Invoice date", type: "date", required: true, synonyms: ["date", "invoice date", "issued"] },
      { key: "due_at", label: "Due date", type: "date", required: true, synonyms: ["due", "due date"] },
      { key: "amount", label: "Amount", type: "money", required: true, synonyms: ["total", "invoice amount"] },
      { key: "status", label: "Status", type: "enum", enum: ["draft", "sent", "paid", "void"], synonyms: ["invoice status"] },
    ] },
  { id: "con_payments", table: "con_payments", company: "atlas-consulting", label: "Payments received", keyLabel: "Payment ID", keySynonyms: ["payment id", "id", "reference"], description: "Cash received (cash basis).",
    fields: [
      { key: "invoice_key", label: "Invoice number", type: "text", required: true, synonyms: ["invoice", "invoice number", "invoice #"] },
      { key: "received_at", label: "Received date", type: "date", required: true, synonyms: ["date", "payment date"] },
      { key: "amount", label: "Amount", type: "money", required: true, synonyms: ["payment", "total"] },
    ] },
];

export const datasetById = (id: string) => DATASETS.find((d) => d.id === id);
export const companyScope = (c: DatasetDef["company"]) => `company:${c}`;

export function sqlType(t: FieldType) {
  return { text: "text", date: "date", money: "bigint", int: "integer", numeric: "numeric(12,2)", bool: "boolean", percent: "numeric(5,2)", enum: "text" }[t];
}
export const columnFor = (f: FieldDef) => (f.type === "money" ? `${f.key}_cents` : f.key);
