import type { DatasetDef, FieldDef } from "./datasets";

/** RFC 4180 CSV parser (quotes, escaped quotes, CRLF, embedded newlines, BOM). */
export function parseCsv(text: string): string[][] {
  const s = text.replace(/^﻿/, "");
  const rows: string[][] = [];
  let row: string[] = [], field = "", q = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i]!;
    if (q) {
      if (c === '"') { if (s[i + 1] === '"') { field += '"'; i++; } else q = false; }
      else field += c;
    } else if (c === '"' && field === "") q = true;
    else if (c === ",") { row.push(field); field = ""; }
    else if (c === "\n" || c === "\r") {
      if (c === "\r" && s[i + 1] === "\n") i++;
      row.push(field); field = "";
      if (row.some((x) => x.trim() !== "")) rows.push(row);
      row = [];
    } else field += c;
  }
  if (q) throw new Error("Malformed CSV: unterminated quoted field");
  row.push(field);
  if (row.some((x) => x.trim() !== "")) rows.push(row);
  return rows;
}

const norm = (h: string) => h.toLowerCase().replace(/[^a-z0-9%#]+/g, " ").trim();

/** Suggests header → field mapping using labels, keys and synonyms. Unknown headers are left unmapped. */
export function suggestMapping(ds: DatasetDef, headers: string[]): Record<string, string> {
  const map: Record<string, string> = {};
  const used = new Set<string>();
  const cands: [string, string[]][] = [["__key", [ds.keyLabel, ...ds.keySynonyms]], ...ds.fields.map((f) => [f.key, [f.label, f.key.replace(/_/g, " "), ...(f.synonyms ?? [])]] as [string, string[]])];
  for (const h of headers) {
    const n = norm(h);
    const hit = cands.find(([k, syn]) => !used.has(k) && syn.some((x) => norm(x) === n));
    if (hit) { map[h] = hit[0]; used.add(hit[0]); }
  }
  return map;
}

/** Parses money to integer cents. Accepts $, commas, (negatives), -; rejects >2 decimal places rather than silently rounding. */
export function parseMoney(raw: string): number {
  let s = raw.trim();
  if (!s) throw new Error("empty amount");
  let neg = false;
  if (/^\(.*\)$/.test(s)) { neg = true; s = s.slice(1, -1); }
  s = s.replace(/[$\s,]/g, "").replace(/^USD/i, "");
  if (s.startsWith("-")) { neg = !neg; s = s.slice(1); }
  if (!/^\d+(\.\d{1,2})?$/.test(s)) {
    if (/^\d+\.\d{3,}$/.test(s)) throw new Error(`"${raw}" has more than 2 decimal places`);
    throw new Error(`"${raw}" is not a valid amount`);
  }
  const [w, f = ""] = s.split(".");
  const cents = Number(w) * 100 + Number((f + "00").slice(0, 2));
  if (!Number.isSafeInteger(cents)) throw new Error(`"${raw}" is too large`);
  return neg ? -cents : cents;
}

/** Dates: ISO YYYY-MM-DD, US M/D/YYYY, or Excel serial; returns YYYY-MM-DD. */
export function parseDate(raw: string): string {
  const s = raw.trim();
  let m;
  if ((m = s.match(/^(\d{4})-(\d{2})-(\d{2})(?:[T ].*)?$/))) return check(+m[1]!, +m[2]!, +m[3]!, raw);
  if ((m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2}|\d{4})$/))) return check(m[3]!.length === 2 ? 2000 + +m[3]! : +m[3]!, +m[1]!, +m[2]!, raw);
  if (/^\d{5}(\.\d+)?$/.test(s)) { const d = new Date(Date.UTC(1899, 11, 30) + Math.floor(Number(s)) * 86400_000); return d.toISOString().slice(0, 10); }
  throw new Error(`"${raw}" is not a recognized date (use YYYY-MM-DD or M/D/YYYY)`);
}
function check(y: number, mo: number, d: number, raw: string) {
  const dt = new Date(Date.UTC(y, mo - 1, d));
  if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== mo - 1 || dt.getUTCDate() !== d) throw new Error(`"${raw}" is not a valid calendar date`);
  return dt.toISOString().slice(0, 10);
}

export function parseValue(f: FieldDef, raw: string): unknown {
  const s = (raw ?? "").trim();
  if (s === "") { if (f.required) throw new Error(`${f.label} is required`); return null; }
  switch (f.type) {
    case "money": return parseMoney(s);
    case "date": return parseDate(s);
    case "int": { if (!/^-?\d+$/.test(s.replace(/,/g, ""))) throw new Error(`"${s}" is not a whole number`); return Number(s.replace(/,/g, "")); }
    case "numeric": { const n = Number(s.replace(/,/g, "")); if (!Number.isFinite(n)) throw new Error(`"${s}" is not a number`); return Math.round(n * 100) / 100; }
    case "percent": { const n = Number(s.replace("%", "")); if (!Number.isFinite(n) || n < 0 || n > 100) throw new Error(`"${s}" must be 0–100`); return n; }
    case "bool": { const v = s.toLowerCase(); if (["y", "yes", "true", "1", "approved", "x"].includes(v)) return true; if (["n", "no", "false", "0", "pending", "rejected"].includes(v)) return false; throw new Error(`"${s}" is not yes/no`); }
    case "enum": { const v = s.toLowerCase().replace(/[\s-]+/g, "_"); if (!f.enum!.includes(v)) throw new Error(`"${s}" must be one of: ${f.enum!.join(", ")}`); return v; }
    default: return s.slice(0, 2000);
  }
}

export interface RowResult { rowNum: number; key: string | null; values: Record<string, unknown>; errors: string[] }

export function validateRows(ds: DatasetDef, headers: string[], rows: string[][], mapping: Record<string, string>): RowResult[] {
  const idx = (target: string) => headers.findIndex((h) => mapping[h] === target);
  const keyIdx = idx("__key");
  const seen = new Map<string, number>();
  return rows.map((r, i) => {
    const out: RowResult = { rowNum: i + 2, key: null, values: {}, errors: [] };
    const key = keyIdx >= 0 ? (r[keyIdx] ?? "").trim() : "";
    if (!key) out.errors.push(`${ds.keyLabel} is required`);
    else if (seen.has(key)) out.errors.push(`Duplicate ${ds.keyLabel} "${key}" (also row ${seen.get(key)}) in this file`);
    else { seen.set(key, out.rowNum); out.key = key; }
    for (const f of ds.fields) {
      const j = idx(f.key);
      try { out.values[f.key] = parseValue(f, j >= 0 ? r[j] ?? "" : ""); } catch (e) { out.errors.push(`${f.label}: ${(e as Error).message}`); }
    }
    return out;
  });
}

export function missingRequired(ds: DatasetDef, mapping: Record<string, string>) {
  const mapped = new Set(Object.values(mapping));
  return [...(mapped.has("__key") ? [] : [ds.keyLabel]), ...ds.fields.filter((f) => f.required && !mapped.has(f.key)).map((f) => f.label)];
}
