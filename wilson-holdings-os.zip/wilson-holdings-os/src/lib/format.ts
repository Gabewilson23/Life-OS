/** Display formatting only — never used for calculations. */
export function usd(cents: number | null | undefined, opts: { compact?: boolean } = {}) {
  if (cents == null) return "—";
  const v = cents / 100;
  // Exact cents unless the amount is large enough that compact notation is clearer (≥ $100k).
  const compact = !!opts.compact && Math.abs(v) >= 100000;
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: compact ? 0 : 2, maximumFractionDigits: compact ? 1 : 2, notation: compact ? "compact" : "standard" }).format(v);
}
export function fmtMetric(value: number | null, unit: string) {
  if (value == null) return "—";
  if (unit === "usd_cents") return usd(value, { compact: true });
  if (unit === "percent") return `${value}%`;
  if (unit === "hours") return `${value} h`;
  return new Intl.NumberFormat("en-US").format(value);
}
