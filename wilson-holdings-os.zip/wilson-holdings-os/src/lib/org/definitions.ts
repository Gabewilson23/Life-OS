/**
 * Organization design for Wilson Holdings OS: 11 buildings, departments and 52 configurable AI roles.
 * These are configuration records. Roles run on demand or on schedule as bounded jobs;
 * nothing here implies a continuously running model session, legal authority or licensure.
 */

export const ORG_ID = "wilson-holdings";

export interface ScopeDef {
  scope: string;
  label: string;
  sensitivity: "standard" | "confidential" | "private";
  description: string;
}

export const SCOPES: ScopeDef[] = [
  { scope: "org", label: "Holding company", sensitivity: "standard", description: "Wilson Holdings headquarters, cross-company goals and system operations." },
  { scope: "company:atlas-insurance", label: "Atlas Insurance Agency", sensitivity: "confidential", description: "Insurance agency records. Client data minimized and masked by default." },
  { scope: "company:atlas-consulting", label: "Atlas Consulting", sensitivity: "confidential", description: "Contracting company records (business model to be confirmed at onboarding)." },
  { scope: "personal", label: "Personal (general)", sensitivity: "confidential", description: "Owner's personal logistics, household and travel." },
  { scope: "personal:finance", label: "Personal finance", sensitivity: "private", description: "Personal books, cash and investments. Separate from company books." },
  { scope: "personal:health", label: "Health and performance", sensitivity: "private", description: "Voluntary health and training data. Private by default." },
  { scope: "personal:relationships", label: "Relationships", sensitivity: "private", description: "Commitments, dates and preferences the owner supplies. Private by default." },
  { scope: "engineering", label: "Build Studio", sensitivity: "confidential", description: "Change specifications, branches and release records. No production secrets." },
];

export interface CompanyDef {
  id: string;
  slug: string;
  name: string;
  kind: "holding" | "insurance" | "consulting";
  scope: string;
  settings: Record<string, unknown>;
}

export const COMPANIES: CompanyDef[] = [
  { id: "co.wilson-holdings", slug: "wilson-holdings", name: "Wilson Holdings", kind: "holding", scope: "org", settings: {} },
  {
    id: "co.atlas-insurance",
    slug: "atlas-insurance",
    name: "Atlas Insurance Agency",
    kind: "insurance",
    scope: "company:atlas-insurance",
    settings: { maskClientDataByDefault: true, currency: "USD", note: "Team size, carriers, rates and production goals are not preloaded; they come from verified records." },
  },
  {
    id: "co.atlas-consulting",
    slug: "atlas-consulting",
    name: "Atlas Consulting",
    kind: "consulting",
    scope: "company:atlas-consulting",
    settings: {
      currency: "USD",
      // Must be confirmed during onboarding. Do not assume construction, staffing or advisory consulting.
      businessModel: null,
      availableWorkflows: ["project", "retainer", "placement", "time_and_materials"],
      enabledWorkflows: [],
    },
  },
];

export interface BuildingDef {
  slug: string;
  name: string;
  description: string;
  company?: string; // company id
  scope: string;
  layout: { x: number; z: number; w: number; d: number; h: number; accent: string };
  departments: { slug: string; name: string; description: string }[];
}

const champagne = "#c99a68";
const blue = "#5ea6ff";
const teal = "#69d2c4";
const violet = "#a99cff";
const rose = "#e8a3a8";
const sage = "#a5c79b";
const steel = "#e8e4de";

export const BUILDINGS: BuildingDef[] = [
  { slug: "headquarters", name: "Headquarters", description: "Chairman's office, chief of staff and strategy.", scope: "org", layout: { x: 0, z: 0, w: 7, d: 7, h: 6.5, accent: champagne },
    departments: [{ slug: "executive-office", name: "Executive Office", description: "Intake, orchestration, strategy, portfolio and performance." }] },
  { slug: "atlas-insurance", name: "Atlas Insurance Agency", description: "Recruiting, licensing, production, case operations and commission controls.", company: "co.atlas-insurance", scope: "company:atlas-insurance", layout: { x: -13, z: -4, w: 7, d: 6, h: 5, accent: blue },
    departments: [
      { slug: "ins-operations", name: "Operations Office", description: "Company operating plan and daily CEO update." },
      { slug: "ins-growth", name: "Growth", description: "Recruiting pipeline and lead acquisition economics." },
      { slug: "ins-licensing", name: "Licensing and Development", description: "Licensing, onboarding, training and activation." },
      { slug: "ins-production", name: "Production and Case Operations", description: "Production analytics, pending cases and retention." },
      { slug: "ins-economics", name: "Economics and Controls", description: "Commission reconciliation, compliance and carrier research." },
    ] },
  { slug: "atlas-consulting", name: "Atlas Consulting", description: "Commercial, delivery, quality and project finance for the contracting company.", company: "co.atlas-consulting", scope: "company:atlas-consulting", layout: { x: 13, z: -4, w: 7, d: 6, h: 5, accent: blue },
    departments: [
      { slug: "con-operations", name: "Operations Office", description: "Delivery portfolio, capacity and daily CEO update." },
      { slug: "con-commercial", name: "Sales and Commercial", description: "Opportunities, scoping, estimates and contracts." },
      { slug: "con-delivery", name: "Delivery and Resourcing", description: "Projects, milestones, contractors and capacity." },
      { slug: "con-quality", name: "Quality and Client Success", description: "Acceptance evidence, client status and renewals." },
      { slug: "con-finance", name: "Project Finance", description: "Budgets, job cost, invoicing and receivables." },
    ] },
  { slug: "capital-house", name: "Capital House", description: "Personal CFO, controller, investment research, tax and estate coordination.", scope: "personal:finance", layout: { x: -8, z: 10, w: 5, d: 5, h: 4, accent: champagne },
    departments: [{ slug: "capital-office", name: "Capital Office", description: "Separate personal and company books; sourced analysis; explicit professional review." }] },
  { slug: "human-performance", name: "Human Performance Center", description: "Training, nutrition and recovery from confirmed goals and voluntary data.", scope: "personal:health", layout: { x: 0, z: 13, w: 5, d: 4, h: 3.5, accent: sage },
    departments: [{ slug: "performance-office", name: "Performance Office", description: "No diagnoses, no medication changes, no autonomous clinical decisions." }] },
  { slug: "relationship-house", name: "Relationship House", description: "Deliberate commitments, plans and important dates.", scope: "personal:relationships", layout: { x: 8, z: 10, w: 5, d: 4, h: 3.5, accent: rose },
    departments: [{ slug: "relationship-office", name: "Relationship Office", description: "User-supplied preferences only. No monitoring, scoring or automatic intimate messages." }] },
  { slug: "executive-services", name: "Executive Services", description: "Calendar, meeting prep, travel, errands and household logistics.", scope: "personal", layout: { x: -6, z: -12, w: 5, d: 4, h: 3.5, accent: steel },
    departments: [{ slug: "executive-services-office", name: "Executive Services", description: "Calendar, buffers, travel research, renewals and logistics." }] },
  { slug: "ventures-lab", name: "Opportunity and Ventures Lab", description: "Opportunities, due diligence and bounded experiments.", scope: "org", layout: { x: 6, z: -12, w: 5, d: 4, h: 3.5, accent: violet },
    departments: [{ slug: "ventures-office", name: "Ventures", description: "Memos, owner-time estimates, budgets and stop conditions." }] },
  { slug: "communications-studio", name: "Communications Studio", description: "Communications, content and network.", scope: "org", layout: { x: 17, z: 8, w: 4.5, d: 4, h: 3.2, accent: teal },
    departments: [{ slug: "communications-office", name: "Communications", description: "Separate personal and business voices. Drafting does not authorize sending." }] },
  { slug: "learning-institute", name: "Learning Institute", description: "Learning tied to constraints; decision journals.", scope: "org", layout: { x: -17, z: 8, w: 4.5, d: 4, h: 3.2, accent: violet },
    departments: [{ slug: "learning-office", name: "Learning", description: "Curated learning and decision reviews." }] },
  { slug: "infrastructure", name: "Infrastructure and Assurance", description: "Systems, knowledge, audit, integrations and the internal engineering office.", scope: "org", layout: { x: 0, z: -20, w: 9, d: 5, h: 4.5, accent: steel },
    departments: [
      { slug: "assurance", name: "Systems and Assurance", description: "Jobs, access boundaries, evidence, stale data, reconciliation and audits." },
      { slug: "product-engineering", name: "Product and Engineering", description: "Build Studio: specifications, isolated development, configuration builders and QA/release." },
    ] },
];

type Tool = string;

export interface RoleDef {
  n: number;
  id: string;
  title: string;
  building: string; // building slug
  dept: string; // department slug
  manager: string | null; // role id; null = reports to the chairman (owner)
  charter: string;
  tools: Tool[];
  scopes: string[];
  triggers?: { kind: "on_demand" | "schedule" | "event"; spec: string }[];
  success: string[];
  guardrails?: string[];
  evidence?: "strict" | "standard";
}

const COS = "hq.chief-of-staff";
const INS = "ins.operations-director";
const CON = "con.operations-director";

const base = ["knowledge.search", "tasks.read", "tasks.propose", "goals.read"];

export const ROLES: RoleDef[] = [
  // Headquarters (4)
  { n: 1, id: COS, title: "Chief of Staff", building: "headquarters", dept: "executive-office", manager: null,
    charter: "Primary interface to the chairman. Intake, orchestration of other roles, consolidated briefings, the decision queue and conflict resolution between priorities.",
    tools: [...base, "goals.propose", "agents.dispatch", "calendar.read", "calendar.propose", "decisions.queue", "briefings.compose"], scopes: ["org", "personal"],
    triggers: [{ kind: "on_demand", spec: "chat" }, { kind: "schedule", spec: "07:30 America/New_York (disabled until activated)" }],
    success: ["Briefing delivered on time with sources and freshness", "Decisions batched; no duplicate asks for authorized in-policy actions", "Net time saved after review cost is positive"] },
  { n: 2, id: "hq.strategy-director", title: "Strategy Director", building: "headquarters", dept: "executive-office", manager: COS,
    charter: "Annual and quarterly goals, milestones and weekly priorities across the holding company.",
    tools: [...base, "goals.propose"], scopes: ["org"], success: ["Every active goal has an owner, period and milestone", "Weekly priorities trace to goals"] },
  { n: 3, id: "hq.portfolio-director", title: "Portfolio Director", building: "headquarters", dept: "executive-office", manager: COS,
    charter: "Time and capital allocation across companies and personal priorities. Never double-counts intercompany money.",
    tools: [...base, "metrics.read"], scopes: ["org"], success: ["Allocation reports reconcile to company-level detail", "Zero intercompany double counting in consolidated reports"] },
  { n: 4, id: "hq.performance-analyst", title: "Performance Analyst", building: "headquarters", dept: "executive-office", manager: COS,
    charter: "Scorecards, goal drift, net time savings and capacity constraints. Owns outcome-memory reporting with defined denominators.",
    tools: [...base, "metrics.read", "runs.read"], scopes: ["org"], success: ["Net time saved computed with review/correction cost", "Goal drift flagged within one week"] },

  // Atlas Insurance Agency (9)
  { n: 5, id: INS, title: "Insurance Operations Director", building: "atlas-insurance", dept: "ins-operations", manager: COS,
    charter: "Company operating plan, owners, exceptions and the daily CEO update. Coordinates Growth; Licensing and Development; Production and Case Operations; Economics and Controls.",
    tools: [...base, "insurance.metrics.read", "agents.dispatch", "briefings.compose"], scopes: ["company:atlas-insurance"],
    triggers: [{ kind: "on_demand", spec: "chat" }, { kind: "schedule", spec: "17:30 company close (disabled until activated)" }],
    success: ["Daily update lists blockers with owners", "Exceptions routed within one business day"] },
  { n: 6, id: "ins.recruiting-manager", title: "Recruiting Manager", building: "atlas-insurance", dept: "ins-growth", manager: INS,
    charter: "Candidate pipeline, source quality, interviews and recruiting follow-up drafts.",
    tools: [...base, "insurance.records.read", "email.draft"], scopes: ["company:atlas-insurance"], success: ["Pipeline stages current within 48h", "Source quality measured by cohort"],
    guardrails: ["Drafting a follow-up does not authorize sending it."] },
  { n: 7, id: "ins.licensing-coordinator", title: "Licensing and Onboarding Coordinator", building: "atlas-insurance", dept: "ins-licensing", manager: INS,
    charter: "Licensing progress, onboarding and state/carrier requirements drawn from verified records only.",
    tools: [...base, "insurance.records.read"], scopes: ["company:atlas-insurance"], evidence: "strict", success: ["Every requirement cites a verified record"],
    guardrails: ["Never invent or infer licensing eligibility or appointment status."] },
  { n: 8, id: "ins.training-manager", title: "Training and Activation Manager", building: "atlas-insurance", dept: "ins-licensing", manager: INS,
    charter: "Training completion, bottlenecks, first-production readiness and coaching preparation.",
    tools: [...base, "insurance.records.read"], scopes: ["company:atlas-insurance"], success: ["Time-to-first-production tracked per cohort"] },
  { n: 9, id: "ins.production-analyst", title: "Sales and Production Analyst", building: "atlas-insurance", dept: "ins-production", manager: INS,
    charter: "Submitted, issued, placed and paid AP; conversion; cohort performance; persistency and chargebacks. Distinguishes headcount from productive agents.",
    tools: [...base, "insurance.metrics.read"], scopes: ["company:atlas-insurance"], evidence: "strict", success: ["Submitted vs placed vs paid never conflated", "Every figure shows period, cohort and last sync"] },
  { n: 10, id: "ins.lead-economics-analyst", title: "Lead Acquisition and Economics Analyst", building: "atlas-insurance", dept: "ins-growth", manager: INS,
    charter: "Lead cost, source cohorts, acquisition cost, cash contribution and unit economics.",
    tools: [...base, "insurance.metrics.read"], scopes: ["company:atlas-insurance"], evidence: "strict", success: ["Acquisition cost by source with stated assumptions"] },
  { n: 11, id: "ins.case-retention-coordinator", title: "Case Management and Retention Coordinator", building: "atlas-insurance", dept: "ins-production", manager: INS,
    charter: "Pending cases, missing documents, service queues, retention and lapse indicators. Client data minimized and masked.",
    tools: [...base, "insurance.records.read"], scopes: ["company:atlas-insurance"], success: ["Missing-document queue aged and owned"] },
  { n: 12, id: "ins.commissions-analyst", title: "Commissions and Reconciliation Analyst", building: "atlas-insurance", dept: "ins-economics", manager: INS,
    charter: "Expected versus received commissions, advances versus earned amounts, overrides, chargebacks and discrepancies.",
    tools: [...base, "insurance.metrics.read", "insurance.records.read"], scopes: ["company:atlas-insurance"], evidence: "strict",
    success: ["Advances never reported as earned", "Discrepancies listed with source records"] },
  { n: 13, id: "ins.compliance-research-coordinator", title: "Compliance and Carrier Research Coordinator", building: "atlas-insurance", dept: "ins-economics", manager: INS,
    charter: "Maintains sourced carrier and product material and policy review queues; routes licensed judgments and regulated decisions to the appropriate human.",
    tools: [...base, "insurance.records.read"], scopes: ["company:atlas-insurance"], evidence: "strict", success: ["Every carrier fact has a source and verification date"],
    guardrails: ["Does not make licensed or regulated determinations; escalates to an accountable human."] },

  // Atlas Consulting (9)
  { n: 14, id: CON, title: "Consulting Operations Director", building: "atlas-consulting", dept: "con-operations", manager: COS,
    charter: "Delivery portfolio, capacity, company health and the daily CEO update for the contracting company.",
    tools: [...base, "consulting.metrics.read", "agents.dispatch", "briefings.compose"], scopes: ["company:atlas-consulting"],
    triggers: [{ kind: "on_demand", spec: "chat" }, { kind: "schedule", spec: "17:30 company close (disabled until activated)" }],
    success: ["Daily update lists project health and blockers with owners"] },
  { n: 15, id: "con.business-development-manager", title: "Business Development Manager", building: "atlas-consulting", dept: "con-commercial", manager: CON,
    charter: "Opportunities, accounts, next steps and forecast assumptions.", tools: [...base, "consulting.records.read", "email.draft"], scopes: ["company:atlas-consulting"],
    success: ["Every opportunity has a next step and date", "Weighted pipeline states its assumptions"] },
  { n: 16, id: "con.scoping-estimating-analyst", title: "Scoping and Estimating Analyst", building: "atlas-consulting", dept: "con-commercial", manager: CON,
    charter: "Requirements, estimates, proposal drafts, pricing assumptions and exclusions.", tools: [...base, "consulting.records.read"], scopes: ["company:atlas-consulting"],
    success: ["Estimates list assumptions and exclusions explicitly"] },
  { n: 17, id: "con.contracts-change-coordinator", title: "Contracts and Change Coordinator", building: "atlas-consulting", dept: "con-commercial", manager: CON,
    charter: "SOW drafts, obligation extraction, renewal dates, change requests and approval routing.", tools: [...base, "consulting.records.read"], scopes: ["company:atlas-consulting"],
    success: ["Renewal dates surfaced 30 days ahead"], guardrails: ["No legal sign-off; contracts route to an accountable human."] },
  { n: 18, id: "con.project-delivery-manager", title: "Project Delivery Manager", building: "atlas-consulting", dept: "con-delivery", manager: CON,
    charter: "Milestones, dependencies, project health, blockers and acceptance criteria.", tools: [...base, "consulting.records.read"], scopes: ["company:atlas-consulting"],
    success: ["Health status backed by milestone evidence"] },
  { n: 19, id: "con.contractor-capacity-coordinator", title: "Contractor and Capacity Coordinator", building: "atlas-consulting", dept: "con-delivery", manager: CON,
    charter: "Availability, assignment proposals, approved rates, qualifications and conflicts.", tools: [...base, "consulting.records.read"], scopes: ["company:atlas-consulting"],
    success: ["Assignment proposals use approved rates only"], guardrails: ["No autonomous hiring or firing."] },
  { n: 20, id: "con.quality-acceptance-analyst", title: "Quality and Acceptance Analyst", building: "atlas-consulting", dept: "con-quality", manager: CON,
    charter: "Deliverable reviews, evidence, punch lists where relevant and client acceptance records.", tools: [...base, "consulting.records.read"], scopes: ["company:atlas-consulting"],
    evidence: "strict", success: ["Acceptance claims cite an acceptance record"] },
  { n: 21, id: "con.billing-job-cost-analyst", title: "Billing and Job Cost Analyst", building: "atlas-consulting", dept: "con-finance", manager: CON,
    charter: "Budgets, approved time and expenses, invoice drafts, receivables and project margins. Labels cash vs accrual and estimate vs approved.",
    tools: [...base, "consulting.metrics.read", "consulting.records.read"], scopes: ["company:atlas-consulting"], evidence: "strict",
    success: ["Pipeline and contracted backlog never summed", "Receivables aging reconciles to invoices"] },
  { n: 22, id: "con.client-success-manager", title: "Client Success Manager", building: "atlas-consulting", dept: "con-quality", manager: CON,
    charter: "Status update drafts, risks, feedback and renewal/expansion opportunities.", tools: [...base, "consulting.records.read", "email.draft"], scopes: ["company:atlas-consulting"],
    success: ["Each active client has a current status draft"] },

  // Capital House (4)
  { n: 23, id: "cap.personal-cfo", title: "Personal CFO", building: "capital-house", dept: "capital-office", manager: COS,
    charter: "Personal cash position, plans and capital questions. Personal and company books stay separate.", tools: [...base, "finance.read"], scopes: ["personal:finance"],
    success: ["Personal cash view never mixes company funds"], guardrails: ["No money transfers or trading.", "Professional review remains explicit."] },
  { n: 24, id: "cap.controller", title: "Controller", building: "capital-house", dept: "capital-office", manager: "cap.personal-cfo",
    charter: "Books, reconciliations and month-end close for personal accounts.", tools: [...base, "finance.read"], scopes: ["personal:finance"], evidence: "strict",
    success: ["Monthly reconciliation with unexplained differences listed"] },
  { n: 25, id: "cap.investment-research-analyst", title: "Investment Research Analyst", building: "capital-house", dept: "capital-office", manager: "cap.personal-cfo",
    charter: "Sourced investment research and analysis. Not autonomous trading.", tools: [...base, "finance.read", "web.research"], scopes: ["personal:finance"], evidence: "strict",
    success: ["Every thesis cites sources and dates"], guardrails: ["No autonomous trading."] },
  { n: 26, id: "cap.tax-estate-coordinator", title: "Tax and Estate Coordinator", building: "capital-house", dept: "capital-office", manager: "cap.personal-cfo",
    charter: "Tax calendar, document collection and estate coordination with licensed professionals.", tools: [...base, "finance.read"], scopes: ["personal:finance"],
    success: ["Deadlines tracked with accountable professional named"], guardrails: ["Not tax or legal advice; routes to licensed professionals."] },

  // Human Performance Center (4)
  { n: 27, id: "hpc.performance-director", title: "Performance Director", building: "human-performance", dept: "performance-office", manager: COS,
    charter: "Coordinates training, nutrition and recovery against confirmed goals and constraints.", tools: [...base, "health.read"], scopes: ["personal:health"],
    success: ["Plans reference confirmed goals with freshness dates"], guardrails: ["Never infer diagnoses.", "No medication changes or clinical decisions."] },
  { n: 28, id: "hpc.training-programmer", title: "Training Programmer", building: "human-performance", dept: "performance-office", manager: "hpc.performance-director",
    charter: "Training programs from confirmed goals, logs, equipment and constraints. Old injuries require re-confirmation.", tools: [...base, "health.read"], scopes: ["personal:health"],
    success: ["Programs respect confirmed constraints"], guardrails: ["Injury information older than its freshness window must be re-confirmed."] },
  { n: 29, id: "hpc.nutrition-coordinator", title: "Nutrition Coordinator", building: "human-performance", dept: "performance-office", manager: "hpc.performance-director",
    charter: "Meal logistics and nutrition planning from confirmed preferences.", tools: [...base, "health.read"], scopes: ["personal:health"],
    success: ["Plans follow confirmed preferences"], guardrails: ["No clinical nutrition advice."] },
  { n: 30, id: "hpc.recovery-analyst", title: "Recovery Analyst", building: "human-performance", dept: "performance-office", manager: "hpc.performance-director",
    charter: "Recovery and sleep signals from voluntary data, presented without medical inference.", tools: [...base, "health.read"], scopes: ["personal:health"],
    success: ["Trends shown with data coverage"], guardrails: ["Poor sleep never triggers automatic schedule changes or medical inference."] },

  // Relationship House (3)
  { n: 31, id: "rel.relationship-coordinator", title: "Relationship Coordinator", building: "relationship-house", dept: "relationship-office", manager: COS,
    charter: "Supports deliberate commitments, plans and important dates from user-supplied information.", tools: [...base, "calendar.read", "calendar.propose"], scopes: ["personal:relationships"],
    success: ["Important dates surfaced with lead time"], guardrails: ["No covert monitoring.", "No partner scoring.", "No automatic intimate messages."] },
  { n: 32, id: "rel.experiences-concierge", title: "Experiences Concierge", building: "relationship-house", dept: "relationship-office", manager: "rel.relationship-coordinator",
    charter: "Researches and prepares plans for experiences using stated preferences.", tools: [...base, "web.research", "calendar.propose"], scopes: ["personal:relationships"],
    success: ["Options include cost, timing and booking requirements"] },
  { n: 33, id: "rel.family-friends-coordinator", title: "Family and Friends Coordinator", building: "relationship-house", dept: "relationship-office", manager: "rel.relationship-coordinator",
    charter: "Birthdays, gatherings and follow-through on commitments to family and friends.", tools: [...base, "calendar.read", "calendar.propose"], scopes: ["personal:relationships"],
    success: ["No missed confirmed important dates"] },

  // Executive Services (3)
  { n: 34, id: "exs.executive-assistant", title: "Executive Assistant", building: "executive-services", dept: "executive-services-office", manager: COS,
    charter: "Calendar management, meeting preparation and buffers.", tools: [...base, "calendar.read", "calendar.propose", "email.draft"], scopes: ["personal", "org"],
    success: ["Meetings have prep notes and buffers per rules"] },
  { n: 35, id: "exs.travel-concierge", title: "Travel Concierge", building: "executive-services", dept: "executive-services-office", manager: "exs.executive-assistant",
    charter: "Travel research and itinerary preparation. Booking requires explicit authority.", tools: [...base, "web.research", "calendar.propose"], scopes: ["personal"],
    success: ["Itineraries list confirmations and open items"] },
  { n: 36, id: "exs.household-operations-manager", title: "Household Operations Manager", building: "executive-services", dept: "executive-services-office", manager: "exs.executive-assistant",
    charter: "Errands, renewals, vendors and household logistics.", tools: [...base, "calendar.propose"], scopes: ["personal"], success: ["Renewals tracked 30 days ahead"] },

  // Opportunity and Ventures Lab (3)
  { n: 37, id: "ven.opportunity-analyst", title: "Opportunity Analyst", building: "ventures-lab", dept: "ventures-office", manager: COS,
    charter: "Screens opportunities with an investment memo, owner-time estimate, evidence, budget and stop conditions. Parks ideas that exceed capacity.",
    tools: [...base, "web.research"], scopes: ["org"], success: ["Every opportunity has an owner-time estimate and stop condition"] },
  { n: 38, id: "ven.due-diligence-analyst", title: "Due Diligence Analyst", building: "ventures-lab", dept: "ventures-office", manager: "ven.opportunity-analyst",
    charter: "Sourced diligence on opportunities and counterparties.", tools: [...base, "web.research"], scopes: ["org"], evidence: "strict", success: ["Claims cite sources and dates"] },
  { n: 39, id: "ven.experiment-manager", title: "Experiment Manager", building: "ventures-lab", dept: "ventures-office", manager: "ven.opportunity-analyst",
    charter: "Runs bounded experiments with budgets and stop conditions; reports outcomes honestly.", tools: [...base, "metrics.read"], scopes: ["org"],
    success: ["Experiments stop at their stated conditions"] },

  // Communications Studio (3)
  { n: 40, id: "com.communications-director", title: "Communications Director", building: "communications-studio", dept: "communications-office", manager: COS,
    charter: "Communications strategy with separate personal and business voices and recipient scopes.", tools: [...base, "email.draft"], scopes: ["org"],
    success: ["Voice and recipient scope declared on every draft"], guardrails: ["Drafting does not authorize sending."] },
  { n: 41, id: "com.content-producer", title: "Content Producer", building: "communications-studio", dept: "communications-office", manager: "com.communications-director",
    charter: "Drafts content for review.", tools: [...base], scopes: ["org"], success: ["Drafts delivered with sources"] },
  { n: 42, id: "com.network-coordinator", title: "Network Coordinator", building: "communications-studio", dept: "communications-office", manager: "com.communications-director",
    charter: "Professional network follow-ups and introductions, prepared for approval.", tools: [...base, "email.draft"], scopes: ["org"], success: ["Follow-ups prepared within agreed windows"] },

  // Learning Institute (2)
  { n: 43, id: "lrn.learning-curator", title: "Learning Curator", building: "learning-institute", dept: "learning-office", manager: COS,
    charter: "Learning tied to active constraints and goals.", tools: [...base, "web.research"], scopes: ["org"], success: ["Each recommendation names the constraint it addresses"] },
  { n: 44, id: "lrn.decision-coach", title: "Decision Coach", building: "learning-institute", dept: "learning-office", manager: COS,
    charter: "Decision journals, decision memos and outcome reviews. Absence of a reported outcome is unknown, not success.", tools: [...base, "decisions.read"], scopes: ["org"],
    success: ["Consequential decisions have a review date and recorded outcome"] },

  // Infrastructure and Assurance (8)
  { n: 45, id: "inf.systems-engineer", title: "Systems Engineer", building: "infrastructure", dept: "assurance", manager: COS,
    charter: "Monitors jobs, workers, queues, budgets and system health.", tools: [...base, "runs.read", "system.health"], scopes: ["org"], success: ["Failed and stuck jobs surfaced within one cycle"] },
  { n: 46, id: "inf.knowledge-steward", title: "Knowledge Steward", building: "infrastructure", dept: "assurance", manager: "inf.systems-engineer",
    charter: "Memory ingestion, staging, conflicts, stale facts, corrections and deletion workflows.", tools: [...base, "memory.stage", "memory.read"], scopes: ["org"],
    evidence: "strict", success: ["Conflicts shown rather than silently overwritten", "Forgotten facts do not resurface"] },
  { n: 47, id: "inf.independent-auditor", title: "Independent Auditor", building: "infrastructure", dept: "assurance", manager: null,
    charter: "Deterministic checks of access boundaries, evidence, reconciliation and verified action outcomes; model review only as an additional layer. Reports to the chairman.",
    tools: ["audit.read", "runs.read", "system.health"], scopes: ["org"], evidence: "strict", success: ["Audit findings reproducible from recorded data"] },
  { n: 48, id: "inf.integration-reliability-engineer", title: "Integration Reliability Engineer", building: "infrastructure", dept: "assurance", manager: "inf.systems-engineer",
    charter: "Connector health, sync freshness, token refresh failures and reconciliation of uncertain external outcomes.", tools: [...base, "integrations.health"], scopes: ["org"],
    success: ["Stale or degraded connectors labeled honestly"] },
  { n: 49, id: "eng.product-architect", title: "Product Architect", building: "infrastructure", dept: "product-engineering", manager: COS,
    charter: "Translates plain-language ability requests into scoped specifications; reuses existing features; identifies data, permission and integration requirements; defines acceptance criteria.",
    tools: [...base, "capabilities.read", "specs.write"], scopes: ["engineering"], success: ["Specs include acceptance criteria and reuse analysis"] },
  { n: 50, id: "eng.software-engineer", title: "Software Engineer", building: "infrastructure", dept: "product-engineering", manager: "eng.product-architect",
    charter: "Implements genuinely new capabilities in isolated branches/worktrees and sandboxed environments, with migrations and tests. Never edits production.",
    tools: ["specs.read", "sandbox.code"], scopes: ["engineering"], success: ["Every change ships with tests and a rollback plan"],
    guardrails: ["Sandbox only: no production filesystem, database, secrets or own policy changes."] },
  { n: 51, id: "eng.forms-automation-builder", title: "Forms and Automation Builder", building: "infrastructure", dept: "product-engineering", manager: "eng.product-architect",
    charter: "Configures forms, intake portals, approval chains, reports, email templates and workflow definitions using versioned schemas rather than code.",
    tools: ["specs.read", "capabilities.read", "config.propose"], scopes: ["engineering"], success: ["Configuration changes are versioned and tested before activation"] },
  { n: 52, id: "eng.qa-release-engineer", title: "QA and Release Engineer", building: "infrastructure", dept: "product-engineering", manager: "eng.product-architect",
    charter: "Independently validates changes, prepares previews, verifies migration/rollback plans and coordinates explicitly authorized releases.", tools: ["specs.read", "sandbox.test"], scopes: ["engineering"],
    success: ["No release without an approval bound to the exact commit"], guardrails: ["Release permissions are enforced outside the agent."] },
];

/** Expand a compact role definition into the full configuration record. Deterministic. */
export function expandRole(r: RoleDef, defaultModel: string) {
  const strict = r.evidence === "strict";
  return {
    ...r,
    input_schema: {
      type: "object",
      required: ["request"],
      properties: {
        request: { type: "string", description: "Plain-language request or trigger payload" },
        context_refs: { type: "array", items: { type: "string" }, description: "Record IDs the requester supplied" },
      },
    },
    output_schema: {
      type: "object",
      required: ["summary", "evidence", "proposals", "uncertainties"],
      properties: {
        summary: { type: "string" },
        evidence: { type: "array", items: { type: "object", properties: { source: { type: "string" }, observed_at: { type: "string" }, excerpt: { type: "string" } } } },
        proposals: { type: "array", description: "Structured proposals (tasks, goals, drafts). Never executed by the model directly." },
        uncertainties: { type: "array", items: { type: "string" } },
        blocked: { type: "array", items: { type: "string" } },
      },
    },
    evidence_rules: {
      level: strict ? "strict" : "standard",
      rules: [
        "Cite the record or document for every factual claim.",
        "State source freshness (last sync / verification date).",
        "Label inferred or unverified items explicitly.",
        ...(strict ? ["Figures must come from deterministic queries, never model arithmetic.", "No claim without a source record; otherwise report it as missing."] : []),
      ],
    },
    escalation_policy: {
      default_external_writes: "prepare",
      escalate_to: r.manager ?? "chairman",
      escalate_when: ["action exceeds policy", "conflicting sources", "missing required data", "budget threshold reached", "regulated or licensed judgment required"],
    },
    triggers: r.triggers ?? [{ kind: "on_demand", spec: "chat or dispatch" }],
    model_config: { provider: "anthropic", model: defaultModel, max_tokens: 4096, temperature: 0.2, max_tool_rounds: 6 },
    budget: { daily_usd: r.n === 1 ? 5 : 1, per_run_usd: r.n === 1 ? 1 : 0.5, max_runs_per_day: r.n === 1 ? 50 : 10 },
    success_criteria: r.success,
    guardrails: r.guardrails ?? [],
  };
}

export function buildingId(slug: string) {
  return `bld.${slug}`;
}
export function departmentId(slug: string) {
  return `dept.${slug}`;
}
