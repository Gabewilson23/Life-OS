/**
 * Deterministic run state machine. Approval is separate from execution, and execution is separate from
 * verified success: an external action whose outcome is unknown ends as `failed` with certainty 'uncertain'
 * only after reconciliation; it is never blindly retried.
 */
export const RUN_STATES = ["proposed", "queued", "running", "waiting_approval", "blocked", "succeeded", "failed", "cancelled"] as const;
export type RunState = (typeof RUN_STATES)[number];

const TRANSITIONS: Record<RunState, RunState[]> = {
  proposed: ["queued", "cancelled"],
  queued: ["running", "cancelled", "blocked"],
  running: ["succeeded", "failed", "waiting_approval", "blocked", "cancelled", "queued" /* lease expired -> requeue */],
  waiting_approval: ["queued", "cancelled", "blocked"],
  blocked: ["queued", "cancelled", "failed"],
  succeeded: [],
  failed: ["queued" /* explicit retry after reconciliation */],
  cancelled: [],
};

export const TERMINAL: ReadonlySet<RunState> = new Set(["succeeded", "cancelled"]);

export function canTransition(from: RunState, to: RunState) {
  return TRANSITIONS[from].includes(to);
}

export function assertTransition(from: RunState, to: RunState) {
  if (!canTransition(from, to)) throw new Error(`Illegal run transition ${from} → ${to}`);
}

/** Retry is permitted only when the previous attempt's external outcome is confirmed (not uncertain). */
export function canRetry(run: { state: RunState; attempts: number; max_attempts: number; outcome_certainty: "confirmed" | "uncertain" | null }) {
  return run.state === "failed" && run.attempts < run.max_attempts && run.outcome_certainty !== "uncertain";
}

export const STATE_LABEL: Record<string, string> = {
  idle: "Idle", paused: "Paused", proposed: "Proposed", queued: "Queued", running: "Running", waiting_approval: "Waiting for approval",
  blocked: "Blocked", succeeded: "Complete", failed: "Failed", cancelled: "Cancelled",
};
