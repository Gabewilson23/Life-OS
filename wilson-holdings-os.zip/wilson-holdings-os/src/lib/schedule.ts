/**
 * DST-safe schedule math. Schedules are expressed in local wall-clock time of an IANA timezone.
 * A run is identified by its reporting window key, so it happens at most once per window.
 */
export type Rule = { freq: "daily"; time: string } | { freq: "weekly"; weekday: number; time: string } | { freq: "monthly"; day: number; time: string };

function parts(d: Date, tz: string) {
  const p = new Intl.DateTimeFormat("en-US", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23", weekday: "short" }).formatToParts(d);
  const g = (t: string) => p.find((x) => x.type === t)!.value;
  return { y: +g("year"), m: +g("month"), d: +g("day"), h: +g("hour"), mi: +g("minute"), wd: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].indexOf(g("weekday")) };
}
/** Minutes to add to UTC to get local time at instant d. */
export function tzOffsetMinutes(d: Date, tz: string) {
  const p = parts(d, tz);
  return (Date.UTC(p.y, p.m - 1, p.d, p.h, p.mi) - Math.floor(d.getTime() / 60000) * 60000) / 60000;
}
/**
 * UTC instant for a local date + HH:MM. Nonexistent local times (spring-forward gap) move forward by the gap;
 * ambiguous times (fall-back) resolve to the first occurrence.
 */
export function zonedToUtc(ymd: string, hhmm: string, tz: string): Date {
  const [y, m, d] = ymd.split("-").map(Number) as [number, number, number];
  const [h, mi] = hhmm.split(":").map(Number) as [number, number];
  const wall = Date.UTC(y, m - 1, d, h, mi);
  const candidates = new Set<number>();
  for (const probe of [wall - 12 * 3600_000, wall, wall + 12 * 3600_000]) candidates.add(wall - tzOffsetMinutes(new Date(probe), tz) * 60000);
  const exact = [...candidates].filter((t) => { const p = parts(new Date(t), tz); return p.y === y && p.m === m && p.d === d && p.h === h && p.mi === mi; }).sort((a, b) => a - b);
  if (exact.length) return new Date(exact[0]!);
  // In a gap: use the offset in effect before the transition, which lands after the gap.
  return new Date(wall - tzOffsetMinutes(new Date(wall - 12 * 3600_000), tz) * 60000);
}
export function localYmd(d: Date, tz: string) {
  const p = parts(d, tz);
  return `${p.y}-${String(p.m).padStart(2, "0")}-${String(p.d).padStart(2, "0")}`;
}
function addDays(ymd: string, n: number) {
  const d = new Date(`${ymd}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
function matches(rule: Rule, ymd: string) {
  const d = new Date(`${ymd}T12:00:00Z`);
  if (rule.freq === "daily") return true;
  if (rule.freq === "weekly") return d.getUTCDay() === rule.weekday;
  return d.getUTCDate() === rule.day;
}
export function windowKey(rule: Rule, ymd: string) {
  return rule.freq === "monthly" ? ymd.slice(0, 7) : ymd;
}
/** The window that is due at `now` (most recent occurrence ≤ now, within the catch-up limit), or null. */
export function dueWindow(rule: Rule, tz: string, now: Date, catchupHours = 6) {
  const today = localYmd(now, tz);
  for (let i = 0; i <= 31; i++) {
    const ymd = addDays(today, -i);
    if (!matches(rule, ymd)) continue;
    const at = zonedToUtc(ymd, rule.time, tz);
    if (at.getTime() > now.getTime()) continue;
    if (now.getTime() - at.getTime() > catchupHours * 3600_000) return null;
    return { windowKey: windowKey(rule, ymd), scheduledFor: at, localDate: ymd };
  }
  return null;
}
/** Next occurrence after `now` — for display. */
export function nextRun(rule: Rule, tz: string, now: Date) {
  const today = localYmd(now, tz);
  for (let i = 0; i <= 62; i++) {
    const ymd = addDays(today, i);
    if (!matches(rule, ymd)) continue;
    const at = zonedToUtc(ymd, rule.time, tz);
    if (at > now) return at;
  }
  return null;
}
/** Quiet hours: returns when a non-urgent notification may be delivered. */
export function afterQuietHours(now: Date, tz: string, quiet: { start: string; end: string } | null) {
  if (!quiet) return now;
  const p = parts(now, tz);
  const cur = p.h * 60 + p.mi;
  const toMin = (s: string) => { const [h, m] = s.split(":").map(Number) as [number, number]; return h * 60 + m; };
  const s = toMin(quiet.start), e = toMin(quiet.end);
  const inQuiet = s < e ? cur >= s && cur < e : cur >= s || cur < e;
  if (!inQuiet) return now;
  const ymd = localYmd(now, tz);
  const endDay = s < e || cur < e ? ymd : addDays(ymd, 1);
  return zonedToUtc(endDay, quiet.end, tz);
}
