import { z } from "zod";
import { createProposal } from "../services/proposals";
import { registerTool, tool, type ToolEnv } from "./tools";

/** Tools that depend on integrations and company data (slices 4–5). Registered on import. */

async function writableAccount(env: ToolEnv, capability: string, scope: string, accountId?: string) {
  const rows = (await env.db.query(`SELECT id, label FROM integration_accounts WHERE scope = $1 AND status <> 'revoked' AND $2 = ANY(capabilities) ${accountId ? "AND id = $3" : ""}`, accountId ? [scope, capability, accountId] : [scope, capability])).rows;
  if (rows.length === 1) return rows[0] as { id: string; label: string };
  if (!rows.length) throw new Error(`No connected account in scope "${scope}" grants ${capability}. Ask the chairman to connect one.`);
  throw new Error(`Several accounts could be used (${rows.map((r) => `${r.label}=${r.id}`).join(", ")}); pass account_id.`);
}

registerTool(tool({
  name: "calendar.read", description: "Upcoming events from connected calendars (mirror) in permitted scopes, with last-sync freshness. For availability decisions, note that data may be stale since last sync.",
  input: z.object({ days: z.number().int().min(1).max(31).optional() }),
  async run(env, i) {
    const rows = (await env.db.query(`SELECT e.title, e.starts_at, e.ends_at, e.all_day, e.scope, a.label, e.last_synced_at, e.attendees FROM calendar_events e JOIN integration_accounts a ON a.id = e.account_id WHERE e.starts_at BETWEEN now() - interval '1 hour' AND now() + make_interval(days => $1) ORDER BY e.starts_at LIMIT 100`, [i.days ?? 7])).rows;
    // Relationship/health-scoped events are masked to "Private" unless this run is permitted that scope (RLS already hides them otherwise).
    return { events: rows.map((r) => ({ title: r.scope.startsWith("personal:") ? "Private" : r.title, start: r.starts_at, end: r.ends_at, calendar: r.label, attendees: (r.attendees as unknown[]).length })), freshness: rows[0]?.last_synced_at ?? "no synced calendars" };
  },
}));

registerTool(tool({
  name: "calendar.propose", description: "Propose a calendar event. Creates a proposal; after acceptance it becomes an approval bound to the exact content. Adding attendees sends invitations.",
  input: z.object({ title: z.string().min(1).max(200), start: z.string().describe("ISO 8601 with offset"), end: z.string(), attendees: z.array(z.string().email()).max(20).optional(), scope: z.string().max(60).optional(), account_id: z.string().uuid().optional(), rationale: z.string().max(1000) }),
  async run(env, i) {
    const scope = i.scope ?? env.defaultScope;
    if (!env.ctx.writeScopes.includes(scope)) throw new Error(`Scope ${scope} not permitted`);
    if (!(new Date(i.end) > new Date(i.start))) throw new Error("end must be after start");
    const acct = await writableAccount(env, "calendar.write", scope, i.account_id);
    const id = await createProposal(env.db, { orgId: env.ctx.orgId, scope, runId: env.runId, agentId: env.agentId, kind: "calendar.event.create", title: `Event: ${i.title}`, payload: { accountId: acct.id, title: i.title, start: i.start, end: i.end, attendees: i.attendees ?? [], calendarId: "primary", visibility: "private" }, rationale: i.rationale });
    return { proposal_id: id, account: acct.label, status: "proposed" };
  },
}));

registerTool(tool({
  name: "email.draft", description: "Propose an email draft. Recipients must be confirmed identities (named in the request, known team members or prior attendees). Drafting never sends.",
  input: z.object({ to: z.array(z.string().email()).min(1).max(10), subject: z.string().max(300), body: z.string().max(20000), scope: z.string().max(60).optional(), account_id: z.string().uuid().optional(), rationale: z.string().max(1000) }),
  async run(env, i) {
    const scope = i.scope ?? env.defaultScope;
    if (!env.ctx.writeScopes.includes(scope)) throw new Error(`Scope ${scope} not permitted`);
    const req = String((await env.db.query(`SELECT input FROM runs WHERE id = $1`, [env.runId])).rows[0]?.input?.request ?? "").toLowerCase();
    for (const addr of i.to) {
      const known = req.includes(addr.toLowerCase()) || (await env.db.query(`SELECT 1 FROM human_members WHERE lower(email) = lower($1) UNION SELECT 1 FROM calendar_events WHERE attendees @> $2::jsonb LIMIT 1`, [addr, JSON.stringify([{ email: addr }])])).rowCount;
      if (!known) throw new Error(`Recipient ${addr} is not a confirmed identity. Ask the chairman to confirm the address instead of guessing.`);
    }
    const acct = await writableAccount(env, "gmail.draft", scope, i.account_id).catch(() => null);
    const id = await createProposal(env.db, { orgId: env.ctx.orgId, scope, runId: env.runId, agentId: env.agentId, kind: acct ? "email.draft.create" : "task.create", title: acct ? `Draft email: ${i.subject}` : `Write email: ${i.subject}`,
      payload: acct ? { accountId: acct.id, to: i.to, cc: [], bcc: [], subject: i.subject, body: i.body } : { title: `Send email "${i.subject}" to ${i.to.join(", ")}`, notes: i.body, priority: 2 }, rationale: i.rationale });
    return { proposal_id: id, note: acct ? "Gmail draft proposed" : "No Gmail account for this scope — proposed as a task with the draft text instead" };
  },
}));

// ---- Company data (slice 4): deterministic metrics only; client names masked for agents. ----
import { consultingMetrics, insuranceMetrics, maskName } from "../services/metrics";

const periodInput = z.object({ from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), cohort: z.string().max(10).optional() });

registerTool(tool({
  name: "insurance.metrics.read", description: "Deterministic Atlas Insurance metrics for a period (submitted/issued/placed/paid AP, headcount vs productive, commissions, chargebacks, lead economics) with definitions and data freshness. Cite these numbers; do not recompute.",
  input: periodInput,
  async run(env, i) { if (!env.ctx.scopes.includes("company:atlas-insurance")) throw new Error("No access to Atlas Insurance data"); return insuranceMetrics(env.db, { from: i.from, to: i.to }, i.cohort); },
}));
registerTool(tool({
  name: "consulting.metrics.read", description: "Deterministic Atlas Consulting metrics: backlog (approved) vs weighted pipeline (forecast), job cost, margins (accrual and cash), receivables aging, utilization, per-project detail, freshness.",
  input: periodInput.omit({ cohort: true }),
  async run(env, i) { if (!env.ctx.scopes.includes("company:atlas-consulting")) throw new Error("No access to Atlas Consulting data"); return consultingMetrics(env.db, { from: i.from, to: i.to }, i.to); },
}));
registerTool(tool({
  name: "insurance.records.read", description: "Look up insurance cases or people by key or status. Client names are masked.",
  input: z.object({ dataset: z.enum(["ins_policies", "ins_people", "ins_commissions"]), key: z.string().max(80).optional(), status: z.string().max(40).optional(), limit: z.number().int().min(1).max(50).optional() }),
  async run(env, i) {
    const col = i.dataset === "ins_people" ? "stage" : i.dataset === "ins_policies" ? "status" : "kind";
    const rows = (await env.db.query(`SELECT * FROM ${i.dataset} WHERE ($1::text IS NULL OR external_key = $1) AND ($2::text IS NULL OR ${col} = $2) ORDER BY updated_at DESC LIMIT $3`, [i.key ?? null, i.status ?? null, i.limit ?? 20])).rows;
    return rows.map(({ client_name, row_hash, org_id, ...r }) => ({ ...r, ...(client_name !== undefined ? { client: maskName(client_name) } : {}) }));
  },
}));
registerTool(tool({
  name: "consulting.records.read", description: "Look up consulting projects, opportunities, invoices or time by key/project.",
  input: z.object({ dataset: z.enum(["con_projects", "con_opportunities", "con_invoices", "con_time", "con_expenses", "con_payments"]), key: z.string().max(80).optional(), project: z.string().max(80).optional(), limit: z.number().int().min(1).max(50).optional() }),
  async run(env, i) {
    const hasProject = ["con_invoices", "con_time", "con_expenses"].includes(i.dataset);
    const rows = (await env.db.query(`SELECT * FROM ${i.dataset} WHERE ($1::text IS NULL OR external_key = $1) ${hasProject ? "AND ($2::text IS NULL OR project_key = $2)" : "AND ($2::text IS NULL OR true)"} ORDER BY updated_at DESC LIMIT $3`, [i.key ?? null, i.project ?? null, i.limit ?? 20])).rows;
    return rows.map(({ row_hash, org_id, ...r }) => r);
  },
}));
registerTool(tool({
  name: "metrics.read", description: "Cross-company headline metrics for the holding company: both companies' key figures side by side WITHOUT summing them (no intercompany double counting).",
  input: z.object({ from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) }),
  async run(env, i) {
    const out: Record<string, unknown> = { note: "Company figures are reported separately and never added together." };
    if (env.ctx.scopes.includes("company:atlas-insurance")) out.atlas_insurance = (await insuranceMetrics(env.db, i)).metrics.map((m) => ({ k: m.key, v: m.value, unit: m.unit }));
    else out.atlas_insurance = "no access granted";
    if (env.ctx.scopes.includes("company:atlas-consulting")) out.atlas_consulting = (await consultingMetrics(env.db, i, i.to)).metrics.map((m) => ({ k: m.key, v: m.value, unit: m.unit }));
    else out.atlas_consulting = "no access granted";
    return out;
  },
}));

// ---- Build Studio (slice 7): configuration proposals, never code execution. ----
import { contractorIntakeTemplate, FormDef, WorkflowDef } from "../services/studio";

registerTool(tool({
  name: "config.propose", description: "Propose a new form and/or workflow built from allowlisted field and step types (validated server-side). Creates DRAFT capabilities on acceptance; activation is separate. Use template 'contractor_intake' for contractor intake requests.",
  input: z.object({ template: z.enum(["contractor_intake"]).optional(), scope: z.string().max(60), form: z.object({ name: z.string(), slug: z.string().regex(/^[a-z0-9-]{3,60}$/), definition: z.unknown() }).optional(), workflow: z.object({ name: z.string(), slug: z.string().regex(/^[a-z0-9-]{3,60}$/), definition: z.unknown() }).optional(), rationale: z.string().max(1000) }),
  async run(env, i) {
    // The proposal lives where this role may write (engineering or the target scope); the chairman's acceptance
    // creates the drafts in the target scope using HIS permissions, so the role cannot grant itself access.
    const proposalScope = env.ctx.writeScopes.includes(i.scope) ? i.scope : env.ctx.writeScopes.includes("engineering") ? "engineering" : null;
    if (!proposalScope) throw new Error(`Scope ${i.scope} not permitted`);
    let form = i.form, workflow = i.workflow;
    if (i.template === "contractor_intake") { const t = contractorIntakeTemplate(); form = { name: "Contractor intake", slug: "contractor-intake", definition: t.form }; workflow = { name: "Contractor intake workflow", slug: "contractor-intake-workflow", definition: t.workflow }; }
    if (form) FormDef.parse(form.definition);
    if (workflow) WorkflowDef.parse(workflow.definition);
    const id = await createProposal(env.db, { orgId: env.ctx.orgId, scope: proposalScope, runId: env.runId, agentId: env.agentId, kind: "capability.create", title: `Build: ${form?.name ?? ""}${form && workflow ? " + " : ""}${workflow?.name ?? ""}`, payload: { targetScope: i.scope, form, workflow }, rationale: i.rationale });
    return { proposal_id: id, status: "proposed — drafts are created on acceptance and must be tested/activated in Build Studio" };
  },
}));
