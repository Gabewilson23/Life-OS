import { z } from "zod";
import type { Ctx, Db } from "../db";
import { listGoals, listTasks } from "../services/work";
import { searchMemory, isStale } from "../services/memory";
import { createProposal } from "../services/proposals";

/**
 * Business tools are narrowly typed application functions. The model only sees tools that are both
 * (a) in the role's allowed_tools and (b) implemented here. Each runs inside the agent's effective
 * access context (role data scopes ∩ requesting user's scopes), enforced again by RLS.
 * Tools never execute external writes: anything external becomes a proposal.
 */
export interface ToolEnv {
  db: Db;
  ctx: Ctx;
  runId: string;
  agentId: string;
  depth: number;
  defaultScope: string;
  dispatch?: (agentId: string, request: string) => Promise<string>;
}
export interface ToolDef<S extends z.ZodType = z.ZodType> {
  name: string; // dotted application name, e.g. tasks.read
  description: string;
  input: S;
  run(env: ToolEnv, input: z.infer<S>): Promise<unknown>;
}

/** Preserves input typing per tool while storing heterogeneous tools in one list. */
export function tool<S extends z.ZodType>(d: ToolDef<S>): ToolDef {
  return d as unknown as ToolDef;
}

const scopeArg = z.string().max(60).optional().describe("Scope to use; must be one of your permitted data scopes");

function pickScope(env: ToolEnv, s?: string) {
  const scope = s ?? env.defaultScope;
  if (!env.ctx.writeScopes.includes(scope)) throw new Error(`Scope "${scope}" is not permitted for this run. Permitted: ${env.ctx.writeScopes.join(", ") || "none (read-only)"}`);
  return scope;
}

const TOOLS: ToolDef[] = [
  tool({
    name: "goals.read", description: "List active goals in your permitted scopes, with period, target and progress.",
    input: z.object({}),
    async run(env) { return (await listGoals(env.db)).map((g) => ({ id: g.id, title: g.title, horizon: g.horizon, scope: g.scope, status: g.status, period: [g.periodStart, g.periodEnd], target: g.targetMetric ? `${g.currentValue ?? "?"} / ${g.targetValue ?? "?"} ${g.targetMetric}` : null, progress_note: g.progressNote, updated_at: g.updatedAt })); },
  }),
  tool({
    name: "tasks.read", description: "List open tasks (title, status, priority 0=critical, due date, scope, linked goal).",
    input: z.object({ include_closed: z.boolean().optional() }),
    async run(env, i) { return (await listTasks(env.db, { includeClosed: !!i.include_closed, limit: 100 })).map((t) => ({ id: t.id, title: t.title, status: t.status, priority: t.priority, due: t.dueDate, scope: t.scope, goal: t.goalTitle, blocked_reason: t.blockedReason })); },
  }),
  tool({
    name: "knowledge.search", description: "Search durable memory (facts, preferences, decisions, outcomes) in permitted scopes. Results include source, confidence and freshness.",
    input: z.object({ query: z.string().min(1).max(200), as_of: z.string().optional().describe("ISO date to ask what was true then") }),
    async run(env, i) {
      const rows = await searchMemory(env.db, env.ctx, { text: i.query, asOf: i.as_of, limit: 10 });
      return rows.map((m) => ({ ref: `memory:${m.id.slice(0, 8)}`, type: m.mtype, subject: m.subject, assertion: m.assertion, confidence: m.confidence, source: m.source_kind, observed: m.observed_at, stale: isStale(m), conflicts: m.conflicts_with.length > 0, scope: m.scope }));
    },
  }),
  tool({
    name: "tasks.propose", description: "Propose a new task for the chairman to accept. Does not create it.",
    input: z.object({ title: z.string().min(1).max(300), notes: z.string().max(2000).optional(), priority: z.number().int().min(0).max(3).optional(), due_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), scope: scopeArg, rationale: z.string().max(1000) }),
    async run(env, i) {
      const scope = pickScope(env, i.scope);
      const id = await createProposal(env.db, { orgId: env.ctx.orgId, scope, runId: env.runId, agentId: env.agentId, kind: "task.create", title: `Task: ${i.title}`, payload: { title: i.title, notes: i.notes ?? "", priority: i.priority ?? 2, dueDate: i.due_date ?? null }, rationale: i.rationale });
      return { proposal_id: id, status: "proposed — awaiting the chairman's decision" };
    },
  }),
  tool({
    name: "goals.propose", description: "Propose a goal (annual/quarterly/monthly/weekly) for acceptance. Does not create it.",
    input: z.object({ title: z.string().min(1).max(300), horizon: z.enum(["annual", "quarterly", "monthly", "weekly"]), description: z.string().max(2000).optional(), scope: scopeArg, rationale: z.string().max(1000) }),
    async run(env, i) {
      const scope = pickScope(env, i.scope);
      const id = await createProposal(env.db, { orgId: env.ctx.orgId, scope, runId: env.runId, agentId: env.agentId, kind: "goal.create", title: `Goal: ${i.title}`, payload: { title: i.title, horizon: i.horizon, description: i.description ?? "" }, rationale: i.rationale });
      return { proposal_id: id, status: "proposed" };
    },
  }),
  tool({
    name: "memory.stage", description: "Propose a fact or preference to remember. It is staged for review and is NOT treated as verified until accepted.",
    input: z.object({ subject: z.string().min(1).max(160), assertion: z.string().min(1).max(2000), mtype: z.enum(["identity", "semantic", "episodic", "working", "procedural", "relationship", "outcome"]), scope: scopeArg, rationale: z.string().max(1000) }),
    async run(env, i) {
      const scope = pickScope(env, i.scope);
      const id = await createProposal(env.db, { orgId: env.ctx.orgId, scope, runId: env.runId, agentId: env.agentId, kind: "memory.remember", title: `Remember: ${i.subject}`, payload: { subject: i.subject, assertion: i.assertion, mtype: i.mtype }, rationale: i.rationale });
      return { proposal_id: id, status: "staged for review" };
    },
  }),
  tool({
    name: "agents.dispatch", description: "Ask another role for a bounded contribution. Delegation depth is limited; the sub-run uses the intersection of permissions.",
    input: z.object({ agent_id: z.string().max(80), request: z.string().min(1).max(4000) }),
    async run(env, i) {
      if (!env.dispatch) throw new Error("Delegation depth limit reached; answer with what you have.");
      return { response: await env.dispatch(i.agent_id, i.request) };
    },
  }),
  tool({
    name: "runs.read", description: "Recent agent runs with state, errors and costs (system monitoring).",
    input: z.object({ limit: z.number().int().min(1).max(50).optional() }),
    async run(env, i) { return (await env.db.query(`SELECT id, agent_id, state, blocked_reason, error, cost_usd, created_at FROM runs ORDER BY created_at DESC LIMIT $1`, [i.limit ?? 20])).rows; },
  }),
  tool({
    name: "decisions.read", description: "Recent decisions on proposals (accepted, rejected, executed) for decision reviews.",
    input: z.object({}),
    async run(env) { return (await env.db.query(`SELECT title, kind, status, decided_at, rationale FROM proposals WHERE status <> 'proposed' ORDER BY decided_at DESC NULLS LAST LIMIT 30`)).rows; },
  }),
];

const extra: ToolDef[] = [];
/** Later slices register additional typed tools (company metrics, calendar, email drafts). */
export function registerTool(t: ToolDef) {
  if (!extra.some((x) => x.name === t.name)) extra.push(t);
}
export function allTools(): ToolDef[] {
  return [...TOOLS, ...extra];
}
export function implementedToolNames() {
  return new Set(allTools().map((t) => t.name));
}
export const toModelName = (n: string) => n.replace(/\./g, "__");
export const fromModelName = (n: string) => n.replace(/__/g, ".");

/** JSON Schema for the model from a zod object (zod 4 native). */
export function toolSpecs(allowed: string[]) {
  return allTools().filter((t) => allowed.includes(t.name)).map((t) => ({ name: toModelName(t.name), description: t.description, input_schema: z.toJSONSchema(t.input) as Record<string, unknown> }));
}
