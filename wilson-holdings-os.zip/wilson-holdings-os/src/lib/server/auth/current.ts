import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import type { Ctx } from "../db";
import { SESSION_COOKIE, validateSession, type SessionUser } from "./session";

export async function currentUser(): Promise<SessionUser | null> {
  const jar = await cookies();
  return validateSession(jar.get(SESSION_COOKIE)?.value);
}

export function ctxFor(u: SessionUser): Ctx {
  return { orgId: u.orgId, actorKind: "user", actorId: u.id, scopes: u.readScopes, writeScopes: u.writeScopes };
}

/** For server components: redirects to /login when unauthenticated. */
export async function requirePageUser() {
  const u = await currentUser();
  if (!u) redirect("/login");
  return { user: u, ctx: ctxFor(u) };
}
