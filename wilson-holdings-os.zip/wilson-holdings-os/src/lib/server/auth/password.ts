import crypto from "node:crypto";

const N = 2 ** 15, r = 8, p = 1, KEYLEN = 64, MAXMEM = 64 * 1024 * 1024;

function scrypt(pw: string, salt: Buffer, n: number, rr: number, pp: number): Promise<Buffer> {
  return new Promise((res, rej) =>
    crypto.scrypt(pw.normalize("NFKC"), salt, KEYLEN, { N: n, r: rr, p: pp, maxmem: MAXMEM }, (e, k) => (e ? rej(e) : res(k))),
  );
}

/** Format: scrypt$N$r$p$saltB64$hashB64 */
export async function hashPassword(pw: string) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(pw, salt, N, r, p);
  return `scrypt$${N}$${r}$${p}$${salt.toString("base64")}$${key.toString("base64")}`;
}

export async function verifyPassword(pw: string, stored: string) {
  const parts = stored.split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  const [, n, rr, pp, salt, hash] = parts as [string, string, string, string, string, string];
  const key = await scrypt(pw, Buffer.from(salt, "base64"), Number(n), Number(rr), Number(pp));
  const expected = Buffer.from(hash, "base64");
  return expected.length === key.length && crypto.timingSafeEqual(expected, key);
}

export function passwordProblems(pw: string): string | null {
  if (pw.length < 12) return "Use at least 12 characters.";
  if (pw.length > 256) return "Password is too long.";
  return null;
}
