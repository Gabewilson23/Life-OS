import crypto from "node:crypto";
import { pool } from "../db";

export const SESSION_COOKIE = "wh_session";
export const IDLE_MS = 12 * 60 * 60 * 1000;
export const ABSOLUTE_MS = 7 * 24 * 60 * 60 * 1000;

export function hashToken(token: string) {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export async function createSession(userId: string, meta: { ua?: string | null; ip?: string | null }) {
  const token = crypto.randomBytes(32).toString("base64url");
  const now = Date.now();
  await pool().query(
    `INSERT INTO sessions(id, user_id, idle_expires_at, absolute_expires_at, user_agent, ip) VALUES ($1,$2,$3,$4,$5,$6)`,
    [hashToken(token), userId, new Date(now + IDLE_MS), new Date(now + ABSOLUTE_MS), meta.ua?.slice(0, 300) ?? null, meta.ip ?? null],
  );
  return { token, maxAgeSeconds: Math.floor(ABSOLUTE_MS / 1000) };
}

export interface SessionUser {
  sessionId: string;
  id: string;
  orgId: string;
  email: string;
  displayName: string;
  role: "owner" | "admin" | "member" | "viewer";
  readScopes: string[];
  writeScopes: string[];
}

/** Validates a raw session token; slides the idle window. Returns null if missing/expired/revoked. */
export async function validateSession(token: string | undefined | null): Promise<SessionUser | null> {
  if (!token || token.length > 200) return null;
  const id = hashToken(token);
  const { rows } = await pool().query(
    `SELECT s.id AS sid, u.id, u.org_id, u.email, u.display_name, u.role
       FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.id = $1 AND s.revoked_at IS NULL AND s.idle_expires_at > now() AND s.absolute_expires_at > now() AND u.disabled_at IS NULL`,
    [id],
  );
  const row = rows[0];
  if (!row) return null;
  await pool().query(`UPDATE sessions SET last_seen_at = now(), idle_expires_at = LEAST(absolute_expires_at, now() + $2::interval) WHERE id = $1`, [id, `${IDLE_MS / 1000} seconds`]);
  const grants = await pool().query(`SELECT scope, access FROM user_scope_grants WHERE user_id = $1`, [row.id]);
  const readScopes = grants.rows.map((g) => g.scope as string);
  const writeScopes = grants.rows.filter((g) => g.access === "write").map((g) => g.scope as string);
  return { sessionId: row.sid, id: row.id, orgId: row.org_id, email: row.email, displayName: row.display_name, role: row.role, readScopes, writeScopes };
}

export async function revokeSession(token: string) {
  await pool().query(`UPDATE sessions SET revoked_at = now() WHERE id = $1`, [hashToken(token)]);
}

/** Simple brute-force protection: 10 failures in 15 minutes locks the email. */
export async function isLockedOut(email: string) {
  const { rows } = await pool().query(
    `SELECT count(*)::int AS n FROM login_attempts WHERE email = $1 AND success = false AND at > now() - interval '15 minutes'`,
    [email],
  );
  return rows[0].n >= 10;
}
export async function recordAttempt(email: string, ip: string | null, success: boolean) {
  await pool().query(`INSERT INTO login_attempts(email, ip, success) VALUES ($1,$2,$3)`, [email, ip, success]);
}
