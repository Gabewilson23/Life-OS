import crypto from "node:crypto";

/** RFC 6238 TOTP (SHA-1, 30 s, 6 digits) — compatible with standard authenticator apps. */
const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
export function base32Encode(buf: Buffer) {
  let bits = 0, value = 0, out = "";
  for (const b of buf) { value = (value << 8) | b; bits += 8; while (bits >= 5) { out += B32[(value >>> (bits - 5)) & 31]; bits -= 5; } }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}
export function base32Decode(s: string) {
  const clean = s.replace(/=+$/, "").toUpperCase().replace(/\s/g, "");
  let bits = 0, value = 0; const out: number[] = [];
  for (const c of clean) { const i = B32.indexOf(c); if (i < 0) throw new Error("bad base32"); value = (value << 5) | i; bits += 5; if (bits >= 8) { out.push((value >>> (bits - 8)) & 255); bits -= 8; } }
  return Buffer.from(out);
}
export function newTotpSecret() { return base32Encode(crypto.randomBytes(20)); }
export function totpAt(secret: string, step: number) {
  const msg = Buffer.alloc(8); msg.writeBigUInt64BE(BigInt(step));
  const h = crypto.createHmac("sha1", base32Decode(secret)).update(msg).digest();
  const o = h[h.length - 1]! & 15;
  return String(((h.readUInt32BE(o) & 0x7fffffff) % 1_000_000)).padStart(6, "0");
}
/** Returns the matched time step (±1 step drift), or null. Callers must reject steps ≤ the last used step (replay). */
export function verifyTotp(secret: string, code: string, now = Date.now()) {
  if (!/^\d{6}$/.test(code)) return null;
  const step = Math.floor(now / 30_000);
  for (const s of [step - 1, step, step + 1]) {
    const c = totpAt(secret, s);
    if (crypto.timingSafeEqual(Buffer.from(c), Buffer.from(code))) return s;
  }
  return null;
}
export function otpauthUri(secret: string, account: string) {
  return `otpauth://totp/${encodeURIComponent(`Wilson Holdings:${account}`)}?secret=${secret}&issuer=${encodeURIComponent("Wilson Holdings")}&algorithm=SHA1&digits=6&period=30`;
}
