import pg from "pg";
import { databaseUrl, env } from "./env";

// Return DATE columns as plain strings (no timezone shifting) and BIGINT as string.
pg.types.setTypeParser(1082, (v) => v);

const g = globalThis as unknown as { __whPool?: pg.Pool };

export function pool(): pg.Pool {
  if (!g.__whPool) {
    g.__whPool = new pg.Pool({ connectionString: stripSslMode(databaseUrl()), ssl: sslConfig(), max: env().DATABASE_POOL_MAX, idleTimeoutMillis: 10_000 });
  }
  return g.__whPool;
}

/** sslmode in the URL is ignored; DATABASE_SSL decides (pg's URL sslmode semantics are changing between versions). */
function stripSslMode(url: string) {
  try {
    const u = new URL(url);
    u.searchParams.delete("sslmode");
    return u.toString();
  } catch {
    return url;
  }
}

function sslConfig(): pg.PoolConfig["ssl"] {
  const mode = env().DATABASE_SSL;
  if (mode === "disable") return false;
  if (mode === "require") return { rejectUnauthorized: false };
  const raw = env().DATABASE_CA_CERT;
  if (!raw) throw new Error("DATABASE_SSL=verify requires DATABASE_CA_CERT (PEM or base64-encoded PEM)");
  const ca = raw.includes("BEGIN CERTIFICATE") ? raw.replace(/\\n/g, "\n") : Buffer.from(raw, "base64").toString("utf8");
  return { ca, rejectUnauthorized: true };
}

export type Db = pg.PoolClient;

/**
 * Access context. Every scoped read/write runs inside `withCtx`, which sets transaction-local
 * settings consumed by Postgres row-level-security policies (see db/migrations/001_core.sql).
 * Application code ALSO filters by scope; RLS is the second, data-layer line of defense.
 */
export interface Ctx {
  orgId: string;
  actorKind: "user" | "agent" | "system";
  actorId: string;
  /** Scopes readable in this context. */
  scopes: string[];
  /** Scopes writable in this context (subset of scopes). */
  writeScopes: string[];
  /** System context bypasses RLS. Only for migrations, seed and audited system jobs. */
  system?: boolean;
}

export async function withCtx<T>(ctx: Ctx, fn: (db: Db) => Promise<T>): Promise<T> {
  const client = await pool().connect();
  try {
    await client.query("BEGIN");
    await client.query(
      "SELECT set_config('app.org_id', $1, true), set_config('app.scopes', $2, true), set_config('app.write_scopes', $3, true), set_config('app.actor', $4, true), set_config('app.bypass_rls', $5, true)",
      [ctx.orgId, ctx.scopes.join(","), ctx.writeScopes.join(","), `${ctx.actorKind}:${ctx.actorId}`, ctx.system ? "on" : "off"],
    );
    // Drop to the non-privileged application role so RLS applies even if the connecting role
    // can bypass it (e.g. Supabase's postgres role). System contexts keep the connecting role.
    if (!ctx.system) await client.query("SET LOCAL ROLE wh_app");
    const result = await fn(serialized(client));
    await client.query("COMMIT");
    return result;
  } catch (e) {
    await client.query("ROLLBACK").catch(() => {});
    throw e;
  } finally {
    client.release();
  }
}

/** Queues queries on one transaction client so callers may use Promise.all safely (pg forbids overlapping queries). */
function serialized(client: pg.PoolClient): Db {
  const raw = client.query.bind(client) as (...a: unknown[]) => Promise<unknown>;
  let chain: Promise<unknown> = Promise.resolve();
  return new Proxy(client, {
    get(target, prop, recv) {
      if (prop !== "query") return Reflect.get(target, prop, recv);
      return (...args: unknown[]) => {
        const run = chain.then(() => raw(...args));
        chain = run.catch(() => undefined);
        return run;
      };
    },
  });
}

export function systemCtx(orgId: string, job = "system"): Ctx {
  return { orgId, actorKind: "system", actorId: job, scopes: [], writeScopes: [], system: true };
}

export function actorRef(ctx: Ctx) {
  return `${ctx.actorKind}:${ctx.actorId}`;
}

/** App-level scope checks (RLS enforces the same rules at the data layer). */
export function assertRead(ctx: Ctx, scope: string) {
  if (!ctx.system && !ctx.scopes.includes(scope)) throw new ForbiddenError();
}
export function assertWrite(ctx: Ctx, scope: string) {
  if (!ctx.system && !ctx.writeScopes.includes(scope)) throw new ForbiddenError();
}

export class ConflictError extends Error {
  status = 409;
  constructor(message = "This record was changed by someone else. Reload and try again.") {
    super(message);
  }
}
export class NotFoundError extends Error {
  status = 404;
  constructor(message = "Not found") {
    super(message);
  }
}
export class ForbiddenError extends Error {
  status = 403;
  constructor(message = "You do not have access to this scope") {
    super(message);
  }
}
