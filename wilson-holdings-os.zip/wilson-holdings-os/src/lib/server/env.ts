import { z } from "zod";

const schema = z.object({
  APP_ENV: z.enum(["development", "test", "production"]).default("development"),
  APP_URL: z.string().url().default("http://localhost:3000"),
  DATABASE_URL: z.string().min(1, "DATABASE_URL is required"),
  // disable (local), require (encrypted, no CA check), verify (encrypted + CA check using DATABASE_CA_CERT)
  DATABASE_SSL: z.enum(["disable", "require", "verify"]).default("disable"),
  DATABASE_CA_CERT: z.string().optional().default(""),
  DATABASE_POOL_MAX: z.coerce.number().int().min(1).max(50).default(5),
  // Shared secret for /api/cron/tick (Netlify scheduled function or external cron)
  CRON_SECRET: z.string().optional().default(""),
  // 32-byte key (base64/base64url) for encrypting OAuth tokens at rest
  TOKEN_ENCRYPTION_KEY: z.string().optional().default(""),
  SESSION_SECRET: z.string().min(32, "SESSION_SECRET must be at least 32 characters"),
  SETUP_TOKEN: z.string().optional().default(""),
  DEMO_MODE: z.enum(["true", "false"]).default("false"),
  DEMO_DATABASE_URL: z.string().optional().default(""),
  ANTHROPIC_API_KEY: z.string().optional().default(""),
  ANTHROPIC_MODEL: z.string().default("claude-sonnet-5-5"),
  AGENT_CONCURRENCY: z.coerce.number().int().min(1).max(20).default(3),
  DEFAULT_TIMEZONE: z.string().default("America/New_York"),
  GOOGLE_CLIENT_ID: z.string().optional().default(""),
  GOOGLE_CLIENT_SECRET: z.string().optional().default(""),
});

export type Env = z.infer<typeof schema>;
let cached: Env | null = null;

/** Validates environment once. Throws a readable error listing every invalid key (values are never printed). */
export function env(): Env {
  if (cached) return cached;
  const parsed = schema.safeParse(process.env);
  if (!parsed.success) {
    const keys = parsed.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ");
    throw new Error(`Invalid environment configuration — ${keys}`);
  }
  if (parsed.data.DEMO_MODE === "true" && !parsed.data.DEMO_DATABASE_URL) {
    throw new Error("Invalid environment configuration — DEMO_MODE=true requires DEMO_DATABASE_URL (demo data lives in a separate database)");
  }
  cached = parsed.data;
  return cached;
}

export function isDemo() {
  return env().DEMO_MODE === "true";
}

/** Database URL for the active namespace. Demo mode never touches the real database. */
export function databaseUrl() {
  return isDemo() ? env().DEMO_DATABASE_URL : env().DATABASE_URL;
}
