import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { env } from "./env";
import { ctxFor } from "./auth/current";
import { SESSION_COOKIE, validateSession, type SessionUser } from "./auth/session";
import type { Ctx } from "./db";

export class HttpError extends Error {
  constructor(public status: number, message: string, public details?: unknown) {
    super(message);
  }
}

/** Rejects cross-origin state-changing requests (defense in depth with SameSite=Lax cookies). */
export function assertSameOrigin(req: NextRequest) {
  const origin = req.headers.get("origin");
  if (!origin) throw new HttpError(403, "Missing Origin header");
  const allowed = new Set([new URL(env().APP_URL).origin, req.nextUrl.origin]);
  if (!allowed.has(origin)) throw new HttpError(403, "Cross-origin request rejected");
}

export async function parseJson<T extends z.ZodType>(req: NextRequest, schema: T): Promise<z.infer<T>> {
  if (!(req.headers.get("content-type") ?? "").includes("application/json")) throw new HttpError(415, "Expected application/json");
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    throw new HttpError(400, "Malformed JSON");
  }
  const r = schema.safeParse(body);
  if (!r.success) throw new HttpError(422, "Validation failed", r.error.issues.map((i) => ({ path: i.path.join("."), message: i.message })));
  return r.data;
}

export async function apiUser(req: NextRequest): Promise<{ user: SessionUser; ctx: Ctx }> {
  const u = await validateSession(req.cookies.get(SESSION_COOKIE)?.value);
  if (!u) throw new HttpError(401, "Not signed in");
  return { user: u, ctx: ctxFor(u) };
}

type Handler<P> = (req: NextRequest, params: P) => Promise<Response>;

/** Wraps a route handler: same-origin check for mutations, consistent error JSON, no stack traces leaked. */
export function route<P = unknown>(fn: Handler<P>) {
  return async (req: NextRequest, context: { params: Promise<P> }) => {
    try {
      if (!["GET", "HEAD", "OPTIONS"].includes(req.method)) assertSameOrigin(req);
      return await fn(req, await context.params);
    } catch (e) {
      const err = e as Error & { status?: number; details?: unknown };
      const status = err instanceof HttpError ? err.status : err.status ?? 500;
      if (status >= 500) console.error("[api]", req.method, req.nextUrl.pathname, err);
      return NextResponse.json({ error: status >= 500 ? "Internal error" : err.message, details: (err as HttpError).details }, { status });
    }
  };
}
