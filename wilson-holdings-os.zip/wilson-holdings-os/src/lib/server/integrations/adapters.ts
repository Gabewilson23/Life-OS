import crypto from "node:crypto";
import { withCtx, systemCtx } from "../db";
import { GOOGLE, googleFetch, ProviderError } from "./google";

/**
 * Consistent connector interface. authorize/refresh/revoke live in google.ts (shared OAuth).
 * Every write takes an idempotency key and is verifiable against the provider afterwards.
 */
export interface WriteResult { outcome: "succeeded" | "failed" | "uncertain"; remoteId?: string; response?: unknown; error?: string }
export interface ConnectorAdapter {
  id: string;
  capabilities: { read: string[]; write: string[] };
  health(orgId: string, accountId: string): Promise<{ ok: boolean; detail: string }>;
  pull?(orgId: string, accountId: string): Promise<{ upserted: number; deleted: number; full: boolean }>;
  proposeWrite(kind: string, payload: Record<string, unknown>): { resource: string; discloses: string[]; summary: string };
  executeAuthorizedWrite(orgId: string, accountId: string, kind: string, payload: Record<string, unknown>, idempotencyKey: string): Promise<WriteResult>;
  verify(orgId: string, accountId: string, kind: string, payload: Record<string, unknown>, idempotencyKey: string, remoteId?: string): Promise<{ exists: boolean; remoteId?: string; remote?: unknown }>;
}

/** Google Calendar event IDs allow base32hex [a-v0-9], 5–1024 chars: a hex digest of the key is valid and deterministic. */
export function calendarEventIdFor(key: string) {
  return crypto.createHash("sha256").update(key).digest("hex").slice(0, 40);
}

const isNetworkError = (e: unknown) => e instanceof TypeError || (e as { name?: string })?.name === "AbortError";

export const googleCalendar: ConnectorAdapter = {
  id: "google-calendar",
  capabilities: { read: ["calendars.list", "events.list"], write: ["calendar.event.create", "calendar.event.update", "calendar.event.delete"] },
  async health(orgId, accountId) {
    try {
      const r = await googleFetch(orgId, accountId, `${GOOGLE.apiBase()}/calendar/v3/users/me/calendarList?maxResults=1`);
      return { ok: r.ok, detail: r.ok ? "Calendar API reachable" : `Calendar API ${r.status}` };
    } catch (e) { return { ok: false, detail: (e as Error).message }; }
  },
  async pull(orgId, accountId) {
    return withCtx(systemCtx(orgId, "calendar-sync"), async (db) => {
      const acct = (await db.query(`SELECT scope, settings FROM integration_accounts WHERE id = $1`, [accountId])).rows[0];
      const calendars: string[] = acct.settings?.calendars?.length ? acct.settings.calendars : ["primary"];
      let upserted = 0, deleted = 0, full = false;
      for (const cal of calendars) {
        const cur = (await db.query(`SELECT cursor FROM sync_cursors WHERE account_id = $1 AND resource = $2`, [accountId, `events:${cal}`])).rows[0]?.cursor as string | undefined;
        let pageToken: string | undefined; let nextSync: string | undefined; let useSync = cur;
        for (let page = 0; page < 20; page++) {
          const q = new URLSearchParams({ singleEvents: "true", maxResults: "250", showDeleted: "true" });
          if (useSync) q.set("syncToken", useSync);
          else { q.set("timeMin", new Date(Date.now() - 14 * 86400_000).toISOString()); q.set("timeMax", new Date(Date.now() + 120 * 86400_000).toISOString()); full = true; }
          if (pageToken) q.set("pageToken", pageToken);
          const r = await googleFetch(orgId, accountId, `${GOOGLE.apiBase()}/calendar/v3/calendars/${encodeURIComponent(cal)}/events?${q}`);
          if (r.status === 410) { useSync = undefined; pageToken = undefined; await db.query(`DELETE FROM calendar_events WHERE account_id = $1 AND calendar_id = $2`, [accountId, cal]); continue; } // sync token expired → full resync
          if (!r.ok) throw new ProviderError(r.status, `events.list failed (${r.status})`);
          const body = await r.json();
          for (const ev of body.items ?? []) {
            if (ev.status === "cancelled") { deleted += (await db.query(`DELETE FROM calendar_events WHERE account_id = $1 AND calendar_id = $2 AND remote_id = $3`, [accountId, cal, ev.id])).rowCount ?? 0; continue; }
            const allDay = !!ev.start?.date;
            await db.query(
              `INSERT INTO calendar_events(org_id, scope, account_id, calendar_id, remote_id, etag, title, starts_at, ends_at, all_day, status, visibility, attendees, recurring_event_id, last_synced_at)
               VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14, now())
               ON CONFLICT (account_id, calendar_id, remote_id) DO UPDATE SET etag = EXCLUDED.etag, title = EXCLUDED.title, starts_at = EXCLUDED.starts_at, ends_at = EXCLUDED.ends_at,
                 all_day = EXCLUDED.all_day, status = EXCLUDED.status, visibility = EXCLUDED.visibility, attendees = EXCLUDED.attendees, recurring_event_id = EXCLUDED.recurring_event_id, last_synced_at = now()`,
              [orgId, acct.scope, accountId, cal, ev.id, ev.etag ?? null, ev.summary ?? "(no title)", ev.start?.dateTime ?? ev.start?.date ?? null, ev.end?.dateTime ?? ev.end?.date ?? null, allDay, ev.status ?? "confirmed", ev.visibility ?? null,
                JSON.stringify((ev.attendees ?? []).map((a: { email?: string; responseStatus?: string }) => ({ email: a.email, response: a.responseStatus }))), ev.recurringEventId ?? null],
            );
            upserted++;
          }
          pageToken = body.nextPageToken;
          nextSync = body.nextSyncToken ?? nextSync;
          if (!pageToken) break;
        }
        if (nextSync) await db.query(`INSERT INTO sync_cursors(account_id, resource, cursor) VALUES ($1,$2,$3) ON CONFLICT (account_id, resource) DO UPDATE SET cursor = EXCLUDED.cursor, cursor_version = sync_cursors.cursor_version + 1, updated_at = now()`, [accountId, `events:${cal}`, nextSync]);
      }
      await db.query(`UPDATE integration_accounts SET last_sync_at = now(), status = 'healthy', last_error = NULL WHERE id = $1`, [accountId]);
      return { upserted, deleted, full };
    });
  },
  proposeWrite(kind, p) {
    const attendees = (p.attendees as string[] | undefined) ?? [];
    return {
      resource: String(p.calendarId ?? "primary"),
      discloses: [
        ...(attendees.length ? [`Google will email invitations to ${attendees.length} attendee(s): ${attendees.join(", ")}`] : ["Private time block — no invitations sent"]),
        ...(p.recurrence ? ["Creates a recurring series"] : []),
        ...(kind !== "calendar.event.create" ? [`Changes an existing event (${String(p.eventId)}) — fails if it changed remotely since preview`] : []),
      ],
      summary: `${kind.split(".").pop()} "${String(p.title ?? "")}" ${p.start ? `${String(p.start)} → ${String(p.end)}` : ""}`,
    };
  },
  async executeAuthorizedWrite(orgId, accountId, kind, p, key) {
    const cal = encodeURIComponent(String(p.calendarId ?? "primary"));
    const attendees = (p.attendees as string[] | undefined) ?? [];
    const sendUpdates = attendees.length ? "all" : "none";
    try {
      if (kind === "calendar.event.create") {
        const id = calendarEventIdFor(key);
        const body = { id, summary: p.title, description: p.description ?? "", start: { dateTime: p.start, timeZone: p.timeZone ?? "America/New_York" }, end: { dateTime: p.end, timeZone: p.timeZone ?? "America/New_York" },
          attendees: attendees.map((email) => ({ email })), visibility: p.visibility ?? "private", ...(p.recurrence ? { recurrence: p.recurrence } : {}) };
        const r = await googleFetch(orgId, accountId, `${GOOGLE.apiBase()}/calendar/v3/calendars/${cal}/events?sendUpdates=${sendUpdates}`, { method: "POST", body: JSON.stringify(body) });
        if (r.status === 409) return { outcome: "succeeded", remoteId: id, response: { note: "already existed (idempotent replay)" } };
        if (r.ok) { const j = await r.json(); return { outcome: "succeeded", remoteId: j.id, response: { htmlLink: j.htmlLink, etag: j.etag } }; }
        if (r.status >= 500 || r.status === 429) return { outcome: "uncertain", error: `Provider ${r.status}` };
        return { outcome: "failed", error: `Provider rejected (${r.status}): ${(await r.text()).slice(0, 200)}` };
      }
      if (kind === "calendar.event.update" || kind === "calendar.event.delete") {
        const url = `${GOOGLE.apiBase()}/calendar/v3/calendars/${cal}/events/${encodeURIComponent(String(p.eventId))}?sendUpdates=${sendUpdates}`;
        const headers = p.etag ? { "if-match": String(p.etag) } : undefined;
        const r = kind === "calendar.event.delete"
          ? await googleFetch(orgId, accountId, url, { method: "DELETE", headers })
          : await googleFetch(orgId, accountId, url, { method: "PATCH", headers, body: JSON.stringify({ summary: p.title, start: p.start ? { dateTime: p.start, timeZone: p.timeZone ?? "America/New_York" } : undefined, end: p.end ? { dateTime: p.end, timeZone: p.timeZone ?? "America/New_York" } : undefined }) });
        if (r.status === 412) return { outcome: "failed", error: "The event changed in Google since the preview; not overwritten. Refresh and re-propose." };
        if (r.ok || (kind === "calendar.event.delete" && r.status === 410)) return { outcome: "succeeded", remoteId: String(p.eventId) };
        if (r.status >= 500 || r.status === 429) return { outcome: "uncertain", error: `Provider ${r.status}` };
        return { outcome: "failed", error: `Provider rejected (${r.status})` };
      }
      return { outcome: "failed", error: `Unsupported action ${kind}` };
    } catch (e) {
      if (e instanceof ProviderError) return { outcome: "failed", error: e.message };
      return { outcome: isNetworkError(e) ? "uncertain" : "failed", error: (e as Error).message };
    }
  },
  async verify(orgId, accountId, kind, p, key, remoteId) {
    const cal = encodeURIComponent(String(p.calendarId ?? "primary"));
    const id = kind === "calendar.event.create" ? (remoteId ?? calendarEventIdFor(key)) : String(p.eventId);
    const r = await googleFetch(orgId, accountId, `${GOOGLE.apiBase()}/calendar/v3/calendars/${cal}/events/${encodeURIComponent(id)}`);
    if (r.status === 404 || r.status === 410) return { exists: false };
    if (!r.ok) throw new ProviderError(r.status, `verify failed (${r.status})`);
    const j = await r.json();
    if (kind === "calendar.event.delete") return { exists: j.status !== "cancelled", remoteId: id };
    return { exists: j.status !== "cancelled", remoteId: j.id, remote: { summary: j.summary, start: j.start, end: j.end, etag: j.etag } };
  },
};

function rfc822(p: Record<string, unknown>, key: string) {
  const hdr = (k: string, v: string) => `${k}: ${v.replace(/[\r\n]+/g, " ")}`;
  const lines = [
    hdr("To", ((p.to as string[]) ?? []).join(", ")),
    ...(((p.cc as string[]) ?? []).length ? [hdr("Cc", (p.cc as string[]).join(", "))] : []),
    ...(((p.bcc as string[]) ?? []).length ? [hdr("Bcc", (p.bcc as string[]).join(", "))] : []),
    hdr("Subject", String(p.subject ?? "")),
    hdr("X-WH-Idempotency", key),
    "MIME-Version: 1.0", "Content-Type: text/plain; charset=UTF-8", "", String(p.body ?? ""),
  ];
  return Buffer.from(lines.join("\r\n")).toString("base64url");
}

export const gmail: ConnectorAdapter = {
  id: "gmail",
  capabilities: { read: ["messages.search", "messages.get", "threads.get"], write: ["email.draft.create", "email.send"] },
  async health(orgId, accountId) {
    try { const r = await googleFetch(orgId, accountId, `${GOOGLE.gmailBase()}/gmail/v1/users/me/profile`); return { ok: r.ok, detail: r.ok ? "Gmail API reachable" : `Gmail API ${r.status}` }; }
    catch (e) { return { ok: false, detail: (e as Error).message }; }
  },
  proposeWrite(kind, p) {
    const to = (p.to as string[]) ?? [];
    return { resource: to.join(","), discloses: kind === "email.send" ? [`Sends email from your account to ${[...to, ...((p.cc as string[]) ?? [])].join(", ")}. Provider acceptance is not proof of delivery.`] : ["Creates a draft only — nothing is sent"], summary: `${kind === "email.send" ? "Send" : "Draft"}: "${String(p.subject ?? "")}" to ${to.join(", ")}` };
  },
  async executeAuthorizedWrite(orgId, accountId, kind, p, key) {
    try {
      if (kind === "email.draft.create") {
        const r = await googleFetch(orgId, accountId, `${GOOGLE.gmailBase()}/gmail/v1/users/me/drafts`, { method: "POST", body: JSON.stringify({ message: { raw: rfc822(p, key), ...(p.threadId ? { threadId: p.threadId } : {}) } }) });
        if (r.ok) { const j = await r.json(); return { outcome: "succeeded", remoteId: j.id, response: { messageId: j.message?.id, threadId: j.message?.threadId } }; }
        if (r.status >= 500 || r.status === 429) return { outcome: "uncertain", error: `Provider ${r.status}` };
        return { outcome: "failed", error: `Provider rejected (${r.status})` };
      }
      if (kind === "email.send") {
        // Sends an existing synced draft by id; the draft is created first in the same approval if needed.
        const r = await googleFetch(orgId, accountId, `${GOOGLE.gmailBase()}/gmail/v1/users/me/drafts/send`, { method: "POST", body: JSON.stringify({ id: p.remoteDraftId }) });
        if (r.ok) { const j = await r.json(); return { outcome: "succeeded", remoteId: j.id, response: { threadId: j.threadId, providerStatus: "accepted" } }; }
        if (r.status >= 500 || r.status === 429) return { outcome: "uncertain", error: `Provider ${r.status}` };
        return { outcome: "failed", error: `Provider rejected (${r.status})` };
      }
      return { outcome: "failed", error: `Unsupported action ${kind}` };
    } catch (e) {
      if (e instanceof ProviderError) return { outcome: "failed", error: e.message };
      return { outcome: isNetworkError(e) ? "uncertain" : "failed", error: (e as Error).message };
    }
  },
  async verify(orgId, accountId, kind, p, key, remoteId) {
    if (kind === "email.send") {
      // A sent message exists in SENT with our idempotency header.
      const q = new URLSearchParams({ q: `in:sent subject:"${String(p.subject ?? "").replace(/"/g, "")}"`, maxResults: "10" });
      const r = await googleFetch(orgId, accountId, `${GOOGLE.gmailBase()}/gmail/v1/users/me/messages?${q}`);
      if (!r.ok) throw new ProviderError(r.status, "verify failed");
      for (const m of (await r.json()).messages ?? []) {
        const g = await googleFetch(orgId, accountId, `${GOOGLE.gmailBase()}/gmail/v1/users/me/messages/${m.id}?format=metadata&metadataHeaders=X-WH-Idempotency`);
        const hs = (await g.json()).payload?.headers ?? [];
        if (hs.some((h: { name: string; value: string }) => h.name.toLowerCase() === "x-wh-idempotency" && h.value === key)) return { exists: true, remoteId: m.id };
      }
      return { exists: false };
    }
    if (remoteId) {
      const r = await googleFetch(orgId, accountId, `${GOOGLE.gmailBase()}/gmail/v1/users/me/drafts/${remoteId}?format=metadata`);
      return { exists: r.ok, remoteId };
    }
    const r = await googleFetch(orgId, accountId, `${GOOGLE.gmailBase()}/gmail/v1/users/me/drafts?maxResults=50`);
    if (!r.ok) throw new ProviderError(r.status, "verify failed");
    for (const d of (await r.json()).drafts ?? []) {
      const g = await googleFetch(orgId, accountId, `${GOOGLE.gmailBase()}/gmail/v1/users/me/drafts/${d.id}?format=metadata`);
      const hs = (await g.json()).message?.payload?.headers ?? [];
      if (hs.some((h: { name: string; value: string }) => h.name.toLowerCase() === "x-wh-idempotency" && h.value === key)) return { exists: true, remoteId: d.id };
    }
    return { exists: false };
  },
};

export async function gmailSearch(orgId: string, accountId: string, query: string, max = 10) {
  const r = await googleFetch(orgId, accountId, `${GOOGLE.gmailBase()}/gmail/v1/users/me/messages?${new URLSearchParams({ q: query, maxResults: String(max) })}`);
  if (!r.ok) throw new ProviderError(r.status, `Gmail search failed (${r.status})`);
  const out = [];
  for (const m of (await r.json()).messages ?? []) {
    const g = await googleFetch(orgId, accountId, `${GOOGLE.gmailBase()}/gmail/v1/users/me/messages/${m.id}?format=metadata&metadataHeaders=From&metadataHeaders=Subject&metadataHeaders=Date`);
    const j = await g.json();
    const h = (n: string) => j.payload?.headers?.find((x: { name: string }) => x.name === n)?.value ?? "";
    out.push({ id: m.id, threadId: j.threadId, from: h("From"), subject: h("Subject"), date: h("Date"), snippet: j.snippet ?? "" });
  }
  return out;
}

export async function driveList(orgId: string, accountId: string, query?: string) {
  const q = new URLSearchParams({ pageSize: "25", fields: "files(id,name,mimeType,modifiedTime,webViewLink)", q: query ? `name contains '${query.replace(/'/g, "\\'")}' and trashed = false` : "trashed = false", orderBy: "modifiedTime desc" });
  const r = await googleFetch(orgId, accountId, `${GOOGLE.apiBase()}/drive/v3/files?${q}`);
  if (!r.ok) throw new ProviderError(r.status, `Drive list failed (${r.status})`);
  return (await r.json()).files ?? [];
}

/** Reads a Drive file as text (Google Docs exported to text/plain; plain-text files downloaded). */
export async function driveReadText(orgId: string, accountId: string, fileId: string, mimeType: string) {
  const id = encodeURIComponent(fileId);
  const url = mimeType === "application/vnd.google-apps.document" ? `${GOOGLE.apiBase()}/drive/v3/files/${id}/export?mimeType=text/plain`
    : mimeType === "application/vnd.google-apps.spreadsheet" ? `${GOOGLE.apiBase()}/drive/v3/files/${id}/export?mimeType=text/csv`
      : `${GOOGLE.apiBase()}/drive/v3/files/${id}?alt=media`;
  const r = await googleFetch(orgId, accountId, url);
  if (!r.ok) throw new ProviderError(r.status, `Drive read failed (${r.status})`);
  return (await r.text()).slice(0, 2_000_000);
}

export const ADAPTERS: Record<string, ConnectorAdapter> = { "calendar.event.create": googleCalendar, "calendar.event.update": googleCalendar, "calendar.event.delete": googleCalendar, "email.draft.create": gmail, "email.send": gmail };
