import { z } from "zod";
import { systemCtx, withCtx, type Ctx } from "../db";
import { decrypt } from "../crypto";
import { assertSafeOutboundUrl } from "../net";
import { upsertRecords } from "../services/imports";
import { datasetById } from "../../company/datasets";

/**
 * Atlas CRM custom REST adapter. The live API contract is NOT verified, so this adapter speaks a documented,
 * minimal contract (docs/CONNECTORS.md) and is exercised only against a local contract-test server.
 *   GET  {base}/capabilities -> {"version": "1", "resources": [{"name": "agents", "fields": [...]}]}
 *   GET  {base}/agents?cursor=  -> {"items": [...], "next_cursor": string|null}
 * Field mapping (CRM field -> dataset field) is configuration, not guessed.
 */
const Capabilities = z.object({ version: z.string(), resources: z.array(z.object({ name: z.string(), fields: z.array(z.string()) })) });

async function call(cfg: { base_url: string; auth_header: string; secret_enc: string | null; trusted_internal: boolean }, path: string) {
  const url = new URL(path, cfg.base_url.endsWith("/") ? cfg.base_url : cfg.base_url + "/");
  await assertSafeOutboundUrl(url.toString(), { trustedInternal: cfg.trusted_internal });
  const res = await fetch(url, { headers: cfg.secret_enc ? { [cfg.auth_header]: decrypt(cfg.secret_enc) } : {}, redirect: "error", signal: AbortSignal.timeout(15_000) });
  if (!res.ok) throw new Error(`Atlas CRM ${path} returned ${res.status}`);
  return res.json();
}

export async function discoverAtlasCrm(orgId: string, configId: string) {
  const s = systemCtx(orgId, "atlas-crm");
  const cfg = (await withCtx(s, (db) => db.query(`SELECT * FROM connector_configs WHERE id = $1`, [configId]))).rows[0];
  const caps = Capabilities.parse(await call(cfg, "capabilities"));
  await withCtx(s, (db) => db.query(`UPDATE connector_configs SET discovered = $2, status = 'authorized', last_error = NULL WHERE id = $1`, [configId, caps]));
  return caps;
}

/** Pulls agents into the insurance people dataset using the configured mapping, with cursor pagination. */
export async function pullAtlasCrmAgents(ctx: Ctx, configId: string) {
  const s = systemCtx(ctx.orgId, "atlas-crm");
  const cfg = (await withCtx(s, (db) => db.query(`SELECT * FROM connector_configs WHERE id = $1`, [configId]))).rows[0];
  const mapping = cfg.mapping as { key: string; fields: Record<string, string> };
  if (!mapping?.key || !mapping.fields) throw new Error("Configure the field mapping first (no endpoints or fields are guessed).");
  const ds = datasetById("ins_people")!;
  let cursor: string | null = null; let total = { inserted: 0, updated: 0, unchanged: 0, rejected: 0 };
  for (let page = 0; page < 50; page++) {
    const body = (await call(cfg, `agents${cursor ? `?cursor=${encodeURIComponent(cursor)}` : ""}`)) as { items: Record<string, unknown>[]; next_cursor: string | null };
    const rows = body.items.map((it) => ({ key: String(it[mapping.key] ?? ""), raw: Object.fromEntries(Object.entries(mapping.fields).map(([crmField, dsField]) => [dsField, it[crmField] == null ? "" : String(it[crmField])])) }));
    const r = await withCtx(ctx, (db) => upsertRecords(db, ctx, ds, cfg.scope, rows, { source: `atlas-crm:${configId}` }));
    total = { inserted: total.inserted + r.inserted, updated: total.updated + r.updated, unchanged: total.unchanged + r.unchanged, rejected: total.rejected + r.rejected };
    cursor = body.next_cursor;
    if (!cursor) break;
  }
  await withCtx(s, (db) => db.query(`UPDATE connector_configs SET last_sync_at = now(), status = 'healthy' WHERE id = $1`, [configId]));
  return total;
}
