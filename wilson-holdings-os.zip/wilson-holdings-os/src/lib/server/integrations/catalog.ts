/** Integration marketplace. Statuses are honest: an entry is only "adapter implemented" if code exists here. */
export type CatalogStatus = "catalog-only" | "adapter implemented" | "unsupported";
export interface CatalogEntry { id: string; name: string; category: string; status: CatalogStatus; read: string[]; write: string[]; notes: string }

export const CATALOG: CatalogEntry[] = [
  { id: "google-calendar", name: "Google Calendar", category: "Calendar", status: "adapter implemented", read: ["calendars", "events (incremental sync)"], write: ["create/update/delete event (approval-gated, verified)"], notes: "OAuth with PKCE; per-account read/write capability selection." },
  { id: "gmail", name: "Gmail", category: "Email", status: "adapter implemented", read: ["search", "message metadata"], write: ["draft create (approval-gated)", "send (separately gated)"], notes: "The gmail.compose scope technically allows sending; the app gates sending with its own approvals." },
  { id: "google-drive", name: "Google Drive", category: "Files", status: "adapter implemented", read: ["list files", "read/export Docs & Sheets as text/CSV"], write: [], notes: "Read-only (drive.readonly)." },
  { id: "csv-xlsx", name: "CSV / XLSX import", category: "Data", status: "adapter implemented", read: ["mapping preview, validation, dedupe, provenance"], write: [], notes: "Both companies." },
  { id: "webhooks", name: "Generic webhooks", category: "Automation", status: "adapter implemented", read: ["signed inbound"], write: ["signed outbound to allowlisted HTTPS destinations"], notes: "HMAC-SHA256 signatures, timestamp replay window, SSRF protection." },
  { id: "atlas-crm", name: "Atlas CRM (custom REST)", category: "CRM", status: "adapter implemented", read: ["capability discovery", "records via configured mapping"], write: [], notes: "Contract-tested against a local server only. Live use is blocked until a verified API contract and credentials exist." },
  ...[
    ["microsoft-365", "Microsoft Outlook / 365 Calendar / OneDrive / Teams", "Productivity"], ["google-sheets", "Google Sheets (write)", "Data"], ["slack", "Slack", "Messaging"], ["zoom", "Zoom", "Meetings"],
    ["twilio", "Twilio SMS", "Messaging"], ["telegram", "Telegram", "Messaging"], ["whatsapp", "WhatsApp Business", "Messaging"], ["groupme", "GroupMe", "Messaging"],
    ["quickbooks", "QuickBooks", "Finance (read-only default)"], ["xero", "Xero", "Finance (read-only default)"], ["stripe", "Stripe", "Finance (read-only default)"], ["bank-aggregation", "Bank data aggregation", "Finance (read-only default)"],
    ["hubspot", "HubSpot", "CRM"], ["salesforce", "Salesforce", "CRM"], ["gohighlevel", "GoHighLevel", "CRM"], ["airtable", "Airtable", "Data"], ["notion", "Notion", "Docs"], ["asana", "Asana", "Tasks"], ["clickup", "ClickUp", "Tasks"], ["monday", "Monday", "Tasks"], ["trello", "Trello", "Tasks"],
    ["docusign", "DocuSign", "Signing (explicit authority)"], ["whoop", "WHOOP", "Health"], ["oura", "Oura", "Health"], ["fitbit", "Fitbit", "Health"], ["garmin", "Garmin", "Health"], ["strava", "Strava", "Health"],
    ["calendly", "Calendly", "Scheduling"], ["github", "GitHub", "Engineering"], ["dropbox", "Dropbox", "Files"], ["s3", "S3-compatible storage", "Files"], ["zapier", "Zapier / Make / n8n", "Automation"], ["mcp", "Approved MCP servers", "Automation"],
  ].map(([id, name, category]) => ({ id: id!, name: name!, category: category!, status: "catalog-only" as const, read: [], write: [], notes: "Not implemented. Provider availability and scopes must be verified before this is labeled supported." })),
  { id: "apple-health", name: "Apple Health", category: "Health", status: "unsupported", read: [], write: [], notes: "A web app cannot read HealthKit directly. Requires a companion iOS app or an authorized export file import." },
];
