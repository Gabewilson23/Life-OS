/**
 * Minimal GitHub REST client for the Build Studio code path. Uses a repository-scoped token from server env
 * (GITHUB_TOKEN, GITHUB_REPO). Never available to business agents; production secrets are not involved.
 */
export function githubConfig() {
  const token = process.env.GITHUB_TOKEN ?? "", repo = process.env.GITHUB_REPO ?? "";
  return token && /^[\w.-]+\/[\w.-]+$/.test(repo) ? { token, repo, base: process.env.GITHUB_API_BASE ?? "https://api.github.com" } : null;
}
async function gh(path: string, init: RequestInit = {}) {
  const c = githubConfig();
  if (!c) throw new Error("GitHub is not configured (GITHUB_TOKEN, GITHUB_REPO).");
  const res = await fetch(`${c.base}/repos/${c.repo}${path}`, { ...init, headers: { authorization: `Bearer ${c.token}`, accept: "application/vnd.github+json", "x-github-api-version": "2022-11-28", ...(init.body ? { "content-type": "application/json" } : {}) } });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) { const e = new Error(`GitHub ${init.method ?? "GET"} ${path} → ${res.status}: ${(body as { message?: string }).message ?? ""}`) as Error & { status: number }; e.status = res.status; throw e; }
  return body as Record<string, unknown>;
}
export async function createBranchWithSpec(branch: string, path: string, content: string, title: string, bodyText: string) {
  const repo = await gh("");
  const def = repo.default_branch as string;
  const ref = await gh(`/git/ref/heads/${encodeURIComponent(def)}`);
  await gh(`/git/refs`, { method: "POST", body: JSON.stringify({ ref: `refs/heads/${branch}`, sha: (ref.object as { sha: string }).sha }) });
  await gh(`/contents/${path}`, { method: "PUT", body: JSON.stringify({ message: `Change request spec: ${title}`, content: Buffer.from(content).toString("base64"), branch }) });
  const pr = await gh(`/pulls`, { method: "POST", body: JSON.stringify({ title, head: branch, base: def, body: bodyText, draft: true }) });
  return { prNumber: pr.number as number, headSha: (pr.head as { sha: string }).sha, url: pr.html_url as string };
}
export async function prState(prNumber: number) {
  const pr = await gh(`/pulls/${prNumber}`);
  const sha = (pr.head as { sha: string }).sha;
  const checks = await gh(`/commits/${sha}/check-runs`);
  const runs = (checks.check_runs as { name: string; status: string; conclusion: string | null }[]) ?? [];
  return { sha, merged: !!pr.merged, draft: !!pr.draft, checks: runs.map((r) => ({ name: r.name, status: r.status, conclusion: r.conclusion })) };
}
/** Merges ONLY if the PR head still equals the approved SHA (GitHub enforces `sha`). */
export async function mergeAtSha(prNumber: number, sha: string) {
  return gh(`/pulls/${prNumber}/merge`, { method: "PUT", body: JSON.stringify({ sha, merge_method: "squash" }) });
}
