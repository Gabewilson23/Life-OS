import crypto from "node:crypto";
import { pool, withCtx, systemCtx, type Ctx } from "../db";
import { env } from "../env";
import { decrypt, encrypt, redact } from "../crypto";

/**
 * Google OAuth 2.0 (authorization code + PKCE S256 + state) and token lifecycle.
 * Endpoints are configurable so contract tests can run against a local fake server.
 */
export const GOOGLE = {
  authUrl: () => process.env.GOOGLE_AUTH_URL ?? "https://accounts.google.com/o/oauth2/v2/auth",
  tokenUrl: () => process.env.GOOGLE_TOKEN_URL ?? "https://oauth2.googleapis.com/token",
  revokeUrl: () => process.env.GOOGLE_REVOKE_URL ?? "https://oauth2.googleapis.com/revoke",
  apiBase: () => process.env.GOOGLE_API_BASE ?? "https://www.googleapis.com",
  gmailBase: () => process.env.GOOGLE_GMAIL_BASE ?? "https://gmail.googleapis.com",
};

export const CAPABILITY_SCOPES: Record<string, string[]> = {
  "calendar.read": ["https://www.googleapis.com/auth/calendar.readonly"],
  "calendar.write": ["https://www.googleapis.com/auth/calendar.events"],
  "gmail.read": ["https://www.googleapis.com/auth/gmail.readonly"],
  // gmail.compose permits creating drafts AND sending; sending is additionally gated by app policy/approvals.
  "gmail.draft": ["https://www.googleapis.com/auth/gmail.compose"],
  "drive.read": ["https://www.googleapis.com/auth/drive.readonly"],
};

export function googleConfigured() {
  return !!(env().GOOGLE_CLIENT_ID && env().GOOGLE_CLIENT_SECRET);
}
export function redirectUri() {
  return `${env().APP_URL.replace(/\/$/, "")}/api/integrations/google/callback`;
}

export async function beginGoogleAuth(ctx: Ctx, p: { scope: string; label: string; capabilities: string[] }) {
  if (!googleConfigured()) throw new Error("Google OAuth is not configured (GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET).");
  const state = crypto.randomBytes(24).toString("base64url");
  const verifier = crypto.randomBytes(48).toString("base64url");
  const challenge = crypto.createHash("sha256").update(verifier).digest("base64url");
  await pool().query(
    `INSERT INTO oauth_states(state, org_id, user_id, provider, account_scope, label, capabilities, code_verifier, expires_at) VALUES ($1,$2,$3,'google',$4,$5,$6,$7, now() + interval '10 minutes')`,
    [state, ctx.orgId, ctx.actorId, p.scope, p.label, p.capabilities, verifier],
  );
  const scopes = ["openid", "email", ...p.capabilities.flatMap((c) => CAPABILITY_SCOPES[c] ?? [])];
  const u = new URL(GOOGLE.authUrl());
  u.search = new URLSearchParams({
    client_id: env().GOOGLE_CLIENT_ID, redirect_uri: redirectUri(), response_type: "code", scope: scopes.join(" "),
    access_type: "offline", prompt: "consent", include_granted_scopes: "true", state, code_challenge: challenge, code_challenge_method: "S256",
  }).toString();
  return u.toString();
}

/** Validates state (single use, unexpired, same user), exchanges the code with the PKCE verifier, stores encrypted tokens. */
export async function completeGoogleAuth(userId: string, state: string, code: string) {
  const st = (await pool().query(`DELETE FROM oauth_states WHERE state = $1 RETURNING *`, [state])).rows[0];
  if (!st || st.user_id !== userId || new Date(st.expires_at) < new Date()) throw new Error("Invalid or expired OAuth state. Start the connection again.");
  const res = await fetch(GOOGLE.tokenUrl(), {
    method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ code, client_id: env().GOOGLE_CLIENT_ID, client_secret: env().GOOGLE_CLIENT_SECRET, redirect_uri: redirectUri(), grant_type: "authorization_code", code_verifier: st.code_verifier }),
  });
  const tok = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(redact(`Token exchange failed (${res.status}): ${JSON.stringify(tok).slice(0, 300)}`));
  const granted = String(tok.scope ?? "").split(" ").filter(Boolean);
  const caps = (st.capabilities as string[]).filter((c) => (CAPABILITY_SCOPES[c] ?? []).every((s) => granted.includes(s)));
  let email: string | null = null;
  try {
    const ui = await fetch(`${GOOGLE.apiBase()}/oauth2/v3/userinfo`, { headers: { authorization: `Bearer ${tok.access_token}` } });
    if (ui.ok) email = (await ui.json()).email ?? null;
  } catch { /* optional */ }
  return withCtx(systemCtx(st.org_id, "oauth"), async (db) => {
    const { rows } = await db.query(
      `INSERT INTO integration_accounts(org_id, scope, provider, label, external_account, status, capabilities, scopes_granted, access_token_enc, refresh_token_enc, token_expires_at, created_by)
       VALUES ($1,$2,'google',$3,$4,'authorized',$5,$6,$7,$8, now() + make_interval(secs => $9), $10) RETURNING id`,
      [st.org_id, st.account_scope, st.label, email, caps, granted, encrypt(tok.access_token), tok.refresh_token ? encrypt(tok.refresh_token) : null, Number(tok.expires_in ?? 3600), `user:${userId}`],
    );
    await db.query(`INSERT INTO audit_events(org_id, scope, actor, action, resource_type, resource_id, summary) VALUES ($1,$2,$3,'integration.connect','integration_account',$4,$5)`,
      [st.org_id, st.account_scope, `user:${userId}`, rows[0].id, `Connected Google account ${email ?? ""} (${caps.join(", ") || "no capabilities granted"})${caps.length < st.capabilities.length ? " — some requested scopes were not granted" : ""}`]);
    return { id: rows[0].id as string, partial: caps.length < st.capabilities.length };
  });
}

export class ProviderError extends Error {
  constructor(public status: number, message: string, public body?: unknown) { super(redact(message)); }
}

/**
 * Returns a valid access token, refreshing under a row lock so concurrent workers don't race the refresh.
 * Revoked/paused accounts never yield a token.
 */
export async function accessToken(orgId: string, accountId: string): Promise<string> {
  return withCtx(systemCtx(orgId, "token"), async (db) => {
    const a = (await db.query(`SELECT * FROM integration_accounts WHERE id = $1 FOR UPDATE`, [accountId])).rows[0];
    if (!a) throw new ProviderError(404, "Integration account not found");
    if (a.status === "revoked") throw new ProviderError(401, "Integration account is revoked");
    if (a.paused) throw new ProviderError(423, "Integration account is paused");
    if (a.token_expires_at && new Date(a.token_expires_at).getTime() - Date.now() > 60_000) return decrypt(a.access_token_enc);
    if (!a.refresh_token_enc) throw new ProviderError(401, "No refresh token; reconnect the account");
    const res = await fetch(GOOGLE.tokenUrl(), { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ client_id: env().GOOGLE_CLIENT_ID, client_secret: env().GOOGLE_CLIENT_SECRET, refresh_token: decrypt(a.refresh_token_enc), grant_type: "refresh_token" }) });
    const tok = await res.json().catch(() => ({}));
    if (!res.ok) {
      const revoked = tok.error === "invalid_grant";
      await db.query(`UPDATE integration_accounts SET status = $2, last_error = $3, updated_at = now() WHERE id = $1`, [accountId, revoked ? "revoked" : "degraded", redact(`refresh failed: ${tok.error ?? res.status}`)]);
      throw new ProviderError(res.status, revoked ? "Google access was revoked; reconnect the account" : "Token refresh failed");
    }
    await db.query(`UPDATE integration_accounts SET access_token_enc = $2, token_expires_at = now() + make_interval(secs => $3), status = CASE WHEN status IN ('degraded','stale') THEN 'healthy' ELSE status END, updated_at = now() WHERE id = $1`,
      [accountId, encrypt(tok.access_token), Number(tok.expires_in ?? 3600)]);
    return tok.access_token as string;
  });
}

export async function googleFetch(orgId: string, accountId: string, url: string, init: RequestInit = {}) {
  const token = await accessToken(orgId, accountId);
  for (let attempt = 0; ; attempt++) {
    const res = await fetch(url, { ...init, headers: { ...(init.headers ?? {}), authorization: `Bearer ${token}`, ...(init.body ? { "content-type": "application/json" } : {}) } });
    if ((res.status === 429 || res.status >= 500) && attempt < 2 && (init.method ?? "GET") === "GET") {
      await new Promise((r) => setTimeout(r, 300 * 2 ** attempt)); // backoff for idempotent reads only
      continue;
    }
    return res;
  }
}

export async function revokeGoogle(ctx: Ctx, accountId: string) {
  const a = await withCtx(systemCtx(ctx.orgId, "revoke"), (db) => db.query(`SELECT * FROM integration_accounts WHERE id = $1`, [accountId])).then((r) => r.rows[0]);
  if (!a || !ctx.writeScopes.includes(a.scope)) throw new Error("Not permitted");
  try {
    const t = a.refresh_token_enc ? decrypt(a.refresh_token_enc) : a.access_token_enc ? decrypt(a.access_token_enc) : null;
    if (t) await fetch(GOOGLE.revokeUrl(), { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ token: t }) });
  } catch { /* still revoke locally */ }
  await withCtx(systemCtx(ctx.orgId, "revoke"), async (db) => {
    await db.query(`UPDATE integration_accounts SET status = 'revoked', access_token_enc = NULL, refresh_token_enc = NULL, updated_at = now(), version = version + 1 WHERE id = $1`, [accountId]);
    // Pending approvals for this account can no longer execute.
    await db.query(`UPDATE approvals SET status = 'revoked' WHERE account_id = $1 AND status IN ('pending','approved')`, [accountId]);
    await db.query(`INSERT INTO audit_events(org_id, scope, actor, action, resource_type, resource_id, summary) VALUES ($1,$2,$3,'integration.revoke','integration_account',$4,'Revoked Google account access')`, [ctx.orgId, a.scope, `user:${ctx.actorId}`, accountId]);
  });
}
