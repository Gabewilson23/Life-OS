import fs from "node:fs";
import path from "node:path";
import { pool } from "./db";

const DIR = path.join(process.cwd(), "db", "migrations");

/** Applies db/migrations/*.sql in order, each in its own transaction, recording checksums. */
export async function runMigrations(): Promise<string[]> {
  const c = await pool().connect();
  const applied: string[] = [];
  try {
    await c.query("SELECT pg_advisory_lock(727001)");
    await c.query(`CREATE TABLE IF NOT EXISTS schema_migrations (name text PRIMARY KEY, checksum text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now())`);
    const done = new Map((await c.query("SELECT name, checksum FROM schema_migrations")).rows.map((r) => [r.name, r.checksum]));
    const files = fs.readdirSync(DIR).filter((f) => f.endsWith(".sql")).sort();
    for (const f of files) {
      const sql = fs.readFileSync(path.join(DIR, f), "utf8");
      const sum = (await import("node:crypto")).createHash("sha256").update(sql).digest("hex");
      if (done.has(f)) {
        if (done.get(f) !== sum) throw new Error(`Migration ${f} was modified after being applied. Create a new migration instead.`);
        continue;
      }
      await c.query("BEGIN");
      try {
        await c.query(sql);
        await c.query("INSERT INTO schema_migrations(name, checksum) VALUES ($1, $2)", [f, sum]);
        await c.query("COMMIT");
        applied.push(f);
      } catch (e) {
        await c.query("ROLLBACK");
        throw new Error(`Migration ${f} failed: ${(e as Error).message}`);
      }
    }
  } finally {
    await c.query("SELECT pg_advisory_unlock(727001)").catch(() => {});
    c.release();
  }
  return applied;
}
