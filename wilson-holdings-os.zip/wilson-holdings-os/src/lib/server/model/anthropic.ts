import type { ContentBlock, ModelAdapter, ModelRequest, ModelResult } from "./types";

/**
 * Direct Anthropic Messages API adapter (streaming SSE). Server-side only.
 * Docs: https://docs.claude.com/en/api/messages-streaming
 */
export class AnthropicAdapter implements ModelAdapter {
  readonly name = "anthropic";
  constructor(private apiKey: string, private baseUrl = "https://api.anthropic.com") {}

  available() {
    return this.apiKey ? ({ ok: true } as const) : ({ ok: false, reason: "ANTHROPIC_API_KEY is not configured on the server" } as const);
  }

  async complete(req: ModelRequest, onText: (d: string) => void): Promise<ModelResult> {
    const res = await fetch(`${this.baseUrl}/v1/messages`, {
      method: "POST",
      signal: req.signal,
      headers: { "content-type": "application/json", "x-api-key": this.apiKey, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: req.model, system: req.system, messages: req.messages, max_tokens: req.maxTokens, temperature: req.temperature, stream: true,
        ...(req.tools.length ? { tools: req.tools } : {}),
      }),
    });
    if (!res.ok || !res.body) {
      const body = await res.text().catch(() => "");
      throw new Error(`Model API error ${res.status}: ${body.slice(0, 300)}`);
    }
    const blocks: (ContentBlock & { _json?: string })[] = [];
    let stopReason = "end_turn";
    const usage = { inputTokens: 0, outputTokens: 0 };
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = "";
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let idx;
      while ((idx = buf.indexOf("\n\n")) >= 0) {
        const chunk = buf.slice(0, idx);
        buf = buf.slice(idx + 2);
        const line = chunk.split("\n").find((l) => l.startsWith("data:"));
        if (!line) continue;
        const ev = JSON.parse(line.slice(5).trim());
        switch (ev.type) {
          case "message_start":
            usage.inputTokens = ev.message?.usage?.input_tokens ?? 0;
            break;
          case "content_block_start":
            blocks[ev.index] = ev.content_block.type === "tool_use" ? { type: "tool_use", id: ev.content_block.id, name: ev.content_block.name, input: {}, _json: "" } : { type: "text", text: "" };
            break;
          case "content_block_delta": {
            const b = blocks[ev.index]!;
            if (ev.delta.type === "text_delta" && b.type === "text") { b.text += ev.delta.text; onText(ev.delta.text); }
            if (ev.delta.type === "input_json_delta" && b.type === "tool_use") b._json += ev.delta.partial_json;
            break;
          }
          case "content_block_stop": {
            const b = blocks[ev.index];
            if (b?.type === "tool_use") { b.input = b._json ? JSON.parse(b._json) : {}; delete b._json; }
            break;
          }
          case "message_delta":
            stopReason = ev.delta?.stop_reason ?? stopReason;
            usage.outputTokens = ev.usage?.output_tokens ?? usage.outputTokens;
            break;
          case "error":
            throw new Error(`Model stream error: ${ev.error?.message ?? "unknown"}`);
        }
      }
    }
    return { content: blocks.filter(Boolean) as ContentBlock[], stopReason, usage };
  }
}
