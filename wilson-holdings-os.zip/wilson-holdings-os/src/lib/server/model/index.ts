import { env, isDemo } from "../env";
import { AnthropicAdapter } from "./anthropic";
import { ScriptedAdapter } from "./scripted";
import type { ModelAdapter } from "./types";

let override: ModelAdapter | null = null;
/** Tests inject a scripted adapter. */
export function setModelAdapterForTests(a: ModelAdapter | null) { override = a; }

export function modelAdapter(): ModelAdapter {
  if (override) return override;
  if (isDemo() && !env().ANTHROPIC_API_KEY) {
    return new ScriptedAdapter(() => ({ content: [{ type: "text", text: "[DEMO] This is a scripted demo response. No model was called and no real data was analyzed." }], stopReason: "end_turn", usage: { inputTokens: 0, outputTokens: 0 } }));
  }
  return new AnthropicAdapter(env().ANTHROPIC_API_KEY);
}

/** Cost estimate only when pricing is configured; otherwise null ("unknown"), never invented. */
export function estimateCost(inputTokens: number, outputTokens: number): number | null {
  const inP = Number(process.env.MODEL_PRICE_INPUT_PER_MTOK ?? "");
  const outP = Number(process.env.MODEL_PRICE_OUTPUT_PER_MTOK ?? "");
  if (!inP || !outP) return null;
  return (inputTokens / 1e6) * inP + (outputTokens / 1e6) * outP;
}
