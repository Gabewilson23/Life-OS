import type { ModelAdapter, ModelRequest, ModelResult } from "./types";

/**
 * Deterministic scripted adapter for automated tests and clearly-labeled demo mode.
 * Output from this adapter is always marked is_demo on runs/messages.
 */
export class ScriptedAdapter implements ModelAdapter {
  readonly name = "scripted";
  calls: ModelRequest[] = [];
  constructor(private script: (req: ModelRequest, turn: number) => ModelResult) {}
  available() { return { ok: true } as const; }
  async complete(req: ModelRequest, onText: (d: string) => void) {
    this.calls.push(req);
    const r = this.script(req, this.calls.length - 1);
    for (const b of r.content) if (b.type === "text") onText(b.text);
    return r;
  }
}
