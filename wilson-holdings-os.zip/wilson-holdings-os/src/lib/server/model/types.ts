/** Provider-neutral model runtime interface. Application agents never see API keys. */
export interface ToolSpec { name: string; description: string; input_schema: Record<string, unknown> }
export type ContentBlock =
  | { type: "text"; text: string }
  | { type: "tool_use"; id: string; name: string; input: Record<string, unknown> }
  | { type: "tool_result"; tool_use_id: string; content: string; is_error?: boolean };
export interface ModelMessage { role: "user" | "assistant"; content: string | ContentBlock[] }
export interface ModelRequest { model: string; system: string; messages: ModelMessage[]; tools: ToolSpec[]; maxTokens: number; temperature: number; signal?: AbortSignal }
export interface ModelResult { content: ContentBlock[]; stopReason: string; usage: { inputTokens: number; outputTokens: number } }

export interface ModelAdapter {
  readonly name: string;
  available(): { ok: true } | { ok: false; reason: string };
  /** Streams text deltas through onText and resolves with the complete assistant turn. */
  complete(req: ModelRequest, onText: (delta: string) => void): Promise<ModelResult>;
}
