import dns from "node:dns/promises";
import net from "node:net";

/** SSRF guard for outbound HTTP to user-configured destinations. */
function isPrivate(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split(".").map(Number) as [number, number];
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
  }
  const v = ip.toLowerCase();
  return v === "::1" || v === "::" || v.startsWith("fc") || v.startsWith("fd") || v.startsWith("fe80") || v.startsWith("ff") || (v.startsWith("::ffff:") && isPrivate(v.slice(7)));
}

export async function assertSafeOutboundUrl(raw: string, opts: { trustedInternal?: boolean } = {}) {
  let u: URL;
  try { u = new URL(raw); } catch { throw new Error("Invalid URL"); }
  if (u.username || u.password) throw new Error("Credentials in URLs are not allowed");
  if (opts.trustedInternal) { if (!["https:", "http:"].includes(u.protocol)) throw new Error("Only http(s)"); return u; }
  if (u.protocol !== "https:") throw new Error("Outbound destinations must use https");
  if (["metadata.google.internal", "metadata", "localhost"].includes(u.hostname.toLowerCase())) throw new Error("Destination not allowed");
  const addrs = net.isIP(u.hostname) ? [{ address: u.hostname }] : await dns.lookup(u.hostname, { all: true });
  if (!addrs.length || addrs.some((a) => isPrivate(a.address))) throw new Error("Destination resolves to a private, loopback, link-local or metadata address");
  return u;
}
export const _isPrivateForTests = isPrivate;
