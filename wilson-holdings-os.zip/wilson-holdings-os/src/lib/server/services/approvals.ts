import { z } from "zod";
import { assertWrite, ConflictError, ForbiddenError, NotFoundError, systemCtx, withCtx, type Ctx, type Db } from "../db";
import { ADAPTERS } from "../integrations/adapters";
import { audit } from "./audit";
import { stableHash } from "./proposals";

/**
 * Approval → execution → verification. Approval is separate from execution, execution from verified success.
 * An approval binds: action kind, scope (company), account, resource, payload content hash, amount, timing, expiry.
 * Any material change produces a different hash and invalidates it. One approval → at most one action attempt.
 */
export const EXTERNAL_KINDS = ["calendar.event.create", "calendar.event.update", "calendar.event.delete", "email.draft.create", "email.send"] as const;
export type ExternalKind = (typeof EXTERNAL_KINDS)[number];

export const ApprovalRequest = z.object({
  kind: z.enum(EXTERNAL_KINDS),
  scope: z.string().min(1).max(60),
  accountId: z.string().uuid(),
  payload: z.record(z.string(), z.unknown()),
  amountCents: z.number().int().nullable().optional(),
  notBefore: z.string().datetime().nullable().optional(),
  expiresInHours: z.number().min(0.1).max(24 * 14).default(48),
  proposalId: z.string().uuid().nullable().optional(),
});

export function approvalHash(a: { kind: string; scope: string; accountId: string | null; resource: string; payload: unknown; amountCents?: number | null; notBefore?: string | null }) {
  return stableHash({ kind: a.kind, scope: a.scope, account: a.accountId, resource: a.resource, payload: a.payload, amount: a.amountCents ?? null, notBefore: a.notBefore ? new Date(a.notBefore).toISOString() : null });
}

async function matchingStandingPermission(db: Db, ctx: Ctx, kind: string, accountId: string, payload: Record<string, unknown>) {
  const perms = (await db.query(`SELECT * FROM standing_permissions WHERE action_kind = $1 AND (account_id IS NULL OR account_id = $2) AND revoked_at IS NULL`, [kind, accountId])).rows;
  for (const p of perms) {
    const c = p.constraints as { no_attendees?: boolean; private_only?: boolean; max_per_day?: number };
    if (c.no_attendees && ((payload.attendees as unknown[]) ?? []).length) continue;
    if (c.private_only && payload.visibility && payload.visibility !== "private") continue;
    if (c.max_per_day) {
      const n = (await db.query(`SELECT count(*)::int n FROM approvals WHERE via_standing_permission = $1 AND created_at > now() - interval '1 day'`, [p.id])).rows[0].n;
      if (n >= c.max_per_day) continue;
    }
    return p as { id: string; description: string };
  }
  return null;
}

export async function requestApproval(db: Db, ctx: Ctx, raw: z.input<typeof ApprovalRequest>) {
  const r = ApprovalRequest.parse(raw);
  assertWrite(ctx, r.scope);
  const acct = (await db.query(`SELECT id, scope, status, capabilities FROM integration_accounts WHERE id = $1`, [r.accountId])).rows[0];
  if (!acct) throw new NotFoundError("Integration account not found in your scopes");
  if (acct.scope !== r.scope) throw new ForbiddenError("This account belongs to a different company/scope; cross-company actions are not allowed.");
  const needed = r.kind.startsWith("calendar") ? "calendar.write" : "gmail.draft";
  if (!(acct.capabilities as string[]).includes(needed)) throw new ForbiddenError(`The account was not granted ${needed}.`);
  const adapter = ADAPTERS[r.kind]!;
  const preview = adapter.proposeWrite(r.kind, r.payload);
  const hash = approvalHash({ kind: r.kind, scope: r.scope, accountId: r.accountId, resource: preview.resource, payload: r.payload, amountCents: r.amountCents, notBefore: r.notBefore });
  const standing = await matchingStandingPermission(db, ctx, r.kind, r.accountId, r.payload);
  const { rows } = await db.query(
    `INSERT INTO approvals(org_id, scope, proposal_id, action_kind, account_id, resource, payload, content_hash, amount_cents, not_before, expires_at, status, via_standing_permission, discloses, requested_by, decided_by, decided_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10, now() + make_interval(secs => $11), $12, $13, $14, $15, $16, CASE WHEN $12 = 'approved' THEN now() END) RETURNING id`,
    [ctx.orgId, r.scope, r.proposalId ?? null, r.kind, r.accountId, preview.resource, r.payload, hash, r.amountCents ?? null, r.notBefore ?? null, Math.round(r.expiresInHours * 3600),
      standing ? "approved" : "pending", standing?.id ?? null, preview.discloses, `${ctx.actorKind}:${ctx.actorId}`, standing ? `policy:${standing.id}` : null],
  );
  await audit(db, ctx, { scope: r.scope, action: standing ? "approval.auto_approved" : "approval.request", type: "approval", id: rows[0].id, summary: `${preview.summary}${standing ? ` — approved by standing permission "${standing.description}"` : " — awaiting approval"}` });
  return { id: rows[0].id as string, status: standing ? "approved" : "pending", hash, preview };
}

/** Converts an accepted agent proposal for an external action into an approval request. */
export async function requestApprovalFromProposal(db: Db, ctx: Ctx, p: { id: string; scope: string; kind: string; payload: Record<string, unknown> }) {
  const kind = p.kind as ExternalKind;
  if (!(EXTERNAL_KINDS as readonly string[]).includes(kind)) throw new ConflictError(`Unsupported proposal kind ${p.kind}`);
  const { accountId, ...payload } = p.payload as { accountId?: string };
  if (!accountId) throw new ConflictError("The proposal does not name a connected account.");
  return (await requestApproval(db, ctx, { kind, scope: p.scope, accountId, payload, proposalId: p.id })).id;
}

export async function decideApproval(db: Db, ctx: Ctx, id: string, approve: boolean, seenHash: string) {
  const seen = (await db.query(`SELECT scope FROM approvals WHERE id = $1`, [id])).rows[0];
  if (!seen) throw new NotFoundError("Approval not found");
  assertWrite(ctx, seen.scope);
  const a = (await db.query(`SELECT * FROM approvals WHERE id = $1 FOR UPDATE`, [id])).rows[0];
  if (a.status !== "pending") throw new ConflictError(`Approval is ${a.status}.`);
  if (a.content_hash !== seenHash) throw new ConflictError("The action changed since you reviewed it. Review it again.");
  if (new Date(a.expires_at) < new Date()) {
    await db.query(`UPDATE approvals SET status = 'expired' WHERE id = $1`, [id]);
    throw new ConflictError("Approval expired.");
  }
  await db.query(`UPDATE approvals SET status = $2, decided_by = $3, decided_at = now(), version = version + 1 WHERE id = $1`, [id, approve ? "approved" : "denied", `user:${ctx.actorId}`]);
  await audit(db, ctx, { scope: a.scope, action: approve ? "approval.approve" : "approval.deny", type: "approval", id, summary: `${approve ? "Approved" : "Denied"} ${a.action_kind}` });
  return { status: approve ? "approved" : "denied" };
}

export async function revokeApproval(db: Db, ctx: Ctx, id: string) {
  const a = (await db.query(`SELECT scope, status FROM approvals WHERE id = $1`, [id])).rows[0];
  if (!a) throw new NotFoundError();
  assertWrite(ctx, a.scope);
  if (!["pending", "approved"].includes(a.status)) throw new ConflictError(`Approval is ${a.status}.`);
  await db.query(`UPDATE approvals SET status = 'revoked', version = version + 1 WHERE id = $1`, [id]);
  await audit(db, ctx, { scope: a.scope, action: "approval.revoke", type: "approval", id, summary: "Revoked approval" });
}

/**
 * Executes an approved action exactly once. Rechecks immediately before the write: approval status,
 * expiry, timing, content hash, global pause, account pause/revocation, and the user's write scope.
 */
export async function executeApproval(ctx: Ctx, approvalId: string) {
  const s = systemCtx(ctx.orgId, "actions");
  const claim = await withCtx(s, async (db) => {
    const a = (await db.query(`SELECT * FROM approvals WHERE id = $1 FOR UPDATE`, [approvalId])).rows[0];
    if (!a) throw new NotFoundError("Approval not found");
    if (!ctx.system && !ctx.writeScopes.includes(a.scope)) throw new ForbiddenError();
    if (a.status === "consumed") throw new ConflictError("This approval was already used. One approval cannot produce a second action.");
    if (a.status !== "approved") throw new ConflictError(`Approval is ${a.status}; it cannot execute.`);
    if (new Date(a.expires_at) < new Date()) { await db.query(`UPDATE approvals SET status = 'expired' WHERE id = $1`, [approvalId]); throw new ConflictError("Approval expired."); }
    if (a.not_before && new Date(a.not_before) > new Date()) throw new ConflictError("Not yet allowed to execute (not_before).");
    const adapter = ADAPTERS[a.action_kind]!;
    const resource = adapter.proposeWrite(a.action_kind, a.payload).resource;
    if (approvalHash({ kind: a.action_kind, scope: a.scope, accountId: a.account_id, resource, payload: a.payload, amountCents: a.amount_cents == null ? null : Number(a.amount_cents), notBefore: a.not_before ? new Date(a.not_before).toISOString() : null }) !== a.content_hash)
      throw new ConflictError("Approved content does not match; refusing to execute.");
    const paused = (await db.query(`SELECT value FROM system_flags WHERE org_id = $1 AND key = 'pause.global'`, [ctx.orgId])).rows[0]?.value === true;
    if (paused) throw new ConflictError("Global pause is engaged; external writes are stopped.");
    const acct = (await db.query(`SELECT status, paused FROM integration_accounts WHERE id = $1`, [a.account_id])).rows[0];
    if (!acct || acct.status === "revoked") { await db.query(`UPDATE approvals SET status = 'revoked' WHERE id = $1`, [approvalId]); throw new ConflictError("The account was revoked; the approval is void."); }
    if (acct.paused) throw new ConflictError("The connector is paused.");
    if ((await db.query(`SELECT value FROM system_flags WHERE org_id = $1 AND key = $2`, [ctx.orgId, `pause.scope:${a.scope}`])).rows[0]?.value === true) throw new ConflictError("This company is paused.");
    await db.query(`UPDATE approvals SET status = 'consumed', version = version + 1 WHERE id = $1`, [approvalId]);
    const key = `approval:${approvalId}`;
    const att = await db.query(`INSERT INTO action_attempts(org_id, scope, approval_id, idempotency_key, action_kind, account_id, state, request) VALUES ($1,$2,$3,$4,$5,$6,'executing',$7) RETURNING id`,
      [ctx.orgId, a.scope, approvalId, key, a.action_kind, a.account_id, a.payload]);
    return { a, key, attemptId: att.rows[0].id as string };
  });
  return performAttempt(ctx, claim.attemptId);
}

/** Runs (or re-runs after reconciliation) the provider call for an attempt, then verifies the remote object. */
async function performAttempt(ctx: Ctx, attemptId: string) {
  const s = systemCtx(ctx.orgId, "actions");
  const att = (await withCtx(s, (db) => db.query(`SELECT * FROM action_attempts WHERE id = $1`, [attemptId]))).rows[0];
  const adapter = ADAPTERS[att.action_kind]!;
  await withCtx(s, (db) => db.query(`UPDATE action_attempts SET tries = tries + 1, state = 'executing', updated_at = now() WHERE id = $1`, [attemptId]));
  const result = await adapter.executeAuthorizedWrite(ctx.orgId, att.account_id, att.action_kind, att.request, att.idempotency_key);
  let verified = false, remoteId = result.remoteId ?? null, state: string = result.outcome;
  if (result.outcome !== "failed") {
    try {
      const v = await adapter.verify(ctx.orgId, att.account_id, att.action_kind, att.request, att.idempotency_key, remoteId ?? undefined);
      verified = att.action_kind.endsWith(".delete") ? !v.exists : v.exists;
      if (verified) { state = "succeeded"; remoteId = v.remoteId ?? remoteId; }
      else if (result.outcome === "uncertain") state = "failed"; // confirmed absent: safe to retry later
    } catch { if (result.outcome === "succeeded") state = "succeeded"; /* verification unavailable: keep outcome, verified=false */ }
  }
  await withCtx(s, async (db) => {
    await db.query(`UPDATE action_attempts SET state = $2, verified = $3, remote_id = $4, response = $5, error = $6, updated_at = now(), verified_at = CASE WHEN $3 THEN now() END WHERE id = $1`,
      [attemptId, state, verified, remoteId, JSON.stringify(result.response ?? null), result.error ?? null]);
    await afterAction(db, att, state, remoteId);
    await db.query(`INSERT INTO audit_events(org_id, scope, actor, action, resource_type, resource_id, summary, after) VALUES ($1,$2,$3,$4,'action_attempt',$5,$6,$7)`,
      [ctx.orgId, att.scope, `${ctx.actorKind}:${ctx.actorId}`, `action.${state}`, attemptId, `${att.action_kind}: ${state}${verified ? " (verified)" : ""}${remoteId ? ` remote ${remoteId}` : ""}${result.error ? ` — ${result.error}` : ""}`, { remoteId, verified }]);
  });
  return { attemptId, state, verified, remoteId, error: result.error };
}

async function afterAction(db: Db, att: { action_kind: string; request: Record<string, unknown>; scope: string; org_id: string; account_id: string }, state: string, remoteId: string | null) {
  if (state !== "succeeded") return;
  if (att.action_kind === "email.draft.create" && att.request.localDraftId) await db.query(`UPDATE email_drafts SET remote_draft_id = $2, sync_state = 'synced', account_id = $3, updated_at = now() WHERE id = $1`, [att.request.localDraftId, remoteId, att.account_id]);
  if (att.action_kind === "email.send" && att.request.localDraftId) await db.query(`UPDATE email_drafts SET sync_state = 'sent', provider_status = 'accepted', updated_at = now() WHERE id = $1`, [att.request.localDraftId]);
  if (att.action_kind === "calendar.event.create" && remoteId) {
    const p = att.request;
    await db.query(`INSERT INTO calendar_events(org_id, scope, account_id, calendar_id, remote_id, title, starts_at, ends_at, attendees, visibility) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT (account_id, calendar_id, remote_id) DO NOTHING`,
      [att.org_id, att.scope, att.account_id, String(p.calendarId ?? "primary"), remoteId, String(p.title ?? ""), p.start ?? null, p.end ?? null, JSON.stringify(((p.attendees as string[]) ?? []).map((e) => ({ email: e }))), String(p.visibility ?? "private")]);
  }
}

/**
 * Reconciles an uncertain or failed attempt before any retry: if the remote object exists, mark succeeded;
 * otherwise re-execute with the SAME idempotency key (never a blind resend).
 */
export async function reconcileAttempt(ctx: Ctx, attemptId: string, opts: { retryIfAbsent?: boolean } = {}) {
  const s = systemCtx(ctx.orgId, "reconcile");
  const att = (await withCtx(s, (db) => db.query(`SELECT * FROM action_attempts WHERE id = $1`, [attemptId]))).rows[0];
  if (!att) throw new NotFoundError();
  if (!ctx.system && !ctx.writeScopes.includes(att.scope)) throw new ForbiddenError();
  if (att.state === "succeeded" && att.verified) return { state: "succeeded", verified: true, remoteId: att.remote_id };
  const adapter = ADAPTERS[att.action_kind]!;
  const v = await adapter.verify(ctx.orgId, att.account_id, att.action_kind, att.request, att.idempotency_key, att.remote_id ?? undefined);
  const done = att.action_kind.endsWith(".delete") ? !v.exists : v.exists;
  if (done) {
    await withCtx(s, async (db) => {
      await db.query(`UPDATE action_attempts SET state = 'succeeded', verified = true, remote_id = coalesce($2, remote_id), verified_at = now(), updated_at = now() WHERE id = $1`, [attemptId, v.remoteId ?? null]);
      await afterAction(db, att, "succeeded", v.remoteId ?? att.remote_id);
    });
    return { state: "succeeded", verified: true, remoteId: v.remoteId ?? att.remote_id };
  }
  await withCtx(s, (db) => db.query(`UPDATE action_attempts SET state = 'failed', updated_at = now() WHERE id = $1`, [attemptId]));
  if (!opts.retryIfAbsent) return { state: "failed", verified: true, remoteId: null };
  const paused = (await withCtx(s, (db) => db.query(`SELECT value FROM system_flags WHERE org_id = $1 AND key = 'pause.global'`, [ctx.orgId]))).rows[0]?.value === true;
  if (paused) throw new ConflictError("Global pause is engaged; retry blocked.");
  return performAttempt(ctx, attemptId);
}

export async function listApprovals(db: Db, status?: string) {
  return (await db.query(
    `SELECT a.*, ia.label AS account_label, ia.external_account, at.id AS attempt_id, at.state AS attempt_state, at.verified, at.remote_id, at.error AS attempt_error
       FROM approvals a LEFT JOIN integration_accounts ia ON ia.id = a.account_id LEFT JOIN action_attempts at ON at.approval_id = a.id
      WHERE ($1::text IS NULL OR a.status = $1) ORDER BY a.created_at DESC LIMIT 200`, [status ?? null])).rows;
}
