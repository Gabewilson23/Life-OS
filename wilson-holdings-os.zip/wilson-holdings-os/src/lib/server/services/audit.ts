import { actorRef, type Ctx, type Db } from "../db";

export async function audit(db: Db, ctx: Ctx, e: { scope: string; action: string; type: string; id: string; summary?: string; before?: unknown; after?: unknown }) {
  await db.query(
    `INSERT INTO audit_events(org_id, scope, actor, action, resource_type, resource_id, summary, before, after) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
    [ctx.orgId, e.scope, actorRef(ctx), e.action, e.type, e.id, e.summary ?? "", e.before ?? null, e.after ?? null],
  );
}

export async function recentAudit(db: Db, filter: { type?: string; id?: string; limit?: number }) {
  const { rows } = await db.query(
    `SELECT id, scope, actor, action, resource_type, resource_id, summary, at FROM audit_events
      WHERE ($1::text IS NULL OR resource_type = $1) AND ($2::text IS NULL OR resource_id = $2)
      ORDER BY at DESC LIMIT $3`,
    [filter.type ?? null, filter.id ?? null, filter.limit ?? 50],
  );
  return rows;
}
