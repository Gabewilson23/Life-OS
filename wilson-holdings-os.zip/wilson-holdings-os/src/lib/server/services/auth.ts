import { pool, withCtx, systemCtx } from "../db";
import { ORG_ID, SCOPES } from "../../org/definitions";
import { hashPassword, passwordProblems, verifyPassword } from "../auth/password";
import { isLockedOut, recordAttempt } from "../auth/session";
import { HttpError } from "../http";
import { audit } from "./audit";
import crypto from "node:crypto";

export async function ownerExists() {
  const { rows } = await pool().query(`SELECT count(*)::int AS n FROM users`);
  return rows[0].n > 0;
}

function safeEqual(a: string, b: string) {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

/** Creates the single owner account. Requires SETUP_TOKEN and an empty users table. */
export async function setupOwner(input: { setupToken: string; expectedToken: string; displayName: string; email: string; password: string }) {
  if (!input.expectedToken) throw new HttpError(503, "SETUP_TOKEN is not configured on the server.");
  if (!safeEqual(input.setupToken, input.expectedToken)) throw new HttpError(403, "Invalid setup token.");
  const problem = passwordProblems(input.password);
  if (problem) throw new HttpError(422, problem);
  const hash = await hashPassword(input.password);
  return withCtx(systemCtx(ORG_ID, "owner-setup"), async (db) => {
    await db.query("LOCK TABLE users IN EXCLUSIVE MODE");
    const n = (await db.query(`SELECT count(*)::int AS n FROM users`)).rows[0].n;
    if (n > 0) throw new HttpError(409, "An owner already exists. Sign in instead.");
    const { rows } = await db.query(
      `INSERT INTO users(org_id, email, display_name, password_hash, role) VALUES ($1, lower($2), $3, $4, 'owner') RETURNING id`,
      [ORG_ID, input.email.trim(), input.displayName.trim(), hash],
    );
    const id = rows[0].id as string;
    for (const s of SCOPES) {
      await db.query(`INSERT INTO user_scope_grants(user_id, org_id, scope, access, granted_by) VALUES ($1,$2,$3,'write','system:owner-setup')`, [id, ORG_ID, s.scope]);
    }
    await db.query(
      `UPDATE organizations SET settings = jsonb_set(settings, '{onboarding,ownerConfirmed}', 'true'), updated_at = now() WHERE id = $1`,
      [ORG_ID],
    );
    await audit(db, { orgId: ORG_ID, actorKind: "user", actorId: id, scopes: [], writeScopes: [] }, { scope: "org", action: "user.owner_created", type: "user", id, summary: `Owner account created for ${input.displayName.trim()}` });
    return id;
  });
}

export async function login(email: string, password: string, ip: string | null, mfaCode?: string) {
  const e = email.trim().toLowerCase();
  if (await isLockedOut(e)) throw new HttpError(429, "Too many failed attempts. Try again in 15 minutes.");
  const { rows } = await pool().query(`SELECT id, password_hash, mfa_enabled, mfa_secret, mfa_last_step FROM users WHERE email = $1 AND disabled_at IS NULL`, [e]);
  // Always run a verification to keep timing similar for unknown emails.
  const ok = rows[0] ? await verifyPassword(password, rows[0].password_hash) : (await verifyPassword(password, "scrypt$16384$8$1$AAAAAAAAAAAAAAAAAAAAAA==$" + "A".repeat(88)), false);
  await recordAttempt(e, ip, ok);
  if (!ok) throw new HttpError(401, "Email or password is incorrect.");
  if (rows[0].mfa_enabled) {
    if (!mfaCode) throw new HttpError(401, "Enter the 6-digit code from your authenticator app.", { mfaRequired: true });
    const { decrypt } = await import("../crypto");
    const { verifyTotp } = await import("../auth/totp");
    const step = verifyTotp(decrypt(rows[0].mfa_secret), mfaCode);
    if (step == null || (rows[0].mfa_last_step != null && step <= Number(rows[0].mfa_last_step))) {
      await recordAttempt(e, ip, false);
      throw new HttpError(401, "That code is invalid or was already used.", { mfaRequired: true });
    }
    await pool().query(`UPDATE users SET mfa_last_step = $2 WHERE id = $1`, [rows[0].id, step]);
  }
  await pool().query(`UPDATE users SET last_login_at = now() WHERE id = $1`, [rows[0].id]);
  return rows[0].id as string;
}
