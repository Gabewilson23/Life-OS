import { z } from "zod";
import { assertWrite, ConflictError, NotFoundError, type Ctx, type Db } from "../db";
import { createBranchWithSpec, githubConfig, mergeAtSha, prState } from "../integrations/github";
import { audit } from "./audit";
import { stableHash } from "./proposals";

/**
 * Code path for genuinely new abilities. Product Architect spec → isolated branch/PR → independent checks →
 * release approval bound to the exact commit SHA → merge (which triggers the hosting deploy, e.g. Netlify).
 * Nothing touches production before an authorized release. Missing infrastructure is reported as an exact blocker.
 */
const CONFIG_HINTS = ["form", "intake", "survey", "workflow", "automation", "email template", "report", "field", "approval chain"];

export function draftSpec(title: string, request: string) {
  const reuse = CONFIG_HINTS.filter((h) => request.toLowerCase().includes(h));
  return {
    reuseAnalysis: reuse.length ? `Likely achievable with configuration (Build Studio: ${reuse.join(", ")}). Prefer that over code.` : "No existing configurable capability matched; a code change may be needed.",
    dataRequirements: "Identify new tables/columns; additive migrations only; RLS policy for every scoped table.",
    permissions: "State required scopes; new tools must be typed functions and default to prepare-only.",
    integrations: "List any provider APIs and verify current official docs before implementation.",
    acceptanceCriteria: [`${title}: behavior described in the request works end-to-end`, "Typecheck, unit and integration tests pass", "No cross-scope data exposure (RLS test)", "Rollback plan documented and migration tested on a disposable copy"],
    rollbackPlan: "Revert the merge commit; migrations are additive so rollback does not drop data. Data written by the feature remains and is documented.",
  };
}

export async function createChangeRequest(db: Db, ctx: Ctx, p: { title: string; request: string }) {
  assertWrite(ctx, "engineering");
  const spec = draftSpec(p.title, p.request);
  const { rows } = await db.query(`INSERT INTO change_requests(org_id, title, request, spec, status, rollback_plan, created_by) VALUES ($1,$2,$3,$4,'spec',$5,$6) RETURNING id`, [ctx.orgId, p.title, p.request, spec, spec.rollbackPlan, `${ctx.actorKind}:${ctx.actorId}`]);
  await audit(db, ctx, { scope: "engineering", action: "change.create", type: "change_request", id: rows[0].id, summary: `Change request: ${p.title}` });
  return rows[0].id as string;
}

async function load(db: Db, ctx: Ctx, id: string) {
  assertWrite(ctx, "engineering");
  const cr = (await db.query(`SELECT * FROM change_requests WHERE id = $1 FOR UPDATE`, [id])).rows[0];
  if (!cr) throw new NotFoundError("Change request not found");
  return cr;
}

export async function startDevelopment(db: Db, ctx: Ctx, id: string) {
  const cr = await load(db, ctx, id);
  if (!["spec", "blocked"].includes(cr.status)) throw new ConflictError(`Change request is ${cr.status}`);
  if (!githubConfig()) {
    await db.query(`UPDATE change_requests SET status = 'blocked', blocker = $2, updated_at = now() WHERE id = $1`, [id, "GitHub repository access is not configured (set GITHUB_TOKEN with repo scope for this repository only, and GITHUB_REPO=owner/name)."]);
    return { status: "blocked" };
  }
  const branch = `cr/${id.slice(0, 8)}`;
  const md = `# ${cr.title}\n\n## Request\n${cr.request}\n\n## Spec\n\`\`\`json\n${JSON.stringify(cr.spec, null, 2)}\n\`\`\`\n`;
  const pr = await createBranchWithSpec(branch, `docs/change-requests/${id.slice(0, 8)}.md`, md, `[CR] ${cr.title}`, `Change request ${id}. Implement on this branch in an isolated environment (e.g. Claude Code); CI must pass before a release approval can be requested.`);
  await db.query(`UPDATE change_requests SET status = 'in_development', branch = $2, pr_number = $3, commit_sha = $4, blocker = $5, updated_at = now(), version = version + 1 WHERE id = $1`,
    [id, branch, pr.prNumber, pr.headSha, "Implementation runs in an isolated developer environment (no sandbox runner is hosted by this app). Push commits to the branch; checks are read back here."]);
  await audit(db, ctx, { scope: "engineering", action: "change.branch", type: "change_request", id, summary: `Branch ${branch} and draft PR #${pr.prNumber} created` });
  return { status: "in_development", ...pr };
}

/** QA gate: reads CI check runs for the current PR head. Independent of the agent that wrote the code. */
export async function refreshChecks(db: Db, ctx: Ctx, id: string) {
  const cr = await load(db, ctx, id);
  if (!cr.pr_number) throw new ConflictError("No pull request yet");
  const st = await prState(cr.pr_number);
  if (st.merged) { await db.query(`UPDATE change_requests SET status = 'released', updated_at = now() WHERE id = $1`, [id]); return { status: "released" }; }
  const done = st.checks.length > 0 && st.checks.every((c) => c.status === "completed");
  const ok = done && st.checks.every((c) => ["success", "neutral", "skipped"].includes(c.conclusion ?? ""));
  const status = !st.checks.length ? "in_development" : !done ? "preview_ready" : ok ? "qa_passed" : "qa_failed";
  await db.query(`UPDATE change_requests SET status = $2, commit_sha = $3, checks = $4, release_approval_hash = NULL, updated_at = now(), version = version + 1 WHERE id = $1`, [id, status, st.sha, JSON.stringify(st.checks)]);
  return { status, sha: st.sha, checks: st.checks };
}

export async function requestRelease(db: Db, ctx: Ctx, id: string) {
  const cr = await load(db, ctx, id);
  if (cr.status !== "qa_passed") throw new ConflictError("Release requires passing checks on the current commit.");
  const hash = stableHash({ id, pr: cr.pr_number, sha: cr.commit_sha, environment: "production" });
  await db.query(`UPDATE change_requests SET status = 'awaiting_release_approval', release_approval_hash = $2, updated_at = now() WHERE id = $1`, [id, hash]);
  return { hash, sha: cr.commit_sha };
}

/** Authorized release bound to the exact commit; GitHub refuses the merge if the head moved. */
export async function approveRelease(db: Db, ctx: Ctx, id: string, hash: string) {
  const cr = await load(db, ctx, id);
  if (cr.status !== "awaiting_release_approval" || cr.release_approval_hash !== hash) throw new ConflictError("This release approval does not match the current commit. Re-run checks and request again.");
  try { await mergeAtSha(cr.pr_number, cr.commit_sha); }
  catch (e) {
    if ((e as { status?: number }).status === 409) { await db.query(`UPDATE change_requests SET status = 'in_development', release_approval_hash = NULL WHERE id = $1`, [id]); throw new ConflictError("The branch changed after approval; nothing was merged."); }
    throw e;
  }
  await db.query(`UPDATE change_requests SET status = 'released', updated_at = now(), version = version + 1 WHERE id = $1`, [id]);
  await audit(db, ctx, { scope: "engineering", action: "change.release", type: "change_request", id, summary: `Released ${cr.title} at ${String(cr.commit_sha).slice(0, 7)} (merge triggers deploy)` });
  return { status: "released", sha: cr.commit_sha };
}

export const ChangeInput = z.object({ title: z.string().trim().min(3).max(160), request: z.string().trim().min(10).max(5000) });
