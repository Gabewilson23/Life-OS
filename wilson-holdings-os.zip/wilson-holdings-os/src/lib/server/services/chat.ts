import { assertRead, assertWrite, ForbiddenError, NotFoundError, type Ctx, type Db } from "../db";

export const PRIVATE_TTL_HOURS = 24;

export async function listChannels(db: Db) {
  const { rows } = await db.query(
    `SELECT c.*, a.title AS agent_title, (SELECT max(created_at) FROM messages m WHERE m.channel_id = c.id) AS last_at
       FROM channels c LEFT JOIN agent_definitions a ON a.id = c.agent_id
      WHERE c.expires_at IS NULL OR c.expires_at > now() ORDER BY last_at DESC NULLS LAST, c.created_at DESC`,
  );
  return rows;
}

/** One standing channel per role (non-private); private sessions are always new and expire. */
export async function openChannel(db: Db, ctx: Ctx, opts: { agentId: string; private?: boolean }) {
  const a = (await db.query(`SELECT id, title, scope FROM agent_definitions WHERE id = $1`, [opts.agentId])).rows[0];
  if (!a) throw new NotFoundError("Role not found");
  assertRead(ctx, a.scope);
  const kind = a.id === "hq.chief-of-staff" ? "chief_of_staff" : "agent_dm";
  if (!opts.private) {
    const ex = (await db.query(`SELECT * FROM channels WHERE agent_id = $1 AND private = false AND kind = $2 ORDER BY created_at LIMIT 1`, [a.id, kind])).rows[0];
    if (ex) return ex;
  }
  assertWrite(ctx, a.scope);
  const { rows } = await db.query(
    `INSERT INTO channels(org_id, scope, kind, agent_id, title, private, created_by, expires_at) VALUES ($1,$2,$3,$4,$5,$6,$7, CASE WHEN $6 THEN now() + make_interval(hours => $8) END) RETURNING *`,
    [ctx.orgId, a.scope, kind, a.id, opts.private ? `Private session · ${a.title}` : a.title, !!opts.private, `user:${ctx.actorId}`, PRIVATE_TTL_HOURS],
  );
  return rows[0];
}

export async function getChannel(db: Db, id: string) {
  const c = (await db.query(`SELECT c.*, a.title AS agent_title FROM channels c LEFT JOIN agent_definitions a ON a.id = c.agent_id WHERE c.id = $1 AND (c.expires_at IS NULL OR c.expires_at > now())`, [id])).rows[0];
  if (!c) throw new NotFoundError("Channel not found or expired");
  return c;
}

export async function listMessages(db: Db, channelId: string, limit = 100) {
  const { rows } = await db.query(
    `SELECT m.*, r.state AS run_state, r.blocked_reason, r.error AS run_error FROM messages m LEFT JOIN runs r ON r.id = m.run_id
      WHERE m.channel_id = $1 AND (m.expires_at IS NULL OR m.expires_at > now()) ORDER BY m.created_at DESC LIMIT $2`,
    [channelId, limit],
  );
  return rows.reverse();
}

export async function postUserMessage(db: Db, ctx: Ctx, channelId: string, content: string) {
  const c = await getChannel(db, channelId);
  if (!ctx.writeScopes.includes(c.scope)) throw new ForbiddenError("You can read but not write in this channel.");
  const { rows } = await db.query(
    `INSERT INTO messages(org_id, scope, channel_id, role, author, content, private, expires_at) VALUES ($1,$2,$3,'user',$4,$5,$6,$7) RETURNING id`,
    [ctx.orgId, c.scope, channelId, `user:${ctx.actorId}`, content, c.private, c.expires_at],
  );
  return { messageId: rows[0].id as string, channel: c };
}
