import crypto from "node:crypto";
import { assertWrite, ConflictError, NotFoundError, type Ctx, type Db } from "../db";
import { columnFor, companyScope, datasetById, type DatasetDef } from "../../company/datasets";
import { missingRequired, parseCsv, suggestMapping, validateRows } from "../../company/parse";
import { audit } from "./audit";
import { stableHash } from "./proposals";

export const MAX_IMPORT_BYTES = 5 * 1024 * 1024;

export async function readTable(filename: string, buf: Buffer): Promise<string[][]> {
  if (/\.xlsx$/i.test(filename)) {
    const ExcelJS = (await import("exceljs")).default;
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(buf as unknown as ArrayBuffer);
    const ws = wb.worksheets[0];
    if (!ws) throw new Error("Workbook has no sheets");
    const rows: string[][] = [];
    ws.eachRow({ includeEmpty: false }, (row) => {
      const vals = (row.values as unknown[]).slice(1).map((v) => {
        if (v == null) return "";
        if (v instanceof Date) return v.toISOString().slice(0, 10);
        if (typeof v === "object") { const o = v as { text?: string; result?: unknown; richText?: { text: string }[] }; return String(o.text ?? o.result ?? o.richText?.map((t) => t.text).join("") ?? ""); }
        return String(v);
      });
      rows.push(vals);
    });
    return rows;
  }
  if (/\.(csv|txt)$/i.test(filename)) return parseCsv(buf.toString("utf8"));
  throw new Error("Unsupported file type. Upload .csv or .xlsx.");
}

/** Stage a file: parse, suggest mapping, validate a preview. Nothing is written to company records yet. */
export async function previewImport(db: Db, ctx: Ctx, p: { dataset: string; filename: string; data: Buffer }) {
  const ds = datasetById(p.dataset);
  if (!ds) throw new NotFoundError("Unknown dataset");
  const scope = companyScope(ds.company);
  assertWrite(ctx, scope);
  if (p.data.length > MAX_IMPORT_BYTES) throw new ConflictError("File exceeds 5 MB");
  const table = await readTable(p.filename, p.data);
  if (table.length < 2) throw new ConflictError("File has no data rows (first row must be headers).");
  const headers = table[0]!.map((h) => h.trim());
  const sha = crypto.createHash("sha256").update(p.data).digest("hex");
  const prior = (await db.query(`SELECT id, created_at FROM import_batches WHERE dataset = $1 AND file_sha256 = $2 AND status = 'committed' LIMIT 1`, [ds.id, sha])).rows[0];
  const mapping = suggestMapping(ds, headers);
  const preview = validateRows(ds, headers, table.slice(1, 21), mapping);
  const { rows } = await db.query(
    `INSERT INTO import_batches(org_id, scope, dataset, filename, file_sha256, raw, headers, mapping, row_count, status, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'previewed',$10) RETURNING id`,
    [ctx.orgId, scope, ds.id, p.filename.slice(0, 200), sha, p.data, headers, mapping, table.length - 1, `user:${ctx.actorId}`],
  );
  return { batchId: rows[0].id as string, dataset: ds.id, headers, mapping, rowCount: table.length - 1, missing: missingRequired(ds, mapping), preview, duplicateOfBatch: prior?.id ?? null };
}

/**
 * Commit with a confirmed mapping. Valid rows upsert by natural key; identical rows are unchanged (dedupe),
 * changed rows update with version+1, invalid rows are rejected with reasons. Provenance: batch + row number.
 */
export async function commitImport(db: Db, ctx: Ctx, batchId: string, mapping: Record<string, string>, opts: { allowDuplicateFile?: boolean } = {}) {
  const b = (await db.query(`SELECT * FROM import_batches WHERE id = $1 FOR UPDATE`, [batchId])).rows[0];
  if (!b) throw new NotFoundError("Import not found");
  assertWrite(ctx, b.scope);
  if (b.status !== "previewed") throw new ConflictError(`Import is already ${b.status}.`);
  const ds = datasetById(b.dataset) as DatasetDef;
  const missing = missingRequired(ds, mapping);
  if (missing.length) throw new ConflictError(`Map required columns first: ${missing.join(", ")}`);
  const dup = (await db.query(`SELECT id FROM import_batches WHERE dataset = $1 AND file_sha256 = $2 AND status = 'committed' AND id <> $3 LIMIT 1`, [ds.id, b.file_sha256, batchId])).rows[0];
  if (dup && !opts.allowDuplicateFile) throw new ConflictError("This exact file was already imported. Re-importing would change nothing; confirm to proceed anyway.");
  const table = await readTable(b.filename, b.raw);
  const results = validateRows(ds, b.headers, table.slice(1), mapping);
  let inserted = 0, updated = 0, unchanged = 0;
  const errors: { row: number; key: string | null; errors: string[] }[] = [];
  const cols = ds.fields.map(columnFor);
  for (const r of results) {
    if (r.errors.length || !r.key) { errors.push({ row: r.rowNum, key: r.key, errors: r.errors }); continue; }
    const vals = ds.fields.map((f) => r.values[f.key]);
    const hash = stableHash(vals);
    const cur = (await db.query(`SELECT id, row_hash FROM ${ds.table} WHERE scope = $1 AND external_key = $2`, [b.scope, r.key])).rows[0];
    if (cur?.row_hash === hash) { unchanged++; continue; }
    if (cur) {
      await db.query(`UPDATE ${ds.table} SET ${cols.map((c, i) => `${c} = $${i + 3}`).join(", ")}, row_hash = $${cols.length + 3}, batch_id = $${cols.length + 4}, row_num = $${cols.length + 5}, updated_at = now(), version = version + 1 WHERE id = $1 AND scope = $2`,
        [cur.id, b.scope, ...vals, hash, batchId, r.rowNum]);
      updated++;
    } else {
      await db.query(`INSERT INTO ${ds.table}(org_id, scope, external_key, ${cols.join(", ")}, row_hash, batch_id, row_num) VALUES ($1,$2,$3,${cols.map((_, i) => `$${i + 4}`).join(",")},$${cols.length + 4},$${cols.length + 5},$${cols.length + 6})`,
        [ctx.orgId, b.scope, r.key, ...vals, hash, batchId, r.rowNum]);
      inserted++;
    }
  }
  await db.query(`UPDATE import_batches SET status = 'committed', mapping = $2, inserted = $3, updated = $4, unchanged = $5, rejected = $6, errors = $7, committed_at = now(), raw = NULL WHERE id = $1`,
    [batchId, mapping, inserted, updated, unchanged, errors.length, JSON.stringify(errors.slice(0, 5000))]);
  await audit(db, ctx, { scope: b.scope, action: "import.commit", type: "import_batch", id: batchId, summary: `Imported ${ds.label} from ${b.filename}: ${inserted} new, ${updated} updated, ${unchanged} unchanged, ${errors.length} rejected` });
  return { inserted, updated, unchanged, rejected: errors.length, errors: errors.slice(0, 50) };
}

export function errorReportCsv(errors: { row: number; key: string | null; errors: string[] }[]) {
  const esc = (s: string) => `"${s.replace(/"/g, '""')}"`;
  return ["row,key,errors", ...errors.map((e) => `${e.row},${esc(e.key ?? "")},${esc(e.errors.join("; "))}`)].join("\n");
}

/** Upsert already-keyed raw rows from a connector (same validation, dedupe and provenance as file imports). */
export async function upsertRecords(db: Db, ctx: Ctx, ds: DatasetDef, scope: string, rows: { key: string; raw: Record<string, string> }[], prov: { source: string }) {
  assertWrite(ctx, scope);
  const { parseValue } = await import("../../company/parse");
  const sha = crypto.createHash("sha256").update(JSON.stringify(rows)).digest("hex");
  const batchId = (await db.query(`INSERT INTO import_batches(org_id, scope, dataset, filename, file_sha256, row_count, status, created_by, committed_at) VALUES ($1,$2,$3,$4,$5,$6,'committed',$7, now()) RETURNING id`,
    [ctx.orgId, scope, ds.id, prov.source, sha, rows.length, `${ctx.actorKind}:${ctx.actorId}`])).rows[0].id as string;
  let inserted = 0, updated = 0, unchanged = 0;
  const errors: { row: number; key: string | null; errors: string[] }[] = [];
  const cols = ds.fields.map(columnFor);
  for (const [i, r] of rows.entries()) {
    const errs: string[] = [];
    const vals = ds.fields.map((f) => { try { return parseValue(f, r.raw[f.key] ?? ""); } catch (e) { errs.push(`${f.label}: ${(e as Error).message}`); return null; } });
    if (!r.key) errs.push(`${ds.keyLabel} is required`);
    if (errs.length) { errors.push({ row: i + 1, key: r.key || null, errors: errs }); continue; }
    const hash = stableHash(vals);
    const cur = (await db.query(`SELECT id, row_hash FROM ${ds.table} WHERE scope = $1 AND external_key = $2`, [scope, r.key])).rows[0];
    if (cur?.row_hash === hash) { unchanged++; continue; }
    if (cur) {
      await db.query(`UPDATE ${ds.table} SET ${cols.map((c, j) => `${c} = $${j + 3}`).join(", ")}, row_hash = $${cols.length + 3}, batch_id = $${cols.length + 4}, row_num = $${cols.length + 5}, updated_at = now(), version = version + 1 WHERE id = $1 AND scope = $2`, [cur.id, scope, ...vals, hash, batchId, i + 1]);
      updated++;
    } else {
      await db.query(`INSERT INTO ${ds.table}(org_id, scope, external_key, ${cols.join(", ")}, row_hash, batch_id, row_num) VALUES ($1,$2,$3,${cols.map((_, j) => `$${j + 4}`).join(",")},$${cols.length + 4},$${cols.length + 5},$${cols.length + 6})`, [ctx.orgId, scope, r.key, ...vals, hash, batchId, i + 1]);
      inserted++;
    }
  }
  await db.query(`UPDATE import_batches SET inserted = $2, updated = $3, unchanged = $4, rejected = $5, errors = $6 WHERE id = $1`, [batchId, inserted, updated, unchanged, errors.length, JSON.stringify(errors)]);
  return { inserted, updated, unchanged, rejected: errors.length, errors };
}
