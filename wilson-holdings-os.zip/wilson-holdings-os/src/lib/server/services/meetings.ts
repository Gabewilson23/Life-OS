import { z } from "zod";
import { assertRead, assertWrite, ForbiddenError, systemCtx, withCtx, type Ctx } from "../db";
import { createRun, executeRun, type Requester } from "../agents/executor";
import { createTask } from "./work";
import { audit } from "./audit";

export const MeetingInput = z.object({
  title: z.string().trim().min(1).max(200),
  agenda: z.string().trim().min(1).max(4000),
  participants: z.array(z.string().max(80)).min(1).max(6),
  maxRounds: z.number().int().min(1).max(3).default(2),
  scope: z.string().max(60).default("org"),
});

const SynthesisSchema = z.object({
  summary: z.string().max(3000).default(""),
  decisions: z.array(z.object({ text: z.string().max(500), evidence: z.string().max(500).optional() })).max(10).default([]),
  dissent: z.array(z.object({ text: z.string().max(500), by: z.string().max(80).optional() })).max(10).default([]),
  actions: z.array(z.object({ title: z.string().max(300), owner_agent_id: z.string().max(80), due_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), evidence: z.string().max(500).optional() })).max(10).default([]),
});

/**
 * Bounded AI working session: each participant contributes once per round (max 3 rounds × 6 participants),
 * then the Chief of Staff synthesizes decisions, dissent and owned actions as strict JSON. Actions become
 * real tasks assigned to the owning role. No loops beyond the bounds; blocked runs stop the meeting honestly.
 */
export async function runMeeting(ctx: Ctx, u: Requester, raw: z.input<typeof MeetingInput>) {
  const m = MeetingInput.parse(raw);
  assertWrite(ctx, m.scope);
  const s = systemCtx(ctx.orgId, "meetings");
  const agents = (await withCtx(ctx, (db) => db.query(`SELECT id, title, scope FROM agent_definitions WHERE id = ANY($1)`, [m.participants]))).rows;
  if (agents.length !== m.participants.length) throw new ForbiddenError("One or more participants are unknown or outside your scopes.");
  for (const a of agents) assertRead(ctx, a.scope);
  const meetingId = (await withCtx(ctx, (db) => db.query(`INSERT INTO meetings(org_id, scope, title, agenda, participants, max_rounds, status, created_by) VALUES ($1,$2,$3,$4,$5,$6,'running',$7) RETURNING id`,
    [ctx.orgId, m.scope, m.title, m.agenda, m.participants, m.maxRounds, `user:${ctx.actorId}`]))).rows[0].id as string;
  const transcript: string[] = [];
  const stop = async (status: "blocked" | "failed", reason: string) => {
    await withCtx(s, (db) => db.query(`UPDATE meetings SET status = $2, blocked_reason = $3, finished_at = now() WHERE id = $1`, [meetingId, status, reason]));
    return { meetingId, status, reason };
  };
  for (let round = 1; round <= m.maxRounds; round++) {
    for (const a of agents) {
      const req = [`AI working session "${m.title}" — round ${round} of ${m.maxRounds}.`, `Agenda:\n${m.agenda}`,
        transcript.length ? `Contributions so far:\n${transcript.slice(-12).join("\n")}` : "You speak first.",
        `As ${a.title}, contribute within your charter in under 150 words: facts with sources, your position, any dissent, and concrete actions with an owner role. Say "no further input" if you have nothing new.`].join("\n\n");
      const runId = await createRun(u, { agentId: a.id, request: req });
      const r = await executeRun(runId, ctx.orgId);
      if (r.state !== "succeeded") {
        const reason = (await withCtx(s, (db) => db.query(`SELECT coalesce(blocked_reason, error, state) AS r FROM runs WHERE id = $1`, [runId]))).rows[0].r;
        return stop(r.state === "blocked" ? "blocked" : "failed", `${a.title}: ${reason}`);
      }
      transcript.push(`[${a.title}, round ${round}] ${r.text}`);
      await withCtx(s, (db) => db.query(`INSERT INTO meeting_contributions(org_id, scope, meeting_id, round, agent_id, run_id, content) VALUES ($1,$2,$3,$4,$5,$6,$7)`, [ctx.orgId, m.scope, meetingId, round, a.id, runId, r.text]));
    }
    if (round > 1 && transcript.slice(-agents.length).every((t) => /no further input/i.test(t))) break;
  }
  const synthReq = [`Synthesize the AI working session "${m.title}".`, `Agenda:\n${m.agenda}`, `Transcript:\n${transcript.join("\n")}`,
    `Return ONLY JSON: {"summary": string, "decisions": [{"text","evidence"}], "dissent": [{"text","by"}], "actions": [{"title","owner_agent_id","due_date"?,"evidence"}]}. owner_agent_id must be one of: ${m.participants.join(", ")}. Do not invent facts not in the transcript.`].join("\n\n");
  const synthRun = await createRun(u, { agentId: "hq.chief-of-staff", request: synthReq });
  const sr = await executeRun(synthRun, ctx.orgId);
  if (sr.state !== "succeeded") return stop(sr.state === "blocked" ? "blocked" : "failed", "Synthesis did not complete");
  let parsed: z.infer<typeof SynthesisSchema>;
  try {
    const json = sr.text.slice(sr.text.indexOf("{"), sr.text.lastIndexOf("}") + 1);
    parsed = SynthesisSchema.parse(JSON.parse(json));
  } catch { return stop("failed", "Synthesis was not valid structured output; nothing was recorded as a decision."); }
  await withCtx(ctx, async (db) => {
    for (const d of parsed.decisions) await db.query(`INSERT INTO meeting_outcomes(org_id, scope, meeting_id, kind, content, evidence) VALUES ($1,$2,$3,'decision',$4,$5)`, [ctx.orgId, m.scope, meetingId, d.text, d.evidence ?? null]);
    for (const d of parsed.dissent) await db.query(`INSERT INTO meeting_outcomes(org_id, scope, meeting_id, kind, content, owner_agent_id) VALUES ($1,$2,$3,'dissent',$4,$5)`, [ctx.orgId, m.scope, meetingId, d.text, d.by ?? null]);
    for (const a of parsed.actions) {
      const owner = m.participants.includes(a.owner_agent_id) ? a.owner_agent_id : "hq.chief-of-staff";
      const t = await createTask(db, ctx, { scope: m.scope, title: a.title, notes: `From AI working session "${m.title}". Evidence: ${a.evidence ?? "—"}`, status: "open", priority: 2, dueDate: a.due_date ?? null });
      await db.query(`UPDATE tasks SET assignee_kind = 'agent', assignee_id = $2 WHERE id = $1`, [t.id, owner]);
      await db.query(`INSERT INTO meeting_outcomes(org_id, scope, meeting_id, kind, content, owner_agent_id, evidence, task_id) VALUES ($1,$2,$3,'action',$4,$5,$6,$7)`, [ctx.orgId, m.scope, meetingId, a.title, owner, a.evidence ?? null, t.id]);
    }
    await db.query(`UPDATE meetings SET status = 'completed', summary = $2, finished_at = now() WHERE id = $1`, [meetingId, parsed.summary]);
    await audit(db, ctx, { scope: m.scope, action: "meeting.complete", type: "meeting", id: meetingId, summary: `AI session "${m.title}": ${parsed.decisions.length} decisions, ${parsed.actions.length} actions` });
  });
  return { meetingId, status: "completed" as const, decisions: parsed.decisions.length, actions: parsed.actions.length };
}
