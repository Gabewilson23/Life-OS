import { z } from "zod";
import { assertRead, assertWrite, ConflictError, ForbiddenError, NotFoundError, type Ctx, type Db } from "../db";
import { audit } from "./audit";

export const MTYPES = ["identity", "semantic", "episodic", "working", "procedural", "relationship", "outcome"] as const;

export const RememberInput = z.object({
  scope: z.string().min(1).max(60),
  mtype: z.enum(MTYPES),
  subject: z.string().trim().min(1).max(160),
  assertion: z.string().trim().min(1).max(4000),
  aboutPerson: z.string().max(120).default("owner"),
  sensitivity: z.enum(["standard", "sensitive"]).default("standard"),
  /** Explicit intent is required before saving sensitive personal information. */
  confirmSensitive: z.boolean().default(false),
  confidence: z.enum(["user_confirmed", "source_confirmed", "inferred", "unverified"]).default("user_confirmed"),
  sourceKind: z.string().max(40).default("user_entry"),
  sourceRef: z.string().max(500).nullable().optional(),
  excerpt: z.string().max(2000).nullable().optional(),
  staleAfterDays: z.number().int().positive().max(3650).nullable().optional(),
  expiresAt: z.string().datetime().nullable().optional(),
  /** "this changed": supersede active records with the same subject instead of flagging a conflict. */
  supersede: z.boolean().default(false),
});

export type MemoryRow = {
  id: string; scope: string; mtype: string; subject: string; about_person: string; assertion: string | null; sensitivity: string; status: string;
  confidence: string; source_kind: string; source_ref: string | null; excerpt: string | null; observed_at: Date; valid_from: Date; valid_to: Date | null;
  verified_at: Date | null; stale_after_days: number | null; expires_at: Date | null; supersedes_id: string | null; conflicts_with: string[]; version: number; created_at: Date;
};

async function tombstoned(db: Db, ctx: Ctx, sourceKind: string, sourceRef: string | null | undefined, subject: string) {
  const { rows } = await db.query(
    `SELECT 1 FROM memory_tombstones WHERE org_id = $1 AND ((source_kind = $2 AND source_ref IS NOT NULL AND source_ref = $3) OR (subject IS NOT NULL AND subject = $4)) LIMIT 1`,
    [ctx.orgId, sourceKind, sourceRef ?? null, subject],
  );
  return rows.length > 0;
}

/** Stores a memory. Detects contradictions with active records on the same subject and shows them rather than overwriting. */
export async function remember(db: Db, ctx: Ctx, raw: z.input<typeof RememberInput>, opts: { status?: "active" | "staged"; channelPrivate?: boolean } = {}) {
  const m = RememberInput.parse(raw);
  assertWrite(ctx, m.scope);
  if (opts.channelPrivate) throw new ForbiddenError("Private-session content is never written to memory.");
  if (m.sensitivity === "sensitive" && !m.confirmSensitive) throw new ForbiddenError("Saving sensitive information requires explicit confirmation.");
  if (await tombstoned(db, ctx, m.sourceKind, m.sourceRef, m.subject)) throw new ForbiddenError("This source or subject was forgotten and is excluded from memory.");
  const status = opts.status ?? "active";
  const existing = (await db.query(
    `SELECT id, assertion FROM memory_records WHERE org_id = $1 AND scope = $2 AND subject = $3 AND mtype = $4 AND status = 'active' AND about_person = $5`,
    [ctx.orgId, m.scope, m.subject, m.mtype, m.aboutPerson],
  )).rows as { id: string; assertion: string }[];
  const differing = existing.filter((e) => e.assertion.trim().toLowerCase() !== m.assertion.trim().toLowerCase());
  if (existing.length && !differing.length) return { id: existing[0]!.id, duplicate: true, conflicts: [] as string[] };
  let supersedesId: string | null = null;
  let conflicts: string[] = [];
  if (status === "active" && differing.length) {
    if (m.supersede) {
      supersedesId = differing[0]!.id;
      await db.query(`UPDATE memory_records SET status = 'superseded', valid_to = now(), updated_at = now(), version = version + 1 WHERE id = ANY($1::uuid[])`, [differing.map((d) => d.id)]);
    } else conflicts = differing.map((d) => d.id);
  }
  const { rows } = await db.query(
    `INSERT INTO memory_records(org_id, scope, mtype, subject, about_person, assertion, sensitivity, status, confidence, source_kind, source_ref, excerpt,
       verified_at, stale_after_days, expires_at, supersedes_id, conflicts_with, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12, CASE WHEN $9 IN ('user_confirmed','source_confirmed') THEN now() END, $13,$14,$15,$16,$17) RETURNING id`,
    [ctx.orgId, m.scope, m.mtype, m.subject, m.aboutPerson, m.assertion, m.sensitivity, status, m.confidence, m.sourceKind, m.sourceRef ?? null, m.excerpt ?? null,
      m.staleAfterDays ?? null, m.expiresAt ?? null, supersedesId, conflicts, `${ctx.actorKind}:${ctx.actorId}`],
  );
  const id = rows[0].id as string;
  if (conflicts.length) await db.query(`UPDATE memory_records SET conflicts_with = array_append(conflicts_with, $1::uuid), updated_at = now() WHERE id = ANY($2::uuid[])`, [id, conflicts]);
  await audit(db, ctx, { scope: m.scope, action: supersedesId ? "memory.supersede" : "memory.remember", type: "memory", id, summary: `${supersedesId ? "Updated" : "Remembered"} ${m.mtype} fact about ${m.subject}${conflicts.length ? " (conflict flagged)" : ""}` });
  return { id, duplicate: false, conflicts };
}

/** "That is incorrect": replace with a corrected assertion, keeping history. */
export async function correct(db: Db, ctx: Ctx, id: string, assertion: string, version: number) {
  const cur = await getMemory(db, id);
  assertWrite(ctx, cur.scope);
  if (cur.version !== version) throw new ConflictError();
  if (cur.status !== "active") throw new ConflictError("Only active memories can be corrected.");
  return remember(db, ctx, { scope: cur.scope, mtype: cur.mtype as (typeof MTYPES)[number], subject: cur.subject, assertion, aboutPerson: cur.about_person, sensitivity: cur.sensitivity as "standard", confirmSensitive: true, supersede: true, sourceKind: "user_entry", sourceRef: `correction-of:${id}` });
}

/**
 * Forget: erases the assertion/excerpt text, removes lineage pointers (derived retrieval references),
 * and optionally tombstones the source so scheduled imports cannot reintroduce it.
 * Backups retain data until their own retention window lapses (documented in docs/RUNBOOK.md).
 */
export async function forget(db: Db, ctx: Ctx, id: string, opts: { tombstoneSource?: boolean; tombstoneSubject?: boolean; reason?: string } = {}) {
  const cur = await getMemory(db, id);
  assertWrite(ctx, cur.scope);
  // Forget the whole chain (this record and anything it superseded) so history cannot resurface it.
  const chain = (await db.query(
    `WITH RECURSIVE c AS (SELECT id, supersedes_id FROM memory_records WHERE id = $1 UNION ALL SELECT m.id, m.supersedes_id FROM memory_records m JOIN c ON m.id = c.supersedes_id) SELECT id FROM c`,
    [id],
  )).rows.map((r) => r.id as string);
  await db.query(`UPDATE memory_records SET status = 'forgotten', assertion = NULL, excerpt = NULL, embedding_model = NULL, valid_to = coalesce(valid_to, now()), updated_at = now(), version = version + 1 WHERE id = ANY($1::uuid[])`, [chain]);
  await db.query(`DELETE FROM retrieval_lineage WHERE memory_id = ANY($1::uuid[])`, [chain]);
  if (opts.tombstoneSource || opts.tombstoneSubject) {
    await db.query(`INSERT INTO memory_tombstones(org_id, scope, source_kind, source_ref, subject, reason, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [ctx.orgId, cur.scope, cur.source_kind, opts.tombstoneSource ? cur.source_ref : null, opts.tombstoneSubject ? cur.subject : null, opts.reason ?? "", `${ctx.actorKind}:${ctx.actorId}`]);
  }
  await audit(db, ctx, { scope: cur.scope, action: "memory.forget", type: "memory", id, summary: `Forgot ${cur.mtype} memory (${chain.length} version${chain.length > 1 ? "s" : ""})${opts.tombstoneSource || opts.tombstoneSubject ? "; source excluded" : ""}` });
  return { forgotten: chain.length };
}

export async function getMemory(db: Db, id: string): Promise<MemoryRow> {
  const { rows } = await db.query(`SELECT * FROM memory_records WHERE id = $1`, [id]);
  if (!rows[0]) throw new NotFoundError("Memory not found");
  return rows[0];
}

export async function decideStaged(db: Db, ctx: Ctx, id: string, accept: boolean) {
  const cur = await getMemory(db, id);
  assertWrite(ctx, cur.scope);
  if (cur.status !== "staged") throw new ConflictError("Not a staged memory");
  if (!accept) {
    await db.query(`UPDATE memory_records SET status = 'rejected', updated_at = now(), version = version + 1 WHERE id = $1`, [id]);
    return { id };
  }
  await db.query(`UPDATE memory_records SET status = 'rejected', updated_at = now() WHERE id = $1`, [id]);
  return remember(db, ctx, { scope: cur.scope, mtype: cur.mtype as "semantic", subject: cur.subject, assertion: cur.assertion ?? "", aboutPerson: cur.about_person, confidence: cur.confidence as "inferred", sourceKind: cur.source_kind, sourceRef: cur.source_ref, excerpt: cur.excerpt, sensitivity: cur.sensitivity as "standard", confirmSensitive: true });
}

/**
 * Hybrid-ready retrieval. Today: lexical full-text + subject/type/date filters, scope-enforced by RLS and an
 * explicit scope filter. `asOf` answers "what was true then" from superseded history.
 * (Vector retrieval is an optional later layer; vectors would only rank, never grant access.)
 */
export async function searchMemory(db: Db, ctx: Ctx, q: { text?: string; scopes?: string[]; mtypes?: string[]; asOf?: string; includeStaged?: boolean; limit?: number }) {
  const scopes = (q.scopes ?? ctx.scopes).filter((s) => ctx.system || ctx.scopes.includes(s));
  for (const s of scopes) assertRead(ctx, s);
  const params: unknown[] = [scopes];
  let where = `scope = ANY($1) AND assertion IS NOT NULL AND (expires_at IS NULL OR expires_at > now())`;
  if (q.asOf) {
    params.push(q.asOf);
    where += ` AND status IN ('active','superseded') AND valid_from <= $${params.length}::timestamptz AND (valid_to IS NULL OR valid_to > $${params.length}::timestamptz)`;
  } else where += q.includeStaged ? ` AND status IN ('active','staged')` : ` AND status = 'active'`;
  if (q.mtypes?.length) { params.push(q.mtypes); where += ` AND mtype = ANY($${params.length})`; }
  let rank = "0::real";
  if (q.text?.trim()) {
    params.push(q.text.trim());
    const p = params.length;
    where += ` AND (tsv @@ websearch_to_tsquery('english', $${p}) OR subject ILIKE '%' || $${p} || '%')`;
    rank = `ts_rank(tsv, websearch_to_tsquery('english', $${p}))`;
  }
  params.push(q.limit ?? 50);
  const { rows } = await db.query(`SELECT *, ${rank} AS rank FROM memory_records WHERE ${where} ORDER BY rank DESC, observed_at DESC LIMIT $${params.length}`, params);
  return rows as (MemoryRow & { rank: number })[];
}

export function isStale(m: Pick<MemoryRow, "stale_after_days" | "verified_at" | "observed_at">, now = new Date()) {
  if (!m.stale_after_days) return false;
  const base = m.verified_at ?? m.observed_at;
  return now.getTime() - new Date(base).getTime() > m.stale_after_days * 86400_000;
}

/**
 * Task-specific context packet: small working memory + top relevant permitted facts. Records lineage.
 * Never retrieves the whole history; private scopes only if the effective context permits them.
 */
export async function contextPacket(db: Db, ctx: Ctx, request: string, runId: string | null, writeLineage: (rows: { id: string; scope: string; rank: number }[]) => Promise<void>) {
  const working = await searchMemory(db, ctx, { mtypes: ["working"], limit: 8 });
  const relevant = request.trim() ? await searchMemory(db, ctx, { text: request.split(/\s+/).filter((w) => w.length > 3).slice(0, 12).join(" OR "), limit: 8 }) : [];
  const prefs = await searchMemory(db, ctx, { mtypes: ["identity", "procedural"], text: request.split(/\s+/).filter((w) => w.length > 3).slice(0, 12).join(" OR ") || undefined, limit: 5 });
  const seen = new Set<string>();
  const all = [...working, ...prefs, ...relevant].filter((m) => (seen.has(m.id) ? false : (seen.add(m.id), true)));
  if (runId && all.length) await writeLineage(all.map((m) => ({ id: m.id, scope: m.scope, rank: Number(m.rank) || 0 })));
  const lines = all.map((m) => {
    const flags = [m.confidence.replace("_", "-"), isStale(m) ? "STALE — re-verify" : null, m.conflicts_with.length ? "CONFLICTS with another record" : null].filter(Boolean).join(", ");
    return `- [memory:${m.id.slice(0, 8)}] (${m.mtype}; ${m.scope}; observed ${new Date(m.observed_at).toISOString().slice(0, 10)}; ${flags}) ${m.subject}: ${m.assertion}`;
  });
  return { records: all, text: lines.length ? lines.join("\n") : "(no relevant memories in permitted scopes)" };
}
