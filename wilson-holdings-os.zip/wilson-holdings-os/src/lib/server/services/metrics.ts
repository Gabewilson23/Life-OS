import type { Db } from "../db";

/**
 * Deterministic company metrics. All money is integer cents computed in SQL — models never do this arithmetic.
 * Every metric carries a definition, basis and the data cutoff (latest committed import per dataset).
 */
export interface Metric { key: string; label: string; value: number | null; unit: "usd_cents" | "count" | "percent" | "hours" | "ratio"; definition: string; basis?: "cash" | "accrual" | "estimate" | "approved" | "forecast"; drill?: string }
export interface Period { from: string; to: string }

async function freshness(db: Db, datasets: string[]) {
  const { rows } = await db.query(
    `SELECT dataset, max(committed_at) AS at, (array_agg(filename ORDER BY committed_at DESC))[1] AS file FROM import_batches WHERE status = 'committed' AND dataset = ANY($1) GROUP BY dataset`,
    [datasets],
  );
  return Object.fromEntries(datasets.map((d) => {
    const r = rows.find((x) => x.dataset === d);
    return [d, r ? { lastImport: (r.at as Date).toISOString(), file: r.file as string } : null];
  })) as Record<string, { lastImport: string; file: string } | null>;
}

const n = (v: unknown) => (v == null ? null : Number(v));

export async function insuranceMetrics(db: Db, p: Period, cohort?: string) {
  const ap = (await db.query(
    `SELECT
       coalesce(sum(annual_premium_cents) FILTER (WHERE submitted_at BETWEEN $1 AND $2), 0) AS submitted_ap,
       count(*) FILTER (WHERE submitted_at BETWEEN $1 AND $2) AS submitted_n,
       coalesce(sum(annual_premium_cents) FILTER (WHERE issued_at BETWEEN $1 AND $2), 0) AS issued_ap,
       coalesce(sum(annual_premium_cents) FILTER (WHERE placed_at BETWEEN $1 AND $2), 0) AS placed_ap,
       count(*) FILTER (WHERE placed_at BETWEEN $1 AND $2) AS placed_n,
       coalesce(sum(annual_premium_cents) FILTER (WHERE paid_at BETWEEN $1 AND $2), 0) AS paid_ap,
       count(*) FILTER (WHERE submitted_at BETWEEN $1 AND $2 AND placed_at IS NOT NULL) AS submitted_then_placed,
       count(*) FILTER (WHERE placed_at BETWEEN $1 AND $2 AND lapsed_at IS NOT NULL) AS placed_then_lapsed,
       count(*) FILTER (WHERE status IN ('submitted','issued') AND missing_documents IS NOT NULL AND missing_documents <> '') AS pending_missing_docs
     FROM ins_policies p
     WHERE ($3::text IS NULL OR p.agent_key IN (SELECT external_key FROM ins_people WHERE cohort = $3))`,
    [p.from, p.to, cohort ?? null])).rows[0];
  const people = (await db.query(
    `SELECT count(*) FILTER (WHERE kind = 'agent' AND stage = 'active') AS headcount,
            count(*) FILTER (WHERE kind = 'candidate' AND stage NOT IN ('inactive')) AS candidates,
            count(*) FILTER (WHERE stage = 'licensing') AS licensing,
            count(*) FILTER (WHERE kind = 'agent' AND stage = 'active' AND EXISTS (SELECT 1 FROM ins_policies x WHERE x.agent_key = ins_people.external_key AND x.placed_at BETWEEN $1 AND $2)) AS productive
       FROM ins_people WHERE ($3::text IS NULL OR cohort = $3)`, [p.from, p.to, cohort ?? null])).rows[0];
  const comm = (await db.query(
    `SELECT kind, coalesce(sum(expected_cents),0) AS expected, coalesce(sum(received_cents),0) AS received, count(*) FILTER (WHERE expected_cents IS DISTINCT FROM received_cents) AS discrepancies
       FROM ins_commissions WHERE statement_date BETWEEN $1 AND $2 GROUP BY kind`, [p.from, p.to])).rows;
  const ck = (k: string, f: "expected" | "received") => Number(comm.find((r) => r.kind === k)?.[f] ?? 0);
  const leads = (await db.query(
    `SELECT l.source, sum(l.cost_cents) AS cost, sum(l.leads) AS leads,
            (SELECT count(*) FROM ins_policies x WHERE x.lead_source = l.source AND x.placed_at BETWEEN $1 AND $2) AS placed,
            (SELECT coalesce(sum(annual_premium_cents),0) FROM ins_policies x WHERE x.lead_source = l.source AND x.placed_at BETWEEN $1 AND $2) AS placed_ap
       FROM ins_lead_costs l WHERE l.month BETWEEN date_trunc('month', $1::date) AND $2 GROUP BY l.source ORDER BY cost DESC`, [p.from, p.to])).rows;
  const subN = Number(ap.submitted_n), placedN = Number(ap.placed_n);
  const metrics: Metric[] = [
    { key: "submitted_ap", label: "Submitted AP", value: n(ap.submitted_ap), unit: "usd_cents", basis: "forecast", definition: "Sum of annualized premium for applications with a submitted date in the period. Not revenue.", drill: "ins_policies?date=submitted_at" },
    { key: "issued_ap", label: "Issued AP", value: n(ap.issued_ap), unit: "usd_cents", basis: "forecast", definition: "AP with an issued date in the period.", drill: "ins_policies?date=issued_at" },
    { key: "placed_ap", label: "Placed AP", value: n(ap.placed_ap), unit: "usd_cents", basis: "accrual", definition: "AP with a placed (in-force) date in the period.", drill: "ins_policies?date=placed_at" },
    { key: "paid_ap", label: "Paid AP", value: n(ap.paid_ap), unit: "usd_cents", basis: "cash", definition: "AP where the first premium was paid in the period.", drill: "ins_policies?date=paid_at" },
    { key: "placement_rate", label: "Placement rate", value: subN ? Math.round((Number(ap.submitted_then_placed) / subN) * 1000) / 10 : null, unit: "percent", definition: "Of applications submitted in the period, the % that have a placed date (any time). Denominator: submitted count." },
    { key: "headcount", label: "Active agents (headcount)", value: n(people.headcount), unit: "count", definition: "People of kind 'agent' at stage 'active'. Not the same as productive agents.", drill: "ins_people?stage=active" },
    { key: "productive", label: "Productive agents", value: n(people.productive), unit: "count", definition: "Active agents with at least one placed policy in the period." },
    { key: "candidates", label: "Candidates in pipeline", value: n(people.candidates), unit: "count", definition: "Candidates not marked inactive." },
    { key: "advances_received", label: "Advances received", value: ck("advance", "received"), unit: "usd_cents", basis: "cash", definition: "Commission advances received (statement date in period). Advances are not earned commission and can be charged back." },
    { key: "earned_received", label: "Earned commission received", value: ck("earned", "received") + ck("renewal", "received") + ck("override", "received"), unit: "usd_cents", basis: "cash", definition: "Earned + renewal + override amounts received." },
    { key: "chargebacks", label: "Chargebacks", value: ck("chargeback", "received"), unit: "usd_cents", basis: "cash", definition: "Chargeback entries (normally negative) in the period." },
    { key: "commission_gap", label: "Expected − received", value: comm.reduce((a, r) => a + Number(r.expected) - Number(r.received), 0), unit: "usd_cents", basis: "forecast", definition: "Sum over all ledger entries of expected minus received. Positive = money not yet received.", drill: "ins_commissions?discrepancy=1" },
    { key: "lapses", label: "Placed then lapsed", value: n(ap.placed_then_lapsed), unit: "count", definition: "Policies placed in the period that have a lapse date (persistency signal; small samples are noisy)." },
    { key: "missing_docs", label: "Pending cases missing documents", value: n(ap.pending_missing_docs), unit: "count", definition: "Submitted/issued cases with outstanding requirements listed.", drill: "ins_policies?missing=1" },
  ];
  const leadEconomics = leads.map((l) => ({
    source: l.source as string, costCents: Number(l.cost), leads: n(l.leads), placed: Number(l.placed), placedApCents: Number(l.placed_ap),
    costPerPlacementCents: Number(l.placed) ? Math.round(Number(l.cost) / Number(l.placed)) : null,
    apPerDollar: Number(l.cost) ? Math.round((Number(l.placed_ap) / Number(l.cost)) * 100) / 100 : null,
  }));
  return { period: p, cohort: cohort ?? null, metrics, leadEconomics, freshness: await freshness(db, ["ins_people", "ins_policies", "ins_commissions", "ins_lead_costs"]) };
}

export async function consultingMetrics(db: Db, p: Period, asOf: string) {
  const projects = (await db.query(
    `WITH labor AS (SELECT project_key, sum(round(hours * cost_rate_cents))::bigint AS cost, sum(hours) AS hours FROM con_time WHERE approved GROUP BY project_key),
          exp AS (SELECT project_key, sum(amount_cents)::bigint AS cost FROM con_expenses WHERE approved GROUP BY project_key),
          inv AS (SELECT project_key, sum(amount_cents)::bigint AS billed FROM con_invoices WHERE coalesce(status,'sent') <> 'void' GROUP BY project_key),
          pay AS (SELECT i.project_key, sum(p.amount_cents)::bigint AS collected FROM con_payments p JOIN con_invoices i ON i.external_key = p.invoice_key AND i.scope = p.scope GROUP BY i.project_key)
     SELECT pr.external_key, pr.name, pr.client, pr.status, pr.health, pr.billing_model, pr.contract_value_cents, pr.budget_cost_cents, pr.renewal_date,
            coalesce(labor.cost,0) AS labor_cents, coalesce(labor.hours,0) AS hours, coalesce(exp.cost,0) AS expense_cents, coalesce(inv.billed,0) AS billed_cents, coalesce(pay.collected,0) AS collected_cents
       FROM con_projects pr LEFT JOIN labor ON labor.project_key = pr.external_key LEFT JOIN exp ON exp.project_key = pr.external_key
       LEFT JOIN inv ON inv.project_key = pr.external_key LEFT JOIN pay ON pay.project_key = pr.external_key
      ORDER BY pr.name`)).rows.map((r) => {
    const cost = Number(r.labor_cents) + Number(r.expense_cents);
    const billed = Number(r.billed_cents), collected = Number(r.collected_cents);
    return {
      key: r.external_key as string, name: r.name as string, client: r.client as string, status: r.status as string, health: r.health as string | null, billingModel: r.billing_model as string | null,
      contractCents: Number(r.contract_value_cents), budgetCostCents: r.budget_cost_cents == null ? null : Number(r.budget_cost_cents), costCents: cost, hours: Number(r.hours),
      billedCents: billed, collectedCents: collected,
      backlogCents: ["active", "planned", "on_hold"].includes(r.status) ? Math.max(0, Number(r.contract_value_cents) - billed) : 0,
      budgetVarianceCents: r.budget_cost_cents == null ? null : Number(r.budget_cost_cents) - cost,
      accrualMarginCents: billed - cost, cashMarginCents: collected - cost,
      renewalDate: r.renewal_date as string | null,
    };
  });
  const aging = (await db.query(
    `WITH bal AS (SELECT i.external_key, i.client_key, i.due_at, i.amount_cents - coalesce((SELECT sum(p.amount_cents) FROM con_payments p WHERE p.invoice_key = i.external_key AND p.scope = i.scope AND p.received_at <= $1), 0) AS open
                    FROM (SELECT ci.*, pr.client AS client_key FROM con_invoices ci LEFT JOIN con_projects pr ON pr.external_key = ci.project_key AND pr.scope = ci.scope) i
                   WHERE i.issued_at <= $1 AND coalesce(i.status,'sent') NOT IN ('void','draft'))
     SELECT CASE WHEN $1::date - due_at <= 0 THEN 'current' WHEN $1::date - due_at <= 30 THEN '1-30' WHEN $1::date - due_at <= 60 THEN '31-60' WHEN $1::date - due_at <= 90 THEN '61-90' ELSE '90+' END AS bucket,
            sum(open)::bigint AS cents, count(*) AS n FROM bal WHERE open > 0 GROUP BY 1`, [asOf])).rows;
  const pipe = (await db.query(
    `SELECT coalesce(sum(amount_cents),0) AS total, coalesce(sum(round(amount_cents * coalesce(probability,0) / 100.0)),0)::bigint AS weighted, count(*) AS n, count(*) FILTER (WHERE probability IS NULL) AS no_prob
       FROM con_opportunities WHERE stage NOT IN ('won','lost')`)).rows[0];
  const util = (await db.query(
    `SELECT person, sum(hours) AS hours FROM con_time WHERE approved AND work_date BETWEEN $1 AND $2 GROUP BY person ORDER BY hours DESC`, [p.from, p.to])).rows;
  const weeks = Math.max(1, Math.round(((new Date(p.to).getTime() - new Date(p.from).getTime()) / 86400_000 + 1) / 7));
  const sum = (k: keyof (typeof projects)[number]) => projects.reduce((a, x) => a + (Number(x[k]) || 0), 0);
  const buckets = ["current", "1-30", "31-60", "61-90", "90+"].map((b) => ({ bucket: b, cents: Number(aging.find((a) => a.bucket === b)?.cents ?? 0), count: Number(aging.find((a) => a.bucket === b)?.n ?? 0) }));
  const metrics: Metric[] = [
    { key: "backlog", label: "Contracted backlog", value: sum("backlogCents"), unit: "usd_cents", basis: "approved", definition: "For planned/active/on-hold projects: approved contract value minus amounts invoiced. Pipeline is NOT included." },
    { key: "weighted_pipeline", label: "Weighted pipeline", value: Number(pipe.weighted), unit: "usd_cents", basis: "forecast", definition: `Open opportunities × win probability. Assumption: probabilities as entered; ${pipe.no_prob} opportunit${Number(pipe.no_prob) === 1 ? "y has" : "ies have"} no probability and count as 0. Never added to backlog.`, drill: "con_opportunities" },
    { key: "billed", label: "Billed to date", value: sum("billedCents"), unit: "usd_cents", basis: "accrual", definition: "Non-void invoices, all time." , drill: "con_invoices" },
    { key: "collected", label: "Collected to date", value: sum("collectedCents"), unit: "usd_cents", basis: "cash", definition: "Payments received, all time.", drill: "con_payments" },
    { key: "job_cost", label: "Job cost (approved)", value: sum("costCents"), unit: "usd_cents", basis: "approved", definition: "Approved hours × cost rate + approved expenses. Unapproved time/expenses excluded.", drill: "con_time" },
    { key: "accrual_margin", label: "Contribution margin (accrual)", value: sum("billedCents") - sum("costCents"), unit: "usd_cents", basis: "accrual", definition: "Billed − approved job cost." },
    { key: "cash_margin", label: "Contribution margin (cash)", value: sum("collectedCents") - sum("costCents"), unit: "usd_cents", basis: "cash", definition: "Collected − approved job cost." },
    { key: "receivables", label: "Open receivables", value: buckets.reduce((a, b) => a + b.cents, 0), unit: "usd_cents", basis: "accrual", definition: `Invoice balances net of payments as of ${asOf}.`, drill: "con_invoices" },
  ];
  return {
    period: p, asOf, metrics, projects, aging: buckets,
    utilization: util.map((u) => ({ person: u.person as string, hours: Number(u.hours), pctOf40h: Math.round((Number(u.hours) / (40 * weeks)) * 1000) / 10 })),
    utilizationAssumption: `Available capacity assumed at 40 h/week × ${weeks} week(s); adjust for part-time contractors.`,
    freshness: await freshness(db, ["con_opportunities", "con_projects", "con_time", "con_expenses", "con_invoices", "con_payments"]),
  };
}

export function maskName(name: string | null) {
  if (!name) return "—";
  return name.split(/\s+/).map((p) => (p[0] ?? "") + "•••").join(" ");
}
