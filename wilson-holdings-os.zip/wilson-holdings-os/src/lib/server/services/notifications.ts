import { systemCtx, withCtx } from "../db";
import { env } from "../env";
import { afterQuietHours } from "../../schedule";

/**
 * In-app notifications with dedupe (same dedupe_key increments a counter instead of a new alert),
 * grouping, and quiet hours for non-urgent items. External delivery requires a configured destination
 * and permission (not enabled by default).
 */
export async function notify(orgId: string, n: { scope: string; kind: string; title: string; body?: string; link?: string; priority?: "routine" | "important" | "urgent"; dedupeKey: string; groupKey?: string }) {
  return withCtx(systemCtx(orgId, "notify"), async (db) => {
    const org = (await db.query(`SELECT settings FROM organizations WHERE id = $1`, [orgId])).rows[0];
    const quiet = org?.settings?.quietHours ?? { start: "21:00", end: "07:00" };
    const deliverAfter = n.priority === "urgent" ? new Date() : afterQuietHours(new Date(), env().DEFAULT_TIMEZONE, quiet);
    await db.query(
      `INSERT INTO notifications(org_id, scope, kind, title, body, link, priority, dedupe_key, group_key, deliver_after) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       ON CONFLICT (org_id, dedupe_key) DO UPDATE SET occurrences = notifications.occurrences + 1, body = EXCLUDED.body, read_at = CASE WHEN notifications.read_at IS NULL THEN NULL ELSE notifications.read_at END`,
      [orgId, n.scope, n.kind, n.title, n.body ?? "", n.link ?? null, n.priority ?? "routine", n.dedupeKey, n.groupKey ?? null, deliverAfter],
    );
  });
}
