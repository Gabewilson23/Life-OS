import { assertWrite, ConflictError, NotFoundError, type Ctx, type Db } from "../db";
import { audit } from "./audit";

export interface AgentSummary {
  id: string; number: number; title: string; status: "idle" | "paused"; scope: string; buildingId: string; buildingSlug: string; buildingName: string;
  departmentId: string; departmentName: string; managerId: string | null; companyId: string | null; isDemo: boolean; liveState: string;
}

/** liveState is derived from real runs: running/queued/waiting_approval/blocked/failed, else idle/paused. Never animated fakes. */
const LIVE_STATE_SQL = `coalesce((SELECT r.state FROM runs r WHERE r.agent_id = a.id AND r.state IN ('running','queued','waiting_approval','blocked')
                         ORDER BY CASE r.state WHEN 'running' THEN 0 WHEN 'waiting_approval' THEN 1 WHEN 'blocked' THEN 2 ELSE 3 END LIMIT 1), a.status)`;

export async function listAgents(db: Db): Promise<AgentSummary[]> {
  const { rows } = await db.query(
    `SELECT a.id, a.number, a.title, a.status, a.scope, a.building_id, b.slug AS building_slug, b.name AS building_name, a.department_id, d.name AS department_name,
            a.manager_id, a.company_id, a.is_demo, ${LIVE_STATE_SQL} AS live_state
       FROM agent_definitions a JOIN buildings b ON b.id = a.building_id JOIN departments d ON d.id = a.department_id
      ORDER BY a.number`,
  );
  return rows.map((r) => ({
    id: r.id, number: r.number, title: r.title, status: r.status, scope: r.scope, buildingId: r.building_id, buildingSlug: r.building_slug, buildingName: r.building_name,
    departmentId: r.department_id, departmentName: r.department_name, managerId: r.manager_id, companyId: r.company_id, isDemo: r.is_demo, liveState: r.live_state,
  }));
}

export async function getAgent(db: Db, id: string) {
  const { rows } = await db.query(
    `SELECT a.*, b.slug AS building_slug, b.name AS building_name, d.name AS department_name, m.title AS manager_title, ${LIVE_STATE_SQL} AS live_state,
            p.system_prompt
       FROM agent_definitions a JOIN buildings b ON b.id = a.building_id JOIN departments d ON d.id = a.department_id
       LEFT JOIN agent_definitions m ON m.id = a.manager_id
       LEFT JOIN agent_prompt_versions p ON p.agent_id = a.id AND p.version = a.prompt_version
      WHERE a.id = $1`,
    [id],
  );
  const a = rows[0];
  if (!a) return null;
  const reports = await db.query(`SELECT id, title, status FROM agent_definitions WHERE manager_id = $1 ORDER BY number`, [id]);
  const runs = await db.query(`SELECT id, state, created_at, finished_at, error, is_demo FROM runs WHERE agent_id = $1 ORDER BY created_at DESC LIMIT 20`, [id]);
  return { ...a, reports: reports.rows, runs: runs.rows };
}
export type AgentDetail = NonNullable<Awaited<ReturnType<typeof getAgent>>>;

export async function setAgentStatus(db: Db, ctx: Ctx, id: string, status: "idle" | "paused", version: number) {
  const seen = await db.query(`SELECT scope FROM agent_definitions WHERE id = $1`, [id]);
  if (!seen.rows[0]) throw new NotFoundError("Role not found");
  assertWrite(ctx, seen.rows[0].scope);
  const a = (await db.query(`SELECT id, title, scope, status, version FROM agent_definitions WHERE id = $1 FOR UPDATE`, [id])).rows[0];
  if (!a) throw new NotFoundError("Role not found");
  if (a.version !== version) throw new ConflictError();
  const { rows } = await db.query(`UPDATE agent_definitions SET status = $1, version = version + 1, updated_at = now() WHERE id = $2 RETURNING version, status`, [status, id]);
  if (status === "paused") {
    // Pausing stops pending execution: queued runs for this role are cancelled (running ones get a cancel request).
    await db.query(`UPDATE runs SET state = 'cancelled', finished_at = now(), updated_at = now(), version = version + 1 WHERE agent_id = $1 AND state IN ('proposed','queued')`, [id]);
    await db.query(`UPDATE runs SET cancel_requested = true, updated_at = now() WHERE agent_id = $1 AND state IN ('running','waiting_approval','blocked')`, [id]);
  }
  await audit(db, ctx, { scope: a.scope, action: status === "paused" ? "agent.pause" : "agent.resume", type: "agent", id, summary: `${status === "paused" ? "Paused" : "Resumed"} ${a.title}`, before: { status: a.status }, after: { status } });
  return { version: rows[0].version as number, status: rows[0].status as string };
}

export async function listBuildings(db: Db) {
  const { rows } = await db.query(
    `SELECT b.id, b.slug, b.name, b.description, b.scope, b.layout, b.company_id,
            (SELECT count(*)::int FROM agent_definitions a WHERE a.building_id = b.id) AS role_count
       FROM buildings b ORDER BY b.sort`,
  );
  return rows as { id: string; slug: string; name: string; description: string; scope: string; layout: { x: number; z: number; w: number; d: number; h: number; accent: string }; company_id: string | null; role_count: number }[];
}

export async function getBuilding(db: Db, slug: string) {
  const { rows } = await db.query(`SELECT * FROM buildings WHERE slug = $1`, [slug]);
  if (!rows[0]) return null;
  const depts = await db.query(`SELECT id, slug, name, description FROM departments WHERE building_id = $1 ORDER BY sort`, [rows[0].id]);
  const b = rows[0] as { id: string; slug: string; name: string; description: string; scope: string; company_id: string | null };
  return { ...b, departments: depts.rows as { id: string; slug: string; name: string; description: string }[] };
}

export async function listCompanies(db: Db) {
  const { rows } = await db.query(`SELECT id, slug, name, kind, scope, settings FROM companies ORDER BY CASE kind WHEN 'holding' THEN 0 ELSE 1 END, name`);
  return rows;
}

export async function listHumanMembers(db: Db) {
  const { rows } = await db.query(`SELECT id, name, title, kind, company_id, scope FROM human_members ORDER BY name`);
  return rows;
}

// ---- system flags ----
export async function getFlag(db: Db, ctx: Ctx, key: string) {
  const { rows } = await db.query(`SELECT value FROM system_flags WHERE org_id = $1 AND key = $2`, [ctx.orgId, key]);
  return rows[0]?.value;
}
export async function setGlobalPause(db: Db, ctx: Ctx, paused: boolean) {
  assertWrite(ctx, "org");
  await db.query(
    `INSERT INTO system_flags(org_id, key, value, updated_by) VALUES ($1, 'pause.global', $2, $3)
     ON CONFLICT (org_id, key) DO UPDATE SET value = EXCLUDED.value, updated_by = EXCLUDED.updated_by, updated_at = now()`,
    [ctx.orgId, JSON.stringify(paused), `${ctx.actorKind}:${ctx.actorId}`],
  );
  await audit(db, ctx, { scope: "org", action: paused ? "system.pause_global" : "system.resume_global", type: "system", id: "pause.global", summary: paused ? "Global pause engaged — no agent runs or external writes will execute." : "Global pause released." });
}
