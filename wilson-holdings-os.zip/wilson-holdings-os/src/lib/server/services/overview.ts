import type { Ctx, Db } from "../db";
import { env } from "../env";
import { localDate } from "../../time";
import { getOutcomes, listTasks } from "./work";

export async function chairmanOverview(db: Db, ctx: Ctx) {
  const tz = env().DEFAULT_TIMEZONE;
  const today = localDate(tz);
  const [outcomes, tasks, goals, companies, pause, org, runs, audit] = await Promise.all([
    getOutcomes(db, ctx, today),
    listTasks(db, { limit: 200 }),
    db.query(`SELECT status, count(*)::int AS n FROM goals WHERE deleted_at IS NULL GROUP BY status`),
    db.query(`SELECT id, slug, name, kind, scope, settings FROM companies WHERE kind <> 'holding' ORDER BY name`),
    db.query(`SELECT value FROM system_flags WHERE org_id = $1 AND key = 'pause.global'`, [ctx.orgId]),
    db.query(`SELECT settings FROM organizations WHERE id = $1`, [ctx.orgId]),
    db.query(`SELECT state, count(*)::int AS n FROM runs GROUP BY state`),
    db.query(`SELECT actor, action, summary, at FROM audit_events ORDER BY at DESC LIMIT 6`),
  ]);
  const hb = (await db.query(`SELECT worker_id, last_seen FROM worker_heartbeats ORDER BY last_seen DESC LIMIT 1`)).rows[0];
  const decisions = [
    ...(await db.query(`SELECT id, action_kind, coalesce(payload->>'title', payload->>'subject', '') AS t FROM approvals WHERE status = 'pending' ORDER BY created_at LIMIT 5`)).rows.map((a) => ({ id: a.id as string, title: `Approve ${a.action_kind}: ${a.t}`, href: "/approvals" })),
    ...(await db.query(`SELECT p.id, p.title, a.title AS agent FROM proposals p LEFT JOIN agent_definitions a ON a.id = p.agent_id WHERE p.status = 'proposed' ORDER BY p.created_at LIMIT 5`)).rows.map((p) => ({ id: p.id as string, title: `${p.title}${p.agent ? ` — from ${p.agent}` : ""}`, href: "/approvals" })),
  ];
  const integ = (await db.query(`SELECT status, count(*)::int n FROM integration_accounts GROUP BY status`)).rows;
  const imports = (await db.query(`SELECT scope, max(committed_at) AS at FROM import_batches WHERE status = 'committed' GROUP BY scope`)).rows;
  const latestReport = (await db.query(`SELECT id, title, created_at FROM reports ORDER BY created_at DESC LIMIT 1`)).rows[0];
  const overdue = tasks.filter((t) => t.dueDate && t.dueDate < today);
  const blocked = tasks.filter((t) => t.status === "blocked");
  const next = tasks.filter((t) => t.status !== "blocked").slice(0, 6);
  const goalCounts = Object.fromEntries(goals.rows.map((r) => [r.status, r.n])) as Record<string, number>;
  const runCounts = Object.fromEntries(runs.rows.map((r) => [r.state, r.n])) as Record<string, number>;
  const scopedTasks = (scope: string) => tasks.filter((t) => t.scope === scope);
  return {
    today, tz,
    outcomes,
    nextActions: next,
    exceptions: [
      ...blocked.map((t) => ({ kind: "blocked" as const, task: t })),
      ...overdue.filter((t) => t.status !== "blocked").map((t) => ({ kind: "overdue" as const, task: t })),
    ],
    goals: { active: goalCounts.active ?? 0, paused: goalCounts.paused ?? 0, achieved: goalCounts.achieved ?? 0 },
    companies: companies.rows.map((c) => ({
      id: c.id as string, slug: c.slug as string, name: c.name as string, kind: c.kind as string,
      openTasks: scopedTasks(c.scope).length, blocked: scopedTasks(c.scope).filter((t) => t.status === "blocked").length,
      // No company data source is connected yet; the card says so rather than showing invented figures.
      lastReport: null as string | null, lastSync: (imports.find((i) => i.scope === c.scope)?.at as Date | undefined)?.toISOString() ?? null,
      needsConfirmation: c.kind === "consulting" && !(c.settings as { businessModel?: string | null }).businessModel,
    })),
    decisions,
    latestReport: latestReport ? { id: latestReport.id as string, title: latestReport.title as string } : null,
    system: {
      globalPause: pause.rows[0]?.value === true,
      modelCredential: !!env().ANTHROPIC_API_KEY,
      googleOAuthConfigured: !!(env().GOOGLE_CLIENT_ID && env().GOOGLE_CLIENT_SECRET),
      worker: hb ? { id: hb.worker_id as string, lastSeen: (hb.last_seen as Date).toISOString(), healthy: Date.now() - new Date(hb.last_seen).getTime() < 15 * 60_000 } : null,
      integrations: Object.fromEntries(integ.map((r) => [r.status, r.n])) as Record<string, number>,
      runs: runCounts,
      onboarding: (org.rows[0]?.settings as { onboarding?: Record<string, boolean> })?.onboarding ?? {},
    },
    recentActivity: audit.rows as { actor: string; action: string; summary: string; at: Date }[],
  };
}
export type Overview = Awaited<ReturnType<typeof chairmanOverview>>;
