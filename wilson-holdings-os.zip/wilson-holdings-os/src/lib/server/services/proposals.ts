import crypto from "node:crypto";
import { assertWrite, ConflictError, NotFoundError, type Ctx, type Db } from "../db";
import { audit } from "./audit";
import { createGoal, createTask, GoalInput, TaskInput } from "./work";
import { remember } from "./memory";

export function stableHash(v: unknown) {
  const norm = (x: unknown): unknown => (Array.isArray(x) ? x.map(norm) : x && typeof x === "object" ? Object.fromEntries(Object.keys(x as object).sort().map((k) => [k, norm((x as Record<string, unknown>)[k])])) : x);
  return crypto.createHash("sha256").update(JSON.stringify(norm(v))).digest("hex");
}

/** Internal (non-external) proposal kinds executed by deterministic code on acceptance. External kinds go through approvals (slice 5). */
export const INTERNAL_KINDS = ["task.create", "goal.create", "memory.remember", "capability.create"] as const;

export async function createProposal(db: Db, p: { orgId: string; scope: string; runId: string | null; agentId: string | null; kind: string; title: string; payload: Record<string, unknown>; rationale?: string; evidence?: unknown[] }) {
  const { rows } = await db.query(
    `INSERT INTO proposals(org_id, scope, run_id, agent_id, kind, title, payload, payload_hash, rationale, evidence) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
    [p.orgId, p.scope, p.runId, p.agentId, p.kind, p.title.slice(0, 300), p.payload, stableHash(p.payload), p.rationale ?? "", JSON.stringify(p.evidence ?? [])],
  );
  return rows[0].id as string;
}

export async function listProposals(db: Db, opts: { status?: string; runId?: string; limit?: number } = {}) {
  const { rows } = await db.query(
    `SELECT p.*, a.title AS agent_title FROM proposals p LEFT JOIN agent_definitions a ON a.id = p.agent_id
      WHERE ($1::text IS NULL OR p.status = $1) AND ($2::uuid IS NULL OR p.run_id = $2) ORDER BY p.created_at DESC LIMIT $3`,
    [opts.status ?? null, opts.runId ?? null, opts.limit ?? 100],
  );
  return rows;
}

/** Accept/reject with the exact payload hash the user saw. A changed payload invalidates the decision. */
export async function decideProposal(db: Db, ctx: Ctx, id: string, decision: "accept" | "reject", seenHash: string) {
  const seen = (await db.query(`SELECT scope FROM proposals WHERE id = $1`, [id])).rows[0];
  if (!seen) throw new NotFoundError("Proposal not found");
  assertWrite(ctx, seen.scope);
  const p = (await db.query(`SELECT * FROM proposals WHERE id = $1 FOR UPDATE`, [id])).rows[0];
  if (p.status !== "proposed") throw new ConflictError(`Proposal is already ${p.status}.`);
  if (p.payload_hash !== seenHash || stableHash(p.payload) !== seenHash) throw new ConflictError("The proposal changed since you reviewed it. Review it again.");
  if (decision === "reject") {
    await db.query(`UPDATE proposals SET status = 'rejected', decided_by = $2, decided_at = now(), version = version + 1 WHERE id = $1`, [id, `user:${ctx.actorId}`]);
    await audit(db, ctx, { scope: p.scope, action: "proposal.reject", type: "proposal", id, summary: `Rejected: ${p.title}` });
    return { status: "rejected" };
  }
  if (!(INTERNAL_KINDS as readonly string[]).includes(p.kind)) {
    // External actions are routed to the approval pipeline instead of executing here.
    const { requestApprovalFromProposal } = await import("./approvals");
    const approvalId = await requestApprovalFromProposal(db, ctx, p);
    await db.query(`UPDATE proposals SET status = 'accepted', decided_by = $2, decided_at = now(), result = $3, version = version + 1 WHERE id = $1`, [id, `user:${ctx.actorId}`, { approvalId }]);
    await audit(db, ctx, { scope: p.scope, action: "proposal.accept", type: "proposal", id, summary: `Accepted for approval: ${p.title}` });
    return { status: "accepted", approvalId };
  }
  let result: Record<string, unknown>;
  if (p.kind === "task.create") result = { taskId: (await createTask(db, ctx, TaskInput.parse({ ...p.payload, scope: p.scope }))).id };
  else if (p.kind === "goal.create") result = { goalId: (await createGoal(db, ctx, GoalInput.parse({ ...p.payload, scope: p.scope }))).id };
  else if (p.kind === "capability.create") {
    // Creates DRAFT, inactive capabilities only; activation/publishing remains a separate authorized step.
    const { createCapability } = await import("./studio");
    const pl = p.payload as { targetScope?: string; form?: { name: string; slug: string; definition: unknown }; workflow?: { name: string; slug: string; definition: unknown } };
    const target = pl.targetScope ?? p.scope;
    result = {
      formId: pl.form ? await createCapability(db, ctx, { scope: target, kind: "form", ...pl.form }) : null,
      workflowId: pl.workflow ? await createCapability(db, ctx, { scope: target, kind: "workflow", ...pl.workflow }) : null,
    };
  }
  else result = await remember(db, ctx, { ...(p.payload as object), scope: p.scope, confidence: "user_confirmed", sourceKind: "agent", sourceRef: `proposal:${id}` } as never);
  await db.query(`UPDATE proposals SET status = 'executed', decided_by = $2, decided_at = now(), result = $3, version = version + 1 WHERE id = $1`, [id, `user:${ctx.actorId}`, result]);
  await audit(db, ctx, { scope: p.scope, action: "proposal.execute", type: "proposal", id, summary: `Accepted and applied: ${p.title}`, after: result });
  return { status: "executed", result };
}
