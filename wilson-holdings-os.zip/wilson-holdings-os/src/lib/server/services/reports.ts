import { systemCtx, withCtx, type Db } from "../db";
import { env } from "../env";
import { localYmd, zonedToUtc } from "../../schedule";
import { consultingMetrics, insuranceMetrics } from "./metrics";

/**
 * Deterministic reports. Every report stores its period, data cutoff and metric version so numbers can be
 * recomputed later. A model narrative is optional and labeled; reports remain useful when models are down.
 */
export const METRIC_VERSION = "metrics-v1";
export type ReportKind = "chairman_briefing" | "company_close" | "executive_review" | "monthly_owner_report";

interface Section { title: string; items: { text: string; meta?: string; link?: string }[]; empty?: string }

const tz = () => env().DEFAULT_TIMEZONE;
const fmtTime = (d: Date) => new Intl.DateTimeFormat("en-US", { timeZone: tz(), hour: "numeric", minute: "2-digit" }).format(d);
const daysAgo = (d: Date) => Math.max(0, Math.floor((Date.now() - new Date(d).getTime()) / 86400_000));
const usd = (c: number | null) => (c == null ? "—" : new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(c / 100));

async function commonSections(db: Db, from: Date, to: Date, scopes: string[] | null) {
  const scoped = (col = "scope") => `($3::text[] IS NULL OR ${col} = ANY($3::text[]))`;
  const args = [from, to, scopes];
  const blocked = (await db.query(`SELECT title, scope, assignee_id, blocked_reason, updated_at FROM tasks WHERE deleted_at IS NULL AND status = 'blocked' AND updated_at <= $2 AND $1::timestamptz IS NOT NULL AND ${scoped()} ORDER BY updated_at`, args)).rows;
  const overdue = (await db.query(`SELECT title, scope, due_date FROM tasks WHERE deleted_at IS NULL AND status NOT IN ('done','cancelled','blocked') AND due_date < ($2::timestamptz AT TIME ZONE '${tz()}')::date AND $1::timestamptz IS NOT NULL AND ${scoped()} ORDER BY due_date`, args)).rows;
  const done = (await db.query(`SELECT title, scope, completed_at FROM tasks WHERE deleted_at IS NULL AND status = 'done' AND completed_at BETWEEN $1 AND $2 AND ${scoped()} ORDER BY completed_at`, args)).rows;
  const verified = (await db.query(`SELECT action_kind, remote_id, verified_at, scope FROM action_attempts WHERE verified AND state = 'succeeded' AND verified_at BETWEEN $1 AND $2 AND ${scoped()}`, args)).rows;
  const pendingApprovals = (await db.query(`SELECT action_kind, payload->>'title' AS t, payload->>'subject' AS s, scope FROM approvals WHERE status = 'pending' AND ${scoped()} AND $1::timestamptz IS NOT NULL AND $2::timestamptz IS NOT NULL`, args)).rows;
  const proposals = (await db.query(`SELECT title, rationale, scope FROM proposals WHERE status = 'proposed' AND ${scoped()} AND $1::timestamptz IS NOT NULL AND $2::timestamptz IS NOT NULL ORDER BY created_at LIMIT 10`, args)).rows;
  const changes = (await db.query(`SELECT summary, at, scope FROM audit_events WHERE at BETWEEN $1 AND $2 AND ${scoped()} ORDER BY at DESC LIMIT 25`, args)).rows;
  const goals = (await db.query(`SELECT title, target_metric, target_value, current_value, period_end, scope FROM goals WHERE deleted_at IS NULL AND status = 'active' AND ${scoped()} AND $1::timestamptz IS NOT NULL AND $2::timestamptz IS NOT NULL ORDER BY period_end NULLS LAST LIMIT 10`, args)).rows;
  const tomorrowEnd = zonedToUtc(localYmd(new Date(to.getTime() + 86400_000), tz()), "23:59", tz());
  const next = (await db.query(`SELECT title, due_date, scope FROM tasks WHERE deleted_at IS NULL AND status NOT IN ('done','cancelled') AND due_date BETWEEN ($2::timestamptz AT TIME ZONE '${tz()}')::date AND ($4::timestamptz AT TIME ZONE '${tz()}')::date AND $1::timestamptz IS NOT NULL AND ${scoped()} ORDER BY due_date, priority`, [from, to, scopes, tomorrowEnd])).rows;
  return {
    changed: { title: "What changed", items: changes.map((c) => ({ text: c.summary, meta: fmtTime(new Date(c.at)) })), empty: "No recorded changes in this period." } as Section,
    outcomes: { title: "Outcome vs target", items: goals.map((g) => ({ text: g.title, meta: g.target_metric ? `${g.current_value ?? "?"} / ${g.target_value ?? "?"} ${g.target_metric}` : "no numeric target" })), empty: "No active goals with targets." } as Section,
    blockers: { title: "Top blockers (owner · age)", items: [...blocked.map((b) => ({ text: `${b.title}${b.blocked_reason ? ` — ${b.blocked_reason}` : ""}`, meta: `${b.assignee_id ?? "unassigned"} · ${daysAgo(b.updated_at)}d` })), ...overdue.map((o) => ({ text: `Overdue: ${o.title}`, meta: `due ${o.due_date}` }))].slice(0, 10), empty: "No blocked or overdue work." } as Section,
    decisions: { title: "Decisions needed", items: [...pendingApprovals.map((a) => ({ text: `Approve ${a.action_kind}: ${a.t ?? a.s ?? ""}`, meta: "Recommendation: review the bound preview", link: "/approvals" })), ...proposals.map((p) => ({ text: p.title, meta: p.rationale?.slice(0, 120), link: "/approvals" }))], empty: "Nothing awaiting your decision." } as Section,
    verified: { title: "Actions completed & verified", items: [...verified.map((v) => ({ text: `${v.action_kind} verified`, meta: v.remote_id })), ...done.map((d) => ({ text: `Done: ${d.title}` }))], empty: "No completed or verified actions." } as Section,
    next: { title: "Next commitments", items: next.map((n) => ({ text: n.title, meta: `due ${n.due_date}` })), empty: "No commitments due tomorrow." } as Section,
  };
}

async function freshnessSection(db: Db) {
  const imp = (await db.query(`SELECT dataset, max(committed_at) at FROM import_batches WHERE status = 'committed' GROUP BY dataset`)).rows;
  const acct = (await db.query(`SELECT label, status, last_sync_at FROM integration_accounts WHERE status <> 'revoked'`)).rows;
  const items = [
    ...imp.map((r) => ({ text: `Import: ${r.dataset}`, meta: `${daysAgo(r.at)}d old${daysAgo(r.at) > 7 ? " — STALE" : ""}` })),
    ...acct.map((a) => ({ text: `Calendar/email: ${a.label}`, meta: `${a.status}${a.last_sync_at ? ` · synced ${daysAgo(a.last_sync_at)}d ago` : " · never synced"}` })),
  ];
  return { title: "Sources & freshness", items, empty: "No data sources connected or imported — figures below are missing, not zero." } as Section;
}

function readingMinutes(sections: Section[]) {
  const words = sections.reduce((a, s) => a + s.items.reduce((b, i) => b + `${i.text} ${i.meta ?? ""}`.split(/\s+/).length, 3), 0);
  return Math.max(1, Math.round(words / 200));
}

export async function buildReport(orgId: string, kind: ReportKind, opts: { companyId?: string | null; scheduleId?: string | null; windowKey?: string | null; now?: Date } = {}) {
  const now = opts.now ?? new Date();
  const today = localYmd(now, tz());
  const s = systemCtx(orgId, "reports");
  return withCtx(s, async (db) => {
    let from: Date, title: string, scope: string, scopes: string[] | null = null;
    const extra: Section[] = [];
    if (kind === "company_close") {
      const c = (await db.query(`SELECT name, scope, kind FROM companies WHERE id = $1`, [opts.companyId])).rows[0];
      scope = c.scope; scopes = [c.scope];
      from = zonedToUtc(today, "00:00", tz());
      title = `${c.name} — close for ${today}`;
      const m = c.kind === "insurance" ? await insuranceMetrics(db, { from: today, to: today }) : await consultingMetrics(db, { from: today, to: today }, today);
      extra.push({ title: "Results today", items: m.metrics.filter((x) => x.value !== null).slice(0, 8).map((x) => ({ text: x.label, meta: x.unit === "usd_cents" ? usd(x.value) : String(x.value) })), empty: "No company data imported." });
    } else {
      scope = "personal";
      if (kind === "chairman_briefing") { from = new Date(now.getTime() - 24 * 3600_000); title = `Chairman briefing — ${today}`; }
      else if (kind === "executive_review") { from = new Date(now.getTime() - 7 * 86400_000); title = `Executive review — week ending ${today}`; }
      else { from = new Date(now.getTime() - 31 * 86400_000); title = `Owner report — ${today.slice(0, 7)}`; }
      if (kind === "chairman_briefing") {
        const dayEnd = zonedToUtc(today, "23:59", tz());
        const cal = (await db.query(`SELECT title, starts_at, ends_at, scope FROM calendar_events WHERE starts_at BETWEEN $1 AND $2 ORDER BY starts_at`, [zonedToUtc(today, "00:00", tz()), dayEnd])).rows;
        extra.push({ title: "Calendar today", items: cal.map((e) => ({ text: e.scope.startsWith("personal:") ? "Private" : e.title, meta: `${fmtTime(new Date(e.starts_at))}–${fmtTime(new Date(e.ends_at))}` })), empty: "No synced calendar events (or no calendar connected)." });
        const outs = (await db.query(`SELECT position, title, done FROM daily_outcomes WHERE local_date = $1 ORDER BY position`, [today])).rows;
        extra.push({ title: "Today's three outcomes", items: outs.filter((o) => o.title).map((o) => ({ text: `${o.position}. ${o.title}`, meta: o.done ? "done" : undefined })), empty: "Not set yet — choose them on the home screen." });
        const failed = (await db.query(`SELECT agent_id, error, blocked_reason, state FROM runs WHERE state IN ('failed','blocked') AND updated_at > $1`, [from])).rows;
        const degraded = (await db.query(`SELECT label, status, last_error FROM integration_accounts WHERE status IN ('degraded','stale','revoked') `)).rows;
        extra.push({ title: "Overnight exceptions", items: [...failed.map((f) => ({ text: `${f.agent_id} run ${f.state}`, meta: (f.blocked_reason ?? f.error ?? "").slice(0, 100) })), ...degraded.map((d) => ({ text: `${d.label} connection ${d.status}`, meta: d.last_error ?? undefined }))], empty: "No failed runs or degraded connections." });
      }
      // Company summaries: reported side by side, never summed (no intercompany double counting).
      const mtd = { from: `${today.slice(0, 7)}-01`, to: today };
      const ins = await insuranceMetrics(db, kind === "executive_review" ? { from: localYmd(from, tz()), to: today } : mtd);
      const con = await consultingMetrics(db, kind === "executive_review" ? { from: localYmd(from, tz()), to: today } : mtd, today);
      const pick = (ms: { key: string; label: string; value: number | null; unit: string }[], keys: string[]) => ms.filter((x) => keys.includes(x.key)).map((x) => ({ text: x.label, meta: x.unit === "usd_cents" ? usd(x.value) : x.value == null ? "—" : String(x.value) }));
      extra.push({ title: "Atlas Insurance (period to date)", items: ins.freshness.ins_policies ? pick(ins.metrics, ["submitted_ap", "placed_ap", "paid_ap", "productive", "commission_gap"]) : [], empty: "No insurance data imported — figures missing." });
      extra.push({ title: "Atlas Consulting", items: con.freshness.con_projects ? pick(con.metrics, ["backlog", "weighted_pipeline", "receivables", "accrual_margin"]) : [], empty: "No consulting data imported — figures missing." });
      if (kind === "executive_review" || kind === "monthly_owner_report") {
        const hrs = (await db.query(`SELECT scope, sum(extract(epoch FROM (ends_at - starts_at)) / 3600)::numeric(8,1) AS h FROM calendar_events WHERE starts_at BETWEEN $1 AND $2 AND NOT all_day GROUP BY scope`, [from, now])).rows;
        extra.push({ title: "Time allocation (calendar hours)", items: hrs.map((h) => ({ text: h.scope, meta: `${h.h} h` })), empty: "No calendar data — time allocation unknown." });
        const runs = (await db.query(`SELECT state, count(*)::int n FROM runs WHERE created_at > $1 GROUP BY state`, [from])).rows;
        const acts = (await db.query(`SELECT state, count(*)::int n FROM action_attempts WHERE created_at > $1 GROUP BY state`, [from])).rows;
        extra.push({ title: "System reliability", items: [...runs.map((r) => ({ text: `Agent runs ${r.state}`, meta: String(r.n) })), ...acts.map((a) => ({ text: `External actions ${a.state}`, meta: String(a.n) }))], empty: "No agent runs or external actions in period." });
      }
      if (kind === "monthly_owner_report") extra.push({ title: "Personal cash, health & commitments", items: [], empty: "No personal finance or health data source connected — not reported rather than estimated." });
    }
    const common = await commonSections(db, from!, now, scopes);
    const prev = (await db.query(`SELECT id, data, created_at FROM reports WHERE kind = $1 AND scope = $2 ORDER BY created_at DESC LIMIT 1`, [kind, scope])).rows[0];
    // Carry-forward: what the last report flagged as blockers/decisions, with updated age.
    const carry: Section = { title: "Since last report", items: [], empty: prev ? "Nothing carried forward." : "First report of this kind." };
    if (prev) {
      const prevBlockers = ((prev.data.sections as Section[]).find((x) => x.title.startsWith("Top blockers"))?.items ?? []).map((i) => i.text);
      const nowBlockers = new Set(common.blockers.items.map((i) => i.text));
      for (const b of prevBlockers) carry.items.push({ text: b, meta: nowBlockers.has(b) ? `still open (reported ${daysAgo(prev.created_at)}d ago)` : "resolved since last report" });
    }
    const sections = [await freshnessSection(db), ...extra, common.changed, common.outcomes, common.blockers, common.decisions, common.verified, common.next, carry];
    const data = { period: { from: from!.toISOString(), to: now.toISOString(), timezone: tz() }, sections };
    const { rows } = await db.query(
      `INSERT INTO reports(org_id, scope, kind, schedule_id, window_key, title, period_from, period_to, source_cutoff, metric_version, data, reading_minutes, previous_report_id, narrative_status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,'none') RETURNING id`,
      [orgId, scope, kind, opts.scheduleId ?? null, opts.windowKey ?? null, title!, from!, now, now, METRIC_VERSION, JSON.stringify(data), readingMinutes(sections), prev?.id ?? null],
    );
    return { id: rows[0].id as string, scope, title: title! };
  });
}
