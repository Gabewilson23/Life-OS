import { pool, systemCtx, withCtx } from "../db";
import { dueWindow, type Rule } from "../../schedule";
import { executeRun, recoverExpiredLeases } from "../agents/executor";
import { googleCalendar } from "../integrations/adapters";
import { buildReport, type ReportKind } from "./reports";
import { notify } from "./notifications";
import { ORG_ID } from "../../org/definitions";

export const DEFAULT_SCHEDULES = [
  { id: "sched.chairman-briefing", kind: "chairman_briefing", scope: "personal", label: "7:30 AM chairman briefing", rule: { freq: "daily", time: "07:30" }, company_id: null },
  { id: "sched.close.atlas-insurance", kind: "company_close", scope: "company:atlas-insurance", label: "5:30 PM Atlas Insurance close", rule: { freq: "daily", time: "17:30" }, company_id: "co.atlas-insurance" },
  { id: "sched.close.atlas-consulting", kind: "company_close", scope: "company:atlas-consulting", label: "5:30 PM Atlas Consulting close", rule: { freq: "daily", time: "17:30" }, company_id: "co.atlas-consulting" },
  { id: "sched.executive-review", kind: "executive_review", scope: "personal", label: "Friday 3:00 PM executive review", rule: { freq: "weekly", weekday: 5, time: "15:00" }, company_id: null },
  { id: "sched.monthly-owner", kind: "monthly_owner_report", scope: "personal", label: "Monthly owner report (1st, 8:00 AM)", rule: { freq: "monthly", day: 1, time: "08:00" }, company_id: null },
] as const;

/** Runs every due schedule exactly once per window. The unique (schedule_id, window_key) row is the lock. */
export async function runDueSchedules(orgId: string, now = new Date()) {
  const s = systemCtx(orgId, "scheduler");
  const schedules = (await withCtx(s, (db) => db.query(`SELECT * FROM schedules WHERE enabled`))).rows;
  const ran: string[] = [];
  for (const sc of schedules) {
    const w = dueWindow(sc.rule as Rule, sc.timezone, now, sc.catchup_hours);
    if (!w) continue;
    const claimed = await withCtx(s, (db) => db.query(
      `INSERT INTO schedule_runs(org_id, scope, schedule_id, window_key, scheduled_for, status) VALUES ($1,$2,$3,$4,$5,'running') ON CONFLICT (schedule_id, window_key) DO NOTHING RETURNING id`,
      [orgId, sc.scope, sc.id, w.windowKey, w.scheduledFor]));
    if (!claimed.rowCount) continue;
    const runId = claimed.rows[0].id;
    try {
      const r = await buildReport(orgId, sc.kind as ReportKind, { companyId: sc.company_id, scheduleId: sc.id, windowKey: w.windowKey, now });
      await withCtx(s, (db) => db.query(`UPDATE schedule_runs SET status = 'succeeded', report_id = $2, finished_at = now() WHERE id = $1`, [runId, r.id]));
      await notify(orgId, { scope: r.scope, kind: "report", title: r.title, link: `/briefings/${r.id}`, priority: "routine", dedupeKey: `report:${sc.id}:${w.windowKey}`, groupKey: "reports" });
      ran.push(`${sc.id}@${w.windowKey}`);
    } catch (e) {
      await withCtx(s, (db) => db.query(`UPDATE schedule_runs SET status = 'failed', error = $2, finished_at = now() WHERE id = $1`, [runId, (e as Error).message.slice(0, 500)]));
      await notify(orgId, { scope: "org", kind: "system", title: `Scheduled ${sc.label} failed`, body: (e as Error).message.slice(0, 300), priority: "important", dedupeKey: `schedfail:${sc.id}:${w.windowKey}` });
    }
  }
  return ran;
}

/** One bounded unit of background work. Safe to call concurrently from cron and the worker. */
export async function tick(workerId = `tick:${process.pid}`, opts: { maxRuns?: number; now?: Date } = {}) {
  const orgId = ORG_ID;
  const started = Date.now();
  const out: Record<string, unknown> = {};
  out.recovered = await recoverExpiredLeases(orgId);
  out.schedules = await runDueSchedules(orgId, opts.now);
  // Queued agent runs (respecting concurrency inside executeRun)
  const queued = (await withCtx(systemCtx(orgId), (db) => db.query(`SELECT id FROM runs WHERE state = 'queued' ORDER BY created_at LIMIT $1`, [opts.maxRuns ?? 3]))).rows;
  const states: string[] = [];
  for (const q of queued) states.push((await executeRun(q.id, orgId)).state);
  out.runs = states;
  // Connection freshness: sync calendars older than 30 minutes; mark stale after 3 hours without a successful sync.
  const accts = (await withCtx(systemCtx(orgId), (db) => db.query(`SELECT id, label, last_sync_at FROM integration_accounts WHERE status NOT IN ('revoked','setup_needed') AND NOT paused AND 'calendar.read' = ANY(capabilities) AND (last_sync_at IS NULL OR last_sync_at < now() - interval '30 minutes') LIMIT 3`))).rows;
  for (const a of accts) {
    try { await googleCalendar.pull!(orgId, a.id); }
    catch (e) {
      await withCtx(systemCtx(orgId), (db) => db.query(`UPDATE integration_accounts SET status = CASE WHEN last_sync_at < now() - interval '3 hours' OR last_sync_at IS NULL THEN 'stale' ELSE 'degraded' END, last_error = $2 WHERE id = $1`, [a.id, (e as Error).message.slice(0, 300)]));
      await notify(orgId, { scope: "org", kind: "integration", title: `${a.label}: sync failing`, body: (e as Error).message.slice(0, 200), priority: "important", dedupeKey: `sync:${a.id}`, link: "/integrations" });
    }
  }
  // Retention: expire private sessions.
  out.expired = (await withCtx(systemCtx(orgId), (db) => db.query(`DELETE FROM channels WHERE expires_at IS NOT NULL AND expires_at < now()`))).rowCount;
  out.ms = Date.now() - started;
  await pool().query(`INSERT INTO worker_heartbeats(worker_id, kind, last_seen, last_tick) VALUES ($1, $2, now(), $3) ON CONFLICT (worker_id) DO UPDATE SET last_seen = now(), last_tick = EXCLUDED.last_tick`, [workerId, workerId.split(":")[0], JSON.stringify(out)]);
  return out;
}
