import crypto from "node:crypto";
import { z } from "zod";
import { assertWrite, ConflictError, ForbiddenError, NotFoundError, systemCtx, withCtx, type Ctx, type Db } from "../db";
import { audit } from "./audit";
import { createTask } from "./work";
import { notify } from "./notifications";
import { stableHash } from "./proposals";

/**
 * Build Studio configuration path: versioned, schema-validated forms and workflows built from an allowlist of
 * field and step types. No arbitrary code is evaluated. Definitions cannot grant themselves permissions.
 */
const key = z.string().regex(/^[a-z][a-z0-9_]{0,39}$/);
export const FieldDef = z.object({
  key, label: z.string().min(1).max(120),
  type: z.enum(["text", "email", "phone", "textarea", "number", "date", "select", "checkbox"]),
  required: z.boolean().default(false), options: z.array(z.string().max(100)).max(50).optional(), help: z.string().max(300).optional(),
  step: z.number().int().min(0).max(9).default(0), visibleWhen: z.object({ field: key, equals: z.union([z.string(), z.boolean()]) }).optional(),
  sensitive: z.boolean().default(false),
});
export const FormDef = z.object({
  title: z.string().min(1).max(160), description: z.string().max(1000).default(""), consentText: z.string().max(1000).optional(),
  steps: z.array(z.string().max(80)).max(10).default([]), fields: z.array(FieldDef).min(1).max(60), recordType: key,
}).superRefine((d, c) => {
  const keys = new Set<string>();
  for (const f of d.fields) {
    if (keys.has(f.key)) c.addIssue({ code: "custom", message: `Duplicate field key ${f.key}` });
    keys.add(f.key);
    if (f.type === "select" && !f.options?.length) c.addIssue({ code: "custom", message: `${f.key}: select needs options` });
    if (f.visibleWhen && !keys.has(f.visibleWhen.field)) c.addIssue({ code: "custom", message: `${f.key}: visibleWhen must reference an earlier field` });
  }
});
const tmpl = z.string().max(5000);
export const StepDef = z.discriminatedUnion("type", [
  z.object({ type: z.literal("create_record"), recordType: key }),
  z.object({ type: z.literal("create_task"), title: tmpl, notes: tmpl.optional(), assigneeAgentId: z.string().max(80).optional(), priority: z.number().int().min(0).max(3).default(2), dueInDays: z.number().int().min(0).max(90).optional() }),
  z.object({ type: z.literal("draft_email"), toField: key, subject: tmpl, body: tmpl, accountId: z.string().uuid().optional() }),
  z.object({ type: z.literal("notify"), title: tmpl }),
  z.object({ type: z.literal("condition"), field: key, equals: z.union([z.string(), z.boolean()]), skipIfFalse: z.number().int().min(1).max(10) }),
]);
export const WorkflowDef = z.object({
  title: z.string().min(1).max(160),
  trigger: z.object({ type: z.literal("form_submission"), formSlug: z.string().max(80) }),
  steps: z.array(StepDef).min(1).max(20), // sequential; conditions can only skip FORWARD → no cycles by construction
});

export const contractorIntakeTemplate = () => ({
  form: {
    title: "Contractor intake — Atlas Consulting", description: "Tell us about your availability and qualifications.", recordType: "contractor",
    consentText: "I consent to Atlas Consulting storing this information to evaluate contractor engagements.",
    steps: ["About you", "Qualifications"],
    fields: [
      { key: "full_name", label: "Full name", type: "text", required: true, step: 0 },
      { key: "email", label: "Email", type: "email", required: true, step: 0 },
      { key: "phone", label: "Phone", type: "phone", step: 0 },
      { key: "trade", label: "Primary skill / trade", type: "text", required: true, step: 1 },
      { key: "rate_expectation", label: "Hourly rate expectation (USD)", type: "number", step: 1 },
      { key: "available_from", label: "Available from", type: "date", step: 1 },
      { key: "has_insurance", label: "I carry my own liability insurance", type: "checkbox", step: 1 },
      { key: "insurance_carrier", label: "Insurance carrier", type: "text", step: 1, visibleWhen: { field: "has_insurance", equals: true } },
      { key: "notes", label: "Anything else?", type: "textarea", step: 1 },
    ],
  },
  workflow: {
    title: "Contractor intake → directory, review task, confirmation draft",
    trigger: { type: "form_submission", formSlug: "contractor-intake" },
    steps: [
      { type: "create_record", recordType: "contractor" },
      { type: "create_task", title: "Review contractor intake: {{full_name}} ({{trade}})", notes: "Rate expectation: {{rate_expectation}}. Available from {{available_from}}.", assigneeAgentId: "con.project-delivery-manager", priority: 2, dueInDays: 3 },
      { type: "draft_email", toField: "email", subject: "We received your contractor information", body: "Hi {{full_name}},\n\nThank you — Atlas Consulting received your information and will follow up after review.\n\nAtlas Consulting" },
    ],
  },
});

const hashDef = (d: unknown) => stableHash(d);
const fill = (t: string, data: Record<string, unknown>) => t.replace(/\{\{([a-z0-9_]+)\}\}/g, (_, k) => (data[k] == null ? "" : String(data[k])).slice(0, 500));

export async function createCapability(db: Db, ctx: Ctx, p: { scope: string; kind: "form" | "workflow"; name: string; slug: string; definition: unknown; access?: "private" | "public"; ownerAgentId?: string }) {
  assertWrite(ctx, p.scope);
  const def = p.kind === "form" ? FormDef.parse(p.definition) : WorkflowDef.parse(p.definition);
  if (p.kind === "workflow") await assertWorkflowRefs(db, p.scope, def as z.infer<typeof WorkflowDef>);
  const r = await db.query(`INSERT INTO capabilities(org_id, scope, kind, name, slug, access, owner_agent_id, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
    [ctx.orgId, p.scope, p.kind, p.name, p.slug, p.access ?? "private", p.ownerAgentId ?? null, `${ctx.actorKind}:${ctx.actorId}`]).catch((e) => { if (String(e.message).includes("unique")) throw new ConflictError(`Slug "${p.slug}" already exists`); throw e; });
  const id = r.rows[0].id as string;
  await db.query(`INSERT INTO capability_versions(capability_id, org_id, scope, version, definition, definition_hash, created_by) VALUES ($1,$2,$3,1,$4,$5,$6)`, [id, ctx.orgId, p.scope, def, hashDef(def), `${ctx.actorKind}:${ctx.actorId}`]);
  await audit(db, ctx, { scope: p.scope, action: "studio.create", type: "capability", id, summary: `Created ${p.kind} "${p.name}" (draft v1)` });
  return id;
}

async function assertWorkflowRefs(db: Db, scope: string, w: z.infer<typeof WorkflowDef>) {
  for (const s of w.steps) {
    if (s.type === "create_task" && s.assigneeAgentId) {
      const a = (await db.query(`SELECT scope FROM agent_definitions WHERE id = $1`, [s.assigneeAgentId])).rows[0];
      if (!a) throw new ConflictError(`Unknown role ${s.assigneeAgentId}`);
    }
    if (s.type === "draft_email" && s.accountId) {
      const a = (await db.query(`SELECT scope FROM integration_accounts WHERE id = $1`, [s.accountId])).rows[0];
      if (!a || a.scope !== scope) throw new ForbiddenError("The email account must belong to the same company scope as the workflow.");
    }
  }
}

/** Editing never mutates a live version: it adds version N+1 (draft) which must be activated. */
export async function addVersion(db: Db, ctx: Ctx, id: string, definition: unknown) {
  const c = (await db.query(`SELECT * FROM capabilities WHERE id = $1`, [id])).rows[0];
  if (!c) throw new NotFoundError();
  assertWrite(ctx, c.scope);
  const def = c.kind === "form" ? FormDef.parse(definition) : WorkflowDef.parse(definition);
  if (c.kind === "workflow") await assertWorkflowRefs(db, c.scope, def as z.infer<typeof WorkflowDef>);
  const v = (await db.query(`SELECT max(version)::int v FROM capability_versions WHERE capability_id = $1`, [id])).rows[0].v + 1;
  await db.query(`INSERT INTO capability_versions(capability_id, org_id, scope, version, definition, definition_hash, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7)`, [id, ctx.orgId, c.scope, v, def, hashDef(def), `${ctx.actorKind}:${ctx.actorId}`]);
  await audit(db, ctx, { scope: c.scope, action: "studio.version", type: "capability", id, summary: `${c.name}: saved v${v} (not live until activated)` });
  return v;
}

/**
 * Activation. Private, reversible configuration activates directly (owner standing policy). Publishing a PUBLIC
 * form requires an explicit confirmation bound to the exact definition hash the user previewed.
 * Workflows must have passed a test run of the version being activated.
 */
export async function activate(db: Db, ctx: Ctx, id: string, version: number, opts: { access?: "private" | "public"; confirmHash?: string } = {}) {
  const c = (await db.query(`SELECT * FROM capabilities WHERE id = $1 FOR UPDATE`, [id])).rows[0];
  if (!c) throw new NotFoundError();
  assertWrite(ctx, c.scope);
  const v = (await db.query(`SELECT * FROM capability_versions WHERE capability_id = $1 AND version = $2`, [id, version])).rows[0];
  if (!v) throw new NotFoundError("Version not found");
  const access = opts.access ?? c.access;
  if (c.kind === "form" && access === "public" && opts.confirmHash !== v.definition_hash) throw new ConflictError("Publishing a public form requires confirming the exact previewed version.");
  if (c.kind === "workflow" && v.test_status !== "passed") throw new ConflictError("Test this workflow version with sample input before activating it.");
  await db.query(`UPDATE capabilities SET status = 'active', current_version = $2, access = $3, updated_at = now(), version = version + 1 WHERE id = $1`, [id, version, access]);
  await audit(db, ctx, { scope: c.scope, action: access === "public" ? "studio.publish_public" : "studio.activate", type: "capability", id, summary: `${c.name}: v${version} ${access === "public" ? "published publicly" : "activated (private)"}` });
}

export async function setStatus(db: Db, ctx: Ctx, id: string, status: "paused" | "active" | "archived") {
  const c = (await db.query(`SELECT * FROM capabilities WHERE id = $1`, [id])).rows[0];
  if (!c) throw new NotFoundError();
  assertWrite(ctx, c.scope);
  await db.query(`UPDATE capabilities SET status = $2, updated_at = now(), version = version + 1 WHERE id = $1`, [id, status]);
  await audit(db, ctx, { scope: c.scope, action: `studio.${status}`, type: "capability", id, summary: `${c.name}: ${status}` });
}

/** Rollback = make an earlier version live again. History is preserved; submissions keep their own frozen version. */
export async function rollback(db: Db, ctx: Ctx, id: string, toVersion: number) {
  const c = (await db.query(`SELECT * FROM capabilities WHERE id = $1`, [id])).rows[0];
  if (!c) throw new NotFoundError();
  assertWrite(ctx, c.scope);
  const v = (await db.query(`SELECT 1 FROM capability_versions WHERE capability_id = $1 AND version = $2`, [id, toVersion])).rowCount;
  if (!v) throw new NotFoundError("Version not found");
  await db.query(`UPDATE capabilities SET current_version = $2, updated_at = now(), version = version + 1 WHERE id = $1`, [id, toVersion]);
  await audit(db, ctx, { scope: c.scope, action: "studio.rollback", type: "capability", id, summary: `${c.name}: rolled back to v${toVersion}` });
}

function validateSubmission(def: z.infer<typeof FormDef>, raw: Record<string, unknown>) {
  const errors: Record<string, string> = {};
  const data: Record<string, unknown> = {};
  for (const f of def.fields) {
    if (f.visibleWhen && raw[f.visibleWhen.field] !== f.visibleWhen.equals && String(raw[f.visibleWhen.field]) !== String(f.visibleWhen.equals)) continue; // hidden: dropped
    const v = raw[f.key];
    const empty = v == null || v === "" || (f.type === "checkbox" && v !== true && v !== "true" && v !== "on");
    if (empty) { if (f.required) errors[f.key] = `${f.label} is required`; if (f.type === "checkbox") data[f.key] = false; continue; }
    const s = String(v).trim().slice(0, f.type === "textarea" ? 5000 : 500);
    if (f.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)) errors[f.key] = "Enter a valid email";
    else if (f.type === "number" && !Number.isFinite(Number(s))) errors[f.key] = "Enter a number";
    else if (f.type === "date" && !/^\d{4}-\d{2}-\d{2}$/.test(s)) errors[f.key] = "Use YYYY-MM-DD";
    else if (f.type === "select" && !f.options!.includes(s)) errors[f.key] = "Choose an option";
    else if (f.type === "phone" && !/^[0-9+().\-\s]{7,20}$/.test(s)) errors[f.key] = "Enter a valid phone number";
    data[f.key] = f.type === "number" ? Number(s) : f.type === "checkbox" ? true : s;
  }
  return { data, errors };
}

/**
 * Accepts a submission against the LIVE version (frozen on the row). Idempotent by client key: replaying the
 * same submission returns the original and triggers no further downstream work. Rate-limited and spam-guarded.
 */
export async function submitForm(orgId: string, slug: string, raw: Record<string, unknown>, p: { clientKey: string; sourceHash: string; isPublic: boolean; isTest?: boolean; ctx?: Ctx }) {
  const s = systemCtx(orgId, "forms");
  return withCtx(s, async (db) => {
    const c = (await db.query(`SELECT * FROM capabilities WHERE slug = $1 AND kind = 'form'`, [slug])).rows[0];
    if (!c || (c.status !== "active" && !p.isTest)) throw new NotFoundError("This form is not accepting submissions.");
    if (p.isPublic && c.access !== "public") throw new NotFoundError("This form is not accepting submissions.");
    if (!p.isPublic && p.ctx && !p.ctx.writeScopes.includes(c.scope)) throw new ForbiddenError();
    if (typeof raw._hp === "string" && raw._hp) throw new ConflictError("Submission rejected.");
    const existing = (await db.query(`SELECT id FROM form_submissions WHERE form_id = $1 AND client_key = $2`, [c.id, p.clientKey])).rows[0];
    if (existing) return { submissionId: existing.id as string, duplicate: true, errors: {} };
    const recent = (await db.query(`SELECT count(*)::int n FROM form_submissions WHERE form_id = $1 AND source_hash = $2 AND created_at > now() - interval '1 hour'`, [c.id, p.sourceHash])).rows[0].n;
    if (p.isPublic && recent >= 10) throw new ConflictError("Too many submissions. Please try again later.");
    const v = (await db.query(`SELECT definition FROM capability_versions WHERE capability_id = $1 AND version = $2`, [c.id, c.current_version])).rows[0];
    const def = FormDef.parse(v.definition);
    if (def.consentText && raw._consent !== true && raw._consent !== "true" && raw._consent !== "on") return { submissionId: null, duplicate: false, errors: { _consent: "Consent is required" } };
    const { data, errors } = validateSubmission(def, raw);
    if (Object.keys(errors).length) return { submissionId: null, duplicate: false, errors };
    const ins = await db.query(`INSERT INTO form_submissions(org_id, scope, form_id, form_version, data, consent_given, client_key, source_hash, is_test) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT (form_id, client_key) DO NOTHING RETURNING id`,
      [orgId, c.scope, c.id, c.current_version, data, !!def.consentText, p.clientKey, p.sourceHash, !!p.isTest]);
    if (!ins.rowCount) return { submissionId: (await db.query(`SELECT id FROM form_submissions WHERE form_id = $1 AND client_key = $2`, [c.id, p.clientKey])).rows[0].id as string, duplicate: true, errors: {} };
    const submissionId = ins.rows[0].id as string;
    const workflows = (await db.query(`SELECT c.id, c.current_version, c.scope FROM capabilities c JOIN capability_versions v ON v.capability_id = c.id AND v.version = c.current_version WHERE c.kind = 'workflow' AND c.status = 'active' AND v.definition->'trigger'->>'formSlug' = $1`, [slug])).rows;
    for (const w of workflows) await runWorkflow(db, orgId, w.id, w.current_version, submissionId, { ...data, _record_type: def.recordType }, !!p.isTest);
    return { submissionId, duplicate: false, errors: {} };
  });
}

/** Executes allowlisted steps in order. Unique (workflow, trigger) makes replays no-ops. */
export async function runWorkflow(db: Db, orgId: string, workflowId: string, version: number, triggerRef: string, data: Record<string, unknown>, isTest: boolean) {
  const w = (await db.query(`SELECT c.scope, c.name, v.definition FROM capabilities c JOIN capability_versions v ON v.capability_id = c.id AND v.version = $2 WHERE c.id = $1`, [workflowId, version])).rows[0];
  const ins = await db.query(`INSERT INTO workflow_runs(org_id, scope, workflow_id, workflow_version, trigger_ref, status, is_test) VALUES ($1,$2,$3,$4,$5,'running',$6) ON CONFLICT (workflow_id, trigger_ref) DO NOTHING RETURNING id`, [orgId, w.scope, workflowId, version, triggerRef, isTest]);
  if (!ins.rowCount) return { duplicate: true };
  const runId = ins.rows[0].id;
  const def = WorkflowDef.parse(w.definition);
  const log: { step: number; type: string; result: string }[] = [];
  const actor: Ctx = { orgId, actorKind: "system", actorId: `workflow:${workflowId}`, scopes: [w.scope], writeScopes: [w.scope] };
  let status: "succeeded" | "failed" | "waiting_approval" = "succeeded"; let error: string | null = null;
  try {
    for (let i = 0; i < def.steps.length; i++) {
      const st = def.steps[i]!;
      if (st.type === "condition") {
        const ok = data[st.field] === st.equals || String(data[st.field]) === String(st.equals);
        log.push({ step: i, type: st.type, result: ok ? "true" : `false → skipped ${st.skipIfFalse}` });
        if (!ok) i += st.skipIfFalse;
        continue;
      }
      if (st.type === "create_record") {
        const r = await db.query(`INSERT INTO custom_records(org_id, scope, record_type, data, source_submission, is_test) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (source_submission, record_type) DO NOTHING RETURNING id`,
          [orgId, w.scope, st.recordType, Object.fromEntries(Object.entries(data).filter(([k]) => !k.startsWith("_"))), triggerRef.match(/^[0-9a-f-]{36}$/) ? triggerRef : null, isTest]);
        log.push({ step: i, type: st.type, result: r.rows[0]?.id ?? "already existed" });
      } else if (st.type === "create_task") {
        const due = st.dueInDays != null ? new Date(Date.now() + st.dueInDays * 86400_000).toISOString().slice(0, 10) : null;
        const t = await createTask(db, actor, { scope: w.scope, title: `${isTest ? "[TEST] " : ""}${fill(st.title, data)}`.slice(0, 300), notes: fill(st.notes ?? "", data), status: "open", priority: st.priority, dueDate: due });
        if (st.assigneeAgentId) await db.query(`UPDATE tasks SET assignee_kind = 'agent', assignee_id = $2 WHERE id = $1`, [t.id, st.assigneeAgentId]);
        log.push({ step: i, type: st.type, result: t.id });
      } else if (st.type === "draft_email") {
        const to = String(data[st.toField] ?? "");
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to)) throw new Error(`draft_email: field ${st.toField} is not an email`);
        // Recipient is the submitter's own confirmed address from the form. Drafting never sends.
        const d = await db.query(`INSERT INTO email_drafts(org_id, scope, account_id, to_addrs, subject, body_text, sync_state, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
          [orgId, w.scope, st.accountId ?? null, [to], fill(st.subject, data), fill(st.body, data), st.accountId && !isTest ? "pending" : "local_only", `workflow:${workflowId}`]);
        if (st.accountId && !isTest) {
          const { requestApproval } = await import("./approvals");
          await requestApproval(db, actor, { kind: "email.draft.create", scope: w.scope, accountId: st.accountId, payload: { to: [to], cc: [], bcc: [], subject: fill(st.subject, data), body: fill(st.body, data), localDraftId: d.rows[0].id } });
          status = "waiting_approval";
        }
        log.push({ step: i, type: st.type, result: `${d.rows[0].id} (${st.accountId && !isTest ? "Gmail draft awaiting approval" : "local draft — not synced"})` });
      } else if (st.type === "notify") {
        if (!isTest) await notify(orgId, { scope: w.scope, kind: "workflow", title: fill(st.title, data).slice(0, 200), dedupeKey: `wf:${workflowId}:${triggerRef}:${i}` });
        log.push({ step: i, type: st.type, result: isTest ? "skipped in test" : "sent in-app" });
      }
    }
  } catch (e) { status = "failed"; error = (e as Error).message; }
  await db.query(`UPDATE workflow_runs SET status = $2, steps = $3, error = $4, finished_at = now() WHERE id = $1`, [runId, status, JSON.stringify(log), error]);
  return { runId, status, steps: log, error };
}

/** Test a workflow version with sample input (dry run in a rolled-back savepoint; no external requests). */
export async function testWorkflow(db: Db, ctx: Ctx, id: string, version: number, sample: Record<string, unknown>) {
  const c = (await db.query(`SELECT * FROM capabilities WHERE id = $1`, [id])).rows[0];
  if (!c || c.kind !== "workflow") throw new NotFoundError();
  assertWrite(ctx, c.scope);
  // Real execution path inside a savepoint, then rolled back: the test proves the steps work without leaving
  // test tasks, records or drafts behind, and never calls external providers.
  await db.query("SAVEPOINT wf_test");
  let r: Awaited<ReturnType<typeof runWorkflow>>;
  try { r = await runWorkflow(db, ctx.orgId, id, version, `test:${crypto.randomUUID()}`, sample, true); }
  finally { await db.query("ROLLBACK TO SAVEPOINT wf_test"); }
  const passed = r.status !== "failed";
  await db.query(`UPDATE capability_versions SET test_status = $3, test_report = $4 WHERE capability_id = $1 AND version = $2`, [id, version, passed ? "passed" : "failed", JSON.stringify(r)]);
  await audit(db, ctx, { scope: c.scope, action: "studio.test", type: "capability", id, summary: `${c.name} v${version} test ${passed ? "passed" : "failed"}` });
  return r;
}
