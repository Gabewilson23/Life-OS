import crypto from "node:crypto";
import { z } from "zod";
import { systemCtx, withCtx } from "../db";
import { decrypt } from "../crypto";
import { assertSafeOutboundUrl } from "../net";
import { notify } from "./notifications";
import { createProposal } from "./proposals";

export const REPLAY_WINDOW_S = 300;
export function sign(secret: string, ts: string, nonce: string, body: string) {
  return crypto.createHmac("sha256", secret).update(`${ts}.${nonce}.${body}`).digest("hex");
}
const InboundEvent = z.object({ event: z.string().regex(/^[a-z0-9_.-]{1,60}$/), id: z.string().min(1).max(120), data: z.record(z.string(), z.unknown()) });

/**
 * Verifies signature, timestamp window and single-use id (replay protection), validates schema, and records
 * the delivery. Inbound events are untrusted data: they create notifications or proposals, never direct actions.
 */
export async function receiveWebhook(endpointId: string, headers: { ts: string | null; nonce: string | null; sig: string | null }, body: string) {
  const ep = (await withCtx(systemCtx("wilson-holdings", "webhook"), (db) => db.query(`SELECT * FROM webhook_endpoints WHERE id = $1 AND direction = 'inbound' AND enabled`, [endpointId]))).rows[0];
  if (!ep) return { status: 404, error: "unknown endpoint" };
  const { ts, nonce, sig } = headers;
  if (!ts || !nonce || !sig) return { status: 401, error: "missing signature headers" };
  if (Math.abs(Date.now() / 1000 - Number(ts)) > REPLAY_WINDOW_S) return { status: 401, error: "timestamp outside replay window" };
  const expected = sign(decrypt(ep.secret_enc), ts, nonce, body);
  if (expected.length !== sig.length || !crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(sig))) return { status: 401, error: "bad signature" };
  let ev: z.infer<typeof InboundEvent>;
  try { ev = InboundEvent.parse(JSON.parse(body)); } catch { return { status: 422, error: "schema validation failed" }; }
  if (ep.allowed_events.length && !ep.allowed_events.includes(ev.event)) return { status: 403, error: "event not allowed for this endpoint" };
  const s = systemCtx(ep.org_id, "webhook");
  const ins = await withCtx(s, (db) => db.query(`INSERT INTO webhook_deliveries(org_id, scope, endpoint_id, direction, event, payload, idempotency_key, status) VALUES ($1,$2,$3,'inbound',$4,$5,$6,'accepted') ON CONFLICT (endpoint_id, idempotency_key) DO NOTHING RETURNING id`,
    [ep.org_id, ep.scope, ep.id, ev.event, ev.data, `${ev.id}:${nonce}`]));
  if (!ins.rowCount) return { status: 200, duplicate: true };
  const dupId = await withCtx(s, (db) => db.query(`SELECT count(*)::int n FROM webhook_deliveries WHERE endpoint_id = $1 AND idempotency_key LIKE $2`, [ep.id, `${ev.id}:%`]));
  if (dupId.rows[0].n > 1) return { status: 200, duplicate: true }; // same event id re-sent with a new nonce
  if (ev.event === "task.suggest" && typeof ev.data.title === "string") {
    await withCtx(s, (db) => createProposal(db, { orgId: ep.org_id, scope: ep.scope, runId: null, agentId: null, kind: "task.create", title: `Task (from webhook ${ep.name}): ${String(ev.data.title).slice(0, 200)}`, payload: { title: String(ev.data.title).slice(0, 300), notes: `Received via webhook ${ep.name}`, priority: 2 }, rationale: "Inbound webhook suggestion — untrusted until accepted" }));
  }
  await notify(ep.org_id, { scope: ep.scope, kind: "webhook", title: `${ep.name}: ${ev.event}`, priority: "routine", dedupeKey: `wh:${ep.id}:${ev.id}`, groupKey: `wh:${ep.id}` });
  return { status: 202, accepted: true };
}

/** Sends a signed outbound event to an allowlisted destination with SSRF checks, retries and an idempotency key. */
export async function sendWebhook(orgId: string, endpointId: string, event: string, data: Record<string, unknown>, idempotencyKey: string) {
  const s = systemCtx(orgId, "webhook");
  const ep = (await withCtx(s, (db) => db.query(`SELECT * FROM webhook_endpoints WHERE id = $1 AND direction = 'outbound'`, [endpointId]))).rows[0];
  if (!ep || !ep.enabled) throw new Error("Endpoint missing or disabled");
  if (!ep.allowed_events.includes(event)) throw new Error(`Event "${event}" is not authorized for this destination`);
  const paused = (await withCtx(s, (db) => db.query(`SELECT value FROM system_flags WHERE org_id = $1 AND key = 'pause.global'`, [orgId]))).rows[0]?.value === true;
  if (paused) throw new Error("Global pause is engaged");
  await assertSafeOutboundUrl(ep.url, { trustedInternal: ep.trusted_internal });
  const ins = await withCtx(s, (db) => db.query(`INSERT INTO webhook_deliveries(org_id, scope, endpoint_id, direction, event, payload, idempotency_key, status) VALUES ($1,$2,$3,'outbound',$4,$5,$6,'pending') ON CONFLICT (endpoint_id, idempotency_key) DO NOTHING RETURNING id`, [orgId, ep.scope, ep.id, event, data, idempotencyKey]));
  if (!ins.rowCount) return { duplicate: true };
  const id = ins.rows[0].id;
  const body = JSON.stringify({ event, id: idempotencyKey, data });
  for (let attempt = 1; attempt <= 3; attempt++) {
    const ts = String(Math.floor(Date.now() / 1000)), nonce = crypto.randomBytes(12).toString("hex");
    try {
      const res = await fetch(ep.url, { method: "POST", redirect: "error", signal: AbortSignal.timeout(10_000), headers: { "content-type": "application/json", "x-wh-timestamp": ts, "x-wh-nonce": nonce, "x-wh-signature": sign(decrypt(ep.secret_enc), ts, nonce, body), "idempotency-key": idempotencyKey }, body });
      await withCtx(s, (db) => db.query(`UPDATE webhook_deliveries SET attempts = $2, response_status = $3, status = $4 WHERE id = $1`, [id, attempt, res.status, res.ok ? "delivered" : "failed"]));
      if (res.ok || (res.status < 500 && res.status !== 429)) return { status: res.status, delivered: res.ok };
    } catch (e) {
      await withCtx(s, (db) => db.query(`UPDATE webhook_deliveries SET attempts = $2, status = 'failed', error = $3 WHERE id = $1`, [id, attempt, (e as Error).message.slice(0, 200)]));
    }
    await new Promise((r) => setTimeout(r, 250 * 2 ** attempt));
  }
  return { delivered: false };
}
