import { z } from "zod";
import { assertWrite, ConflictError, NotFoundError, type Ctx, type Db } from "../db";
import { audit } from "./audit";

const scopeField = z.string().min(1).max(60);
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD");

export const GoalInput = z.object({
  scope: scopeField.default("org"),
  title: z.string().trim().min(1).max(300),
  description: z.string().max(5000).default(""),
  horizon: z.enum(["annual", "quarterly", "monthly", "weekly"]),
  status: z.enum(["active", "achieved", "paused", "dropped"]).default("active"),
  periodStart: isoDate.nullable().optional(),
  periodEnd: isoDate.nullable().optional(),
  targetMetric: z.string().max(200).nullable().optional(),
  targetValue: z.number().finite().nullable().optional(),
  currentValue: z.number().finite().nullable().optional(),
  progressNote: z.string().max(2000).default(""),
  parentId: z.string().uuid().nullable().optional(),
});
export const GoalPatch = GoalInput.partial().extend({ version: z.number().int().positive() });

export const TaskInput = z.object({
  scope: scopeField.default("org"),
  title: z.string().trim().min(1).max(300),
  notes: z.string().max(5000).default(""),
  status: z.enum(["open", "in_progress", "waiting", "blocked", "done", "cancelled"]).default("open"),
  priority: z.number().int().min(0).max(3).default(2),
  dueDate: isoDate.nullable().optional(),
  goalId: z.string().uuid().nullable().optional(),
  blockedReason: z.string().max(1000).nullable().optional(),
});
export const TaskPatch = TaskInput.partial().extend({ version: z.number().int().positive() });

const goalCols: Record<string, string> = {
  scope: "scope", title: "title", description: "description", horizon: "horizon", status: "status", periodStart: "period_start",
  periodEnd: "period_end", targetMetric: "target_metric", targetValue: "target_value", currentValue: "current_value", progressNote: "progress_note", parentId: "parent_id",
};
const taskCols: Record<string, string> = {
  scope: "scope", title: "title", notes: "notes", status: "status", priority: "priority", dueDate: "due_date", goalId: "goal_id", blockedReason: "blocked_reason",
};

/** Read (for a clear 403 vs 404), check write scope, then lock. FOR UPDATE alone would hide read-only rows under RLS. */
async function lockForWrite(db: Db, ctx: Ctx, table: "goals" | "tasks", id: string) {
  const seen = await db.query(`SELECT scope FROM ${table} WHERE id = $1 AND deleted_at IS NULL`, [id]);
  if (!seen.rows[0]) throw new NotFoundError(table === "goals" ? "Goal not found" : "Task not found");
  assertWrite(ctx, seen.rows[0].scope);
  const cur = await db.query(`SELECT * FROM ${table} WHERE id = $1 AND deleted_at IS NULL FOR UPDATE`, [id]);
  if (!cur.rows[0]) throw new NotFoundError();
  return cur;
}

async function companyForScope(db: Db, scope: string): Promise<string | null> {
  const { rows } = await db.query(`SELECT id FROM companies WHERE scope = $1 AND kind <> 'holding' LIMIT 1`, [scope]);
  return rows[0]?.id ?? null;
}

function mapGoal(r: Record<string, unknown>) {
  return {
    id: r.id as string, scope: r.scope as string, companyId: r.company_id as string | null, parentId: r.parent_id as string | null, title: r.title as string,
    description: r.description as string, horizon: r.horizon as string, status: r.status as string, periodStart: r.period_start as string | null,
    periodEnd: r.period_end as string | null, targetMetric: r.target_metric as string | null,
    targetValue: r.target_value == null ? null : Number(r.target_value), currentValue: r.current_value == null ? null : Number(r.current_value),
    progressNote: r.progress_note as string, version: r.version as number, updatedAt: (r.updated_at as Date).toISOString(),
    openTasks: r.open_tasks == null ? undefined : Number(r.open_tasks),
  };
}
export type Goal = ReturnType<typeof mapGoal>;

function mapTask(r: Record<string, unknown>) {
  return {
    id: r.id as string, scope: r.scope as string, goalId: r.goal_id as string | null, goalTitle: (r.goal_title as string | null) ?? null, title: r.title as string,
    notes: r.notes as string, status: r.status as string, priority: r.priority as number, dueDate: r.due_date as string | null,
    blockedReason: r.blocked_reason as string | null, version: r.version as number, updatedAt: (r.updated_at as Date).toISOString(),
    completedAt: r.completed_at ? (r.completed_at as Date).toISOString() : null,
  };
}
export type Task = ReturnType<typeof mapTask>;

export async function listGoals(db: Db, opts: { includeClosed?: boolean } = {}) {
  const { rows } = await db.query(
    `SELECT g.*, (SELECT count(*) FROM tasks t WHERE t.goal_id = g.id AND t.deleted_at IS NULL AND t.status NOT IN ('done','cancelled')) AS open_tasks
       FROM goals g WHERE g.deleted_at IS NULL AND ($1 OR g.status IN ('active','paused'))
      ORDER BY CASE g.horizon WHEN 'annual' THEN 0 WHEN 'quarterly' THEN 1 WHEN 'monthly' THEN 2 ELSE 3 END, g.created_at`,
    [!!opts.includeClosed],
  );
  return rows.map(mapGoal);
}

export async function createGoal(db: Db, ctx: Ctx, input: z.infer<typeof GoalInput>) {
  assertWrite(ctx, input.scope);
  const { rows } = await db.query(
    `INSERT INTO goals(org_id, scope, company_id, parent_id, title, description, horizon, status, period_start, period_end, target_metric, target_value, current_value, progress_note, created_by, provenance)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING *`,
    [ctx.orgId, input.scope, await companyForScope(db, input.scope), input.parentId ?? null, input.title, input.description, input.horizon, input.status,
      input.periodStart ?? null, input.periodEnd ?? null, input.targetMetric ?? null, input.targetValue ?? null, input.currentValue ?? null, input.progressNote,
      `${ctx.actorKind}:${ctx.actorId}`, { source: "user_entry", entered_at: new Date().toISOString() }],
  );
  const g = mapGoal(rows[0]);
  await audit(db, ctx, { scope: g.scope, action: "goal.create", type: "goal", id: g.id, summary: `Created goal "${g.title}"`, after: g });
  return g;
}

/** Optimistic concurrency: the caller's version must match, otherwise ConflictError (no silent overwrite). */
export async function updateGoal(db: Db, ctx: Ctx, id: string, patch: z.infer<typeof GoalPatch>) {
  const cur = await lockForWrite(db, ctx, "goals", id);
  const before = mapGoal(cur.rows[0]);
  assertWrite(ctx, before.scope);
  if (patch.scope) assertWrite(ctx, patch.scope);
  if (before.version !== patch.version) throw new ConflictError();
  const sets: string[] = [];
  const vals: unknown[] = [];
  for (const [k, col] of Object.entries(goalCols)) {
    if (k in patch && (patch as Record<string, unknown>)[k] !== undefined) {
      vals.push((patch as Record<string, unknown>)[k]);
      sets.push(`${col} = $${vals.length}`);
    }
  }
  if (patch.scope) {
    vals.push(await companyForScope(db, patch.scope));
    sets.push(`company_id = $${vals.length}`);
  }
  vals.push(id);
  const { rows } = await db.query(`UPDATE goals SET ${[...sets, "version = version + 1", "updated_at = now()"].join(", ")} WHERE id = $${vals.length} RETURNING *`, vals);
  const after = mapGoal(rows[0]);
  await audit(db, ctx, { scope: after.scope, action: "goal.update", type: "goal", id, summary: `Updated goal "${after.title}"`, before, after });
  return after;
}

export async function deleteGoal(db: Db, ctx: Ctx, id: string, version: number) {
  const cur = await lockForWrite(db, ctx, "goals", id);
  const g = mapGoal(cur.rows[0]);
  assertWrite(ctx, g.scope);
  if (g.version !== version) throw new ConflictError();
  await db.query(`UPDATE goals SET deleted_at = now(), version = version + 1, updated_at = now() WHERE id = $1`, [id]);
  await db.query(`UPDATE tasks SET goal_id = NULL, version = version + 1, updated_at = now() WHERE goal_id = $1`, [id]);
  await audit(db, ctx, { scope: g.scope, action: "goal.delete", type: "goal", id, summary: `Deleted goal "${g.title}"`, before: g });
}

export async function listTasks(db: Db, opts: { includeClosed?: boolean; goalId?: string; limit?: number } = {}) {
  const { rows } = await db.query(
    `SELECT t.*, g.title AS goal_title FROM tasks t LEFT JOIN goals g ON g.id = t.goal_id AND g.deleted_at IS NULL
      WHERE t.deleted_at IS NULL AND ($1 OR t.status NOT IN ('done','cancelled')) AND ($2::uuid IS NULL OR t.goal_id = $2)
      ORDER BY (t.status IN ('done','cancelled')), t.priority, t.due_date NULLS LAST, t.created_at LIMIT $3`,
    [!!opts.includeClosed, opts.goalId ?? null, opts.limit ?? 500],
  );
  return rows.map(mapTask);
}

export async function createTask(db: Db, ctx: Ctx, input: z.infer<typeof TaskInput>) {
  assertWrite(ctx, input.scope);
  const { rows } = await db.query(
    `INSERT INTO tasks(org_id, scope, company_id, goal_id, title, notes, status, priority, due_date, blocked_reason, created_by, completed_at, provenance)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11, CASE WHEN $7 = 'done' THEN now() END, $12) RETURNING *`,
    [ctx.orgId, input.scope, await companyForScope(db, input.scope), input.goalId ?? null, input.title, input.notes, input.status, input.priority,
      input.dueDate ?? null, input.blockedReason ?? null, `${ctx.actorKind}:${ctx.actorId}`, { source: "user_entry", entered_at: new Date().toISOString() }],
  );
  const t = mapTask(rows[0]);
  await audit(db, ctx, { scope: t.scope, action: "task.create", type: "task", id: t.id, summary: `Created task "${t.title}"`, after: t });
  return t;
}

export async function updateTask(db: Db, ctx: Ctx, id: string, patch: z.infer<typeof TaskPatch>) {
  const cur = await lockForWrite(db, ctx, "tasks", id);
  const before = mapTask(cur.rows[0]);
  assertWrite(ctx, before.scope);
  if (patch.scope) assertWrite(ctx, patch.scope);
  if (before.version !== patch.version) throw new ConflictError();
  const sets: string[] = [];
  const vals: unknown[] = [];
  for (const [k, col] of Object.entries(taskCols)) {
    if (k in patch && (patch as Record<string, unknown>)[k] !== undefined) {
      vals.push((patch as Record<string, unknown>)[k]);
      sets.push(`${col} = $${vals.length}`);
    }
  }
  if (patch.status) {
    vals.push(patch.status === "done");
    sets.push(`completed_at = CASE WHEN $${vals.length}::boolean THEN coalesce(completed_at, now()) ELSE NULL END`);
  }
  if (patch.scope) {
    vals.push(await companyForScope(db, patch.scope));
    sets.push(`company_id = $${vals.length}`);
  }
  vals.push(id);
  const { rows } = await db.query(`UPDATE tasks SET ${[...sets, "version = version + 1", "updated_at = now()"].join(", ")} WHERE id = $${vals.length} RETURNING *`, vals);
  const after = mapTask(rows[0]);
  await audit(db, ctx, { scope: after.scope, action: "task.update", type: "task", id, summary: patch.status && patch.status !== before.status ? `Task "${after.title}": ${before.status} → ${after.status}` : `Updated task "${after.title}"`, before, after });
  return after;
}

export async function deleteTask(db: Db, ctx: Ctx, id: string, version: number) {
  const cur = await lockForWrite(db, ctx, "tasks", id);
  const t = mapTask(cur.rows[0]);
  assertWrite(ctx, t.scope);
  if (t.version !== version) throw new ConflictError();
  await db.query(`UPDATE tasks SET deleted_at = now(), version = version + 1, updated_at = now() WHERE id = $1`, [id]);
  await audit(db, ctx, { scope: t.scope, action: "task.delete", type: "task", id, summary: `Deleted task "${t.title}"`, before: t });
}

// ---- Daily outcomes (three per local date) ----

export const OutcomeInput = z.object({
  localDate: isoDate,
  position: z.number().int().min(1).max(3),
  title: z.string().max(300),
  done: z.boolean().default(false),
  goalId: z.string().uuid().nullable().optional(),
  version: z.number().int().nonnegative(), // 0 = not yet created
});

export async function getOutcomes(db: Db, ctx: Ctx, localDate: string) {
  const { rows } = await db.query(
    `SELECT o.*, g.title AS goal_title FROM daily_outcomes o LEFT JOIN goals g ON g.id = o.goal_id WHERE o.user_id = $1 AND o.local_date = $2 ORDER BY position`,
    [ctx.actorId, localDate],
  );
  return [1, 2, 3].map((p) => {
    const r = rows.find((x) => x.position === p);
    return { position: p, title: (r?.title as string) ?? "", done: !!r?.done, goalId: (r?.goal_id as string) ?? null, goalTitle: (r?.goal_title as string) ?? null, version: (r?.version as number) ?? 0 };
  });
}

export async function saveOutcome(db: Db, ctx: Ctx, o: z.infer<typeof OutcomeInput>) {
  assertWrite(ctx, "org");
  if (o.version === 0) {
    const { rows } = await db.query(
      `INSERT INTO daily_outcomes(org_id, user_id, local_date, position, title, done, goal_id) VALUES ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT (user_id, local_date, position) DO NOTHING RETURNING version`,
      [ctx.orgId, ctx.actorId, o.localDate, o.position, o.title, o.done, o.goalId ?? null],
    );
    if (!rows[0]) throw new ConflictError();
    await audit(db, ctx, { scope: "org", action: "outcome.set", type: "daily_outcome", id: `${o.localDate}#${o.position}`, summary: `Outcome ${o.position} for ${o.localDate}: "${o.title}"` });
    return { version: rows[0].version as number };
  }
  const { rows } = await db.query(
    `UPDATE daily_outcomes SET title = $1, done = $2, goal_id = $3, version = version + 1, updated_at = now()
      WHERE user_id = $4 AND local_date = $5 AND position = $6 AND version = $7 RETURNING version`,
    [o.title, o.done, o.goalId ?? null, ctx.actorId, o.localDate, o.position, o.version],
  );
  if (!rows[0]) throw new ConflictError();
  await audit(db, ctx, { scope: "org", action: "outcome.set", type: "daily_outcome", id: `${o.localDate}#${o.position}`, summary: `Outcome ${o.position} for ${o.localDate}: "${o.title}"${o.done ? " (done)" : ""}` });
  return { version: rows[0].version as number };
}
