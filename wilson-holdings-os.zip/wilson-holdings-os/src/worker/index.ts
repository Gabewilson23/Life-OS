/**
 * Long-running worker (optional on Netlify, where the scheduled function calls /api/cron/tick instead).
 * Run anywhere with database access: `npm run worker`. Safe alongside cron: every unit of work is claimed
 * transactionally (schedule windows, run leases), so duplicates are impossible.
 */
import "../../scripts/_env";
import { pool } from "../lib/server/db";
import { tick } from "../lib/server/services/scheduler";

const id = `worker:${process.pid}`;
const INTERVAL = Number(process.env.WORKER_INTERVAL_MS ?? 30_000);
let stopping = false;
process.on("SIGTERM", () => (stopping = true));
process.on("SIGINT", () => (stopping = true));

console.log(`[worker] ${id} started, interval ${INTERVAL}ms`);
while (!stopping) {
  try { const r = await tick(id, { maxRuns: 3 }); if ((r.schedules as string[]).length || (r.runs as string[]).length) console.log("[worker]", JSON.stringify(r)); }
  catch (e) { console.error("[worker] tick failed:", (e as Error).message); }
  await new Promise((r) => setTimeout(r, INTERVAL));
}
await pool().end();
console.log("[worker] stopped");
