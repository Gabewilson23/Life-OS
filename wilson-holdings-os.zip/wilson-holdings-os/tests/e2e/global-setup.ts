import { execSync } from "node:child_process";
export default function globalSetup() {
  const env = { ...process.env, DATABASE_URL: process.env.E2E_DATABASE_URL ?? "postgres://wh:wh_local_dev@localhost:5432/wilson_holdings_e2e", SESSION_SECRET: "e2e-secret-e2e-secret-e2e-secret-0000", APP_ENV: "test" };
  execSync("npx tsx scripts/reset.ts && npx tsx scripts/migrate.ts && npx tsx scripts/seed.ts", { env, stdio: "inherit" });
}
