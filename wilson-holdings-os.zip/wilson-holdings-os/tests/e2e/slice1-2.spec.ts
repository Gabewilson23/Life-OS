import { expect, test, type Page } from "@playwright/test";

const OWNER = { name: "Gabe Wilson", email: "owner@e2e.local", password: "e2e-very-long-password" };

async function signIn(page: Page) {
  await page.goto("/login");
  await page.getByLabel("Email").fill(OWNER.email);
  await page.getByLabel("Password").fill(OWNER.password);
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page.getByRole("heading", { level: 1 })).toContainText("Gabe");
}

test.describe.serial("slices 1–2", () => {
  test("unauthenticated users are sent to owner setup; wrong token is rejected", async ({ page }) => {
    await page.goto("/");
    await expect(page).toHaveURL(/\/login|\/setup/);
    await page.goto("/setup");
    await page.getByLabel("Setup token").fill("wrong");
    await page.getByLabel("Your name").fill(OWNER.name);
    await page.getByLabel("Email").fill(OWNER.email);
    await page.getByLabel("Password (12+ characters)").fill(OWNER.password);
    await page.getByLabel("Confirm password").fill(OWNER.password);
    await page.getByRole("button", { name: "Create owner account" }).click();
    await expect(page.getByText("Invalid setup token.")).toBeVisible();
    await page.getByLabel("Setup token").fill("e2e-setup-token");
    await page.getByRole("button", { name: "Create owner account" }).click();
    await expect(page.getByRole("heading", { level: 1 })).toContainText("Gabe.");
  });

  test("chairman home: set an outcome, add a task, add and edit a goal — all persisted", async ({ page }) => {
    await signIn(page);
    const o1 = page.getByLabel("Outcome 1");
    await o1.fill("Confirm Atlas Consulting business model");
    await o1.press("Enter");
    await expect(page.getByText("Outcome 1 for", { exact: false })).toBeVisible();
    await page.getByLabel("New task").first().fill("Call carrier about appointment status");
    await page.getByRole("button", { name: "Add", exact: true }).first().click();
    await expect(page.getByRole("button", { name: "Call carrier about appointment status" })).toBeVisible();

    await page.goto("/goals");
    await page.getByLabel("Goal", { exact: true }).fill("Stand up Wilson Holdings OS");
    await page.getByRole("button", { name: "Add goal" }).click();
    await expect(page.getByRole("heading", { name: "Stand up Wilson Holdings OS" })).toBeVisible();
    await page.getByRole("button", { name: "Edit Stand up Wilson Holdings OS" }).click();
    await page.getByLabel("Goal", { exact: true }).nth(1).fill("Stand up Wilson Holdings OS (slice 1)");
    await page.getByRole("button", { name: "Save goal" }).click();
    await expect(page.getByRole("heading", { name: "Stand up Wilson Holdings OS (slice 1)" })).toBeVisible();

    // A fresh browser context (new session, full reload) sees the same persisted state.
    await page.context().clearCookies();
    await signIn(page);
    await expect(page.getByLabel("Outcome 1")).toHaveValue("Confirm Atlas Consulting business model");
    await page.goto("/goals");
    await expect(page.getByRole("heading", { name: "Stand up Wilson Holdings OS (slice 1)" })).toBeVisible();
  });

  test("organization shows 52 roles across 11 buildings; role profile and pause work", async ({ page }) => {
    await signIn(page);
    await page.goto("/agents");
    await expect(page.getByRole("heading", { level: 1 })).toHaveText("52 AI roles across 11 buildings");
    await page.getByRole("link", { name: "Commissions and Reconciliation Analyst" }).click();
    await expect(page).toHaveURL(/\/agents\/ins\.commissions-analyst$/);
    await expect(page.getByText("Advances never reported as earned")).toBeVisible();
    await page.getByRole("button", { name: "Pause role" }).click();
    await expect(page.getByRole("button", { name: /Resume/ })).toBeVisible();
    await expect(page.getByText("Paused Commissions and Reconciliation Analyst")).toBeVisible();
    await page.getByRole("button", { name: /Resume/ }).click();
    await expect(page.getByRole("button", { name: "Pause role" })).toBeVisible();
  });

  test("campus and focus mode open the same role record", async ({ page }) => {
    await signIn(page);
    await page.goto("/campus");
    const dir = page.getByRole("complementary", { name: "Campus directory" });
    await dir.getByRole("button", { name: /Atlas Insurance Agency/ }).click();
    await expect(page).toHaveURL(/focus=atlas-insurance/);
    const campusHref = await dir.getByRole("link", { name: /Recruiting Manager/ }).getAttribute("href");
    await page.goto("/agents");
    const focusHref = await page.getByRole("link", { name: "Recruiting Manager" }).getAttribute("href");
    expect(campusHref).toBe(focusHref);
    await page.goto(campusHref!);
    await expect(page.getByRole("heading", { level: 1 })).toHaveText("Recruiting Manager");
  });

  test("keyboard: command palette finds a role and navigates", async ({ page }) => {
    await signIn(page);
    await page.keyboard.press("Control+k");
    const box = page.getByRole("combobox", { name: "Search" });
    await box.fill("Chief of Staff");
    await expect(page.getByRole("option", { name: /1\. Chief of Staff/ })).toBeVisible();
    await page.getByRole("option", { name: /1\. Chief of Staff/ }).click();
    await expect(page).toHaveURL(/\/agents\/hq\.chief-of-staff$/);
    await page.keyboard.press("g");
    await page.keyboard.press("t");
    await expect(page).toHaveURL(/\/tasks$/);
  });

  test("mobile and non-WebGL: campus falls back to a usable plan", async ({ browser }) => {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, reducedMotion: "reduce" });
    const page = await ctx.newPage();
    await page.addInitScript(() => { HTMLCanvasElement.prototype.getContext = () => null; }); // simulate no WebGL
    await signIn(page);
    await page.goto("/campus");
    await expect(page.getByRole("img", { name: "Campus plan" })).toBeVisible();
    await expect(page.getByText(/WebGL is unavailable/)).toBeVisible();
    await page.getByRole("button", { name: /Capital House, 4 roles/ }).focus();
    await page.keyboard.press("Enter");
    await expect(page).toHaveURL(/focus=capital-house/);
    await expect(page.getByRole("navigation", { name: "Primary (mobile)" })).toBeVisible();
    await ctx.close();
  });

  test("3D scene loads lazily when WebGL is available", async ({ page }) => {
    await signIn(page);
    await page.goto("/campus");
    // Either the canvas mounts, or (no GPU in CI) the boundary falls back to the plan — never a blank page.
    await expect(page.locator("canvas").or(page.getByRole("img", { name: "Campus plan" }))).toBeVisible({ timeout: 15000 });
  });
});
