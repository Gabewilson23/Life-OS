import path from "node:path";
import { expect, test, type Page } from "@playwright/test";

const OWNER = { email: "owner@e2e.local", password: "e2e-very-long-password" };
async function signIn(page: Page) {
  await page.goto("/login");
  await page.getByLabel("Email").fill(OWNER.email);
  await page.getByLabel("Password").fill(OWNER.password);
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page.getByRole("heading", { level: 1 })).toContainText("Gabe");
}

test.describe.serial("slices 3–7", () => {
  test("chief-of-staff chat persists the message and shows an honest blocked state without a model key", async ({ page }) => {
    await signIn(page);
    await page.goto("/chat");
    await expect(page.getByText("Model credential missing")).toBeVisible();
    await page.getByRole("textbox", { name: "Message", exact: true }).fill("What should I focus on today?");
    await page.getByRole("button", { name: "Send" }).click();
    await expect(page.getByText("What should I focus on today?")).toBeVisible();
    await expect(page.getByText(/Not run — Model credential missing/)).toBeVisible({ timeout: 15000 });
  });

  test("memory: remember, then forget", async ({ page }) => {
    await signIn(page);
    await page.goto("/memory");
    await page.getByLabel("Remember this").fill("I protect Sunday mornings for family.");
    await page.getByLabel("Subject (topic key)").fill("schedule.sunday");
    await page.getByRole("button", { name: "Remember", exact: true }).click();
    await expect(page.getByText("I protect Sunday mornings for family.")).toBeVisible();
    page.once("dialog", (d) => d.dismiss());
    await page.getByRole("button", { name: "Forget" }).first().click();
    await expect(page.getByText("I protect Sunday mornings for family.")).toHaveCount(0); // removed from active retrieval
  });

  test("insurance import → console shows submitted vs placed vs paid AP from the file", async ({ page }) => {
    await signIn(page);
    await page.goto("/imports");
    await page.getByLabel("Dataset").selectOption("ins_policies");
    await page.getByLabel(/File/).setInputFiles(path.resolve("tests/fixtures/ins_policies.csv"));
    await expect(page.getByText("Map columns (4 rows)")).toBeVisible();
    await page.getByRole("button", { name: "Import 4 rows" }).click();
    await expect(page.getByText(/4 new/)).toBeVisible();
    await page.goto("/companies/atlas-insurance?from=2026-10-01&to=2026-10-31");
    await expect(page.locator("div").filter({ hasText: /^Submitted AP/ }).first()).toBeVisible();
    await expect(page.getByText("$2,600.50")).toBeVisible(); // submitted AP: 1,200 + 800.50 + 600
    await expect(page.getByText("$3,000.50")).toHaveCount(2); // issued AP and placed AP (both $3,000.50 in this fixture)
    await page.getByRole("link", { name: "Source records →" }).first().click();
    await expect(page.getByText("ins_policies.csv · row 2")).toBeVisible();
    await expect(page.getByText("A••• S•••")).toBeVisible(); // masked client name
  });

  test("briefing runs on demand and discloses data freshness", async ({ page }) => {
    await signIn(page);
    await page.goto("/briefings");
    await expect(page.getByText("Disabled (seeded schedules start off)").first()).toBeVisible();
    await page.getByRole("button", { name: "Briefing now" }).click();
    await expect(page).toHaveURL(/\/briefings\/[0-9a-f-]+$/);
    await expect(page.getByRole("heading", { name: "Sources & freshness" })).toBeVisible();
    await expect(page.getByText("Import: ins_policies")).toBeVisible();
  });

  test("integrations are honest: Google shows setup needed; catalog-only entries are labeled", async ({ page }) => {
    await signIn(page);
    await page.goto("/integrations");
    await expect(page.getByText("Setup needed").first()).toBeVisible();
    await expect(page.getByText("catalog-only").first()).toBeVisible();
    await page.goto("/approvals");
    await expect(page.getByRole("heading", { name: /Waiting on you/ })).toBeVisible();
  });

  test("Build Studio: contractor intake → test → activate → publish → public submission → record, task, local draft", async ({ page, browser }) => {
    await signIn(page);
    await page.goto("/studio");
    await page.getByRole("button", { name: "Contractor intake form + workflow" }).click();
    await expect(page).toHaveURL(/\/studio\/[0-9a-f-]+$/);
    const formUrl = page.url();
    await page.getByRole("link", { name: "Contractor intake workflow" }).click();
    await page.getByRole("button", { name: /Test v1 with sample/ }).click();
    await expect(page.getByText("Test run finished")).toBeVisible();
    await page.getByRole("button", { name: "Activate v1" }).click();
    await expect(page.getByText("v1 activated")).toBeVisible();
    await page.goto(formUrl);
    page.once("dialog", (d) => d.accept());
    await page.getByRole("button", { name: /Publish v1 publicly/ }).click();
    await expect(page.getByText("Published")).toBeVisible();
    const href = await page.getByRole("link", { name: /Open public form/ }).getAttribute("href");
    const anon = await browser.newContext();
    const pub = await anon.newPage();
    await pub.goto(href!);
    await pub.getByLabel("Full name").fill("Robin Field");
    await pub.getByLabel("Email").fill("robin@example.test");
    await pub.getByRole("button", { name: "Next" }).click();
    await pub.getByLabel("Primary skill / trade").fill("Carpentry");
    await pub.getByRole("checkbox", { name: /I consent/ }).check();
    await pub.getByRole("button", { name: "Submit" }).click();
    await expect(pub.getByText("Your submission was received.")).toBeVisible();
    await anon.close();
    await page.goto("/tasks");
    await expect(page.getByRole("button", { name: /Review contractor intake: Robin Field/ })).toBeVisible();
    await page.goto("/email");
    await expect(page.getByText("We received your contractor information")).toBeVisible();
    await expect(page.getByText("not synced").first()).toBeVisible();
  });

  test("desktop dock and notifications bell are present", async ({ page }) => {
    await signIn(page);
    await expect(page.getByRole("navigation", { name: "Dock" })).toBeVisible();
    await page.getByRole("link", { name: /Notifications/ }).click();
    await expect(page).toHaveURL(/\/notifications$/);
  });
});
