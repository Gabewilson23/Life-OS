import http from "node:http";
import crypto from "node:crypto";
import type { AddressInfo } from "node:net";

/** Local contract-test server emulating the subset of Google OAuth/Calendar/Gmail the adapters use. */
export interface FakeGoogle {
  url: string;
  events: Map<string, Record<string, unknown>>;
  drafts: Map<string, { id: string; raw: string; headers: { name: string; value: string }[] }>;
  refreshCount: number;
  calls: string[];
  /** Next N event inserts: 'drop' = fail before creating; 'ghost' = create then return 503 (lost response). */
  failMode: { insert?: "drop" | "ghost"; count?: number };
  codes: Map<string, { challenge: string; scope: string }>;
  close(): Promise<void>;
}

export async function startFakeGoogle(): Promise<FakeGoogle> {
  const f = { events: new Map(), drafts: new Map(), refreshCount: 0, calls: [] as string[], failMode: {} as FakeGoogle["failMode"], codes: new Map() } as unknown as FakeGoogle;
  const server = http.createServer(async (req, res) => {
    const chunks: Buffer[] = [];
    for await (const c of req) chunks.push(c as Buffer);
    const body = Buffer.concat(chunks).toString();
    const url = new URL(req.url!, "http://x");
    f.calls.push(`${req.method} ${url.pathname}`);
    const json = (code: number, obj: unknown) => { res.writeHead(code, { "content-type": "application/json" }); res.end(JSON.stringify(obj)); };
    if (url.pathname === "/token") {
      const p = new URLSearchParams(body);
      if (p.get("grant_type") === "refresh_token") { f.refreshCount++; await new Promise((r) => setTimeout(r, 50)); return json(200, { access_token: `ya29.refreshed${f.refreshCount}`, expires_in: 3600 }); }
      const c = f.codes.get(p.get("code") ?? "");
      if (!c) return json(400, { error: "invalid_grant" });
      const ch = crypto.createHash("sha256").update(p.get("code_verifier") ?? "").digest("base64url");
      if (ch !== c.challenge) return json(400, { error: "invalid_grant", error_description: "PKCE mismatch" });
      return json(200, { access_token: "ya29.first", refresh_token: "1//refresh", expires_in: 3600, scope: c.scope });
    }
    if (url.pathname === "/revoke") return json(200, {});
    if (url.pathname === "/oauth2/v3/userinfo") return json(200, { email: "owner@example.test" });
    const auth = req.headers.authorization ?? "";
    if (!auth.startsWith("Bearer ya29.")) return json(401, { error: "unauthorized" });
    let m;
    if ((m = url.pathname.match(/^\/calendar\/v3\/calendars\/([^/]+)\/events$/)) && req.method === "POST") {
      const ev = JSON.parse(body);
      if (f.failMode.insert && (f.failMode.count ?? 1) > 0) {
        f.failMode.count = (f.failMode.count ?? 1) - 1;
        const mode = f.failMode.insert;
        if (!f.failMode.count) f.failMode = {};
        if (mode === "drop") return json(503, { error: "backend" });
        f.events.set(ev.id, { ...ev, status: "confirmed", etag: '"1"' });
        return json(503, { error: "lost response" });
      }
      if (f.events.has(ev.id)) return json(409, { error: { code: 409, message: "duplicate" } });
      const stored = { ...ev, status: "confirmed", etag: '"1"', htmlLink: `https://calendar.test/${ev.id}` };
      f.events.set(ev.id, stored);
      return json(200, stored);
    }
    if ((m = url.pathname.match(/^\/calendar\/v3\/calendars\/([^/]+)\/events\/([^/]+)$/))) {
      const ev = f.events.get(decodeURIComponent(m[2]!));
      if (req.method === "GET") return ev ? json(200, ev) : json(404, { error: "notFound" });
      if (req.method === "DELETE") { if (!ev) return json(410, {}); f.events.delete(decodeURIComponent(m[2]!)); res.writeHead(204); return res.end(); }
    }
    if (url.pathname.match(/^\/calendar\/v3\/calendars\/[^/]+\/events$/) && req.method === "GET") {
      return json(200, { items: [...f.events.values()], nextSyncToken: "sync-1" });
    }
    if (url.pathname === "/calendar/v3/users/me/calendarList") return json(200, { items: [{ id: "primary" }] });
    if (url.pathname === "/gmail/v1/users/me/drafts" && req.method === "POST") {
      const raw = JSON.parse(body).message.raw as string;
      const text = Buffer.from(raw, "base64url").toString();
      const headers = text.split("\r\n\r\n")[0]!.split("\r\n").map((l) => ({ name: l.split(":")[0]!, value: l.slice(l.indexOf(":") + 1).trim() }));
      const id = `r-${f.drafts.size + 1}`;
      f.drafts.set(id, { id, raw, headers });
      return json(200, { id, message: { id: `m-${id}`, threadId: `t-${id}` } });
    }
    if (url.pathname === "/gmail/v1/users/me/drafts" && req.method === "GET") return json(200, { drafts: [...f.drafts.values()].map((d) => ({ id: d.id })) });
    if ((m = url.pathname.match(/^\/gmail\/v1\/users\/me\/drafts\/([^/]+)$/))) {
      const d = f.drafts.get(m[1]!);
      return d ? json(200, { id: d.id, message: { payload: { headers: d.headers } } }) : json(404, {});
    }
    json(404, { error: "not emulated", path: url.pathname });
  });
  await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
  const port = (server.address() as AddressInfo).port;
  f.url = `http://127.0.0.1:${port}`;
  process.env.GOOGLE_API_BASE = f.url;
  process.env.GOOGLE_GMAIL_BASE = f.url;
  process.env.GOOGLE_TOKEN_URL = `${f.url}/token`;
  process.env.GOOGLE_REVOKE_URL = `${f.url}/revoke`;
  process.env.GOOGLE_AUTH_URL = `${f.url}/auth`;
  f.close = () => new Promise((r) => server.close(() => r()));
  return f;
}
