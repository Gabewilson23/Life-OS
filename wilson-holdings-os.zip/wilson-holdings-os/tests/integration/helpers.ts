import { pool, withCtx, systemCtx, type Ctx } from "@/lib/server/db";
import { runMigrations } from "@/lib/server/migrate";
import { seedOrganization } from "@/lib/server/seed";
import { ORG_ID, SCOPES } from "@/lib/org/definitions";
import { hashPassword } from "@/lib/server/auth/password";

export async function freshDb() {
  await pool().query("DROP SCHEMA public CASCADE; CREATE SCHEMA public;");
  await runMigrations();
  await withCtx(systemCtx(ORG_ID, "test-seed"), (db) => seedOrganization(db, { defaultModel: "test-model", timezone: "America/New_York" }));
}

/** Creates a user with specific grants and returns their access context. */
export async function makeUser(email: string, grants: { scope: string; access: "read" | "write" }[], role = "member"): Promise<Ctx> {
  const h = await hashPassword("a-long-test-password");
  const { rows } = await pool().query(`INSERT INTO users(org_id, email, display_name, password_hash, role) VALUES ($1,$2,$3,$4,$5) RETURNING id`, [ORG_ID, email, email, h, role]);
  for (const g of grants) await pool().query(`INSERT INTO user_scope_grants(user_id, org_id, scope, access, granted_by) VALUES ($1,$2,$3,$4,'test')`, [rows[0].id, ORG_ID, g.scope, g.access]);
  return { orgId: ORG_ID, actorKind: "user", actorId: rows[0].id, scopes: grants.map((g) => g.scope), writeScopes: grants.filter((g) => g.access === "write").map((g) => g.scope) };
}

export const ALL_WRITE = SCOPES.map((s) => ({ scope: s.scope, access: "write" as const }));
