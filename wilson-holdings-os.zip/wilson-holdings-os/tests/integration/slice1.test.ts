import { afterAll, beforeAll, describe, expect, it } from "vitest";
import pg from "pg";
import { pool, withCtx, systemCtx, ConflictError, ForbiddenError, type Ctx } from "@/lib/server/db";
import { ORG_ID } from "@/lib/org/definitions";
import { login, setupOwner } from "@/lib/server/services/auth";
import { createSession, validateSession, revokeSession } from "@/lib/server/auth/session";
import { createGoal, createTask, listGoals, listTasks, updateGoal, updateTask, saveOutcome, getOutcomes, deleteGoal } from "@/lib/server/services/work";
import { listAgents, setAgentStatus, listBuildings, getAgent } from "@/lib/server/services/org";
import { freshDb, makeUser, ALL_WRITE } from "./helpers";

let owner: Ctx;

beforeAll(async () => {
  await freshDb();
  owner = await makeUser("owner@test.local", ALL_WRITE, "owner");
});
afterAll(async () => { await pool().end(); });

describe("seed", () => {
  it("creates 11 buildings and 52 roles with prompts, idempotently", async () => {
    await withCtx(systemCtx(ORG_ID), async (db) => {
      const { seedOrganization } = await import("@/lib/server/seed");
      await seedOrganization(db, { defaultModel: "test-model", timezone: "America/New_York" }); // re-run
      expect((await db.query("SELECT count(*)::int n FROM buildings")).rows[0].n).toBe(11);
      expect((await db.query("SELECT count(*)::int n FROM agent_definitions")).rows[0].n).toBe(52);
      expect((await db.query("SELECT count(*)::int n FROM agent_prompt_versions")).rows[0].n).toBe(52);
      expect((await db.query("SELECT count(*)::int n FROM policies WHERE level = 'escalate'")).rows[0].n).toBe(5);
    });
  });
  it("owner sees all 52 roles across 11 buildings", async () => {
    const [agents, buildings] = await withCtx(owner, (db) => Promise.all([listAgents(db), listBuildings(db)]));
    expect(agents).toHaveLength(52);
    expect(buildings).toHaveLength(11);
    expect(agents.every((a) => a.liveState === "idle")).toBe(true); // no fake activity
  });
});

describe("owner setup and sessions", () => {
  it("requires the setup token and refuses a second owner", async () => {
    await pool().query("DELETE FROM user_scope_grants; DELETE FROM sessions; DELETE FROM users WHERE email <> 'owner@test.local'");
    // A different DB state: temporarily hide existing users by testing via count check
    await expect(setupOwner({ setupToken: "wrong", expectedToken: "right", displayName: "X", email: "x@y.z", password: "a-long-password!" })).rejects.toThrow(/Invalid setup token/);
    await expect(setupOwner({ setupToken: "right", expectedToken: "right", displayName: "X", email: "x@y.z", password: "a-long-password!" })).rejects.toThrow(/already exists/);
  });
  it("logs in, validates, slides and revokes a session; locks out after repeated failures", async () => {
    const id = await login("owner@test.local", "a-long-test-password", null);
    const s = await createSession(id, {});
    const u = await validateSession(s.token);
    expect(u?.email).toBe("owner@test.local");
    await revokeSession(s.token);
    expect(await validateSession(s.token)).toBeNull();
    expect(await validateSession("not-a-token")).toBeNull();
    for (let i = 0; i < 10; i++) await expect(login("owner@test.local", "nope", null)).rejects.toThrow(/incorrect/);
    await expect(login("owner@test.local", "a-long-test-password", null)).rejects.toThrow(/Too many/);
    await pool().query("DELETE FROM login_attempts");
  });
});

describe("goals and tasks persist with concurrency control", () => {
  it("creates, edits and survives an app restart (new connection pool)", async () => {
    const g = await withCtx(owner, (db) => createGoal(db, owner, { scope: "org", title: "Confirm operating model", description: "", horizon: "quarterly", status: "active", progressNote: "" }));
    const g2 = await withCtx(owner, (db) => updateGoal(db, owner, g.id, { version: g.version, title: "Confirm Atlas Consulting operating model" }));
    expect(g2.version).toBe(2);
    // Simulate restart: brand-new pool reading the same database.
    const fresh = new pg.Pool({ connectionString: process.env.DATABASE_URL });
    const c = await fresh.connect();
    await c.query("BEGIN; SELECT set_config('app.org_id', $1, true), set_config('app.scopes', 'org', true)", [ORG_ID]).catch(async () => {
      await c.query("BEGIN"); await c.query("SELECT set_config('app.org_id', $1, true), set_config('app.scopes', 'org', true)", [ORG_ID]);
    });
    const r = await c.query("SELECT title, version FROM goals WHERE id = $1", [g.id]);
    await c.query("COMMIT"); c.release(); await fresh.end();
    expect(r.rows[0]).toEqual({ title: "Confirm Atlas Consulting operating model", version: 2 });
  });
  it("rejects stale writes instead of silently overwriting", async () => {
    const t = await withCtx(owner, (db) => createTask(db, owner, { scope: "org", title: "Draft Q1 plan", notes: "", status: "open", priority: 1 }));
    await withCtx(owner, (db) => updateTask(db, owner, t.id, { version: t.version, status: "in_progress" }));
    await expect(withCtx(owner, (db) => updateTask(db, owner, t.id, { version: t.version, status: "done" }))).rejects.toBeInstanceOf(ConflictError);
    const done = await withCtx(owner, (db) => updateTask(db, owner, t.id, { version: t.version + 1, status: "done" }));
    expect(done.completedAt).not.toBeNull();
    const reopened = await withCtx(owner, (db) => updateTask(db, owner, t.id, { version: done.version, status: "open" }));
    expect(reopened.completedAt).toBeNull();
  });
  it("deleting a goal unlinks but keeps tasks; audit is append-only", async () => {
    const g = await withCtx(owner, (db) => createGoal(db, owner, { scope: "org", title: "Temp", description: "", horizon: "weekly", status: "active", progressNote: "" }));
    const t = await withCtx(owner, (db) => createTask(db, owner, { scope: "org", title: "Linked", notes: "", status: "open", priority: 2, goalId: g.id }));
    await withCtx(owner, (db) => deleteGoal(db, owner, g.id, g.version));
    const tasks = await withCtx(owner, (db) => listTasks(db));
    expect(tasks.find((x) => x.id === t.id)?.goalId).toBeNull();
    await expect(withCtx(systemCtx(ORG_ID), (db) => db.query("UPDATE audit_events SET summary = 'x'"))).rejects.toThrow(/append-only/);
    const n = await withCtx(owner, (db) => db.query("SELECT count(*)::int n FROM audit_events WHERE resource_id = $1", [g.id]));
    expect(n.rows[0].n).toBe(2);
  });
  it("saves the chairman's three outcomes per local date", async () => {
    await withCtx(owner, (db) => saveOutcome(db, owner, { localDate: "2026-11-13", position: 1, title: "Close the agency plan", done: false, version: 0 }));
    await expect(withCtx(owner, (db) => saveOutcome(db, owner, { localDate: "2026-11-13", position: 1, title: "dup", done: false, version: 0 }))).rejects.toBeInstanceOf(ConflictError);
    await withCtx(owner, (db) => saveOutcome(db, owner, { localDate: "2026-11-13", position: 1, title: "Close the agency plan", done: true, version: 1 }));
    const o = await withCtx(owner, (db) => getOutcomes(db, owner, "2026-11-13"));
    expect(o[0]).toMatchObject({ title: "Close the agency plan", done: true, version: 2 });
    expect(o[1]).toMatchObject({ title: "", version: 0 });
  });
});

describe("scope isolation (application + row-level security)", () => {
  let insurance: Ctx;
  beforeAll(async () => {
    await withCtx(owner, async (db) => {
      await createTask(db, owner, { scope: "personal:health", title: "Physio follow-up", notes: "", status: "open", priority: 2 });
      await createTask(db, owner, { scope: "company:atlas-consulting", title: "Consulting SOW review", notes: "", status: "open", priority: 2 });
      await createTask(db, owner, { scope: "company:atlas-insurance", title: "Insurance licensing check", notes: "", status: "open", priority: 2 });
    });
    insurance = await makeUser("ins-lead@test.local", [{ scope: "company:atlas-insurance", access: "write" }, { scope: "org", access: "read" }]);
  });
  it("a company-scoped user cannot read the other company or private personal scopes", async () => {
    const titles = (await withCtx(insurance, (db) => listTasks(db))).map((t) => t.title);
    expect(titles).toContain("Insurance licensing check");
    expect(titles).not.toContain("Physio follow-up");
    expect(titles).not.toContain("Consulting SOW review");
    const agents = await withCtx(insurance, (db) => listAgents(db));
    expect(agents.some((a) => a.scope === "personal:health")).toBe(false);
    expect(await withCtx(insurance, (db) => getAgent(db, "hpc.performance-director"))).toBeNull();
  });
  it("app layer rejects writes to read-only or ungranted scopes", async () => {
    await expect(withCtx(insurance, (db) => createTask(db, insurance, { scope: "org", title: "x", notes: "", status: "open", priority: 2 }))).rejects.toBeInstanceOf(ForbiddenError);
    await expect(withCtx(insurance, (db) => createGoal(db, insurance, { scope: "personal:health", title: "x", description: "", horizon: "weekly", status: "active", progressNote: "" }))).rejects.toBeInstanceOf(ForbiddenError);
  });
  it("RLS blocks raw SQL that bypasses application checks", async () => {
    // Insert straight into the table, skipping assertWrite: the database itself refuses.
    await expect(withCtx(insurance, (db) => db.query(`INSERT INTO tasks(org_id, scope, title, created_by) VALUES ($1, 'org', 'sneaky', 'x')`, [ORG_ID]))).rejects.toThrow(/row-level security/);
    const upd = await withCtx(insurance, (db) => db.query(`UPDATE tasks SET title = 'pwned' WHERE scope = 'personal:health'`));
    expect(upd.rowCount).toBe(0);
    const raw = await withCtx(insurance, (db) => db.query(`SELECT count(*)::int n FROM tasks WHERE scope LIKE 'personal%'`));
    expect(raw.rows[0].n).toBe(0);
    // Without any context (e.g. a forgotten withCtx in a background job) nothing is visible.
    const none = await pool().query(`SELECT count(*)::int n FROM tasks`);
    expect(none.rows[0].n).toBe(0);
  });
  it("search-style queries are scope-filtered too", async () => {
    const r = await withCtx(insurance, (db) => db.query(`SELECT title FROM tasks WHERE title ILIKE '%review%' OR title ILIKE '%physio%'`));
    expect(r.rows).toHaveLength(0);
  });
});

describe("agent pause", () => {
  it("pausing a role cancels its queued runs and flags running ones; requires scope write", async () => {
    await withCtx(systemCtx(ORG_ID), async (db) => {
      await db.query(`INSERT INTO runs(org_id, scope, agent_id, state, requested_by) VALUES ($1,'org','hq.strategy-director','queued','test'), ($1,'org','hq.strategy-director','running','test')`, [ORG_ID]);
    });
    const before = (await withCtx(owner, (db) => listAgents(db))).find((a) => a.id === "hq.strategy-director")!;
    expect(before.liveState).toBe("running"); // derived from real runs
    const a = await withCtx(owner, (db) => getAgent(db, "hq.strategy-director"));
    await withCtx(owner, (db) => setAgentStatus(db, owner, "hq.strategy-director", "paused", a!.version));
    const runs = await withCtx(owner, (db) => db.query(`SELECT state, cancel_requested FROM runs WHERE agent_id = 'hq.strategy-director' ORDER BY state`));
    expect(runs.rows).toEqual([{ state: "cancelled", cancel_requested: false }, { state: "running", cancel_requested: true }]);
    const viewer = await makeUser("viewer@test.local", [{ scope: "org", access: "read" }], "viewer");
    await expect(withCtx(viewer, (db) => setAgentStatus(db, viewer, "hq.strategy-director", "idle", a!.version + 1))).rejects.toBeInstanceOf(ForbiddenError);
  });
});
