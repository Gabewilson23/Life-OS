import fs from "node:fs";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { pool, withCtx, ConflictError, ForbiddenError, type Ctx } from "@/lib/server/db";
import { commitImport, previewImport } from "@/lib/server/services/imports";
import { consultingMetrics, insuranceMetrics } from "@/lib/server/services/metrics";
import { freshDb, makeUser, ALL_WRITE } from "./helpers";

let owner: Ctx;
const fx = (f: string) => fs.readFileSync(`tests/fixtures/${f}`);
async function load(ds: string, file: string) {
  const p = await withCtx(owner, (db) => previewImport(db, owner, { dataset: ds, filename: file, data: fx(file) }));
  return withCtx(owner, (db) => commitImport(db, owner, p.batchId, p.mapping));
}

beforeAll(async () => {
  await freshDb();
  owner = await makeUser("owner@test.local", ALL_WRITE, "owner");
  for (const [d, f] of [["ins_people", "ins_people.csv"], ["ins_policies", "ins_policies.csv"], ["ins_commissions", "ins_commissions.csv"], ["con_projects", "con_projects.csv"], ["con_time", "con_time.csv"], ["con_expenses", "con_expenses.csv"], ["con_invoices", "con_invoices.csv"], ["con_payments", "con_payments.csv"]]) await load(d!, f!);
});
afterAll(async () => { await pool().end(); });

describe("insurance metrics from a known fixture", () => {
  it("distinguishes submitted, placed and paid AP and headcount from productive agents", async () => {
    const m = await withCtx(owner, (db) => insuranceMetrics(db, { from: "2026-10-01", to: "2026-10-31" }));
    const v = Object.fromEntries(m.metrics.map((x) => [x.key, x.value]));
    expect(v.submitted_ap).toBe(120000 + 80050 + 60000); // P103 submitted in September
    expect(v.placed_ap).toBe(120000 + 80050 + 100000);
    expect(v.paid_ap).toBe(120000 + 100000);
    expect(v.placement_rate).toBe(66.7); // 2 of 3 October submissions placed
    expect(v.headcount).toBe(3);
    expect(v.productive).toBe(2); // A3 placed nothing
    expect(v.advances_received).toBe(90000);
    expect(v.earned_received).toBe(10000);
    expect(v.chargebacks).toBe(-75000);
    expect(v.commission_gap).toBe(60038);
    expect(v.lapses).toBe(1);
    expect(v.missing_docs).toBe(1);
    expect(m.freshness.ins_policies?.file).toBe("ins_policies.csv");
  });
});

describe("consulting job cost and receivables", () => {
  it("computes approved job cost, margins, backlog vs pipeline and aging correctly", async () => {
    const m = await withCtx(owner, (db) => consultingMetrics(db, { from: "2026-10-01", to: "2026-10-31" }, "2026-11-15"));
    const j1 = m.projects.find((p) => p.key === "J1")!;
    expect(j1.costCents).toBe(55000 + 41250 + 25025); // unapproved time & expense excluded
    expect(j1.billedCents).toBe(1500000);
    expect(j1.collectedCents).toBe(600000);
    expect(j1.backlogCents).toBe(5000000 - 1500000);
    expect(j1.budgetVarianceCents).toBe(3000000 - 121275);
    const v = Object.fromEntries(m.metrics.map((x) => [x.key, x.value]));
    expect(v.backlog).toBe(3500000 + 2200000);
    expect(v.receivables).toBe(400000 + 500000);
    expect(m.aging.find((a) => a.bucket === "31-60")!.cents).toBe(400000); // I1 due 9/30, 46 days late
    expect(m.aging.find((a) => a.bucket === "1-30")!.cents).toBe(500000);
    expect(v.weighted_pipeline).toBe(0);
  });
});

describe("import safety", () => {
  it("rejects malformed files with row-level reasons and writes nothing invalid", async () => {
    await expect(withCtx(owner, (db) => previewImport(db, owner, { dataset: "ins_policies", filename: "malformed.csv", data: fx("malformed.csv") }))).rejects.toThrow(/unterminated/);
    const ok = Buffer.from("Policy Number,AP,Submit Date,Status\nP900,12.345,2026-13-01,bogus\n,100,2026-10-01,submitted\nP901,100,2026-10-01,submitted\n");
    const p = await withCtx(owner, (db) => previewImport(db, owner, { dataset: "ins_policies", filename: "bad.csv", data: ok }));
    const r = await withCtx(owner, (db) => commitImport(db, owner, p.batchId, p.mapping));
    expect(r).toMatchObject({ inserted: 1, rejected: 2 });
    expect(r.errors[0]!.errors.join(" ")).toMatch(/more than 2 decimal.*valid calendar date|valid calendar date/);
  });
  it("deduplicates: same file is refused; changed rows update; identical rows are unchanged", async () => {
    const p = await withCtx(owner, (db) => previewImport(db, owner, { dataset: "con_projects", filename: "con_projects.csv", data: fx("con_projects.csv") }));
    expect(p.duplicateOfBatch).not.toBeNull();
    await expect(withCtx(owner, (db) => commitImport(db, owner, p.batchId, p.mapping))).rejects.toBeInstanceOf(ConflictError);
    const changed = Buffer.from(fx("con_projects.csv").toString().replace("amber", "red"));
    const p2 = await withCtx(owner, (db) => previewImport(db, owner, { dataset: "con_projects", filename: "con_projects_v2.csv", data: changed }));
    const r = await withCtx(owner, (db) => commitImport(db, owner, p2.batchId, p2.mapping));
    expect(r).toMatchObject({ inserted: 0, updated: 1, unchanged: 1 });
  });
  it("company scopes are enforced on imports and metrics", async () => {
    const ins = await makeUser("ins@test.local", [{ scope: "company:atlas-insurance", access: "write" }]);
    await expect(withCtx(ins, (db) => previewImport(db, ins, { dataset: "con_projects", filename: "x.csv", data: fx("con_projects.csv") }))).rejects.toBeInstanceOf(ForbiddenError);
    const m = await withCtx(ins, (db) => consultingMetrics(db, { from: "2026-10-01", to: "2026-10-31" }, "2026-11-15"));
    expect(m.projects).toHaveLength(0); // RLS hides the other company entirely
  });
});
