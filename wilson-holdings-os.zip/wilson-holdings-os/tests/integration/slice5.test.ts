import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import { pool, withCtx, systemCtx, ConflictError, type Ctx } from "@/lib/server/db";
import { ORG_ID } from "@/lib/org/definitions";
import { encrypt, redact } from "@/lib/server/crypto";
import { accessToken, beginGoogleAuth, completeGoogleAuth, revokeGoogle } from "@/lib/server/integrations/google";
import { calendarEventIdFor, googleCalendar } from "@/lib/server/integrations/adapters";
import { decideApproval, executeApproval, reconcileAttempt, requestApproval } from "@/lib/server/services/approvals";
import { freshDb, makeUser, ALL_WRITE } from "./helpers";
import { startFakeGoogle, type FakeGoogle } from "./fake-google";
import crypto from "node:crypto";

let owner: Ctx; let fake: FakeGoogle; let acct: string;
const ev = (title: string, extra: Record<string, unknown> = {}) => ({ title, start: "2026-11-20T15:00:00-05:00", end: "2026-11-20T16:00:00-05:00", calendarId: "primary", ...extra });

async function newAccount(scope = "personal", expiresIn = 3600) {
  return (await withCtx(systemCtx(ORG_ID), (db) => db.query(
    `INSERT INTO integration_accounts(org_id, scope, provider, label, status, capabilities, access_token_enc, refresh_token_enc, token_expires_at, created_by)
     VALUES ($1,$2,'google','Test','healthy',ARRAY['calendar.read','calendar.write','gmail.draft'],$3,$4, now() + make_interval(secs => $5),'test') RETURNING id`,
    [ORG_ID, scope, encrypt("ya29.valid"), encrypt("1//refresh"), expiresIn]))).rows[0].id as string;
}
async function approveAndRun(kind: "calendar.event.create" | "email.draft.create", payload: Record<string, unknown>, account = acct) {
  const r = await withCtx(owner, (db) => requestApproval(db, owner, { kind, scope: "personal", accountId: account, payload }));
  if (r.status === "pending") await withCtx(owner, (db) => decideApproval(db, owner, r.id, true, r.hash));
  return { approval: r, result: await executeApproval(owner, r.id) };
}

beforeAll(async () => {
  await freshDb();
  owner = await makeUser("owner@test.local", ALL_WRITE, "owner");
  fake = await startFakeGoogle();
  acct = await newAccount();
});
beforeEach(() => { fake.failMode = {}; });
afterAll(async () => { await fake.close(); await pool().end(); });

describe("approval → action → verification", () => {
  it("needs approval, creates exactly one event, verifies it and records the remote ID", async () => {
    const r = await withCtx(owner, (db) => requestApproval(db, owner, { kind: "calendar.event.create", scope: "personal", accountId: acct, payload: ev("Deep work", { attendees: ["a@example.test"] }) }));
    expect(r.status).toBe("pending");
    expect(r.preview.discloses[0]).toMatch(/invitations/);
    await expect(executeApproval(owner, r.id)).rejects.toThrow(/pending/);
    await expect(withCtx(owner, (db) => decideApproval(db, owner, r.id, true, "f".repeat(64)))).rejects.toBeInstanceOf(ConflictError);
    await withCtx(owner, (db) => decideApproval(db, owner, r.id, true, r.hash));
    const out = await executeApproval(owner, r.id);
    expect(out).toMatchObject({ state: "succeeded", verified: true, remoteId: calendarEventIdFor(`approval:${r.id}`) });
    expect(fake.events.size).toBe(1);
    // Replaying the same approval cannot create a duplicate.
    await expect(executeApproval(owner, r.id)).rejects.toThrow(/already used/);
    expect(fake.events.size).toBe(1);
    const mirror = (await withCtx(owner, (db) => db.query("SELECT remote_id FROM calendar_events WHERE remote_id = $1", [out.remoteId]))).rows;
    expect(mirror).toHaveLength(1);
  });

  it("lost provider response (uncertain) is reconciled by verification, not resent", async () => {
    fake.failMode = { insert: "ghost", count: 1 };
    const before = fake.events.size;
    const { result } = await approveAndRun("calendar.event.create", ev("Ghost"));
    expect(result.state).toBe("succeeded"); // verify found it
    expect(fake.events.size).toBe(before + 1);
  });

  it("a failed attempt confirmed absent is retried once with the same idempotency key", async () => {
    fake.failMode = { insert: "drop", count: 1 };
    const before = fake.events.size;
    const { result } = await approveAndRun("calendar.event.create", ev("Retry me"));
    expect(result.state).toBe("failed");
    expect(fake.events.size).toBe(before);
    const again = await reconcileAttempt(owner, result.attemptId, { retryIfAbsent: true });
    expect(again.state).toBe("succeeded");
    const twice = await reconcileAttempt(owner, result.attemptId, { retryIfAbsent: true });
    expect(twice.state).toBe("succeeded");
    expect(fake.events.size).toBe(before + 1);
  });

  it("an altered approval cannot execute; global pause and revocation stop approved writes", async () => {
    const r = await withCtx(owner, (db) => requestApproval(db, owner, { kind: "calendar.event.create", scope: "personal", accountId: acct, payload: ev("Original") }));
    await withCtx(owner, (db) => decideApproval(db, owner, r.id, true, r.hash));
    await withCtx(systemCtx(ORG_ID), (db) => db.query(`UPDATE approvals SET payload = jsonb_set(payload, '{title}', '"Tampered"') WHERE id = $1`, [r.id]));
    await expect(executeApproval(owner, r.id)).rejects.toThrow(/does not match/);

    const p = await withCtx(owner, (db) => requestApproval(db, owner, { kind: "calendar.event.create", scope: "personal", accountId: acct, payload: ev("Paused") }));
    await withCtx(owner, (db) => decideApproval(db, owner, p.id, true, p.hash));
    await withCtx(systemCtx(ORG_ID), (db) => db.query("UPDATE system_flags SET value = 'true' WHERE key = 'pause.global'"));
    await expect(executeApproval(owner, p.id)).rejects.toThrow(/Global pause/);
    await withCtx(systemCtx(ORG_ID), (db) => db.query("UPDATE system_flags SET value = 'false' WHERE key = 'pause.global'"));

    const other = await newAccount();
    const q = await withCtx(owner, (db) => requestApproval(db, owner, { kind: "calendar.event.create", scope: "personal", accountId: other, payload: ev("Revoked") }));
    await withCtx(owner, (db) => decideApproval(db, owner, q.id, true, q.hash));
    await revokeGoogle(owner, other);
    await expect(executeApproval(owner, q.id)).rejects.toThrow(/revoked|is revoked/);
  });

  it("company scopes cannot use another company's account", async () => {
    const insAcct = await newAccount("company:atlas-insurance");
    await expect(withCtx(owner, (db) => requestApproval(db, owner, { kind: "calendar.event.create", scope: "company:atlas-consulting", accountId: insAcct, payload: ev("x") }))).rejects.toThrow(/different company/);
  });

  it("a narrow standing permission auto-approves private blocks only", async () => {
    await withCtx(owner, (db) => db.query(`INSERT INTO standing_permissions(org_id, scope, action_kind, account_id, constraints, description, created_by) VALUES ($1,'personal','calendar.event.create',$2,'{"no_attendees": true, "private_only": true}','Private focus blocks','test')`, [ORG_ID, acct]));
    const a = await withCtx(owner, (db) => requestApproval(db, owner, { kind: "calendar.event.create", scope: "personal", accountId: acct, payload: ev("Focus") }));
    expect(a.status).toBe("approved");
    const b = await withCtx(owner, (db) => requestApproval(db, owner, { kind: "calendar.event.create", scope: "personal", accountId: acct, payload: ev("Meeting", { attendees: ["x@example.test"] }) }));
    expect(b.status).toBe("pending");
  });

  it("creates a Gmail draft (never sends) and verifies it by idempotency header", async () => {
    const { result } = await approveAndRun("email.draft.create", { to: ["client@example.test"], subject: "Status", body: "Draft body" });
    expect(result).toMatchObject({ state: "succeeded", verified: true });
    expect(fake.drafts.size).toBe(1);
    expect(fake.calls.some((c) => c.includes("/send"))).toBe(false);
  });
});

describe("OAuth and tokens", () => {
  it("uses state + PKCE S256 and binds the callback to the initiating user", async () => {
    const url = new URL(await beginGoogleAuth(owner, { scope: "personal", label: "Personal Google", capabilities: ["calendar.read", "calendar.write"] }));
    expect(url.searchParams.get("code_challenge_method")).toBe("S256");
    const state = url.searchParams.get("state")!;
    fake.codes.set("good-code", { challenge: url.searchParams.get("code_challenge")!, scope: "openid email https://www.googleapis.com/auth/calendar.readonly" });
    await expect(completeGoogleAuth("00000000-0000-0000-0000-000000000000", state, "good-code")).rejects.toThrow(/Invalid or expired/);
    // state is single-use: the failed attempt consumed it
    const url2 = new URL(await beginGoogleAuth(owner, { scope: "personal", label: "Personal Google", capabilities: ["calendar.read", "calendar.write"] }));
    fake.codes.set("good-code-2", { challenge: url2.searchParams.get("code_challenge")!, scope: "openid email https://www.googleapis.com/auth/calendar.readonly" });
    const res = await completeGoogleAuth(owner.actorId, url2.searchParams.get("state")!, "good-code-2");
    expect(res.partial).toBe(true); // calendar.write was not granted → partial access is reported
    const row = (await withCtx(owner, (db) => db.query("SELECT capabilities, access_token_enc, external_account FROM integration_accounts WHERE id = $1", [res.id]))).rows[0];
    expect(row.capabilities).toEqual(["calendar.read"]);
    expect(row.access_token_enc).not.toContain("ya29"); // encrypted at rest
    expect(row.external_account).toBe("owner@example.test");
  });

  it("refreshes an expired token exactly once under concurrency", async () => {
    const a = await newAccount("personal", 0);
    const before = fake.refreshCount;
    const [t1, t2] = await Promise.all([accessToken(ORG_ID, a), accessToken(ORG_ID, a)]);
    expect(fake.refreshCount - before).toBe(1);
    expect(t1).toBe(t2);
  });

  it("redacts secrets from logged errors", () => {
    expect(redact('{"access_token":"ya29.abc","refresh_token":"1//xyz"} Bearer ya29.qq sk-ant-123')).not.toMatch(/ya29\.abc|1\/\/xyz|ya29\.qq|sk-ant-123/);
  });

  it("health and incremental pull work against the contract server", async () => {
    expect((await googleCalendar.health(ORG_ID, acct)).ok).toBe(true);
    const r = await googleCalendar.pull!(ORG_ID, acct);
    expect(r.upserted).toBeGreaterThan(0);
    const cur = (await withCtx(systemCtx(ORG_ID), (db) => db.query("SELECT cursor FROM sync_cursors WHERE account_id = $1", [acct]))).rows[0];
    expect(cur.cursor).toBe("sync-1");
  });
});
void crypto;
