import http from "node:http";
import type { AddressInfo } from "node:net";
import { afterAll, afterEach, beforeAll, describe, expect, it } from "vitest";
import { pool, withCtx, systemCtx, type Ctx } from "@/lib/server/db";
import { ORG_ID } from "@/lib/org/definitions";
import { encrypt } from "@/lib/server/crypto";
import { setModelAdapterForTests } from "@/lib/server/model";
import { ScriptedAdapter } from "@/lib/server/model/scripted";
import { runDueSchedules, tick } from "@/lib/server/services/scheduler";
import { runMeeting } from "@/lib/server/services/meetings";
import { notify } from "@/lib/server/services/notifications";
import { receiveWebhook, sendWebhook, sign } from "@/lib/server/services/webhooks";
import { _isPrivateForTests, assertSafeOutboundUrl } from "@/lib/server/net";
import { discoverAtlasCrm, pullAtlasCrmAgents } from "@/lib/server/integrations/atlas-crm";
import { freshDb, makeUser, ALL_WRITE } from "./helpers";

let owner: Ctx;
const req = (c: Ctx) => ({ id: c.actorId, orgId: c.orgId, readScopes: c.scopes, writeScopes: c.writeScopes });
beforeAll(async () => { await freshDb(); owner = await makeUser("owner@test.local", ALL_WRITE, "owner"); });
afterEach(() => setModelAdapterForTests(null));
afterAll(async () => { await pool().end(); });

describe("scheduled briefings", () => {
  it("seeded schedules are disabled until activated", async () => {
    expect(await runDueSchedules(ORG_ID, new Date("2026-11-13T12:31:00Z"))).toEqual([]);
  });
  it("runs once per window across repeated/concurrent ticks and restarts, including the DST-change day", async () => {
    await withCtx(systemCtx(ORG_ID), (db) => db.query(`UPDATE schedules SET enabled = true WHERE id = 'sched.chairman-briefing'`));
    const fallBack = new Date("2026-11-01T12:31:00Z"); // 7:31 AM EST on the day clocks fell back
    const [a, b] = await Promise.all([runDueSchedules(ORG_ID, fallBack), runDueSchedules(ORG_ID, fallBack)]);
    expect([...a, ...b]).toEqual(["sched.chairman-briefing@2026-11-01"]);
    expect(await runDueSchedules(ORG_ID, new Date("2026-11-01T15:00:00Z"))).toEqual([]); // later the same day: same window
    expect(await runDueSchedules(ORG_ID, new Date("2026-11-01T11:31:00Z"))).toEqual([]); // 6:31 EST: before 7:30 local
    expect(await runDueSchedules(ORG_ID, new Date("2026-11-02T12:30:30Z"))).toEqual(["sched.chairman-briefing@2026-11-02"]);
    const n = (await withCtx(systemCtx(ORG_ID), (db) => db.query(`SELECT count(*)::int n FROM reports WHERE kind = 'chairman_briefing'`))).rows[0].n;
    expect(n).toBe(2);
  });
  it("reports disclose missing/stale sources instead of fabricating figures, and are reproducible", async () => {
    const r = (await withCtx(systemCtx(ORG_ID), (db) => db.query(`SELECT data, source_cutoff, metric_version, reading_minutes FROM reports ORDER BY created_at DESC LIMIT 1`))).rows[0];
    const secs = r.data.sections as { title: string; items: unknown[]; empty?: string }[];
    expect(secs[0]!.title).toBe("Sources & freshness");
    expect(secs[0]!.empty).toMatch(/missing, not zero/);
    expect(secs.find((s) => s.title.startsWith("Atlas Insurance"))!.items).toHaveLength(0);
    expect(r.metric_version).toBe("metrics-v1");
    expect(r.reading_minutes).toBeGreaterThanOrEqual(1);
    expect(secs.at(-1)!.title).toBe("Since last report");
  });
  it("tick records a worker heartbeat and processes nothing it shouldn't", async () => {
    const out = await tick("worker:test", { now: new Date("2026-11-03T03:00:00Z") });
    expect(out.schedules).toEqual([]);
    const hb = (await pool().query(`SELECT kind FROM worker_heartbeats WHERE worker_id = 'worker:test'`)).rows[0];
    expect(hb.kind).toBe("worker");
  });
});

describe("notifications", () => {
  it("deduplicates repeated alerts", async () => {
    for (let i = 0; i < 3; i++) await notify(ORG_ID, { scope: "org", kind: "system", title: "Sync failing", priority: "urgent", dedupeKey: "sync:x" });
    const r = (await withCtx(owner, (db) => db.query(`SELECT occurrences FROM notifications WHERE dedupe_key = 'sync:x'`))).rows;
    expect(r).toEqual([{ occurrences: 3 }]);
  });
});

describe("bounded AI meetings", () => {
  it("calls each participant per round, then records decisions, dissent and owned actions as tasks", async () => {
    setModelAdapterForTests(new ScriptedAdapter((rq) => {
      const last = rq.messages.at(-1)!.content as string;
      if (typeof last === "string" && last.startsWith("Synthesize")) return { content: [{ type: "text", text: JSON.stringify({ summary: "Agreed to focus recruiting.", decisions: [{ text: "Prioritize referral recruiting", evidence: "Recruiting Manager round 1" }], dissent: [{ text: "Lead spend may still be needed", by: "ins.lead-economics-analyst" }], actions: [{ title: "Draft referral program", owner_agent_id: "ins.recruiting-manager", due_date: "2026-11-20" }] }) }], stopReason: "end_turn", usage: { inputTokens: 1, outputTokens: 1 } };
      return { content: [{ type: "text", text: "Contribution: referrals convert better (source: cohort data)." }], stopReason: "end_turn", usage: { inputTokens: 1, outputTokens: 1 } };
    }));
    const r = await runMeeting(owner, req(owner), { title: "Recruiting focus", agenda: "Where should Q1 recruiting effort go?", participants: ["ins.recruiting-manager", "ins.lead-economics-analyst"], maxRounds: 2, scope: "company:atlas-insurance" });
    expect(r.status).toBe("completed");
    const contribs = (await withCtx(owner, (db) => db.query(`SELECT count(*)::int n FROM meeting_contributions WHERE meeting_id = $1`, [r.meetingId]))).rows[0].n;
    expect(contribs).toBe(4); // 2 participants × 2 rounds — bounded
    const outs = (await withCtx(owner, (db) => db.query(`SELECT kind, owner_agent_id, task_id FROM meeting_outcomes WHERE meeting_id = $1 ORDER BY kind`, [r.meetingId]))).rows;
    expect(outs.map((o) => o.kind)).toEqual(["action", "decision", "dissent"]);
    const task = (await withCtx(owner, (db) => db.query(`SELECT assignee_kind, assignee_id, scope FROM tasks WHERE id = $1`, [outs[0]!.task_id]))).rows[0];
    expect(task).toEqual({ assignee_kind: "agent", assignee_id: "ins.recruiting-manager", scope: "company:atlas-insurance" });
  });
  it("stops honestly when runs are blocked (no model credential) and rejects >3 rounds", async () => {
    const r = await runMeeting(owner, req(owner), { title: "x", agenda: "y", participants: ["hq.strategy-director"], maxRounds: 1 });
    expect(r.status).toBe("blocked");
    await expect(runMeeting(owner, req(owner), { title: "x", agenda: "y", participants: ["hq.strategy-director"], maxRounds: 9 })).rejects.toThrow();
  });
});

describe("webhooks", () => {
  let epId: string;
  beforeAll(async () => {
    epId = (await withCtx(owner, (db) => db.query(`INSERT INTO webhook_endpoints(org_id, scope, direction, name, secret_enc, allowed_events, created_by) VALUES ($1,'org','inbound','Test hook',$2,ARRAY['task.suggest'],'test') RETURNING id`, [ORG_ID, encrypt("s3cret")]))).rows[0].id;
  });
  const signed = (body: string, ts = String(Math.floor(Date.now() / 1000)), nonce = Math.random().toString(36).slice(2)) => ({ ts, nonce, sig: sign("s3cret", ts, nonce, body) });
  it("accepts a valid signed event once and turns it into a proposal, not an action", async () => {
    const body = JSON.stringify({ event: "task.suggest", id: "evt-1", data: { title: "Follow up with carrier" } });
    const h = signed(body);
    expect((await receiveWebhook(epId, h, body)).status).toBe(202);
    expect((await receiveWebhook(epId, h, body)).duplicate).toBe(true); // replayed
    expect((await receiveWebhook(epId, signed(body), body)).duplicate).toBe(true); // same event id, new nonce
    const p = (await withCtx(owner, (db) => db.query(`SELECT status FROM proposals WHERE title LIKE '%Follow up with carrier%'`))).rows;
    expect(p).toEqual([{ status: "proposed" }]);
    expect((await withCtx(owner, (db) => db.query(`SELECT count(*)::int n FROM tasks WHERE title = 'Follow up with carrier'`))).rows[0].n).toBe(0);
  });
  it("rejects bad signatures, stale timestamps, schema violations and disallowed events", async () => {
    const body = JSON.stringify({ event: "task.suggest", id: "evt-2", data: {} });
    expect((await receiveWebhook(epId, { ...signed(body), sig: "0".repeat(64) }, body)).status).toBe(401);
    expect((await receiveWebhook(epId, signed(body, String(Math.floor(Date.now() / 1000) - 3600)), body)).status).toBe(401);
    const bad = JSON.stringify({ event: "task.suggest", data: "nope" });
    expect((await receiveWebhook(epId, signed(bad), bad)).status).toBe(422);
    const other = JSON.stringify({ event: "money.move", id: "e3", data: {} });
    expect((await receiveWebhook(epId, signed(other), other)).status).toBe(403);
  });
  it("blocks SSRF destinations and unauthorized outbound events", async () => {
    for (const ip of ["127.0.0.1", "10.0.0.5", "169.254.169.254", "192.168.1.1", "::1", "fd00::1", "100.64.0.1"]) expect(_isPrivateForTests(ip)).toBe(true);
    expect(_isPrivateForTests("8.8.8.8")).toBe(false);
    await expect(assertSafeOutboundUrl("http://example.com/x")).rejects.toThrow(/https/);
    await expect(assertSafeOutboundUrl("https://169.254.169.254/latest/meta-data")).rejects.toThrow(/private/);
    await expect(assertSafeOutboundUrl("https://user:pw@example.com")).rejects.toThrow(/Credentials/);
    const out = (await withCtx(owner, (db) => db.query(`INSERT INTO webhook_endpoints(org_id, scope, direction, name, url, secret_enc, allowed_events, created_by) VALUES ($1,'org','outbound','Out','https://127.0.0.1/hook',$2,ARRAY['report.ready'],'test') RETURNING id`, [ORG_ID, encrypt("k")]))).rows[0].id;
    await expect(sendWebhook(ORG_ID, out, "secrets.dump", {}, "k1")).rejects.toThrow(/not authorized/);
    await expect(sendWebhook(ORG_ID, out, "report.ready", {}, "k2")).rejects.toThrow(/private/);
  });
});

describe("Atlas CRM contract adapter", () => {
  it("discovers capabilities and pulls paginated agents through the configured mapping", async () => {
    const server = http.createServer((rq, rs) => {
      if (rq.headers["x-api-key"] !== "crm-key") { rs.writeHead(401); return rs.end(); }
      const u = new URL(rq.url!, "http://x");
      rs.setHeader("content-type", "application/json");
      if (u.pathname === "/api/capabilities") return rs.end(JSON.stringify({ version: "1", resources: [{ name: "agents", fields: ["agent_no", "display_name", "state"] }] }));
      if (u.pathname === "/api/agents") return rs.end(JSON.stringify(u.searchParams.get("cursor") ? { items: [{ agent_no: "Z2", display_name: "Kai Moss", kind: "agent", state: "active" }], next_cursor: null } : { items: [{ agent_no: "Z1", display_name: "Lee Park", kind: "agent", state: "licensing" }, { agent_no: "", display_name: "No Key", kind: "agent", state: "active" }], next_cursor: "p2" }));
      rs.writeHead(404); rs.end();
    });
    await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
    const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}/api/`;
    const cfg = (await withCtx(owner, (db) => db.query(`INSERT INTO connector_configs(org_id, scope, connector, base_url, auth_header, secret_enc, mapping, trusted_internal, created_by) VALUES ($1,'company:atlas-insurance','atlas-crm',$2,'x-api-key',$3,$4,true,'test') RETURNING id`,
      [ORG_ID, base, encrypt("crm-key"), { key: "agent_no", fields: { display_name: "name", kind: "kind", state: "stage" } }]))).rows[0].id;
    expect((await discoverAtlasCrm(ORG_ID, cfg)).resources[0]!.name).toBe("agents");
    const r = await pullAtlasCrmAgents(owner, cfg);
    expect(r).toMatchObject({ inserted: 2, rejected: 1 });
    const again = await pullAtlasCrmAgents(owner, cfg);
    expect(again).toMatchObject({ inserted: 0, unchanged: 2 });
    server.close();
  });
});
