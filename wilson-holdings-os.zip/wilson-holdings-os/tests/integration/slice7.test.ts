import http from "node:http";
import type { AddressInfo } from "node:net";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { pool, withCtx, systemCtx, ConflictError, ForbiddenError, type Ctx } from "@/lib/server/db";
import { ORG_ID } from "@/lib/org/definitions";
import { base32Encode, totpAt, verifyTotp } from "@/lib/server/auth/totp";
import { encrypt } from "@/lib/server/crypto";
import { login } from "@/lib/server/services/auth";
import { activate, addVersion, contractorIntakeTemplate, createCapability, rollback, setStatus, submitForm, testWorkflow } from "@/lib/server/services/studio";
import { approveRelease, createChangeRequest, refreshChecks, requestRelease, startDevelopment } from "@/lib/server/services/changes";
import { freshDb, makeUser, ALL_WRITE } from "./helpers";

let owner: Ctx;
beforeAll(async () => { await freshDb(); owner = await makeUser("owner@test.local", ALL_WRITE, "owner"); });
afterAll(async () => { await pool().end(); });

describe("MFA (TOTP)", () => {
  it("matches the RFC 6238 SHA-1 test vector", () => {
    const secret = base32Encode(Buffer.from("12345678901234567890"));
    expect(totpAt(secret, 1)).toBe("287082");
    expect(verifyTotp(secret, "287082", 59_000)).toBe(1);
  });
  it("requires a code at login and rejects replayed codes", async () => {
    const secret = base32Encode(Buffer.from("abcdefghijabcdefghij"));
    await pool().query(`UPDATE users SET mfa_enabled = true, mfa_secret = $2 WHERE id = $1`, [owner.actorId, encrypt(secret)]);
    await expect(login("owner@test.local", "a-long-test-password", null)).rejects.toThrow(/6-digit code/);
    const code = totpAt(secret, Math.floor(Date.now() / 30_000));
    await expect(login("owner@test.local", "a-long-test-password", null, code)).resolves.toBe(owner.actorId);
    await expect(login("owner@test.local", "a-long-test-password", null, code)).rejects.toThrow(/already used/);
    await pool().query(`UPDATE users SET mfa_enabled = false WHERE id = $1`, [owner.actorId]);
    await pool().query(`DELETE FROM login_attempts`);
  });
});

describe("Build Studio: contractor intake (acceptance scenarios 1–2)", () => {
  let formId: string, wfId: string;
  const scope = "company:atlas-consulting";
  const sample = { full_name: "Chris Vega", email: "chris@example.test", trade: "Electrical", rate_expectation: "65", has_insurance: true, insurance_carrier: "Acme Mutual", _consent: true };
  it("creates editable drafts, requires a passing test before activation, and a bound confirmation to publish publicly", async () => {
    const t = contractorIntakeTemplate();
    formId = await withCtx(owner, (db) => createCapability(db, owner, { scope, kind: "form", name: "Contractor intake", slug: "contractor-intake", definition: t.form }));
    wfId = await withCtx(owner, (db) => createCapability(db, owner, { scope, kind: "workflow", name: "Contractor intake workflow", slug: "contractor-intake-workflow", definition: t.workflow }));
    await expect(withCtx(owner, (db) => activate(db, owner, wfId, 1))).rejects.toThrow(/Test this workflow/);
    const test = await withCtx(owner, (db) => testWorkflow(db, owner, wfId, 1, sample));
    expect(test.status).toBe("succeeded");
    await withCtx(owner, (db) => activate(db, owner, wfId, 1));
    await expect(withCtx(owner, (db) => activate(db, owner, formId, 1, { access: "public" }))).rejects.toThrow(/exact previewed version/);
    const hash = (await withCtx(owner, (db) => db.query(`SELECT definition_hash FROM capability_versions WHERE capability_id = $1 AND version = 1`, [formId]))).rows[0].definition_hash;
    await withCtx(owner, (db) => activate(db, owner, formId, 1, { access: "public", confirmHash: hash }));
  });
  it("one submission → exactly one scoped contractor record, one assigned review task, one local unsynced draft; replay adds nothing", async () => {
    const r = await submitForm(ORG_ID, "contractor-intake", sample, { clientKey: "client-1", sourceHash: "ip-a", isPublic: true });
    expect(r.errors).toEqual({});
    const again = await submitForm(ORG_ID, "contractor-intake", sample, { clientKey: "client-1", sourceHash: "ip-a", isPublic: true });
    expect(again).toMatchObject({ duplicate: true, submissionId: r.submissionId });
    const q = async (sql: string) => (await withCtx(systemCtx(ORG_ID), (db) => db.query(sql))).rows;
    expect(await q(`SELECT scope, data->>'full_name' AS n FROM custom_records WHERE record_type = 'contractor' AND NOT is_test`)).toEqual([{ scope, n: "Chris Vega" }]);
    expect(await q(`SELECT assignee_id, scope FROM tasks WHERE title LIKE 'Review contractor intake: Chris Vega%'`)).toEqual([{ assignee_id: "con.project-delivery-manager", scope }]);
    expect(await q(`SELECT to_addrs, sync_state FROM email_drafts WHERE subject = 'We received your contractor information'`)).toEqual([{ to_addrs: ["chris@example.test"], sync_state: "local_only" }]);
  });
  it("validates input, conditional visibility, consent, honeypot and rate limits", async () => {
    const bad = await submitForm(ORG_ID, "contractor-intake", { full_name: "", email: "nope", _consent: true }, { clientKey: "c2", sourceHash: "ip-b", isPublic: true });
    expect(Object.keys(bad.errors)).toEqual(expect.arrayContaining(["full_name", "email", "trade"]));
    expect((await submitForm(ORG_ID, "contractor-intake", { ...sample }, { clientKey: "c3", sourceHash: "ip-b", isPublic: true }).then(() => null, (e) => e)) ).toBeNull();
    const noConsent = await submitForm(ORG_ID, "contractor-intake", { ...sample, _consent: false }, { clientKey: "c4", sourceHash: "ip-b", isPublic: true });
    expect(noConsent.errors).toHaveProperty("_consent");
    await expect(submitForm(ORG_ID, "contractor-intake", { ...sample, _hp: "bot" }, { clientKey: "c5", sourceHash: "ip-b", isPublic: true })).rejects.toThrow(/rejected/);
    const hidden = (await withCtx(systemCtx(ORG_ID), (db) => db.query(`SELECT data FROM form_submissions WHERE client_key = 'c3'`))).rows[0].data;
    expect(hidden.insurance_carrier).toBe("Acme Mutual");
    const noIns = await submitForm(ORG_ID, "contractor-intake", { ...sample, has_insurance: false }, { clientKey: "c6", sourceHash: "ip-b", isPublic: true });
    const d2 = (await withCtx(systemCtx(ORG_ID), (db) => db.query(`SELECT data FROM form_submissions WHERE id = $1`, [noIns.submissionId]))).rows[0].data;
    expect(d2.insurance_carrier).toBeUndefined(); // hidden field dropped
    for (let i = 0; i < 10; i++) await submitForm(ORG_ID, "contractor-intake", sample, { clientKey: `rl-${i}`, sourceHash: "ip-c", isPublic: true });
    await expect(submitForm(ORG_ID, "contractor-intake", sample, { clientKey: "rl-x", sourceHash: "ip-c", isPublic: true })).rejects.toThrow(/Too many/);
  });
  it("edits create a new version without redeploying; old submissions keep their schema version; pause and rollback work", async () => {
    const t = contractorIntakeTemplate();
    const v2 = await withCtx(owner, (db) => addVersion(db, owner, formId, { ...t.form, fields: [...t.form.fields, { key: "linkedin", label: "LinkedIn URL", type: "text" }] }));
    expect(v2).toBe(2);
    const h2 = (await withCtx(owner, (db) => db.query(`SELECT definition_hash FROM capability_versions WHERE capability_id = $1 AND version = 2`, [formId]))).rows[0].definition_hash;
    await withCtx(owner, (db) => activate(db, owner, formId, 2, { access: "public", confirmHash: h2 }));
    const r = await submitForm(ORG_ID, "contractor-intake", { ...sample, linkedin: "in/chris" }, { clientKey: "v2-1", sourceHash: "ip-d", isPublic: true });
    const vers = (await withCtx(systemCtx(ORG_ID), (db) => db.query(`SELECT client_key, form_version FROM form_submissions WHERE client_key IN ('client-1', 'v2-1') ORDER BY client_key`))).rows;
    expect(vers).toEqual([{ client_key: "client-1", form_version: 1 }, { client_key: "v2-1", form_version: 2 }]);
    expect(r.submissionId).toBeTruthy();
    await withCtx(owner, (db) => setStatus(db, owner, formId, "paused"));
    await expect(submitForm(ORG_ID, "contractor-intake", sample, { clientKey: "p1", sourceHash: "ip-e", isPublic: true })).rejects.toThrow(/not accepting/);
    await withCtx(owner, (db) => setStatus(db, owner, formId, "active"));
    await withCtx(owner, (db) => rollback(db, owner, formId, 1));
    expect((await withCtx(owner, (db) => db.query(`SELECT current_version FROM capabilities WHERE id = $1`, [formId]))).rows[0].current_version).toBe(1);
    expect((await withCtx(owner, (db) => db.query(`SELECT count(*)::int n FROM capability_versions WHERE capability_id = $1`, [formId]))).rows[0].n).toBe(2);
  });
  it("workflow definitions cannot reach another company's email account", async () => {
    const acct = (await withCtx(systemCtx(ORG_ID), (db) => db.query(`INSERT INTO integration_accounts(org_id, scope, provider, label, status, capabilities, created_by) VALUES ($1,'company:atlas-insurance','google','Ins','healthy',ARRAY['gmail.draft'],'t') RETURNING id`, [ORG_ID]))).rows[0].id;
    const t = contractorIntakeTemplate();
    const wf = { ...t.workflow, steps: [{ type: "draft_email", toField: "email", subject: "x", body: "y", accountId: acct }] };
    await expect(withCtx(owner, (db) => createCapability(db, owner, { scope, kind: "workflow", name: "x", slug: "x-wf", definition: wf }))).rejects.toBeInstanceOf(ForbiddenError);
  });
});

describe("Build Studio code path (scenarios 3 & 5)", () => {
  it("reports an exact blocker when repository access is missing; non-engineering users cannot create changes", async () => {
    delete process.env.GITHUB_TOKEN;
    const id = await withCtx(owner, (db) => createChangeRequest(db, owner, { title: "Commission variance report", request: "A new coded report comparing carrier statements to expected commissions" }));
    expect((await withCtx(owner, (db) => startDevelopment(db, owner, id))).status).toBe("blocked");
    const ins = await makeUser("ins@test.local", [{ scope: "company:atlas-insurance", access: "write" }]);
    await expect(withCtx(ins, (db) => createChangeRequest(db, ins, { title: "x x x", request: "something long enough" }))).rejects.toBeInstanceOf(ForbiddenError);
  });
  it("branch + PR, independent checks, release approval bound to the commit; a moved head cannot be released", async () => {
    let head = "sha-1"; let merged = false; const conclusions = { v: "success" };
    const srv = http.createServer(async (rq, rs) => {
      const chunks: Buffer[] = []; for await (const c of rq) chunks.push(c as Buffer);
      const body = chunks.length ? JSON.parse(Buffer.concat(chunks).toString()) : {};
      const p = new URL(rq.url!, "http://x").pathname.replace("/repos/o/r", "");
      rs.setHeader("content-type", "application/json");
      if (p === "") return rs.end(JSON.stringify({ default_branch: "main" }));
      if (p === "/git/ref/heads/main") return rs.end(JSON.stringify({ object: { sha: "base" } }));
      if (p === "/git/refs" || p.startsWith("/contents/")) { rs.writeHead(201); return rs.end("{}"); }
      if (p === "/pulls" && rq.method === "POST") { rs.writeHead(201); return rs.end(JSON.stringify({ number: 7, head: { sha: head }, html_url: "https://github.test/pr/7" })); }
      if (p === "/pulls/7") return rs.end(JSON.stringify({ head: { sha: head }, merged, draft: true }));
      if (p.startsWith("/commits/")) return rs.end(JSON.stringify({ check_runs: [{ name: "CI", status: "completed", conclusion: conclusions.v }] }));
      if (p === "/pulls/7/merge") { if (body.sha !== head) { rs.writeHead(409); return rs.end(JSON.stringify({ message: "Head branch was modified" })); } merged = true; return rs.end(JSON.stringify({ merged: true })); }
      rs.writeHead(404); rs.end("{}");
    });
    await new Promise<void>((r) => srv.listen(0, "127.0.0.1", r));
    process.env.GITHUB_TOKEN = "ghp_test"; process.env.GITHUB_REPO = "o/r"; process.env.GITHUB_API_BASE = `http://127.0.0.1:${(srv.address() as AddressInfo).port}`;
    const id = await withCtx(owner, (db) => createChangeRequest(db, owner, { title: "Variance report", request: "New coded report for commission variance" }));
    expect((await withCtx(owner, (db) => startDevelopment(db, owner, id))).status).toBe("in_development");
    expect((await withCtx(owner, (db) => refreshChecks(db, owner, id))).status).toBe("qa_passed");
    const rel = await withCtx(owner, (db) => requestRelease(db, owner, id));
    head = "sha-2"; // someone pushed after approval was requested
    await expect(withCtx(owner, (db) => approveRelease(db, owner, id, rel.hash))).rejects.toBeInstanceOf(ConflictError);
    expect(merged).toBe(false);
    expect((await withCtx(owner, (db) => refreshChecks(db, owner, id))).status).toBe("qa_passed");
    const rel2 = await withCtx(owner, (db) => requestRelease(db, owner, id));
    await expect(withCtx(owner, (db) => approveRelease(db, owner, id, rel.hash))).rejects.toThrow(/does not match/);
    await withCtx(owner, (db) => approveRelease(db, owner, id, rel2.hash));
    expect(merged).toBe(true);
    srv.close();
    delete process.env.GITHUB_TOKEN;
  });
});
