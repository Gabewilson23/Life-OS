import { describe, expect, it } from "vitest";
import { assertTransition, canRetry, canTransition } from "@/lib/runs/state-machine";
import { hashPassword, verifyPassword, passwordProblems } from "@/lib/server/auth/password";
import { localDate } from "@/lib/time";
import { BUILDINGS, ROLES, expandRole } from "@/lib/org/definitions";
import { deskPositions } from "@/components/campus/types";

describe("run state machine", () => {
  it("allows the documented happy path", () => {
    expect(canTransition("proposed", "queued")).toBe(true);
    expect(canTransition("queued", "running")).toBe(true);
    expect(canTransition("running", "waiting_approval")).toBe(true);
    expect(canTransition("waiting_approval", "queued")).toBe(true);
    expect(canTransition("running", "succeeded")).toBe(true);
  });
  it("rejects illegal transitions and terminal exits", () => {
    expect(() => assertTransition("succeeded", "running")).toThrow();
    expect(() => assertTransition("proposed", "running")).toThrow(); // must be queued first
    expect(canTransition("cancelled", "queued")).toBe(false);
  });
  it("never retries an uncertain external outcome", () => {
    expect(canRetry({ state: "failed", attempts: 1, max_attempts: 3, outcome_certainty: "uncertain" })).toBe(false);
    expect(canRetry({ state: "failed", attempts: 1, max_attempts: 3, outcome_certainty: "confirmed" })).toBe(true);
    expect(canRetry({ state: "failed", attempts: 3, max_attempts: 3, outcome_certainty: "confirmed" })).toBe(false);
  });
});

describe("password hashing", () => {
  it("verifies correct and rejects wrong passwords", async () => {
    const h = await hashPassword("correct horse battery staple");
    expect(h.startsWith("scrypt$")).toBe(true);
    expect(await verifyPassword("correct horse battery staple", h)).toBe(true);
    expect(await verifyPassword("wrong", h)).toBe(false);
    expect(await verifyPassword("x", "garbage")).toBe(false);
    expect(passwordProblems("short")).not.toBeNull();
  });
});

describe("timezone dates", () => {
  it("computes America/New_York local dates across DST boundaries", () => {
    // 2026-11-01 06:30Z = 01:30 EST (after fall-back at 06:00Z); 2026-11-01 03:30Z = 23:30 EDT Oct 31
    expect(localDate("America/New_York", new Date("2026-11-01T03:30:00Z"))).toBe("2026-10-31");
    expect(localDate("America/New_York", new Date("2026-11-01T06:30:00Z"))).toBe("2026-11-01");
    // spring forward 2026-03-08 07:00Z
    expect(localDate("America/New_York", new Date("2026-03-08T04:59:00Z"))).toBe("2026-03-07");
    expect(localDate("America/New_York", new Date("2026-03-08T05:00:00Z"))).toBe("2026-03-08");
  });
});

describe("organization design", () => {
  it("defines exactly 52 roles in 11 buildings with the specified distribution", () => {
    expect(ROLES).toHaveLength(52);
    expect(BUILDINGS).toHaveLength(11);
    expect(new Set(ROLES.map((r) => r.id)).size).toBe(52);
    expect(ROLES.map((r) => r.n).sort((a, b) => a - b)).toEqual(Array.from({ length: 52 }, (_, i) => i + 1));
    const count = (slug: string) => ROLES.filter((r) => r.building === slug).length;
    expect([count("headquarters"), count("atlas-insurance"), count("atlas-consulting"), count("capital-house"), count("human-performance"), count("relationship-house"),
      count("executive-services"), count("ventures-lab"), count("communications-studio"), count("learning-institute"), count("infrastructure")]).toEqual([4, 9, 9, 4, 4, 3, 3, 3, 3, 2, 8]);
  });
  it("every role references a real building, department and earlier manager", () => {
    for (const r of ROLES) {
      const b = BUILDINGS.find((x) => x.slug === r.building);
      expect(b, r.id).toBeTruthy();
      expect(b!.departments.some((d) => d.slug === r.dept), r.id).toBe(true);
      if (r.manager) expect(ROLES.find((m) => m.id === r.manager)!.n).toBeLessThan(r.n);
    }
  });
  it("expanded roles carry every required configuration field and default to prepare-only", () => {
    for (const r of ROLES.map((x) => expandRole(x, "m"))) {
      for (const k of ["input_schema", "output_schema", "evidence_rules", "escalation_policy", "triggers", "model_config", "budget", "success_criteria"] as const) expect(r[k], `${r.id}.${k}`).toBeTruthy();
      expect(r.escalation_policy.default_external_writes).toBe("prepare");
      expect(r.tools.length).toBeGreaterThan(0);
      expect(r.scopes.length).toBeGreaterThan(0);
    }
  });
  it("engineering roles have no access to personal or company data scopes", () => {
    for (const r of ROLES.filter((x) => x.dept === "product-engineering")) expect(r.scopes).toEqual(["engineering"]);
    for (const r of ROLES.filter((x) => x.dept !== "product-engineering")) expect(r.tools.some((t) => t.startsWith("sandbox."))).toBe(false);
  });
  it("lays out desks inside the building footprint", () => {
    for (const [x, z] of deskPositions(9, 7, 6)) { expect(Math.abs(x)).toBeLessThan(3.5); expect(Math.abs(z)).toBeLessThan(3); }
  });
});
