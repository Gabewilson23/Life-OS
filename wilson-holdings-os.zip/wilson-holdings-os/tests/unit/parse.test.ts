import { describe, expect, it } from "vitest";
import { parseCsv, parseDate, parseMoney, suggestMapping } from "@/lib/company/parse";
import { datasetById } from "@/lib/company/datasets";

describe("import parsing", () => {
  it("parses money to exact integer cents and refuses silent rounding", () => {
    expect(parseMoney("$1,200.00")).toBe(120000);
    expect(parseMoney("800.5")).toBe(80050);
    expect(parseMoney("(750.00)")).toBe(-75000);
    expect(parseMoney("-0.01")).toBe(-1);
    expect(parseMoney("0.1") + parseMoney("0.2")).toBe(30); // no float drift
    expect(() => parseMoney("12.345")).toThrow(/more than 2 decimal/);
    expect(() => parseMoney("abc")).toThrow();
  });
  it("parses dates strictly", () => {
    expect(parseDate("9/1/2026")).toBe("2026-09-01");
    expect(parseDate("2026-02-28")).toBe("2026-02-28");
    expect(parseDate("46000")).toBe("2025-12-09");
    expect(() => parseDate("2026-02-30")).toThrow(/valid calendar date/);
    expect(() => parseDate("13/1/2026")).toThrow();
  });
  it("handles quoted CSV fields and detects unterminated quotes", () => {
    expect(parseCsv('a,b\r\n"x, y","he said ""hi"""\n')).toEqual([["a", "b"], ["x, y", 'he said "hi"']]);
    expect(() => parseCsv('a\n"oops')).toThrow(/unterminated/);
  });
  it("suggests column mappings from synonyms", () => {
    const m = suggestMapping(datasetById("ins_policies")!, ["Policy Number", "AP", "Submit Date", "Status", "Mystery"]);
    expect(m).toEqual({ "Policy Number": "__key", AP: "annual_premium", "Submit Date": "submitted_at", Status: "status" });
  });
});
