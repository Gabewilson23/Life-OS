import { describe, expect, it } from "vitest";
import { afterQuietHours, dueWindow, nextRun, zonedToUtc } from "@/lib/schedule";

const NY = "America/New_York";
describe("DST-safe scheduling", () => {
  it("maps 7:30 AM New York to the right UTC instant across both DST transitions", () => {
    expect(zonedToUtc("2026-10-31", "07:30", NY).toISOString()).toBe("2026-10-31T11:30:00.000Z"); // EDT
    expect(zonedToUtc("2026-11-01", "07:30", NY).toISOString()).toBe("2026-11-01T12:30:00.000Z"); // EST (fall-back day)
    expect(zonedToUtc("2026-03-07", "07:30", NY).toISOString()).toBe("2026-03-07T12:30:00.000Z");
    expect(zonedToUtc("2026-03-08", "07:30", NY).toISOString()).toBe("2026-03-08T11:30:00.000Z"); // spring-forward day
  });
  it("handles nonexistent and ambiguous local times deterministically", () => {
    expect(zonedToUtc("2026-03-08", "02:30", NY).toISOString()).toBe("2026-03-08T07:30:00.000Z"); // gap → 03:30 EDT
    expect(zonedToUtc("2026-11-01", "01:30", NY).toISOString()).toBe("2026-11-01T05:30:00.000Z"); // first 01:30 (EDT)
  });
  it("yields one window per day; not before the time; not after the catch-up limit", () => {
    const rule = { freq: "daily" as const, time: "07:30" };
    expect(dueWindow(rule, NY, new Date("2026-11-01T12:29:00Z"), 6)).toBeNull();
    expect(dueWindow(rule, NY, new Date("2026-11-01T12:30:00Z"))?.windowKey).toBe("2026-11-01");
    expect(dueWindow(rule, NY, new Date("2026-11-01T18:00:00Z"))?.windowKey).toBe("2026-11-01");
    expect(dueWindow(rule, NY, new Date("2026-11-01T19:00:00Z"))).toBeNull();
  });
  it("weekly Friday 3 PM and monthly reports", () => {
    const fri = { freq: "weekly" as const, weekday: 5, time: "15:00" };
    expect(dueWindow(fri, NY, new Date("2026-11-13T20:05:00Z"))?.windowKey).toBe("2026-11-13");
    expect(dueWindow(fri, NY, new Date("2026-11-12T20:05:00Z"))).toBeNull();
    expect(nextRun(fri, NY, new Date("2026-11-12T20:05:00Z"))?.toISOString()).toBe("2026-11-13T20:00:00.000Z");
    const mon = { freq: "monthly" as const, day: 1, time: "08:00" };
    expect(dueWindow(mon, NY, new Date("2026-12-01T14:00:00Z"))?.windowKey).toBe("2026-12");
  });
  it("defers routine notifications until quiet hours end", () => {
    const q = { start: "21:00", end: "07:00" };
    expect(afterQuietHours(new Date("2026-11-13T03:00:00Z"), NY, q).toISOString()).toBe("2026-11-13T12:00:00.000Z"); // 22:00 → 07:00 next day
    expect(afterQuietHours(new Date("2026-11-13T16:00:00Z"), NY, q).toISOString()).toBe("2026-11-13T16:00:00.000Z");
  });
});
