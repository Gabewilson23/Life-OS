import { defineConfig } from "vitest/config";
import path from "node:path";
export default defineConfig({
  resolve: { alias: { "@": path.resolve(import.meta.dirname, "src") } },
  test: {
    include: ["tests/unit/**/*.test.ts", "tests/integration/**/*.test.ts"],
    fileParallelism: false,
    testTimeout: 20000,
    env: { DATABASE_URL: process.env.TEST_DATABASE_URL ?? "postgres://wh:wh_local_dev@localhost:5432/wilson_holdings_test", SESSION_SECRET: "test-secret-test-secret-test-secret-00", APP_ENV: "test", APP_URL: "http://localhost:3000", GOOGLE_CLIENT_ID: "test-client", GOOGLE_CLIENT_SECRET: "test-secret", TOKEN_ENCRYPTION_KEY: "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef", CRON_SECRET: "test-cron-secret", AGENT_CONCURRENCY: "3" },
  },
});
